import fs from 'fs'
import path from 'path'
import net from 'net'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/25DpXkaVG2cDJ5oFqh7vhXERPaev/index.html?babelChannel=ttt2&visitScene=233'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '补贴超市天天领京豆', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._drawn = 0
        this._skip = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    // app 内 RPC cookie 通道(全量 19 字段含设备指纹, pt_key 为 app 自动续期版)
    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpcCk = await this._rpcCk()
        if (rpcCk && rpcCk.includes('pt_key=')) {
            const pinOf = ck => { try { let m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            let want = pinOf(base)
            const got = pinOf(rpcCk)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpcCk
        }
        return base
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // b63ff 域 superSubsidyScene: assignmentId 稳定不重签, 旧 1426 = 缺 ext/浏览序错; 浏览型 1→0 翻转 flag 后刮 100
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) { p.log('no signer'); return null }
                const ck = await this._ckFull(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'plus_business', client: 'android', clientVersion: '15.10.50'}, appId: 'b63ff', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('loginType', '2'); f.append('loginWQBiz', ''); f.append('scval', 'test01')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn + '&scene=' + (fn === 'bff_rightsCenter_jdInteractTask' ? 'jdInteractTask' : 'commonDoInteractiveAssignment'), 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(3000 * k)
        }
        return null
    }

    async cards(p, user) {
        const r = await this.wg(p, user, 'bff_rightsCenter_jdInteractTask', {taskType: 'beanDailySign_newBeanTask', popFlag: '0', scene: 'jdInteractTask', commonScene: 'superSubsidyScene', needBeanSignStatus: '1'}, 2)
        return (((r || {}).rs || {}).beanTask || {}).taskList || []
    }

    _mk(t, at, code) {
        const items = (t.ext || {}).shoppingActivity || []
        const b = {scene: 'commonDoInteractiveAssignment', commonScene: 'superSubsidyScene', activityCode: code || 'newBeanTask', businessScenario: 'jingDouCenter', assignmentId: t.encryptAssignmentId, actionType: String(at), itemId: (items[0] || {}).advId || ''}
        const jump = (items[0] || {}).url || ''
        if (jump) b.ext = JSON.stringify({jumpUrl: jump})
        return b
    }

    // 刮卡(实弹验证): 0=发奖, 1712001/1711001=已刮已签跳过, 1714002=限流等15s
    async scrape(p, user, t, code) {
        for (let k = 0; k < 3; k++) {
            const r = await this.wg(p, user, 'bff_rightsCenter_interaction', this._mk(t, 100, code), 1)
            const c = String((r || {}).code || '')
            if (c === '0' || c === '1711000') {
                this._drawn++
                let prize = ''
                try { prize = JSON.stringify((r || {}).rs || {}).slice(0, 80) } catch (e) {}
                p.log('  刮中:', t.assignmentName, prize)
                return true
            }
            if (c === '1712001' || c === '1711001') { this._skip++; return false }
            if (c === '1714002') {
                p.log('  限流, 等15s重试:', t.assignmentName)
                await this.wait(15000)
                continue
            }
            p.log('  刮异:', t.assignmentName, c, String((r || {}).msg || '').slice(0, 40))
            this._fails++
            return false
        }
        this._skip++
        p.log('  限流放弃:', t.assignmentName)
        return false
    }

    // 浏览型两段式(实弹验证): actionType=1 成功码'1', actionType=0 成功码'0'; 完成后 flag 翻转可直接刮
    async doBrowse(p, user, t) {
        const items = (t.ext || {}).shoppingActivity || []
        if (!items.length) return false
        const wd = (t.ext || {}).waitDuration || 5
        const r1 = await this.wg(p, user, 'bff_rightsCenter_interaction', this._mk(t, 1), 1)
        const c1 = String((r1 || {}).code || '')
        if (c1 !== '1' && c1 !== '0' && c1 !== '1711000') {
            p.log('  领取拒:', t.assignmentName, c1)
            this._fails++
            return false
        }
        await this.wait((wd + 6) * 1000)
        const r2 = await this.wg(p, user, 'bff_rightsCenter_interaction', this._mk(t, 0), 1)
        const c2 = String((r2 || {}).code || '')
        if (c2 !== '0' && c2 !== '1711000') {
            p.log('  完成拒:', t.assignmentName, c2)
            this._fails++
            return false
        }
        p.log('  浏览完成:', t.assignmentName)
        return true
    }

    async main(p) {
        const user = p.data.user
        for (let round = 1; round <= 3; round++) {
            const tasks = await this.cards(p, user)
            if (!tasks.length) { p.log('任务池空'); return }
            let acted = 0
            for (const t of tasks) {
                const nm = t.assignmentName || '?'
                const cnt = t.completionCnt || 0
                const lim = t.assignmentTimesLimit || 1
                if (t.completionFlag && cnt >= lim) {
                    const code = t.assignmentType === 5 ? 'beanDailySign' : 'newBeanTask'
                    if (await this.scrape(p, user, t, code)) acted++
                    await this.wait(8000)
                } else if (t.assignmentType === 1 && !t.completionFlag) {
                    p.log('做:', nm, cnt + '/' + lim)
                    if (await this.doBrowse(p, user, t)) {
                        acted++
                        await this.wait(6000)
                    } else {
                        await this.wait(3000)
                    }
                }
            }
            if (!acted) break
        }
        const fin = await this.cards(p, user)
        let pend = 0
        for (const t of fin) {
            if (!t.completionFlag || (t.completionCnt || 0) < (t.assignmentTimesLimit || 1)) { p.log('未完成:', t.assignmentName, (t.completionCnt || 0) + '/' + (t.assignmentTimesLimit || 1)); pend++ }
        }
        p.log('刮中', this._drawn, '张, 已刮跳过', this._skip, ', 未完成', pend, '项')
        p.info.work = this._fails === 0
    }
}
