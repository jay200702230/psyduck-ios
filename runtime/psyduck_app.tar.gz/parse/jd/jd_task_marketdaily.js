import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/3mRMAxEdkCj3zBRPRP9Y4DMKLqu/index.html'
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

// 京东健康 market_daily 任务 (2026-10-23 抓包实锤: appid=jdh-middle, 域 4b818)
const EID = 'AEJINAIPWUEFEJ7BRW25JIDK447LPR3RIEQYSJT6RSIZF4W2FRZY4HQLDLZ6ETXOCU7AKOILZ6577SK6CKIUE6QHPE'
const DEV_BODY = {
    platform: 1, osVersion: '13', screen: '360*800', eid: EID,
    client: 'android', clientVersion: '15.10.50', model: 'IN2010', brand: 'OnePlus',
    uuid: '3303461326131633-2313731633939346', networkType: 'wifi'
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东健康市场任务', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) return null
                const ck = this._ckForUser(user)
                if (!ck) return null
                if (!globalThis.__mdWarm) {
                    try { this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'jdh-middle', client: 'android', clientVersion: '15.10.50'}, appId: '4b818'}) } catch (e) {}
                    await this.wait(3500)
                    globalThis.__mdWarm = true
                }
                const signed = this._wgSigner.sign({
                    functionId: fn, body: bodyObj, ck,
                    base: {appid: 'jdh-middle', client: 'android', clientVersion: '15.10.50'},
                    appId: '4b818'
                })
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('platform', '3')
                f.append('loginType', '2')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    const rq = https.request({
                        hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                        headers: {
                            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'content-length': Buffer.byteLength(post), cookie: ck,
                            origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA
                        }
                    }, rs => {
                        let d = ''
                        rs.on('data', c => d += c)
                        rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
                    })
                    rq.on('error', () => resolve(null))
                    rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
                    rq.write(post); rq.end()
                })
                if (r) return r
                p.log(`${fn} 空响应, 第${k}次...`)
            } catch (e) {
                p.log(`${fn} 异常: ${String(e && e.message || e).slice(0, 120)}`)
            }
            await this.wait(3000 * k)
        }
        return null
    }

    async rawGet(p, user, url, referer) {
        if (!url) return
        try {
            for (let hop = 0; hop < 2 && url; hop++) {
                const out = await new Promise(resolve => {
                    const u = new URL(url)
                    const rq = https.request({
                        hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
                        headers: {cookie: this._ckForUser(user), 'user-agent': UA, referer: referer || W_PAGE, accept: 'text/html,*/*'}
                    }, rs => {
                        rs.resume()
                        rs.on('end', () => resolve({status: rs.statusCode, loc: rs.headers.location || ''}))
                    })
                    rq.on('error', () => resolve({status: 0, loc: ''}))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve({status: 0, loc: ''}) })
                    rq.end()
                })
                if (out.status === 302 && out.loc) { url = new URL(out.loc, url).href; referer = url } else { url = '' }
            }
        } catch (e) {}
    }

    async main(p) {
        let user = p.data.user
        let list = await this.wg(p, user, 'market_daily_pageIndex', Object.assign({taskVersion: 1, channel: 'daily'}, DEV_BODY), 2)
        if (!list) { p.log('pageIndex 空响应'); return }
        // 结构探针
        p.log('pageIndex:', JSON.stringify(list).slice(0, 700))
        let tasks = (list.data && list.data.result && (list.data.result.assignmentList || list.data.result.taskList)) || (list.data && list.data.assignmentList) || []
        if (!tasks.length) { p.log('任务池空或结构变化'); return }
        let done = 0
        for (const t of tasks) {
            if (t.completionFlag || t.finished || t.timeStatus === 3) continue
            const aid = t.encryptAssignmentId || ''
            const atype = t.assignmentType !== undefined ? t.assignmentType : 0
            const sub = (t.assignmentSubList || t.subTaskList || [])[0] || {}
            const jumpUrl = sub.url || sub.jumpUrl || t.url || t.forwardUrl || ''
            if (!aid) { p.log('跳过(无id):', t.assignmentName); continue }
            p.log('做:', t.assignmentName || aid)
            let r1 = await this.wg(p, user, 'market_daily_doCompleteTask', Object.assign({assignmentType: atype, encryptAssignmentId: aid, actionType: 1, channel: 'daily'}, DEV_BODY), 1)
            p.log('  受理:', JSON.stringify(r1).slice(0, 120))
            if (jumpUrl) await this.rawGet(p, user, jumpUrl, W_PAGE)
            await this.wait(((+t.waitDuration || 5) + 2) * 1000)
            let r0 = await this.wg(p, user, 'market_daily_doCompleteTask', Object.assign({assignmentType: atype, encryptAssignmentId: aid, actionType: 0, channel: 'daily'}, DEV_BODY), 1)
            p.log('  完成:', JSON.stringify(r0).slice(0, 150))
            done++
            p.info.work = true
            await this.wait(6000)
        }
        p.log(`本轮完成 ${done} 个`)
    }
}
