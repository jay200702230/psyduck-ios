import {Template} from '../../template.js'
import {Panel} from "../../util/panel.js";
import net from 'net'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {execFile} from 'child_process'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东Cookie过期检测',
            userData: true,
            validCookie: true,
            interval: 2000,
            crontab: 24,
            prompt: {
                change: `expired|all  #expired:只转换过期账户, all:即使账号没过期也强制转换`,
            },
            readme: [
                "如需wskey转换cookie,请将wskey存储在jdUser.ini用户节点里面,或者使用环境变量 JD_WSCK/JdWskey",
                "优先读取ini文件,再读环境变量. 如果只想使用环境变量,请不要在ini文件里添加wskey"
            ]
        }
    }

    async prepare() {
        if (this.haskey(this.profile, 'change', 'expired')) {
            let expired = await this.getExpire()
            if (expired) {
                this.shareCode({
                    change: 1,
                    task: expired.join("|")
                })
            }
            else {
                this.log("没有过期账户,跳过运行")
                this.jump = 1
            }
        }
        let wsck = process.env.JD_WSCK || process.env.JdWskey
        this.wsck = {}
        this.jsck = {}
        if (wsck) {
            for (let i of wsck.split("&")) {
                try {
                    let pin = this.match(/pin\s*=\s*([^;]+)/, i)
                    let wskey = this.match(/wskey\s*=\s*([^;]+)/, i)
                    if (wskey) {
                        this.wsck[decodeURIComponent(pin)] = wskey
                    }
                    let jskey = this.match(/jskey\s*=\s*([^;]+)/, i)
                    if (jskey) {
                        this.jsck[decodeURIComponent(pin)] = jskey
                    }
                } catch (e) {
                }
            }
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let name = p.info.name
        var expire = 0
        if (this.haskey(this.profile, 'change', 'all')) {
            expire = 2
        }
        else {
            let s = await this.autoCurl({
                    'url': `https://plogin.m.jd.com/cgi-bin/ml/islogin`,
                    user,
                    algo: {
                        shell: 1,
                    },
                }
            )
            if (this.haskey(s, 'islogin', '1')) {
                p.log("账户还未过期")
                this.valid(user, true)
            }
            else if (this.haskey(s, 'islogin', '0')) {
                p.log("账户过期")
                expire = 1
            }
            else {
                p.err("没有获取到数据")
            }
        }
        if (expire) {
            let userData = this.userData[user] || {}
            // ---- 主路: a2(wskey) -> genToken 换 pt_key (A2 纸面寿命3年, 不依赖 App 会话在线状态) ----
            let ptCookie = await this.tryGenPt(userData.wskey || this.wsck[user], user, p)
            let appAccounts = -1
            if (!ptCookie) {
                // ---- 换取失败: 重新从京东App解密最新A2, 有账号则再试 ----
                let a2out = ''
                try { a2out = (await this.a2Local()).out } catch (e) {}
                const am = a2out.match(/已写入\s*(\d+)\s*个账号/)
                appAccounts = am ? Number(am[1]) : -1
                const wk2 = this.fileWskey()
                if (wk2) {
                    p.log('已重新获取京东App内A2, 再次尝试换取pt_key')
                    ptCookie = await this.tryGenPt(wk2, user, p)
                }
            }
            if (ptCookie) {
                this.dict[user] = {cookie: ptCookie}
                this.valid(user, true)
            }
            else {
                // ---- RPC 桥兜底: CookieManager 现值 (App 会话恢复期可用) ----
                let rpc = null
                try { rpc = await this.rpcCookie() } catch (e) {}
                if (rpc && rpc.ok && rpc.cookie && rpc.cookie.includes('pt_key=') && rpc.cookie.includes('pt_pin=')) {
                    this.dict[user] = {cookie: rpc.cookie}
                    p.log(`openKey已从京东App CookieManager 刷新 (${rpc.cookie.length}字节)`)
                    this.valid(user, true)
                }
                else if (appAccounts === 0) {
                    p.log('⚠ 京东App未登录: 请打开京东App完成登录后再跑')
                    this.msg(`${name} 京东App未登录, 无法换取pt_key`)
                }
                else {
                    p.msg('账号过期了呀🐶 (A2换取失败且App无可用兜底)')
                }
            }
        }
    }

    async done() {
        try {
            if (Object.keys(this.dict).length) {
                let panel = new Panel(this.dict)
                await panel.send()
            }
        } catch (e) {
        }
    }

    // 重新从京东App解密最新A2 (a2local.mjs 自行写回 config/jdUser.ini)
    a2Local() {
        const jd = path.dirname(fileURLToPath(import.meta.url))
        return new Promise(resolve => {
            const env = {...process.env, LD_LIBRARY_PATH: path.join(jd, '../../../lib')}
            execFile(path.join(jd, '../../../node'),
                [path.join(jd, '../../../a2local.mjs'), '/data/data/com.psyduck.jdtask/files/jd_users.xml', path.join(jd, '../..')],
                {timeout: 20000, env}, (err, stdout, stderr) => {
                resolve({err, out: String(stdout || '') + String(stderr || '')})
            })
        })
    }

    // 从 config/jdUser.ini 读最新wskey (a2local 刚写入)
    fileWskey() {
        try {
            const jd = path.dirname(fileURLToPath(import.meta.url))
            const txt = fs.readFileSync(path.join(jd, '../../config/jdUser.ini'), 'utf8')
            const m = txt.match(/wskey=([A-Za-z0-9_]+)/)
            return m ? m[1] : ''
        } catch (e) { return '' }
    }

    // a2(wskey) -> genToken -> appjmp -> pt_key(openKey)
    async tryGenPt(wskey, user, p) {
        if (!wskey) return null
        for (let i = 0; i < 2; i++) {
            var genToken = await this.autoCurl({
                    'url': `https://api.m.jd.com/client.action?functionId=genToken`,
                    'form': `functionId=genToken&body=%7B%22to%22%3A%223.cn%5C%2F10-${this.rand(100000, 999999)}%22%2C%22sceneid%22%3A%2225%22%2C%22action%22%3A%22to%22%7D&uuid=8885e2e6fc106910&client=apple&clientVersion=15.0.15&st=1739755840783&sv=111&sign=91359115eb2809fd16036088787dee1d`,
                    cookie: `wskey=${wskey};pin=${encodeURIComponent(user)};`,
                    algo: i == 0 ? {app: true} : {app: true, shell: false},
                    response: 'all',
                    headers: {
                        'x-rp-client': 'ios_4.0.0',
                        'x-httpex-retry': "1",
                        'jd-hybrid-refer': 'Home_Main',
                        'x-referer-package': 'com.360buy.jdmobile'
                    }
                }
            )
            let tokenKey = this.haskey(genToken, 'content.tokenKey') || ''
            p.log(`genToken(${i == 0 ? 'app' : 'app-shell'}):`, tokenKey ? tokenKey.slice(0, 8) + '***' : String(this.haskey(genToken, 'echo') || this.haskey(genToken, 'errMsg') || '无tokenKey').slice(0, 60))
            if (tokenKey && tokenKey.slice(0, 2) == 'AA') {
                let y = await this.autoCurl({
                        'url': `https://un.m.jd.com/cgi-bin/app/appjmp`,
                        form: `tokenKey=${tokenKey}&&lbs={"cityId":"","districtId":"","provinceId":"","districtName":"","lng":"117.543210,"provinceName":"","lat":"23.987654","cityName":""}&to=${encodeURIComponent("https://bean.m.jd.com/beanDetail/index.action")}`,
                        response: "all",
                        maxRedirects: 0,
                        scheme: 'http',
                        algo: {
                            shell: false
                        }
                    }
                )
                if (this.haskey(y, 'cookie') && y.cookie.includes('pt_key=')) {
                    p.log(`openKey换取成功 (${String(y.cookie).length}字节)`)
                    return y.cookie
                }
                p.log('appjmp未返回pt_key')
                return null
            }
        }
        return null
    }

    rpcCookie() {
        return new Promise(resolve => {
            const s = net.connect(28900, '127.0.0.1', () => s.write(JSON.stringify({cmd: 'cookie', url: 'https://www.jd.com'}) + '\n'))
            let buf = ''
            s.on('data', d => {
                buf += d.toString()
                if (buf.includes('\n')) {
                    try { s.end() } catch (e) {}
                    try { resolve(JSON.parse(buf.trim())) } catch (e) { resolve({ok: false}) }
                }
            })
            s.on('error', () => resolve({ok: false}))
            setTimeout(() => { try { s.destroy() } catch (e) {}; resolve({ok: false}) }, 12000)
        })
    }
}

