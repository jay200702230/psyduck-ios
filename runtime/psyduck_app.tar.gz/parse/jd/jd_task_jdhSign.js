import {execFile} from 'child_process'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

// 京东健康福利中心签到(开锦囊) 纯协议: laputa.jd.com/onlineDoctorWel 福利页
// 链路: getKitTask(h5st,jdh-middle) 取动态encodeId -> doTaskGw(h5st,laputa) 开锦囊 -> queryAwardGw 查京豆余额
// 每日 5:00-8:00 开锦囊奖励更多; bizCode 105 = 今日已开/份额为0, 跳过即可
const KIT_APPKEY = '250141600001'
const KIT_ACTIVITY = '34703'
const KIT_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const KIT_UUID = '122270672.1792129479730559203534.1792129479.1792129479.1792139686.2'
const KIT_CURL = '/data/user/0/com.psyduck.jdtask/files/rt/bin/psyduck-curl'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: "京东健康签到",
            crontab: 3,
            libressl: true
        }
        this._ckCache = ''
        this._ckAt = 0
    }

    async prepare() {
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.jdhCk()
    }
    jdhCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const ck = mainCk || any
            if (ck) { this._ckCache = ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache
    }

    api(fid, form) {
        return new Promise(resolve => {
            execFile(KIT_CURL, ['-sk', '-X', 'POST', `https://api.m.jd.com/api?functionId=${fid}`,
                '-H', 'Content-Type: application/x-www-form-urlencoded',
                '-H', `User-Agent: ${KIT_UA}`,
                '-H', 'Referer: https://laputa.jd.com/',
                '-H', `Cookie: ${this.jdhCk()}`,
                '--data', form.toString(), '--max-time', '20'],
                {timeout: 25000, maxBuffer: 4 * 1024 * 1024},
                (err, stdout) => resolve(err ? {raw: '', err: String(err.message).slice(0, 80)} : {raw: String(stdout || '')}))
        })
    }

    async signed(fid, body, appid) {
        if (!this._signer) this._signer = await import('./jd_signer_node.mjs')
        const signed = this._signer.sign({functionId: fid, body, ck: this.jdhCk(), base: {appid, client: 'wh5'}})
        const form = new URLSearchParams()
        for (const k in signed) form.append(k, String(signed[k]))
        form.append('client', 'wh5')
        form.append('uuid', KIT_UUID)
        return form
    }

    stripTag(s) {
        return String(s || '').replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()
    }

    async main(p) {
        let user = p.data.user
        const ck = this._ckForUser(user)
        if (!ck) { p.err("cookie/jd.ini 无 main 账号 cookie"); return }

        // 1) getKitTask: 活动状态 + 动态 encodeId
        let kit = null
        try {
            const r = await this.api('jdh_bm_getKitTask', await this.signed('jdh_bm_getKitTask',
                {m_patch_appKey: KIT_APPKEY, groupCode: 'openkits', channel: 'jdhapp'}, 'jdh-middle'))
            kit = r.raw ? JSON.parse(r.raw) : null
        } catch (e) { }
        const res = kit && kit.result
        if (!res || !res.encodeId) { p.err("getKitTask 失败: " + String(kit ? kit.echo || kit.code : '空响应').slice(0, 60)); return }
        const streak = (this.stripTag(res.kitCenterRightLabel).match(/已连签\s*(\d+)/) || [0, 0])[1]
        const addLabel = this.stripTag(res.kitCenterLabel).match(/可得\s*\+?(\d+)/)
        const todayAdd = addLabel ? addLabel[1] : (res.addNum || 0)
        p.log(`连签${streak}天 今日可得+${todayAdd} status=${res.status}`)

        // 2) doTaskGw: 开锦囊(签到)
        const doBody = {appKey: KIT_APPKEY, channel: 'jdhapp', encodeId: res.encodeId, infoId: 'kits', platform: 3}
        let done = null
        try {
            const r = await this.api('jdh_msoa_doTaskGw', await this.signed('jdh_msoa_doTaskGw', doBody, 'laputa'))
            const j = r.raw ? JSON.parse(r.raw) : null
            done = j && j.result && j.result.result ? j.result.result : null
        } catch (e) { }
        if (!done) { p.err("doTaskGw 空响应"); return }
        if (done.bizCode && done.bizCode !== 0) {
            p.log(`开锦囊未成: biz${done.bizCode} ${String(done.msg || '').slice(0, 30)} (已开/窗口外)`)
        } else {
            const award = done.result || done
            p.log(`开锦囊成功 +${(award && (award.num || award.addNum)) || '?'}京豆`)
            // 3) sendAwardGw 兜底领奖(失败不影响)
            try { await this.api('jdh_msoa_sendAwardGw', await this.signed('jdh_msoa_sendAwardGw', doBody, 'laputa')) } catch (e) { }
        }

        // 4) 余额复核
        try {
            const r = await this.api('jdh_msoa_queryAwardGw', await this.signed('jdh_msoa_queryAwardGw',
                {appKey: KIT_APPKEY, activityId: KIT_ACTIVITY, channel: 'jdhapp', awardType: 2}, 'laputa'))
            const j = r.raw ? JSON.parse(r.raw) : null
            if (j && j.result) p.log(`京豆余额 ${j.result.num}`)
        } catch (e) { }
    }
}
