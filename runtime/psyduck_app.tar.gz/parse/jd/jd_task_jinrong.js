import {Template} from '../../template.js'
import jsdom from "jsdom";
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    // ms.jr.jd.com 框架链路风控空响应, json 请求直连 (真机即 POST application/json, 无需 h5st)
    async jrPost(url, json, user) {
        const post = this.dumps(json)
        const u = new URL(url)
        const ck = this._ckForUser(user)
        return new Promise(resolve => {
            const rq = https.request({
                hostname: u.hostname, path: u.pathname + u.search, method: 'POST',
                headers: {
                    'content-type': 'application/json;charset=UTF-8',
                    'content-length': Buffer.byteLength(post),
                    ...(ck ? {cookie: ck} : {}),
                    origin: 'https://show.jd.com', referer: 'https://show.jd.com/',
                    'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {}
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (opts && opts.json && u.includes('ms.jr.jd.com')) return await this.jrPost(u, opts.json, opts.user)
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东金融赚京豆',
            headers: {
                referer: 'https://show.jd.com/m/RkO0AE9rKrYy6ZDd'
            },
            sync: 1,
            verify: 1,
            crontab: 3,
            prompt: {
                channelCode: '活动id'
            }
        }
    }

    async prepare() {
        let ua = this.userAgents().jd
        let resourceLoader = new jsdom.ResourceLoader({
            userAgent: ua,
            "referer": "https://iu.jr.jd.com/",
        });
        let virtualConsole = new jsdom.VirtualConsole();
        this.jsConfig = {
            "url": "https://iu.jr.jd.com/",
            "referer": "https://iu.jr.jd.com/",
            "userAgent": ua,
            runScripts: "dangerously",
            resources: resourceLoader,
            includeNodeLocations: true,
            storageQuota: 10000000,
            pretendToBeVisual: true,
            virtualConsole,
        };
        let JSDOM = jsdom.JSDOM
        let a = new JSDOM(`<body><script src="https://jrsecstatic.jdpay.com/jr-sec-dev-static/aar2.min.js"></script> <script src="https://m.jr.jd.com/common/jssdk/jrbridge/2.0.0/jrbridge.js"></script>   <script src="https://jrsecstatic.jdpay.com/jr-sec-dev-static/cryptico.min.js"></script>  </body>`, this.jsConfig)
        await this.wait(3000)
        if (a.window.AAR2) {
            a.window.AAR2.init();
            this.crypto = {
                aar: new a.window.AAR2(),
                cry: a.window.cryptico
            }
        }
        else {
            this.log("jsdom没有获取到aar2")
            this.jump = 1
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        const aar = this.crypto.aar
        let info = await this.getInfo(user, 'jsTk') || {}
        let device = {
            deviceInfo: {
                "jsToken": "",
                "fp": this.md5(new Date().getTime().toString()),
                // "sdkToken": `jdd01YG5AHZNQU4TUXDWWHFZ7G5SAAJCXWGQWUMQPTWY6BVJJMTTEDYJVZXJSSF3ZHX2UFPU26WZJWZN4GY7TS4QAKPSMUCCDJSBBUTS5AFI01234567`,
                "eid": info.eid || `FQ7Z2DTGYZSJM5FKY${this.rand(10, 99)}JLAURRHP2UZHK2ID7554EMNWWNNSK3JBCTLTR45IOP3Z5K3YJHOG${this.rand(10, 99)}SJAOB${this.rand(10, 99)}KVS3RH7G2U`,
            },
        }
        var nonce = aar.nonce()
        var signature = aar.sign(this.dumps({
            "channelCode": context.channelCode,
            PIN: user
        }), nonce)
        let mile = await this.autoCurl({
                'url': `https://ms.jr.jd.com/gw2/generic/Mission/h5/m/queryMilePost`,
                json: {
                    "reqData": {
                        "source": "mdH5Pagedeploy",
                        "token": "TVBaZRYGYS",
                        "channelCode": context.channelCode,
                        "milePostIdList": context.milePostIdList || [115],
                        "queryMissionFlag": 2,
                        "deviceInfo": device.deviceInfo
                    }
                },
                user
            }
        )
        // console.log(this.dumps(mile))
        let data = this.haskey(mile, 'resultData.data.0.missionList')
        if (!data) p.log('[queryMilePost] resp=' + this.dumps(mile).slice(0, 200))
        let status = 1
        let isDo = 0
        if (data) {
            for (let i of data) {
                if (i.status == 2) {
                    p.log("任务已完成:", i.name)
                }
                else {
                    let doLink = i.doLink
                    let pp = this.query(doLink, '&', 1)
                    if (pp.juid) {
                        p.log("正在运行:", i.name)
                        let T = aar.nonce()
                        status = 0
                        let receive = await this.autoCurl({
                                'url': `https://ms.jr.jd.com/gw/generic/mission/h5/m/receiveMission`,
                                'json': {
                                    "reqData": {
                                        "channelCode": context.channelCode,
                                        "missionId": i.missionId,
                                        "deviceInfo": device.deviceInfo,
                                        "nonce": T,
                                        "signature": aar.sign(this.dumps({
                                            channelCode: context.channelCode,
                                            PIN: user,
                                            missionId: i.missionId,
                                        }), T)
                                    }
                                },
                                user
                            }
                        )
                        await this.wait(1000)
                        let jump = await this.autoCurl({
                                'url': `https://ms.jr.jd.com/gw2/generic/mission/h5/m/getJumpInfo?juid=${pp.juid}&signature=${aar.sign(this.dumps({
                                    juid: pp.juid,
                                    PIN: user,
                                }), T)}&nonce=${T}&jrAppVersion=6.9.80&systemEnv=IOS`,
                                user
                            }
                        )
                        if (this.haskey(jump, 'resultData.success')) {
                            isDo++
                            if (i.awards[0].awardName == '京豆') {
                                p.award(i.awards[0].awardRealNum, 'bean')
                            }
                            else {
                                p.msg(`${i.awards[0].awardName}: ${i.awards[0].awardRealNum}`)
                            }
                            status = 1
                        }
                        else {
                            p.log("跳转失败...")
                            status = 0
                        }
                        await this.wait(2000)
                    }
                }
            }
        }
        else {
            status = 0
            p.err("没有获取到任务数据...")
        }
        // let bvd = await this.autoCurl({
        //         'url': `https://ms.jr.jd.com/gw/generic/aladdin/h5/m/buildVisualizeData`,
        //         json: {
        //             reqData: {"buildCodes": ["common"], "engineType": 1, "pageIdStr": "RkO0AE9rKrYy6ZDd"}
        //         },
        //         user
        //     }
        // )
        // console.log(this.dumps(bvd))
        let mid = context.adId
        let cco = context.adChannel
        if (mid && cco) {
            let qm = await this.autoCurl({
                    'url': `https://ms.jr.jd.com/gw/generic/mission/h5/m/queryMission`,
                    json: {
                        "reqData": {
                            "channelCode": cco,
                            "missionIds": [
                                mid
                            ],
                            "deviceInfo": device.deviceInfo,
                            "nonce": nonce,
                            "signature": aar.sign(this.dumps({
                                channelCode: cco,
                                PIN: user,
                                // missionId: i.missionId,
                            }), nonce)
                        }
                    },
                    user
                }
            )
            // console.log(this.dumps(qm))
            if (this.haskey(qm, 'resultData.data.0.doLink')) {
                let d = qm.resultData.data[0]
                let doLink = d.doLink
                let pp = this.query(doLink, '&', 1)
                if (pp.juid) {
                    p.log("正在运行:", d.name)
                    let T = aar.nonce()
                    let receive = await this.autoCurl({
                            'url': `https://ms.jr.jd.com/gw/generic/mission/h5/m/receiveMission`,
                            'json': {
                                "reqData": {
                                    "channelCode": cco,
                                    "missionId": mid,
                                    "deviceInfo": device.deviceInfo,
                                    "nonce": T,
                                    "signature": aar.sign(this.dumps({
                                        channelCode: cco,
                                        PIN: user,
                                        missionId: mid,
                                    }), T)
                                }
                            },
                            user
                        }
                    )
                    await this.wait(1000)
                    let jump = await this.autoCurl({
                            'url': `https://ms.jr.jd.com/gw2/generic/mission/h5/m/getJumpInfo?juid=${pp.juid}&signature=${aar.sign(this.dumps({
                                juid: pp.juid,
                                PIN: user,
                            }), T)}&nonce=${T}&jrAppVersion=6.9.80&systemEnv=IOS`,
                            user
                        }
                    )
                    // console.log(jump)
                    if (this.haskey(jump, 'resultData.success')) {
                        if (d.awards[0].awardName == '京豆') {
                            p.award(d.awards[0].awardRealNum, 'bean')
                        }
                        else {
                            p.msg(`${d.awards[0].awardName}: ${d.awards[0].awardRealNum}`)
                        }
                        isDo++
                    }
                    else {
                        p.log("跳转失败...")
                    }
                }
            }
        }
        if (isDo) {
            mile = await this.autoCurl({
                    'url': `https://ms.jr.jd.com/gw2/generic/Mission/h5/m/queryMilePost`,
                    json: {
                        "reqData": {
                            "source": "mdH5Pagedeploy",
                            "token": "TVBaZRYGYS",
                            "channelCode": context.channelCode,
                            "milePostIdList": context.milePostIdList || [115],
                            "queryMissionFlag": 2,
                            "deviceInfo": device.deviceInfo
                        }
                    },
                    user
                }
            )
        }
        for (let i of this.haskey(mile, 'resultData.data.0.milePostNodeList')) {
            if (i.nodeAwardStatus == 1) {
                p.log("获取奖励中...")
                let award = await this.autoCurl({
                        'url': `https://ms.jr.jd.com/gw2/generic/Mission/h5/m/awardMilePostNode`,
                        json: {
                            "reqData": {
                                "source": "mdH5Pagedeploy",
                                "token": "hyuyulRpQX",
                                "channelCode": context.channelCode,
                                "milePostId": (context.milePostIdList || [115])[0],
                                "number": i.number,
                                "deviceInfo": device.deviceInfo
                            }
                        },
                        user
                    }
                )
                if (this.haskey(award, 'resultData.code', '0000')) {
                    p.award(i.awards[0].awardRealNum, 'bean')
                }
            }
        }
        if (status) {
            p.info.work = true
        }
    }
}

