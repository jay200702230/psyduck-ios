import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东京喜自营签到',
            crontab: 3,
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/2iqSwv1JiDHxAkHAikfU6XAECFmo/index.html',
            },
            turn: 1,
            sync: 1,
            verify: 1,
            prompt: {
                craftId: '活动id'
            },
        }
    }

    async prepare() {
        // craftId 改为可选: 京喜自营频道签到活动实例ID每期变化, 缺参时先探测配置, 拿不到安静跳过
        try {
            await this.field('craftId')
        } catch (e) { }
    }

    // async middle() {
    //     if (this.turnCount == 1) {
    //         for (let user of this.random(this.help, this.help.length)) {
    //             let shareId = await this.getTemp(user)
    //             if (shareId) {
    //                 this.shareCode({
    //                     shareId,
    //                     user,
    //                     model: 'shuffle'
    //                 })
    //             }
    //         }
    //         if (!this._shareCode.length) {
    //             this.jump = true
    //         }
    //     }
    // }
    async main(p) {
        let user = p.data.user;
        let context = p.context;
        // craftId 缺失时先探测频道页活动配置(京喜自营签到活动实例ID每期变化, ini 无法长期维护)
        if (!context.craftId || context.craftId === 'undefined') {
            const findCraft = (o, d) => {
                if (!o || d > 6 || typeof o !== 'object') return ''
                for (let k of Object.keys(o)) {
                    if (k === 'craftId' && typeof o[k] === 'string' && o[k].length > 4) return o[k]
                    let r = findCraft(o[k], d + 1)
                    if (r) return r
                }
                return ''
            }
            let qa = await this.autoCurl({
                    url: `https://api.m.jd.com/api?functionId=jxzy_active_queryActive&appid=jx_h5_babel&t=${Date.now()}&channel=jxh5&clientVersion=1.2.5&client=jxh5&cthr=1&loginType=2&body={"activeVersion":2,"configIds":"694e9b25e854ff9b013373a3,67ea9a16512557d84cdcca5e,6aaf5036f68e8d75b3ef8ec8","pageId":"2iqSwv1JiDHxAkHAikfU6XAECFmo","tttId":"","edit":0,"benefitEdit":0,"canInstall":0,"installed":0,"sceneval":2,"buid":325,"appCode":"ms1888ebbf","time":${Date.now()}}`,
                    user,
                    algo: {
                        signStr: true
                    }
                }
            )
            let cid = findCraft(this.haskey(qa, 'data') || qa, 0)
            if (cid) {
                context.craftId = cid
                p.log("探测到活动ID:", cid)
            }
            else {
                p.log("跳过: 频道页无签到活动配置, 需真机京喜自营频道签到页获取活动ID后填入 jd.ini [jd_task_jxzySign] craftId")
                p.info.work = true
                return
            }
        }
        if (this.turnCount == 0) {
            let query = await this.autoCurl({
                    'url': `https://api.m.jd.com/api?functionId=jxzy_active_querySign&appid=jx_h5_babel&t=1749971701995&channel=jxh5&clientVersion=1.2.5&client=jxh5&cthr=1&loginType=2&body={"source":"jxzy","craftId":"${context.craftId}","sceneval":2,"buid":325,"appCode":"ms1888ebbf"}`,
                    user,
                    algo: {
                        signStr: true,
                        expire: {
                            code: 13,
                        }
                    }
                }
            )
            let shareId = this.haskey(query, 'data.helpTask.shareId')
            if (shareId) {
                this.setTemp(user, shareId, 86400)
            }
            let sign = await this.autoCurl({
                    url: `https://api.m.jd.com/api?functionId=jxzy_active_drawSign&appid=jx_h5_babel&t=1749971385687&channel=jxh5&clientVersion=1.2.5&client=jxh5&body={"itemId":"1","craftId":"${context.craftId}","source":"jxzy","sceneval":2,"buid":325,"appCode":"ms1888ebbf"}`,
                    user,
                    algo: {
                        appId: 'c50cc',
                        signStr: true
                    }
                }
            )
            if (this.haskey(sign, 'data.alreadySignDays')) {
                p.log("签到天数:", sign.data.alreadySignDays)
                switch (sign.data.alreadySignDays) {
                    case 2:
                        var bean = 4;
                        break
                    case 3:
                        var bean = 10;
                        break
                    default:
                        var bean = 2
                        break
                }
                if (this.haskey(sign, 'data.prizeInfos')) {
                    for (let i of sign.data.prizeInfos) {
                        if (i.prizeType == 2) {
                            p.award(i.discount, 'bean')
                        }
                        else {
                            p.log(i)
                        }
                    }
                }
                else {
                    p.award(bean, 'bean')
                }
                p.info.work = true
            }
            else if (this.haskey(sign, 'code', 103)) {
                p.info.work = true
                p.log("已签到天数:", this.haskey(query, 'data.alreadySignDays') || 1)
            }
            else if (this.haskey(sign, 'code', [3001, 3009])) {
                p.log('非活动受邀用户')
                p.info.work = true
                p.info.complete = true
            }
            else {
                p.log(sign)
            }
            let s = await this.autoCurl({
                    'url': `https://api.m.jd.com/api?functionId=jxzy_active_task_queryTaskList`,
                    'form': `functionId=jxzy_active_task_queryTaskList&appid=jx_h5_babel&t=1783744584966&channel=jxh5&clientVersion=1.2.5&client=jxh5&cthr=1&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&body={"source":"jxzy","craftId":"${context.craftId}","sceneval":2,"buid":325,"appCode":"ms1888ebbf","time":1783744584966,"signStr":"43144d23491400805f78ae6247a9413a"}`,
                    user,
                    algo: {
                        signStr: true,
                        expire: {
                            code: 13,
                        },
                    }
                }
            )
            let isOk
            let canClaimAmount = this.haskey(s, 'data.canClaimAmount')
            if (canClaimAmount) {
                let taskInfoList = this.haskey(s, 'data.taskInfoList')
                // console.log(this.dumps(taskInfoList))
                for (let i of taskInfoList) {
                    if (this.haskey(i, 'extInfo.helpCommonConfig')) {
                    }
                    else if (this.haskey(i, 'extInfo.browseTask')) {
                        let tk = i.extInfo.browseTask
                        if (tk.completionFlag) {
                            p.log("任务已完成:", i.taskName)
                        }
                        else {
                            isOk = 0
                            p.log("正在运行:", i.taskName)
                            let di = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=jxzy_active_task_completeTask`,
                                    'form': `functionId=jxzy_active_task_completeTask&appid=jx_h5_babel&t=1783744584659&channel=jxh5&clientVersion=1.2.5&client=jxh5&uuid=&cthr=1&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&body={"craftId":"${context.craftId}","taskId":"${i.taskId}","itemId":"${i.taskProgress.itemId}","taskType":${i.taskType},"sceneval":2,"buid":325,"appCode":"ms1888ebbf","time":1783744584659,"signStr":"6a8b54b2863145d466bd8fb0429ea2a2"}`,
                                    user,
                                    algo: {
                                        signStr: true,
                                        appId: 'cec1e'
                                    }
                                }
                            )
                            if (this.haskey(di, 'code', 0)) {
                                if (tk.browseTime) {
                                    p.log("正在等待:", tk.browseTime)
                                    await this.wait(1000 * parseInt(tk.browseTime))
                                }
                                let rw = await this.autoCurl({
                                        'url': `https://api.m.jd.com/api?functionId=jxzy_active_task_rewardTask`,
                                        'form': `functionId=jxzy_active_task_rewardTask&appid=jx_h5_babel&t=1783744586516&channel=jxh5&clientVersion=1.2.5&client=jxh5&uuid=&cthr=1&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&body={"craftId":"${context.craftId}","taskId":"${i.taskId}","itemId":"${i.taskProgress.itemId}","taskType":${i.taskType},"sceneval":2,"buid":325,"appCode":"ms1888ebbf","time":1783744586516,"signStr":"d8f048a0ed51cc9244680c7adad8ebfd"}`,
                                        user,
                                        algo: {
                                            signStr: true,
                                            appId: '573fe'
                                        }
                                    }
                                )
                                if (this.haskey(rw, 'data.prizeInfos.0')) {
                                    if (this.haskey(rw, 'data.prizeInfos.0.prizeType', 2)) {
                                        p.award(rw.data.prizeInfos[0].discount, 'bean')
                                    }
                                    else {
                                        p.log(rw.data.prizeInfos)
                                    }
                                    isOk = 1
                                }
                                else {
                                    p.log(rw)
                                }
                                await this.wait(1000)
                            }
                            else {
                                break
                            }
                        }
                    }
                }
            }
        }
        // else if (this.turnCount == 1) {
        //     if (context.user == user) {
        //         p.log("不能助力自己")
        //     }
        //     else {
        //         let help = await this.autoCurl({
        //                 url: `https://api.m.jd.com/api?functionId=jxzy_active_signHelp&appid=jx_h5_babel&t=1753429360117&channel=jxh5&clientVersion=1.2.5&client=jxh5&body={"source":"jxzy","craftId":"${context.craftId}","shareId":"${context.shareId}","sceneval":2,"buid":325,"appCode":"ms1888ebbf"}`,
        //                 algo: {
        //                     appId: 'f85a9',
        //                     signStr: true
        //                 },
        //                 user
        //             }
        //         )
        //         if (this.haskey(help, 'code', 0)) {
        //             p.info.work = true
        //             p.log("助力成功...")
        //         }
        //         else if (this.haskey(help, 'code', 3306)) {
        //             p.info.work = true
        //             p.log('您今天已经帮助过这位好友啦')
        //             p.info.work = true
        //         }
        //         else if (this.haskey(help, 'code', 3037)) {
        //             p.info.work = true
        //             p.log('今日助力次数已用完，明天再来帮助好友吧')
        //         }
        //         else if (this.haskey(help, 'code', 3004)) {
        //             p.info.work = true
        //             p.log('活动太火爆，请稍后再试！')
        //         }
        //         else {
        //             console.log(this.haskey(help, 'msg') || help)
        //         }
        //     }
        // }
    }
}

