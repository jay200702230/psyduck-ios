import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'

const PB_INI = (() => {
    for (const pt of ['/ql/data/psyduck/cookie/jd.ini', '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini']) {
        try { if (fs.existsSync(pt)) return pt } catch (e) {}
    }
    return '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini'
})()
const PB_PAGE = 'https://pro.m.jd.com/mall/active/4Gck3RiwkxFEyA9ztVmQ2zwqjNRr/index.html'
// farmNew 验证过的活动平台 appId 表
const PB_APPIDS = {
    apTaskList: ['54ed7', 'activities_platform'],
    apsDoTask: ['54ed7', 'activities_platform'],
    apStartTaskTime: ['acb1e', 'activity_platform_se'],
    apTaskDrawAward: ['f0f3f', 'activities_platform'],
    apDoLimitTimeTask: ['ebecc', 'activities_platform']
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: "京东种豆得豆",
            turn: 2,
            crontab: 4,
            tempExpire: 1500000,
            tempFile: 'jdGlobalAssist',
            help: "main",
            prompt: {
                inviteJson: 'true #使用自定义助力码'
            },
            readme: `如要使用自定义助力码,请在框架目录/inviter创建jd_task_plantBean.json,按需修改[{"user":"a","plantUuid":"abc","itemId":"xxx"},{"user":"b","plantUuid":"efg","itemId":"xxx"}]`,
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/4Gck3RiwkxFEyA9ztVmQ2zwqjNRr/index.html'
            }
        }
    }

    async prepare() {
    }

    // ============ 自签名直连层(框架curl被风控, 与 jd_task_farmNew/jd_task_wxFarm 同链路) ============
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(PB_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.fwCookie()
    }
    fwCookie() {
        if (this._pbCk && Date.now() - this._pbCkAt < 600000) return this._pbCk
        try {
            const txt = fs.readFileSync(PB_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._pbCk = guid ? guid + ';' + ck : ck; this._pbCkAt = Date.now() }
        } catch (e) {}
        return this._pbCk || ''
    }

    // 活动平台请求(farmNew 验证形态): 自签名 + appId 查表
    async pbApReq(fn, bodyObj) {
        const ids = PB_APPIDS[fn] || ['54ed7', 'activities_platform']
        const body = this.dumps(bodyObj)
        return await this.farmCurl({
            url: 'https://api.m.jd.com/api',
            algo: {appId: ids[0]},
            form: `functionId=${fn}&body=${encodeURIComponent(body)}&t=${Date.now()}&appid=${ids[1]}&client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame`
        })
    }

    async farmCurl(opts) {
        if (!this._pbSigner) {
            try { this._pbSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._pbSigner) return null
        let url = String(opts.url || 'https://api.m.jd.com/api')
        // form 为空时参数从 URL query 提取(种豆子任务体系全走 client.action?functionId= 形态)
        const form = String(opts.form || '') || (url.includes('?') ? url.split('?').slice(1).join('?') : '')
        const host = (url.match(/https?:\/\/([^/?]+)/) || ['', 'api.m.jd.com'])[1]
        const path = url.replace(/^https?:\/\/[^/?]+/, '').split('?')[0] || '/api'
        const getv = k => { const m = form.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        // 非 api.m.jd.com 的老接口(京喜/wq)自带硬编码h5st, 直发不重签
        if (host !== 'api.m.jd.com') {
            return new Promise(resolve => {
                const rq = https.request({
                    hostname: host, path, method: 'POST',
                    headers: {
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        cookie: ck, origin: PB_PAGE, referer: PB_PAGE,
                        'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                    }
                }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
                rq.on('error', () => resolve(null))
                rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
                rq.end()
            })
        }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const t = String(Date.now())
        const base = {
            appid: getv('appid') || 'activities_platform',
            client: getv('client') || 'ios', clientVersion: getv('clientVersion') || '15.6.50',
            t, body, functionId: fn, networkType: 'wifi'
        }
        const signed = this._pbSigner.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || 'c57f6', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: host, path: path + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: PB_PAGE, referer: PB_PAGE,
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async middle() {
        if (this.turnCount == 1) {
            for (let i of this.inviter) {
                if (i.plantUuid && i.itemId) {
                    let inviter = {
                        ...i, ...{
                            category: 'plantBean',
                            limit: 1,
                            times: 6,
                            model: 'user'
                        }
                    }
                    this.shareCode(inviter)
                }
                else {
                    this.err(`助力账户:${i.user}缺少助力参数itemId或plantUuid`)
                }
            }
            for (let user of this.help) {
                let plantUuid = await this.hgetTemp(user, 'plantUuid')
                let itemId = await this.hgetTemp(user, 'itemId')
                if (plantUuid && itemId) {
                    this.shareCode({
                        user,
                        plantUuid,
                        itemId,
                        category: 'plantBean',
                        limit: 1,
                        times: 6,
                        model: 'user'
                    })
                }
            }
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        if (this.turnCount == 0) {
            context.linkId = '4HcenxuZM4XiHesOb1HG4g'
            let ua = 'client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame&build=170394&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone14,5&lang=zh_CN&osVersion=16.3&partner=-1&cthr=1'
            // 种豆得豆页面签到: 互动小游戏连签, 得京豆+收获值
            let wHome = await this.farmCurl({
                    'url': `https://api.m.jd.com/api?functionId=weGameHome`,
                    'form': `functionId=weGameHome&body={"envType":1,"linkId":"${context.linkId}","appType":1}&appid=wegame-hub&${ua}`,
                    user,
                    algo: {
                        appId: '101aa'
                    }
                }
            )
            let signVo = this.haskey(wHome, 'data.signMainVo')
            if (signVo && signVo.currentStatus == 1) {
                p.log("正在签到...")
                let wSign = await this.farmCurl({
                        'url': `https://api.m.jd.com/api?functionId=weGameLottery`,
                        'form': `functionId=weGameLottery&body={"envType":1,"linkId":"${context.linkId}","appType":1,"status":1,"markStr":"${signVo.markStr || ''}"}&appid=wegame-hub&${ua}`,
                        user,
                        algo: {
                            appId: '730a6'
                        }
                    }
                )
                if (this.haskey(wSign, 'data.awardResultVO.amount')) {
                    p.award(wSign.data.awardResultVO.amount, 'bean')
                    p.info.work = true
                }
                else if (this.haskey(wSign, 'code', 0) == 0 || String(this.haskey(wSign, 'errMsg') || '').includes('成功')) {
                    p.log("签到成功")
                    p.info.work = true
                }
                else {
                    p.log("签到:", this.haskey(wSign, 'errMsg') || wSign)
                }
            }
            else if (signVo && signVo.currentStatus == 3) {
                p.log("今日已签到")
            }
            else {
                p.log(`种豆签到入口: ${this.haskey(wHome, 'errMsg') || this.dumps(wHome).slice(0, 80)}`)
            }
            // 心跳: 拉取营养液产出的随机时间范围
            let heartbeat = await this.farmCurl({
                    'url': `https://api.m.jd.com/api`,
                    'form': `functionId=plantBeanHeartbeat&appid=activities_platform&body={"linkId":"${context.linkId}","monitor_source":"plant_m_plant_index","version":"9.2.4.6","busiVersion":"2","appType":1}&ext={"prstate":"0"}&uemps=0-2-999&${ua}`,
                    user,
                    algo: {
                        appId: '65198'
                    }
                }
            )
            let rnd = this.haskey(heartbeat, 'data.randomTimeRangeInfo')
            if (rnd) {
                p.log(`营养液产出间隔: ${rnd.min}~${rnd.max}秒`)
            }
            let errId = {}
            let listss = await this.farmCurl({
                'url': `https://api.m.jd.com/api?functionId=apTaskList`,
                'form': `functionId=apTaskList&body={"linkId":"${context.linkId}","queryType":6,"channel":4,"area":"16_1315_3486_59642"}&appid=activities_platform&${ua}`,
                user
            })
            // 试玩专区(queryType 6): 玩一玩系列小游戏任务挂在这里, 主池(queryType 0)看不到
            const q6 = (this.haskey(listss, 'data') && (Array.isArray(listss.data) ? listss.data : listss.data.taskList)) || []
            if (q6.length) p.log(`试玩专区(${q6.length}): ` + q6.map(t => `${String(t.taskShowTitle || t.taskTitle || '').slice(0, 14)}(${t.taskType}${t.taskFinished === true ? ',完' : ''})`).join(', '))
            // 活动池浏览任务(joyPark 验证链路): apsDoTask 直报(服务端原始 pipeExt+真实 itemId), 计时任务补 apDoLimitTimeTask, apTaskDrawAward 领奖
            {
                // GAME/PLAY_/MINI_GAME 不再跳过: AI掼蛋/斗地主类「访问即完成」可协议做, do 拒自动落补领/跳过
                const skipType = /^(CUMULATIVE_TIMES|ADD_WIDGET|WECHAT_SHARE|ORDER_MARK|SUBSCRIBE|WECHAT|ACCUMULATE|SHOPPING|WATER|SHARE_INVITE)/
                const skipAsg = new Set()
                const brief = t => ({
                    asg: (t.pipeExt && t.pipeExt.assignmentId) || t.assignmentId || '',
                    type: String(t.taskType || ''),
                    src: t.taskSourceUrl || (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].itemId) || '',
                    tl: (t.timeLimitPeriod || 0),
                    fin: t.taskFinished === true,
                    raw: t,
                    title: String(t.taskShowTitle || t.taskTitle || '').slice(0, 14)
                })
                let guard = 0, pbDone = 0, pbSkip = 0
                while (guard++ < 40) {
                    const lr = await this.pbApReq('apTaskList', {linkId: context.linkId, queryType: 0, channel: 4, area: '16_1315_3486_59642'})
                    const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
                    if (!tasks.length) break
                    if (guard === 1) p.log(`活动任务池 ${tasks.length} 个`)
                    for (const i of tasks) {
                        if (i.taskType === 'SHARE_INVITE' && i.pipeExt && i.pipeExt.itemId) {
                            try { await this.hsetTemp(user, 'itemId', i.pipeExt.itemId) } catch (e) {}
                        }
                    }
                    const cur = tasks.map(brief).find(b => !b.fin && !skipAsg.has(b.asg) && !skipType.test(b.type) && /^(BROWSE|FOLLOW|EXTERNAL_BROWSE|CONSECUTIVE_SIGN_IN|JOIN_OTHER_ACT|GAME|PLAY_|MINI_GAME)/.test(b.type))
                    if (!cur) {
                        // 透明化: 列出本轮跳过/剩余的不可做任务
                        const left = tasks.filter(t => t.taskFinished !== true && !skipAsg.has((t.pipeExt && t.pipeExt.assignmentId) || t.assignmentId || '') && skipType.test(String(t.taskType || '')))
                        if (left.length) p.log(`池内跳过: ${left.map(t => `${String(t.taskShowTitle || t.taskTitle || '').slice(0, 12)}(${t.taskType})`).join(', ')}`)
                        break
                    }
                    // pipeExt 必须用服务端下发的原始对象(含 activityId 等), 自拼会被严格任务校验拒「没有达到做任务条件」
                    const rawPe = (cur.raw.pipeExt && Object.keys(cur.raw.pipeExt).length) ? {...cur.raw.pipeExt} : {taskType: cur.type, assignmentId: cur.asg}
                    p.log(`[${cur.title}] ${cur.type} 开始`)
                    let items = []
                    if (cur.type === 'CONSECUTIVE_SIGN_IN') {
                        items.push({itemId: '', pe: rawPe})
                    }
                    else if (cur.src) {
                        let src = cur.src
                        if (!/^FOLLOW/.test(cur.type) && /^\d+$/.test(src)) src = 'http://item.jd.com/' + src + '.html'
                        // item 级 pipeExt 必须合并(东东农场/JOY游记等引流任务的 item.pipeExt.itemId 是活动专属ID, 缺失必 2018)
                        const it0 = cur.raw.taskItemList && cur.raw.taskItemList[0]
                        items.push({itemId: encodeURIComponent(src), pe: {...rawPe, ...((it0 && it0.pipeExt) || {})}})
                    }
                    else {
                        const detail = await this.pbApReq('apTaskDetail', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: context.linkId, pipeExt: rawPe, actFlowCode: 'apTaskDetail'})
                        for (const it of (this.haskey(detail, 'data.taskItemList') || cur.raw.taskItemList || [])) {
                            if (it.itemId) items.push({itemId: encodeURIComponent(it.itemId), pe: {...rawPe, ...(it.pipeExt || {})}})
                        }
                    }
                    if (!items.length) {
                        // 无 sourceUrl 且 detail 无浏览项 = 跨App引流任务(东东农场/JOY游记等), 服务端校验真实页面埋点, 协议侧无解
                        p.log(`[${cur.title}] 无浏览项下发(跨App引流任务), 跳过`)
                        skipAsg.add(cur.asg); pbSkip++
                        continue
                    }
                    let okOne = false
                    for (let ix = 0; ix < items.length; ix++) {
                        const dit = items[ix]
                        const dr = await this.pbApReq('apsDoTask', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: context.linkId, pipeExt: dit.pe, taskInsert: false, itemId: dit.itemId || undefined})
                        if (dr && (dr.success === true || dr.code === 0)) {
                            okOne = true
                            if (cur.tl > 0) {
                                p.log(`[${cur.title}] 停留${cur.tl}s后计时[${ix + 1}/${items.length}]`)
                                await this.wait(cur.tl * 1000 + 1500)
                                await this.pbApReq('apDoLimitTimeTask', {linkId: context.linkId})
                            }
                            else {
                                await this.wait(3000 + Math.floor(Math.random() * 2000))
                            }
                            const aw = await this.pbApReq('apTaskDrawAward', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: context.linkId, pipeExt: dit.pe})
                            const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
                            if (awd) p.log(`[${cur.title}] ${awd}`)
                            else p.log(`[${cur.title}] 上报完成[${ix + 1}/${items.length}](奖励随气泡发放)`)
                        }
                        else {
                            const dm = (dr && (dr.errMsg || dr.msg)) || JSON.stringify(dr).slice(0, 60)
                            const rc = dr && dr.code
                            if (rc === 2018 || rc === 2031 || rc === 2014) {
                                // 直报被拒 → 回退受理制(浏览页面15秒类计时任务必须受理建计时: 受理→wait→do→确认)
                                const st2 = await this.pbApReq('apStartTaskTime', {linkId: context.linkId, taskId: -9999, itemId: dit.itemId, channel: 4, pipeExt: dit.pe})
                                if (st2 && (st2.success === true || st2.code === 0)) {
                                    await this.wait((cur.tl > 0 ? cur.tl : 10) * 1000 + 1500)
                                    const dr2 = await this.pbApReq('apsDoTask', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: context.linkId, pipeExt: dit.pe, taskInsert: false, itemId: dit.itemId || undefined})
                                    if (dr2 && (dr2.success === true || dr2.code === 0)) {
                                        okOne = true
                                        await this.pbApReq('apDoLimitTimeTask', {linkId: context.linkId})
                                        const aw2 = await this.pbApReq('apTaskDrawAward', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: context.linkId, pipeExt: dit.pe})
                                        const awd2 = aw2 && Array.isArray(aw2.data) ? aw2.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
                                        p.log(`[${cur.title}] 受理制补做${awd2 ? ' ' + awd2 : '成功(奖励随气泡发放)'}`)
                                    }
                                    else {
                                        p.log(`[${cur.title}] code=${rc} 受理制补做仍拒: ${(dr2 && (dr2.errMsg || dr2.msg)) || JSON.stringify(dr2).slice(0, 50)}`)
                                        skipAsg.add(cur.asg); pbSkip++
                                    }
                                }
                                else {
                                    p.log(`[${cur.title}] code=${rc}: ${(dr && (dr.errMsg || dr.msg)) || ''}, 受理拒`)
                                    skipAsg.add(cur.asg); pbSkip++
                                }
                                break
                            }
                            if (/没有达到做任务条件|已完成/.test(dm)) {
                                // App内真实完成过/需真实交互: do 上报被拒, 落 drawAward 试补领
                                const aw = await this.pbApReq('apTaskDrawAward', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: context.linkId, pipeExt: dit.pe})
                                const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
                                if (awd) { okOne = true; p.log(`[${cur.title}] do拒(${dm}) 补领${awd}`) }
                                else p.log(`[${cur.title}] do拒(${dm}), 无奖可补`)
                                skipAsg.add(cur.asg)
                                break
                            }
                            p.log(`[${cur.title}] do拒: ${dm}`)
                            skipAsg.add(cur.asg); pbSkip++
                            break
                        }
                    }
                    if (okOne) pbDone++
                    await this.wait(2000)
                }
                if (pbDone) p.log(`活动池任务完成 ${pbDone} 个`)
                if (pbSkip) p.log(`活动池 ${pbSkip} 个任务服务端拒`)
            }

            var index = await this.farmCurl({
                    'form': `functionId=plantBeanIndex&appid=signed_wh5&body={"wxHeadImgUrl":"","shareUuid":"","channel":"baibaoxiang","plantUpdateV1":"v1","monitor_source":"plant_m_plant_index","version":"9.2.4.6","busiVersion":"2","appType":1}&ext=%7B%22prstate%22%3A%220%22%7D&uemps=0-2-999&${ua}`,
                    user,
                    algo: {
                        'appId': 'd246a',
                        expire: {
                            "code": "3"
                        }
                    }
                }
            )
            if (this.haskey(index, 'code', '3')) {
                p.err(`没有获取到数据`)
                p.info.jump = true
                return
            }
            else if (this.haskey(index, 'code', '411')) {
                p.err(`前方道路拥挤,等待两分钟`)
                return
            }
            var plantUuid
            if (this.haskey(index, 'data.jwordShareInfo')) {
                let share = this.query(index.data.jwordShareInfo.shareUrl, '&', 1)
                plantUuid = share.plantUuid
                await this.hsetTemp(user, 'plantUuid', plantUuid)
            }
            let roundId
            for (let r of this.haskey(index, 'data.roundList')) {
                if (!roundId && r.dateDesc.includes('本期')) {
                    roundId = r.roundId
                }
                if (r.awardState == 5) {
                    let reward = await this.farmCurl({
                            'url': `https://api.m.jd.com/client.action?functionId=receivedBean&body={"monitor_refer":"receivedBean","monitor_source":"plant_app_plant_index","roundId":"${r.roundId}","version":"9.2.4.6"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                            user
                        }
                    )
                    if (this.haskey(reward, 'data.awardBean')) {
                        p.msg(`获取上期奖励: ${reward.data.awardBean}`)
                    }
                }
                else if (r.roundState == 2) {
                    // 气泡定时产出(nutrCountLimit 最多3个), 循环收取直到无气泡
                    for (let bi = 0; bi < 4; bi++) {
                        await this.farmCurl({
                                'url': `https://api.m.jd.com/client.action?functionId=receiveNutrients&body={"monitor_refer":"plant_receiveNutrients","monitor_source":"plant_app_plant_index","roundId":"${r.roundId}","version":"9.2.4.6"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                user,
                                algo: {
                                    appId: 'b56b8'
                                }
                            }
                        )
                        let bubbles = r.bubbleInfos
                        if (!bubbles || !bubbles.length) {
                            // 新版本气泡信息由独立接口下发
                            let bubble = await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=plantBeanBubbleInfo&appid=signed_wh5&body={"roundId":"${r.roundId}","monitor_source":"plant_m_plant_index","version":"9.2.4.6","busiVersion":"2","appType":1}&ext={"prstate":"0"}&uemps=0-2-999&${ua}`,
                                    user,
                                    algo: {
                                        appId: 'd246a'
                                    }
                                }
                            )
                            bubbles = this.haskey(bubble, 'data.bubbleInfos') || []
                        }
                        if (!bubbles || !bubbles.length) {
                            if (bi === 0) p.log(`气泡暂无可收(定时产出中)`)
                            break
                        }
                        for (let j of bubbles) {
                            p.log(`气泡收取 ${j.name}: ${j.nutrNum}`)
                            let culture = await this.farmCurl({
                                    'url': `https://api.m.jd.com/client.action?functionId=cultureBean&body={"monitor_refer":"plant_index","monitor_source":"plant_app_plant_index","roundId":"${r.roundId}","nutrientsType":"${j.nutrientsType}","version":"9.2.4.6"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                    user,
                                    algo: {
                                        appId: '6a216'
                                    }
                                }
                            )
                            if (this.haskey(culture, 'data')) {
                                p.info.work = true
                                p.log(`气泡营养液已施肥`)
                            }
                            else if (String(this.haskey(culture, 'errorCode') || '').includes('PB001')) {
                                // 连续施肥限流, 退避后重试一次
                                await this.wait(5000)
                                const culture2 = await this.farmCurl({
                                        'url': `https://api.m.jd.com/client.action?functionId=cultureBean&body={"monitor_refer":"plant_index","monitor_source":"plant_app_plant_index","roundId":"${r.roundId}","nutrientsType":"${j.nutrientsType}","version":"9.2.4.6"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                        user,
                                        algo: {
                                            appId: '6a216'
                                        }
                                    }
                                )
                                if (this.haskey(culture2, 'data')) {
                                    p.info.work = true
                                    p.log(`气泡营养液已施肥(重试)`)
                                }
                                else {
                                    p.log(`气泡施肥重试仍失败: ${this.haskey(culture2, 'errorMessage') || this.dumps(culture2).slice(0, 60)}`)
                                }
                            }
                            else {
                                p.log(`气泡施肥失败: ${this.haskey(culture, 'msg') || this.haskey(culture, 'errMsg') || this.dumps(culture).slice(0, 60)}`)
                            }
                        }
                        await this.wait(2500)
                    }
                }
            }
            let status = 1
            for (let i of this.haskey(index, 'data.taskList')) {
                if (i.isFinished) {
                    p.log(i.taskName, "任务已经完成")
                }
                else {
                    p.log(`开始做 ${i.taskName}任务`, i.taskType);
                    let totalNum = parseInt(i.totalNum)
                    let gainedNum = parseInt(i.gainedNum)
                    status = 0
                    switch (i.taskType) {
                        case 2:
                            status = 1
                            break
                        case 57:
                            await this.farmCurl({
                                    'url': `https://m.jingxi.com/jxbfd/user/DoubleSignDeal?g_ty=h5&g_tk=&appCode=msd1188198&__t=1657108409440&dwEnv=7&strDeviceId=a3b4e844090b28d5c38e7529af8115172079be4d&strZone=jxbfd&bizCode=jxbfd&source=jxbfd&_cfd_t=1657108409190&_stk=__t%2C_cfd_t%2CbizCode%2CdwEnv%2Csource%2CstrDeviceId%2CstrZone&_ste=1&h5st=20220706195330228%3B1980457211661562%3B10032%3Btk02w78551ad830nuMcGB4Qsv9QxapLP7gZdOCYE5PVV%2Bna%2Bb4KU21drJq64oP82965Vdc1tGqVU%2Flp7ydcZ5XgH0Feh%3B241b6f1d21bf8e41f380a5dd29a7bac2a6f1f65a0c7ef1b1f751eaea4c40dd9c%3B3.0%3B1657108410228&sceneval=2`,
                                    // 'form':``,
                                    user
                                }
                            )
                            await this.wait(2000)
                            await this.farmCurl({
                                    'url': `https://wq.jd.com/jxjdsignin/SignedInfo?channel=jx_zdddsq&_t=1657108415230&h5st=20220706195335235%3B9699666907452188%3B0f6ed%3Btk02wacc21c5518nsBms0rLLAn98Xun6p1dT6CW8Pkictd4WSbmiuCg8ZokHnTWf8b7LrBNq0ADjUcmobc3%2BX8Caeday%3Bfeaa80ef87c85cd9de17d9a9f5d40e02150d9e5c3734c8a42a4a33e64fc60668%3B3.0%3B1657108415235&_stk=_t%2Cchannel&_=1657108415242&sceneval=2&g_login_type=1&g_ty=ajax&appCode=msc588d6d5`,
                                    // 'form':``,
                                    user
                                }
                            )
                            await this.wait(2000)
                            let reward = await this.farmCurl({
                                    'url': `https://wq.jd.com/jxjdsignin/IssueReward?channel=jx_zdddsq&_t=1657108494784&_stk=_t%2Cchannel&sceneval=2&g_login_type=1&g_ty=ajax&appCode=msc588d6d5`,
                                    // 'form':``,
                                    user
                                }
                            )
                            break
                        case 96:
                            let sign = await this.farmCurl({
                                    'url': `https://wq.jd.com/tjjdsignin/SignedInfo?channel=jx_zdddsq&_t=1663080425215&&_stk=_t%2Cchannel&_=1663080425642&sceneval=2&g_login_type=1&g_ty=ajax&appCode=msc588d6d5`,
                                    algo: {
                                        appId: '0f6ed',
                                        type: "pingou"
                                    },
                                    user
                                }
                            )
                            await this.wait(4000)
                            let reward2 = await this.farmCurl({
                                    'url': `https://wq.jd.com/tjjdsignin/IssueReward?channel=jx_zdddsq&_t=1663080432487&_stk=_t%2Cchannel&sceneval=2&g_login_type=1&g_ty=ajax&appCode=msc588d6d5`,
                                    user,
                                    algo: {
                                        appId: '0f6ed',
                                        type: "pingou"
                                    }
                                }
                            )
                            break
                        case 92:
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=receiveNutrientsTask&body=${this.dumps({
                                        "monitor_refer": "plant_receiveNutrientsTask",
                                        "monitor_source": "plant_app_plant_index",
                                        "awardType": "92",
                                        "version": i.version
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.wait(2000)
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=gotConfigDataForBrand&body=${this.dumps({
                                        "k": "farmShareConfig",
                                        "babelChannel": "10",
                                        "channel": 3,
                                        "type": "json",
                                        "version": 16
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=initForFarm&body=${this.dumps({
                                        "version": 16,
                                        "channel": 3,
                                        "babelChannel": "10"
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=taskInitForFarm&body=${this.dumps({
                                        "version": 16,
                                        "channel": 3,
                                        "babelChannel": "10"
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=farmMarkStatus&body=${this.dumps({
                                        "version": 16,
                                        "channel": 3,
                                        "babelChannel": "10"
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=friendListInitForFarm&body=${this.dumps({
                                        "version": 16,
                                        "channel": 3,
                                        "babelChannel": "10"
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=gotConfigDataForBrand&body=${this.dumps({
                                        "k": "farmRule",
                                        "babelChannel": "10",
                                        "channel": 3,
                                        "type": "json",
                                        "version": 16
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=ddnc_toStayModal&body=${this.dumps({
                                        "version": 16,
                                        "channel": 3,
                                        "babelChannel": "10"
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=queryPathWithActId&body=${this.dumps({
                                        "babelChannel": "10",
                                        "channel": 3,
                                        "actId": "3KSjXqQabiTuD1cJ28QskrpWoBKT",
                                        "version": 16
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=isUserFollow&body=${this.dumps({
                                        "themeId": "519",
                                        "informationParam": {
                                            "isRvc": "0",
                                            "fp": "-1",
                                            "eid": "eidIf0aa8121d5saWrnr3ryoR6qt1FxGRFjFGVq57Vv5jwdgmcxSHUO23TTEORkTW84A92Fijx10j2lZfx228DL+PAqTpx3MK1VsIZiVGD2pPczQWVRx",
                                            "shshshfp": "-1",
                                            "userAgent": "-1",
                                            "referUrl": "-1",
                                            "shshshfpa": "-1"
                                        },
                                        "businessId": "1"
                                    })}&appid=wh5&osVersion=&screen=390*844&networkType=&timestamp=1740479461598&d_brand=&d_model=&wqDefault=false&client=apple&clientVersion=15.0.20`,
                                    user,
                                    alog: {
                                        app: true
                                    }
                                }
                            )
                            break
                        case 10:
                            let channel = await this.farmCurl({
                                    'url': `https://api.m.jd.com/client.action?functionId=plantChannelTaskList&body=%7B%7D&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                    // 'form':``,
                                    user
                                }
                            )
                            var list = [...channel.data.goodChannelList, ...channel.data.normalChannelList]
                            for (let n of list) {
                                if (n.taskState == '2') {
                                    let plantChannelNutrientsTask = await this.farmCurl({
                                            'url': `https://api.m.jd.com/client.action?functionId=plantChannelNutrientsTask&body={"channelTaskId":"${n.channelTaskId}","channelId":"${n.channelId}"}&uuid=16496899654652091525278.275.1651079578494&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                            // 'form':``,
                                            user,
                                            algo: {
                                                appId: '2424e'
                                            }
                                        }
                                    )
                                    if (this.haskey(plantChannelNutrientsTask, 'data.nutrCount')) {
                                        p.log(this.haskey(plantChannelNutrientsTask, 'data.nutrToast'))
                                        gainedNum++
                                    }
                                    if (gainedNum == totalNum) {
                                        break
                                    }
                                }
                            }
                            break
                        case 3:
                            let shopTaskList =
                                await this.farmCurl({
                                        'url': `https://api.m.jd.com/client.action?functionId=shopTaskList&body={"monitor_refer": "plant_receiveNutrients"}&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                        user
                                    }
                                )
                            var list = [...(this.haskey(shopTaskList, 'data.goodShopList') || []), ...(this.haskey(shopTaskList, 'data.moreShopList') || [])]
                            for (let k of list) {
                                if (k.taskState == '2') {
                                    let shopNutrientsTask = await this.farmCurl({
                                            'url': `https://api.m.jd.com/client.action?functionId=shopNutrientsTask&body={"monitor_refer":"plant_shopNutrientsTask","version":"9.2.4.6","shopId":"${k.shopId}","shopTaskId":"${k.shopTaskId}"}&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                            user,
                                            algo: {
                                                appId: "19c88"
                                            }
                                        }
                                    )
                                    if (this.haskey(shopNutrientsTask, 'data.nutrCount')) {
                                        p.log(this.haskey(shopNutrientsTask, 'data.nutrToast'))
                                        gainedNum++
                                    }
                                    if (gainedNum == totalNum) {
                                        break
                                    }
                                    await this.wait(2000)
                                }
                            }
                            break
                        case 5:
                            p.log("开始执行:", i.taskName)
                            let productTaskList =
                                await this.farmCurl({
                                        'url': `https://api.m.jd.com/client.action?functionId=productTaskList&body={"monitor_source":"plant_app_plant_index","monitor_refer":"plant_productTaskList","version":"9.2.4.6"}&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                        user,
                                        algo: {appId: '7351b'}
                                    }
                                )
                            for (let z of this.haskey(productTaskList, 'data.productInfoList')) {
                                let productNutrientsTask = await this.farmCurl({
                                        'url': `https://api.m.jd.com/client.action?functionId=productNutrientsTask&body={"monitor_refer":"plant_productNutrientsTask","monitor_source":"plant_app_plant_index","productTaskId":"${z[0].productTaskId}","skuId":"${z[0].skuId}","version":"9.2.4.6"}&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                                        user,
                                        algo: {
                                            appId: 'a4e2d'
                                        }
                                    }
                                )
                                await this.wait(2000)
                                p.log(productNutrientsTask.data.nutrToast || productNutrientsTask.data)
                            }
                            break
                        default:
                            let s = await this.farmCurl({
                                    'url': `https://api.m.jd.com/client.action?functionId=receiveNutrientsTask&appid=signed_wh5&body={"awardType":"${i.taskType}","monitor_source":"plant_m_plant_index","monitor_refer":"plant_receiveNutrientsTask","version":"9.2.4.6"}&client=apple&clientVersion=13.2.8&networkType=wifi&osVersion=15.7.5&uuid=713528612071b94e23fcd28144db476f856f9fc5&partner=&d_brand=iPhone&d_model=iPhone8,1&screen=667*375&openudid=713528612071b94e23fcd28144db476f856f9fc5&adid=`,
                                    // 'form':``,
                                    user,
                                    algo: {
                                        appId: 'd22ac'
                                    }
                                }
                            )
                            p.log(this.haskey(s, 'data.nutrToast'))
                            break
                    }
                    await this.wait(2000)
                }
            }
            if (this.haskey(index, 'data.fixedEntryTask.state', 2)) {
                p.log(`正在访问:`, index.data.fixedEntryTask.noticePopText)
                let culture = await this.farmCurl({
                        'url': `https://api.m.jd.com/client.action?functionId=cultureBean&body={"monitor_refer":"plant_index","monitor_source":"plant_app_plant_index","roundId":"${roundId}","nutrientsType":"${index.data.fixedEntryTask.nutrientsType}","version":"9.2.4.6"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                        user,
                        algo: {
                            appId: '6a216'
                        }
                    }
                )
            }
            let friendList = await this.farmCurl({
                    'url': `https://api.m.jd.com/client.action?functionId=plantFriendList&body={"version":"9.2.4.1","monitor_refer":"plantFriendList","monitor_source":"plant_app_plant_index","pageNum":"1"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                    user
                }
            )
            for (let i of this.haskey(friendList, 'data.friendInfoList')) {
                if (i.nutrCount) {
                    status = 0
                    let collectUserNutr = await this.farmCurl({
                            'url': `https://api.m.jd.com/client.action?functionId=collectUserNutr&body={"monitor_refer":"collectUserNutr","monitor_source":"plant_app_plant_index","roundId":"${roundId}","paradiseUuid":"${i.paradiseUuid}","version":"9.2.4.1"}&client=apple&clientVersion=13.2.8&&uuid=0721076da75ec3ea8e5f481e6d68bb4b7420c38d&appid=signed_wh5&partner=&d_brand=iPhone&d_model=iPhone13%2C3&clientVersion=13.1.0&osVersion=13.1.0&client=apple&screen=844*390`,
                            user,
                            algo: {
                                'appId': '14357',
                            }
                        }
                    )
                    let collectResult = this.haskey(collectUserNutr, 'data.collectResult')
                    if (collectResult == '3') {
                        status = 1
                        p.log('今日帮助收取次数已达上限，明天再来帮忙吧')
                        break
                    }
                    else if (collectResult == '1') {
                        status = 1
                        p.log(collectUserNutr.data.collectMsg.replace("*plantNickName*", i.plantNickName).replace('*friendNutrRewards*', collectUserNutr.data.friendNutrRewards).replace('*collectNutrRewards*', collectUserNutr.data.collectNutrRewards))
                    }
                    await this.wait(2000)
                }
            }
            if (status) {
            }
        }
        else {
            if (!context.plantUuid) {
                return
            }
            if (context.user == user) {
                p.log("不能助力自己...")
                return
            }
            let itemId = context.itemId || await this.hgetTemp(context.user, 'itemId')
            let invitePin = context.plantUuid || await this.hgetTemp(context.user, 'plantUuid')
            p.log(context.user, itemId, invitePin)
            if (!itemId || !invitePin) {
                p.err(`助力账户:${context.user}缺少助力参数itemId或plantUuid`)
            }
            else {
                let help = await this.farmCurl({
                        'form': `functionId=plantHelpShare&appid=signed_wh5&body={"taskId":"-9999","invitePin":"${invitePin}","itemId":"${itemId}","assignmentId":"4aza4ZXp34G4bGwdS89wZKoRg9o","monitor_source":"plant_m_plant_index","monitor_refer":"uploadInteractiveAssignment","version":"9.2.4.6","busiVersion":"2"}&ext=%7B%22prstate%22%3A%220%22%7D&uemps=0-2-999&client=ios&clientVersion=15.5.15`,
                        user,
                        algo: {
                            appId: 'c1728'
                        }
                    }
                )
                let data = this.haskey(help, 'data') || {}
                if (data.code == 0) {
                    p.log(`助力成功:`, user,)
                    p.info.help = true
                }
                else if (data.code == 2) {
                    p.info.complete = true
                    p.log(data.errMsg)
                }
                else if (data.code == 3) {
                    p.log(data.errMsg)
                    p.info.help = true
                }
                else if (data.code == 4) {
                    p.log(data.errMsg)
                    p.context.finish = true
                }
                else {
                    p.log(data)
                }
                await this.wait(2000)
            }
        }
    }

    async done() {
        let code = []
        for (let user of this.help) {
            let plantUuid = await this.hgetTemp(user, 'plantUuid')
            let itemId = await this.hgetTemp(user, 'itemId')
            if (plantUuid && itemId) {
                code.push({user, plantUuid, itemId})
            }
        }
        console.log('InviteCode:', this.dumps(code))
    }
}
