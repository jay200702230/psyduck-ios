import {Template} from '../../template.js'
import net from 'net'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {execFile} from 'child_process'
import {fileURLToPath} from 'url'

// 实时凭据保活 v3:
// 1) 28900 Frida 桥从京东App活会话取最新 pt_key -> islogin 验活 -> 原子写回 cookie/jd.ini
// 2) execFile 调 a2local.mjs 解密京东App wjlogin prefs -> 自行写入 config/jdUser.ini
// 京东App未运行/桥不可达时保持原文件不动.
const BASE = path.join(path.dirname(fileURLToPath(import.meta.url)), '../..')
const CK_INI = path.join(BASE, 'cookie/jd.ini')
const USER_INI = path.join(BASE, 'config/jdUser.ini')
const A2LOCAL = '/data/user/0/com.psyduck.jdtask/files/rt/a2local.mjs'
const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '实时凭据保活(pt_key+wskey)', prompt: {}, turn: 1, crontab: '*/20 * * * *'}
    }

    async prepare() {
    }

    rpcCookie() {
        return new Promise(resolve => {
            let buf = '', done = false
            const s = net.connect(28900, '127.0.0.1', () => s.write(JSON.stringify({cmd: 'cookie', url: 'https://www.jd.com'}) + '\n'))
            s.on('data', d => {
                buf += d
                if (buf.includes('\n') && !done) {
                    done = true
                    s.end()
                    try { resolve(JSON.parse(buf.trim())) } catch (e) { resolve({err: 'parse:' + buf.slice(0, 80)}) }
                }
            })
            s.on('error', e => resolve({err: String(e).slice(0, 80)}))
            setTimeout(() => { if (!done) { s.destroy(); resolve({err: 'timeout'}) } }, 8000)
        })
    }

    islogin(ckStr) {
        return new Promise(resolve => {
            const rq = https.get('https://plogin.m.jd.com/cgi-bin/ml/islogin', {headers: {cookie: ckStr, 'user-agent': UA}}, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d).islogin == 1) } catch (e) { resolve(false) } })
            })
            rq.on('error', () => resolve(false))
            rq.setTimeout(10000, () => { rq.destroy(); resolve(false) })
        })
    }

    // execFile 调 a2local.mjs 解密 wjlogin prefs, 工具自己写 jdUser.ini
    a2Sync() {
        return new Promise(resolve => {
            const env = {...process.env, LD_LIBRARY_PATH: path.join(BASE, '../lib')}
            execFile('/data/user/0/com.psyduck.jdtask/files/rt/node',
                [A2LOCAL, '/data/data/com.psyduck.jdtask/files/jd_users.xml', BASE], {timeout: 20000, env}, (err, stdout, stderr) => {
                resolve({err, out: String(stdout || '') + String(stderr || '')})
            })
        })
    }

    async main(p) {
        let synced = false

        // ---- 1. pt_key 实时同步 (RPC 桥) ----
        const rpc = await this.rpcCookie()
        if (rpc && !rpc.err) {
            const rpcCk = typeof (rpc.cookie || rpc.data) === 'string' ? (rpc.cookie || rpc.data) : JSON.stringify(rpc.cookie || rpc.data)
            const rpcPtKey = (rpcCk.match(/pt_key=([^;\s"]+)/) || ['', ''])[1]
            const rpcPin = (rpcCk.match(/pt_pin=([^;\s"]+)/) || ['', ''])[1]
            if (rpcPtKey && (!rpcPin || rpcPin === 'jd_48ab91a646392')) {
                const txt = fs.readFileSync(CK_INI, 'utf8')
                let cur = '', iniCk = ''
                for (const ln of txt.split(/\r?\n/)) {
                    const m = ln.match(/^\[(.+)\]$/)
                    if (m) { cur = m[1]; continue }
                    if (cur === 'main' && ln.includes('pt_key=')) { iniCk = ln.trim(); break }
                }
                const iniPtKey = (iniCk.match(/pt_key=([^;\s]+)/) || ['', ''])[1]
                if (rpcPtKey !== iniPtKey) {
                    const rpcFull = iniCk.replace(/pt_key=[^;]+/, 'pt_key=' + rpcPtKey)
                    if (await this.islogin(rpcFull)) {
                        const tmp = CK_INI + '.tmp'
                        fs.writeFileSync(tmp, txt.replace(iniCk, rpcFull))
                        fs.renameSync(tmp, CK_INI)
                        p.log(`pt_key已刷新: ${iniPtKey.slice(0, 16)}... -> ${rpcPtKey.slice(0, 16)}...`)
                        synced = true
                    } else {
                        p.log('RPC新pt_key验活失败, 不写回')
                    }
                } else {
                    p.log('pt_key已是最新')
                }
            }
        } else {
            p.log('RPC不可达(京东App未运行/桥未起): ' + (rpc && rpc.err || ''))
        }

        // ---- 2. wskey 实时同步 (a2local.mjs 解密 wjlogin prefs) ----
        try {
            const before = (fs.readFileSync(USER_INI, 'utf8').match(/wskey=([^\n\r]*)/) || ['', ''])[1]
            const a2 = await this.a2Sync()
            if (a2.err) {
                p.log('a2local执行失败: ' + String(a2.err.message || a2.err).slice(0, 80))
            } else {
                const after = (fs.readFileSync(USER_INI, 'utf8').match(/wskey=([^\n\r]*)/) || ['', ''])[1]
                if (after && after !== before) {
                    p.log(`wskey已同步(a2local): ${after.slice(0, 12)}...`)
                    synced = true
                } else if (after) {
                    p.log('wskey已是最新(a2local)')
                } else {
                    p.log('a2local未解出wskey: ' + a2.out.slice(0, 60).replace(/\s+/g, ' '))
                }
            }
        } catch (e) {
            p.log('wskey同步异常: ' + String(e.message).slice(0, 60))
        }

        if (synced) p.info.work = true
        p.msg('实时凭据保活OK (pt_key=RPC桥, wskey=a2local)')
    }
}
