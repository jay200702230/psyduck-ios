import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const BH_PAGE = 'https://pro.m.jd.com/'
const BH_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东领京豆',
            turn: 2,
            crontab: 3,
            model: 'user'
        }
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _bhCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._bhCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容两种形态: form 型(bff) 与 client.action 型(body 在 URL query 上, jsonp 响应)
    async beanCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!form && !u.includes('functionId=')) return null
        if (!this._bhSigner) {
            try { this._bhSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._bhSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._bhSigner.sign({
            functionId: fn, body: bodyObj, ck,
            appId: (opts && opts.algo && opts.algo.appId) || undefined,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'apple', clientVersion: getv('clientVersion') || '15.5.15'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: (opts && opts.referer) || BH_PAGE, 'user-agent': BH_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        // jsonp 剥壳: jsonp_xxx({...})
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async prepare() {
        let feeds = await this.beanCurl({
                'url': `https://api.m.jd.com/client.action?functionId=homeFeedsList&body={"page":1,"appid":"fd4bb","needSecurity":true,"bizId":"active","pageId":"JingDou_SceneHome"}&appid=signed_wh5&client=apple&clientVersion=11.8.2&networkType=wifi&osVersion=11.4&screen=320*504&uuid=434e858e755c9b1ec6e6d6abc0348d9b6d985300&openudid=434e858e755c9b1ec6e6d6abc0348d9b6d985300&d_model=iPhone8,4`,
                algo: {
                    appId: "fd4bb",
                }
            }
        )
        if (this.haskey(feeds, 'data.feedsList')) {
            this.code = (this.column(feeds.data.feedsList, 'skuId'))
        }
        else {
            this.code = [
                '100124947609',
                '10113472733713',
                '10111336292831',
                '100043430641',
                '100061222266',
                '100042916006',
                '100072438118',
                '100116209250',
                '100135636960',
                '100010459381'
            ]
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        if (this.turnCount == 1) {
            let uuid = this.md5(user)
            for (let i of this.code) {
                let task = await this.beanCurl({
                        url: `https://api.m.jd.com/client.action?functionId=beanHomeTask&body={"skuId":"${i}","awardFlag":false,"type":"1","source":"feeds","scanTime":${new Date().getTime()}}&appid=ld&client=apple&clientVersion=12.3.4&networkType=wifi&osVersion=15.1.1&loginType=2&screen=390*753&uuid=${uuid}&openudid=${uuid}&d_model=iPhone13,3&jsonp=jsonp_1691746000054_62149`,
                        user,
                        algo: {
                            expire: {
                                code: "3"
                            }
                        }
                    }
                )
                const progress = this.haskey(task, 'data.taskProgress')
                const threshold = this.haskey(task, 'data.taskThreshold')
                // 浏览做满(或 HT203 次数上限=已做满) 且 awardStatus=false → 补领奖
                // taskProgress/taskThreshold 为空串(风控软拒畸形返回)时不得判满, 否则领奖必报"用户未登录"
                const pv = String(progress === undefined ? '' : progress)
                const tv = String(threshold === undefined ? '' : threshold)
                const full = (pv !== '' && tv !== '' && pv == tv && !this.haskey(task, 'data.awardStatus'))
                const ht203 = String(this.haskey(task, 'errorCode') || '') === 'HT203'
                if (ht203) {
                    // HT203=浏览次数超上限, 本sku无奖可领, 领奖必报HT101, 直接跳过
                    p.log('浏览已做满(HT203), 本sku无奖可领, 跳过')
                    p.info.work = true
                    break
                }
                if (full) {
                    p.log(`浏览任务完成[${progress === undefined ? '?' : progress}/${threshold === undefined ? '?' : threshold}],正在抽奖`)
                    // 领奖必须带上 skuId/type/scanTime, 只发 awardFlag 会报 HT101 配置参数为空
                    let reward = await this.beanCurl({
                            'url': `https://api.m.jd.com/client.action?functionId=beanHomeTask&body=${this.dumps({
                                "skuId": i,
                                "awardFlag": true,
                                "type": "1",
                                "source": "feeds",
                                "scanTime": new Date().getTime()
                            })}&appid=ld&client=apple&clientVersion=12.3.4&networkType=wifi&osVersion=15.1.1&loginType=2&screen=390*753&uuid=${uuid}&openudid=${uuid}&d_model=iPhone13,3&jsonp=jsonp_1691746000054_62149`,
                            user
                        }
                    )
                    if (this.haskey(reward, 'data')) {
                        p.info.work = true
                        if (reward.data.beanNum) {
                            // p.msg(`京豆: ${reward.data.beanNum}`)
                            p.award(reward.data.beanNum, 'bean')
                        }
                        else {
                            p.log('领奖返回:', this.dumps(reward.data).slice(0, 100))
                        }
                    }
                    else {
                        p.log('领奖失败:', this.haskey(reward, 'errorMessage') || this.dumps(reward).slice(0, 100))
                    }
                    break
                }
                if (!this.haskey(task, 'data')) {
                    p.log(this.haskey(task, 'errorMessage'))
                    if (this.haskey(task, "errorCode", ['HT201', 'HT205'])) {
                        p.info.work = true
                    }
                    break
                }
                p.log(`正在浏览任务[${progress}/${threshold}]`)
                await this.wait(2000)
            }
        }
        else {
            // 签到日历「点一下」真报文: beanRewardNode + assignmentId=1 + actionType=0 (页面 25xqCA 楼层 00041489 解密)
            // 旧 beanDailySign/VdbAAQEQ 那套是任务列表上报, 不发豆, 已废弃
            const signBody = {scene: 'commonDoInteractiveAssignment', activityCode: 'beanRewardNode', businessScenario: 'jingDouCenter', assignmentId: '1', actionType: '0', itemId: ''}
            let sign = await this.beanCurl({
                    'form': `functionId=bff_rightsCenter_interaction&body=${encodeURIComponent(JSON.stringify(signBody))}&appid=plus_business&client=android&clientVersion=15.10.50`,
                    user,
                    referer: 'https://pro.m.jd.com/mall/active/25xqCADVDNAd1wTHojZv2p37yKBG/index.html',
                    algo: {
                        appId: '90b26'
                    }
                }
            )
            if (this.haskey(sign, 'code', '0') || sign && sign.code === 0) {
                p.info.work = true
                p.log("签到成功")
                if (this.haskey(sign, 'rs.rewardsInfo.successRewards')) {
                    for (let [k, v] of Object.entries(sign.rs.rewardsInfo.successRewards)) {
                        if (k == "3") {
                            p.award(v[0].quantity, 'bean')
                        }
                        else if (k == "4") {
                            p.award(v[0].discount, 'redpacket')
                        }
                        else if (k == '8') {
                            p.log(v[0].useRange, '优惠券')
                        }
                    }
                }
            }
            else if (this.haskey(sign, 'code', ['1711001', '1711002', '103', '104', '3101'])) {
                p.info.work = true
                p.log('你已经签到过啦')
            }
            else {
                // 限流/异常时只打一句话术, 不 dump 原始响应(避免 msg/displayMsg 噪音)
                p.log('签到:', this.haskey(sign, 'msg') || this.haskey(sign, 'errMsg') || this.dumps(sign).slice(0, 80))
            }
            // 限时惊喜 15京豆: 特价频道试用tab横幅 (newtry common_do_task, h5st appId=35fa0)
            // 两步: queryReceiveTimes 查可领状态 → doReceiveRewards 领取
            const ntryBase = {
                channelId: '20', itemId: '1',
                assignmentId: '3c2cBQA7BDeyEbJCzmPx18gfnGcA',
                actionType: '0',
                extMap: {sceneType: 1, babelChannel: 'ttt63'}
            }
            const ntryFid = 'functionId=common_do_task&appid=newtry&client=android&clientVersion=15.10.50'
            const ntryRef = 'https://pro.m.jd.com/mall/active/G7sQ92vWSBsTHzk4e953qUGWQJ4/index.html?babelChannel=ttt63&has_native=0&father=tj&linkTag=shiyong'
            let ntry = await this.beanCurl({
                    form: `${ntryFid}&body=${encodeURIComponent(JSON.stringify({...ntryBase, ext: {queryReceiveTimes: 1}}))}`,
                    user,
                    referer: ntryRef,
                    algo: {appId: '35fa0'}
                }
            )
            const nCan = this.haskey(ntry, 'data.result.assignmentResult.assignmentInfo.canAddReceiveTimes')
            if (nCan) {
                let ntryRecv = await this.beanCurl({
                        form: `${ntryFid}&body=${encodeURIComponent(JSON.stringify({...ntryBase, ext: {queryReceiveTimes: 1, doReceiveRewards: 1}}))}`,
                        user,
                        referer: ntryRef,
                        algo: {appId: '35fa0'}
                    }
                )
                const rw = this.haskey(ntryRecv, 'data.result.assignmentResult.rewardsInfo.successRewards')
                if (rw) {
                    for (let [rk, rv] of Object.entries(rw)) {
                        for (let it of rv) p.award(it.quantity, 'bean')
                    }
                    p.log('限时惊喜领取成功')
                }
                else {
                    p.log('限时惊喜:', this.haskey(ntryRecv, 'data.bizMsg') || this.dumps(ntryRecv).slice(0, 100))
                }
            }
            else {
                p.log('限时惊喜:', this.haskey(ntry, 'data.bizMsg') || '今日无可领')
            }
        }
    }
}
