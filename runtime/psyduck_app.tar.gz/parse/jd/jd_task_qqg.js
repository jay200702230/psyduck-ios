import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import https from 'https'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/3kJySXAsWt6yaACgabnBPAMwde2K/index.html'
const LINKID = 'DK5AKix94Val24r4_XsEmQ'
const AREA = '16_1315_3486_59642'
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '全球购签到互动福利', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    // h2 会话: acb1e 网关校验传输层指纹, h1.1 一律 403 (2026-10-23 实测)
    _h2() {
        if (this._h2s && !this._h2s.destroyed && this._h2s.closeCode === undefined) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // activities_platform 族: 六参数 slim 签名 (与 webview signSync 对齐) + h2 传输
    // 域码: apTaskList/apTaskDetail/apDoLimitTimeTask=ebecc, apStartTaskTime=acb1e(appid=activity_platform_se),
    //       apsDoTask=54ed7, apTaskDrawAward=f0f3f, inviteFissionHome=eb67b/Poll=b3f11/DrawPrize=c02c6
    async wg(p, user, fn, bodyObj, algo, retries, opts) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) { p.log('no signer'); return null }
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const appid = (opts && opts.appid) || 'activities_platform'
                const signed = this._wgSigner.sign({
                    functionId: fn, body: bodyObj, ck,
                    base: {appid, client: 'android', clientVersion: '15.10.50'},
                    appId: algo, slim: true
                })
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('platform', '3'); f.append('loginType', '2'); f.append('loginWQBiz', 'wegame')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({
                            ':method': 'POST', ':path': '/api?functionId=' + fn,
                            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'content-length': String(Buffer.byteLength(post)),
                            cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE,
                            'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'
                        })
                    } catch (e) {
                        try { s.close() } catch (e2) {}
                        this._h2s = null
                        return fin(null)
                    }
                    let d = ''
                    st.on('response', h => { if (h[':status'] !== 200) p.log('[dbg]', fn, 'st=' + h[':status'], d.slice(0, 100)) })
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { p.log('[dbg]', fn, 'h2err ' + String(e).slice(0, 80)); try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(3000 * k)
        }
        return null
    }

    async rawGet(p, user, url, referer) {
        if (!url) return
        try {
            for (let hop = 0; hop < 2 && url; hop++) {
                const out = await new Promise(resolve => {
                    const u = new URL(url)
                    const rq = https.request({
                        hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
                        headers: {cookie: this._ckForUser(user), 'user-agent': UA, referer: referer || W_PAGE, accept: 'text/html,*/*'}
                    }, rs => {
                        rs.resume()
                        rs.on('end', () => resolve({status: rs.statusCode, loc: rs.headers.location || ''}))
                    })
                    rq.on('error', () => resolve({status: 0, loc: ''}))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve({status: 0, loc: ''}) })
                    rq.end()
                })
                if (out.status === 302 && out.loc) { url = new URL(out.loc, url).href; referer = url } else { url = '' }
            }
        } catch (e) {}
    }

    // 拉单个任务的 item 列表 (apTaskList 里 taskItemList 可能为空)
    async _items(p, user, t) {
        let items = (t.taskItemList || []).filter(x => x && x.itemId)
        if (items.length) return items
        const d = await this.wg(p, user, 'apTaskDetail', {linkId: LINKID, taskId: t.id}, 'ebecc', 1)
        const info = (d && d.data && (d.data.taskInfoVO || d.data)) || {}
        items = (info.taskItemList || []).filter(x => x && x.itemId)
        return items
    }

    // BROWSE_CHANNEL 纯协议引擎: 受理(acb1e)→等计时→doLimitTimeTask 收判; tls=0 走 apsDoTask(54ed7)
    async doBrowseTask(p, user, t) {
        const items = await this._items(p, user, t)
        if (!items.length) { p.log('  无落地页, 跳过:', t.taskShowTitle || t.taskTitle || t.id); return }
        const tls = t.timeLimitSwitch
        const tlp = t.timeLimitPeriod || 3
        const assign = t.pipeExt && t.pipeExt.assignmentId
        let done = 0
        let rounds = Math.max(1, (t.taskLimitTimes || 1) - (t.taskDoTimes || 0))
        for (let rnd = 0; rnd < rounds + 2; rnd++) {
            if (done >= rounds) break
            const it = items[rnd % items.length]
            const pipe = {taskType: t.taskType, timeLimitSwitch: (it.pipeExt && it.pipeExt.timeLimitSwitch != null) ? it.pipeExt.timeLimitSwitch : tls, itemId: it.pipeExt && it.pipeExt.itemId, assignmentId: assign}
            const itemEnc = encodeURIComponent(it.itemId)
            let ok = false
            if (tls === 1 || tls === 2) {
                const st = await this.wg(p, user, 'apStartTaskTime', {linkId: LINKID, taskId: t.id, itemId: itemEnc, taskInsert: false, channel: 4, pipeExt: pipe, actFlowCode: 'apStartTaskTime'}, 'acb1e', 1, {appid: 'activity_platform_se'})
                const stc = st ? String(st.code) : 'null'
                if (stc !== '0') {
                    p.log('  受理(' + stc + ' ' + String(st && st.errMsg).slice(0, 20) + '), 退避重试')
                    this._fails++
                    await this.wait(stc === '2024' ? 8000 : 45000)
                    continue
                }
                await this.wait(Math.max(6500, tlp * 1000 + 3000))
                const lt = await this.wg(p, user, 'apDoLimitTimeTask', {linkId: LINKID, actFlowCode: 'apDoLimitTimeTask'}, 'ebecc', 1)
                const dd = (lt && lt.data) || {}
                ok = dd.finished === true || dd.alreadyGranted === true
                if (lt && String(lt.code) === '2024') { await this.wait(8000); continue }
                if (!ok && lt && String(lt.code) !== '0' && String(lt.code) !== '2031') this._fails++
                p.log('  r' + (rnd + 1) + ' 收判:', lt ? (lt.code + ' finished=' + dd.finished + ' 奖=' + JSON.stringify(dd.awardInfo || null).slice(0, 80)) : '空响应')
            } else {
                const st = await this.wg(p, user, 'apsDoTask', {taskType: t.taskType, taskId: t.id, channel: 4, checkVersion: true, linkId: LINKID, pipeExt: pipe, itemId: itemEnc, actFlowCode: 'apDoTask'}, '54ed7', 1)
                const stc = st ? String(st.code) : 'null'
                ok = stc === '0'
                if (stc === '2005' || stc === '2018') { await this.wait(50000); continue }
                if (!ok) this._fails++
                p.log('  r' + (rnd + 1) + ' apsDoTask:', stc, String(st && st.errMsg).slice(0, 24))
                await this.wait(12000)
            }
            if (ok) done++
            await this.wait(9000)
            const chk = await this.wg(p, user, 'apTaskList', {linkId: LINKID}, 'ebecc', 1)
            const me = ((chk && chk.data) || []).find(x => x.id === t.id)
            if (!me) { p.log('  任务已从池中消失(完成)'); done = rounds; break }
            if (me.taskFinished) { p.log('  状态: 已完成 ' + me.taskDoTimes + '/' + me.taskLimitTimes); done = rounds; break }
            if (me.taskDoTimes != null && (me.taskDoTimes || 0) >= (me.taskLimitTimes || 1)) { p.log('  状态: 次数已满待判定'); done = rounds; break }
            p.log('  状态: do=' + me.taskDoTimes + '/' + me.taskLimitTimes)
        }
        // 领奖
        const chk = await this.wg(p, user, 'apTaskList', {linkId: LINKID}, 'ebecc', 1)
        const me = ((chk && chk.data) || []).find(x => x.id === t.id)
        if (me && +me.canDrawAwardNum > 0) {
            const cr = await this.wg(p, user, 'apTaskDrawAward', {taskType: t.taskType, taskId: t.id, channel: 4, checkVersion: true, linkId: LINKID, pipeExt: me.pipeExt || {}, actFlowCode: 'apTaskDrawAward'}, 'f0f3f', 1)
            p.log('  领奖:', cr ? (cr.code + ' ' + String(cr.errMsg).slice(0, 30)) : '空响应')
        }
        return done > 0
    }

    // 抽奖: inviteFission 族; 80202 会吞次数, 重试一次即停
    async drawAll(p, user) {
        const home = await this.wg(p, user, 'inviteFissionHome', {linkId: LINKID}, 'eb67b', 2)
        if (!home) { p.log('  抽奖home失败'); return }
        const chance = (home.data && home.data.prizeNum) || 0
        p.log('  抽奖机会:', chance)
        let n = 0
        while (n < chance && n < 10) {
            await this.wg(p, user, 'inviteFissionPoll', {linkId: LINKID}, 'b3f11', 1)
            const r = await this.wg(p, user, 'inviteFissionDrawPrize', {linkId: LINKID, area: AREA}, 'c02c6', 1)
            const dd = (r && r.data) || {}
            if (r && String(r.code) === '80202') {
                p.log('  80202 限流, 12s 后重试一次')
                await this.wait(12000)
                const r2 = await this.wg(p, user, 'inviteFissionDrawPrize', {linkId: LINKID, area: AREA}, 'c02c6', 1)
                if (r2 && String(r2.code) === '80202') { p.log('  仍限流, 停止保护剩余次数'); break }
                n++
                continue
            }
            n++
            p.log('  抽奖#' + n + ':', r ? JSON.stringify(r).slice(0, 200) : '空响应')
            await this.wait(5000)
        }
    }

    async main(p) {
        let user = p.data.user
        await this.rawGet(p, user, W_PAGE, 'https://pro.m.jd.com/')
        await this.wait(2000)
        const list = await this.wg(p, user, 'apTaskList', {linkId: LINKID}, 'ebecc', 2)
        const tasks = (list && list.data) || []
        if (!Array.isArray(tasks) || !tasks.length) { p.log('任务池空或限流:', JSON.stringify(list).slice(0, 150)); return }
        const pend = tasks.filter(t => !t.taskFinished && ['BROWSE_CHANNEL', 'EXTERNAL_BROWSE'].includes(t.taskType))
        p.log('任务 ' + tasks.length + ' 个, 未完成浏览 ' + pend.length + ' 个')
        for (const t of pend) {
            const award = (t.configBaseList || [])[0]
            p.log('做:', t.id, t.taskShowTitle || t.taskTitle, '| 奖:', award ? (award.awardName + 'x' + award.awardGivenNumber) : '?', '| tls=' + t.timeLimitSwitch)
            await this.doBrowseTask(p, user, t)
            await this.wait(6000)
        }
        p.log('抽奖:')
        await this.drawAll(p, user)
        if (this._fails > 0) {
            p.log('存在 ' + this._fails + ' 个失败项, 本轮不写缓存, 下轮重试')
            p.info.work = false
        } else {
            p.info.work = true
        }
    }
}
