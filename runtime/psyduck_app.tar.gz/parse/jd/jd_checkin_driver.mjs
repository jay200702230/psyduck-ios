import fs from 'fs'
import path from 'path'

const CKDIR = '/ql/data/psyduck/ck_full'
const ini = fs.readFileSync('/ql/data/psyduck/cookie/jd.ini', 'utf8')

// 账号源 1: jd.ini (续期链自动刷新)
const acc = new Map()
for (const ln of ini.split(/\r?\n/)) {
    if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
        const pm = ln.match(/pt_pin=([^;\s]+)/)
        if (pm) {
            let pin = pm[1]
            try { pin = decodeURIComponent(pin) } catch (e) {}
            if (!acc.has(pin)) acc.set(pin, ln.trim())
        }
    }
}
// 账号源 2: ck_full/*.txt 手动全量覆盖 (文件名=pin, 优先级最高)
try {
    for (const f of fs.readdirSync(CKDIR)) {
        if (!f.endsWith('.txt')) continue
        const pin = decodeURIComponent(f.replace('.txt', ''))
        const line = fs.readFileSync(path.join(CKDIR, f), 'utf8').trim()
        if (line.includes('pt_key=')) acc.set(pin, line)
    }
} catch (e) {}

console.log('[driver] accounts:', [...acc.keys()].join(','))

const target = process.argv[2] || 'jd_task_checkin'
console.log('[driver] target:', target)
const {Main} = await import('/ql/data/psyduck/parse/jd/' + target + '.js')
for (const [pin, ck] of acc) {
    console.log('===== 账号:', pin, '(ck len', ck.length + ')')
    const m = new Main()
    m._ckOverride = ck
    const p = {log: (...a) => console.log('[P]', ...a), data: {user: pin}, context: {}, info: {}}
    try {
        await m.main(p)
    } catch (e) {
        console.log('[driver] 账号异常:', String(e).slice(0, 200))
    }
    await new Promise(r => setTimeout(r, 5000))
}
console.log('[driver] ALL-DONE')
