import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

// 京东「京豆抵现金」频道任务 (2026-10-22 真机抓包 LSPosed jd_net_dump)
// 列表: common_task_list  body={"ext":{"queryReceiveTimes":1},"extMap":{"sceneType":2},"channelId":"8"}
// 上报: common_do_task    body={"channelId":"8","itemId":"1","assignmentId":"...","actionType":0,"ext":{"doReceiveRewards":null|1}}
// 签名: h5st 5.3 (appid=Bigsale), referer=pro.m.jd.com/mall/active/3b86xJ8EVja357au9NNG6ZSeV3Fw
const DY_PAGE = 'https://pro.m.jd.com/mall/active/3b86xJ8EVja357au9NNG6ZSeV3Fw/index.html'
const DY_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东京豆抵现金',
            pageUrl: DY_PAGE,
            headers: {referer: DY_PAGE},
            turn: 1,
            crontab: 3
        }
    }

    _dyCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._dyCk()
    }

    // h5st 自签名直连 api.m.jd.com (同 beanBrowse bbCurl 模式)
    async dyCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._dySigner) {
            try { this._dySigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._dySigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._dySigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'Bigsale', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: DY_PAGE, 'user-agent': DY_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    dumps(o) { return JSON.stringify(o) }

    // 任务列表, 限流退避重试
    async fetchTasks(p, user) {
        const body = {ext: {queryReceiveTimes: 1}, extMap: {sceneType: 2}, channelId: '8'}
        for (let i = 1; i <= 3; i++) {
            const r = await this.dyCurl({
                'url': `https://api.m.jd.com/api?functionId=common_task_list`,
                'form': `appid=Bigsale&functionId=common_task_list&body=${encodeURIComponent(this.dumps(body))}&client=android&clientVersion=15.10.50&loginType=2&xAPIClientLanguage=zh_CN&d_brand=OnePlus&d_model=IN2010`,
                user
            })
            const code = String((r && r.code) || '')
            if (r && (r.data || r.result || r.taskList || (r.code === 0 || code === '0'))) return r
            if (code == '1714001' || code == '1714002' || !r || /火爆|稍后再试/.test(this.dumps(r || {}).slice(0, 400))) {
                p.log(`列表限流/空响应(${code || 'null'}), 第${i}次退避...`)
                await this.wait(8000 * i)
                continue
            }
            p.log('任务列表获取失败:', this.dumps(r || {}).slice(0, 200))
            return null
        }
        p.log('任务列表持续限流, 本轮跳过')
        return null
    }

    // 实锤响应结构(2026-10-22 青龙首跑): r.data.result.taskInfo.taskList (四层) — 递归搜 taskList 数组
    pickTasks(r) {
        let out = []
        const walk = (o, depth) => {
            if (!o || typeof o !== 'object' || Array.isArray(o) || depth > 5 || out.length) return
            for (const k in o) {
                const v = o[k]
                if (Array.isArray(v) && (k === 'taskList' || k === 'tasks' || k === 'assignmentList')) { out = v; return }
                if (v && typeof v === 'object') walk(v, depth + 1)
                if (out.length) return
            }
        }
        walk(r, 0)
        return out
    }

    // 信封校验: code=0 且 data.bizCode=0(存在时)
    okResp(r) {
        if (!r || String(r.code) !== '0') return false
        const d = r.data
        if (d && d.bizCode !== undefined && String(d.bizCode) !== '0') return false
        return true
    }

    pickItemId(t) {
        const ext = t.ext || {}
        const arr = ext.itemInfoList || ext.productsInfo || ext.shoppingActivity || ext.followShop || ext.browseShop || []
        return String(ext.itemId || t.itemId || (arr[0] && (arr[0].itemId || arr[0].shopId)) || ext.shopId || t.shopId || '1')
    }

    // 第 idx 次浏览的 itemId (idx 从 0 计): 商品数组按序取, 否则用浏览序号 1,2,3... (抓包实锤 itemId="1" 为序号型)
    pickItemIdN(t, idx) {
        const ext = t.ext || {}
        const arr = ext.itemInfoList || ext.productsInfo || ext.shoppingActivity || []
        if (arr.length && arr[0] && (arr[0].itemId || arr[0].skuId || arr[0].shopId)) {
            const it = arr[Math.min(idx, arr.length - 1)]
            return String(it.itemId || it.skuId || it.shopId || idx + 1)
        }
        return String(idx + 1)
    }

    // do_task 上报: atype=0 浏览上报 / 1 领取任务(isManualReceiveTask), ext.doReceiveRewards=1 领奖
    async doTask(p, user, asgId, itemId, reward, atype) {
        const body = {channelId: '8', itemId: String(itemId || '1'), assignmentId: asgId, actionType: atype || 0, ext: {doReceiveRewards: reward ? 1 : null}}
        for (let k = 1; k <= 3; k++) {
            const r = await this.dyCurl({
                'url': `https://api.m.jd.com/api?functionId=common_do_task`,
                'form': `appid=Bigsale&functionId=common_do_task&body=${encodeURIComponent(this.dumps(body))}&client=android&clientVersion=15.10.50&loginType=2&xAPIClientLanguage=zh_CN&d_brand=OnePlus&d_model=IN2010`,
                user
            })
            const code = String((r && r.code) || '')
            if (code == '1714001' || code == '1714002') {
                p.log(`  上报限流(${code}), 第${k}次退避...`)
                await this.wait(8000 * k)
                continue
            }
            return r
        }
        return null
    }

    // 领奖(带限流退避): bizCode -100/-101 参与人数多 → 20s/40s 退避重试
    async claimRetry(p, user, asgId, itemId) {
        for (let k = 0; k < 3; k++) {
            if (k) {
                p.log(`  领奖限流, 退避${20 * k}s后重试...`)
                await this.wait(20000 * k)
            }
            const a = await this.doTask(p, user, asgId, itemId, true)
            if (this.okResp(a)) return a
            const msg = (a && a.data && a.data.bizMsg) || ''
            if (!/人数|火爆|稍后/.test(msg)) return a
        }
        return null
    }

    async main(p) {
        const user = p.data.user
        const r = await this.fetchTasks(p, user)
        if (!r) return
        const tasks = this.pickTasks(r)
        if (!tasks.length) {
            p.log('任务池为空或结构未识别, 原始响应头300字符:', this.dumps(r).slice(0, 300))
            return
        }
        p.log(`任务池 ${tasks.length} 个`)
        let done = 0, fail = 0
        for (const t of tasks) {
            const asgId = t.encryptAssignmentId || t.assignmentId || t.id
            const name = t.assignmentName || t.taskName || t.name || asgId
            if (!asgId) continue
            const finished = t.completionFlag == 1 || t.finished == 1
            const canRecv = t.canReceiveTimes !== undefined ? +t.canReceiveTimes : (t.canReceive ? 1 : 0)
            const limit = +(t.assignmentTimesLimit || 1)
            const cur = +(t.completionCnt || 0)
            p.log(`- ${name} id=...${String(asgId).slice(-6)} type=${t.assignmentType} done=${t.completionFlag} recv=${canRecv} times=${cur}/${limit}`)
            if (!t.completionFlag && (t.assignmentType == 9 || !t.ext)) p.log(`  ext样本: ${this.dumps(t).slice(0, 280)}`)
            if (finished && canRecv <= 0) continue
            if (fail >= 3) { p.log('连续限流3次, 本轮放弃'); break }
            // 已完成待领奖
            if (finished && canRecv > 0) {
                const c = await this.claimRetry(p, user, asgId, this.pickItemId(t))
                if (c && this.okResp(c)) { p.log(`  完成: ${name}`); done++ } else fail++
                await this.wait(4000)
                continue
            }
            // 多次浏览型任务(如逛2个商品): 按 timesLimit 循环上报 itemId 序号, 再领奖
            let browsed = 0, claimed = false
            for (let i = cur; i < limit; i++) {
                const itemId = this.pickItemIdN(t, i)
                let a = await this.doTask(p, user, asgId, itemId, false)
                let biz = a && a.data ? String(a.data.bizCode) : ''
                let msg = (a && a.data && a.data.bizMsg) || ''
                if (biz === '107') {
                    p.log(`  浏览${i + 1}: 任务未领取, 先领取...`)
                    const c = await this.doTask(p, user, asgId, itemId, false, 1)
                    if (!this.okResp(c)) { p.log(`  领取失败: ${this.dumps(c || {}).slice(0, 100)}`); break }
                    await this.wait(2000)
                    a = await this.doTask(p, user, asgId, itemId, false)
                    biz = a && a.data ? String(a.data.bizCode) : ''
                    msg = (a && a.data && a.data.bizMsg) || ''
                }
                if (biz === '105') { p.log(`  浏览${i + 1}: itemId不支持, 跳过任务`); break }
                if (!this.okResp(a)) {
                    if (!a || /人数|火爆|稍后/.test(msg)) {
                        p.log(`  浏览${i + 1} 限流: ${msg || '空响应'}`)
                        fail++
                        await this.wait(8000)
                    } else {
                        p.log(`  浏览${i + 1} 失败: ${msg || this.dumps(a || {}).slice(0, 100)}`)
                    }
                    if (fail >= 3) break
                    continue
                }
                browsed++
                const waitSec = +((t.ext && t.ext.waitDuration) || t.waitDuration || 8)
                if (waitSec > 0 && waitSec < 60) await this.wait((waitSec + 2) * 1000)
            }
            if (browsed > 0 || cur >= limit) {
                const c2 = await this.claimRetry(p, user, asgId, this.pickItemId(t))
                if (c2 && this.okResp(c2)) {
                    const got = (c2.data && c2.data.result && (c2.data.result.rewardsInfo || c2.data.result.bizMsg)) || ''
                    p.log(`  完成: ${name} ${this.dumps(got).slice(0, 120)}`)
                    done++
                } else {
                    const msg = (c2 && c2.data && c2.data.bizMsg) || ''
                    if (/人数|火爆|稍后/.test(msg) || !c2) fail++
                    p.log(`  最终未领到: ${name} ${this.dumps((c2 && c2.data) || {}).slice(0, 100)}`)
                }
            }
            await this.wait(4000)
        }
        p.log(`本轮完成 ${done} 个`)
    }
}
