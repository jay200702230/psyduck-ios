import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东关注店铺领京豆',
            sync: 1,
            display: true,
            tempExpire: 8640000,
            verify: 1,
            crontab: `${this.rand(5, 10)},${this.rand(35, 40)} 9-23 * * *`,
            prompt: {
                id: '可使用venderId_shopId_activityId,或者venderId,或3.cn链接,或u.jd.com链接',
            },
            readme: '通过url和venderId获取,可能会获取不到activityId,如想准确获取activityId请自行抓包:venderId,shopId,activityId',
            help: 't3'
        }
    }

    async prepare() {
        await this.field('id')
    }

    async batch(p) {
        if (p.id) {
            if (p.id.split("_").length == 3) {
                let [venderId, shopId, activityId] = p.id.split("_")
                p = {
                    ...p, ...{venderId, shopId, activityId}
                }
            }
            else {
                let url
                let shopId, venderId
                if (!isNaN(p.id)) {
                    venderId = p.id
                }
                else {
                    if (p.id.includes("u.jd.com")) {
                        let j = `https://union-click.jd.com/api?time=1633480440000&url=${p.id}&source=10&type=2&platform=6&token=oFEhgxRz1cKD2AR6sFKBmg--&jdUuid=a3b4e844090b28d5c38e7629af8115172079be5d&appVersion=100720&sourceValue=other`;
                        let s = await this.autoCurl({
                                'url': j,
                            }
                        )
                        if (this.haskey(s, 'url')) {
                            url = decodeURIComponent(s.url)
                        }
                    }
                    else {
                        let j = await this.autoCurl({
                                'url': p.id,
                                maxRedirects: 0,
                                scheme: 'http',
                                response: 'all'
                            }
                        )
                        if (this.haskey(j, 'location')) {
                            url = j.location
                        }
                    }
                }
                if (url) {
                    let query = new URL(url).searchParams
                    shopId = query.get('shopId')
                    venderId = query.get('venderId ')
                }
                if (!(shopId && venderId)) {
                    let info = await this.autoCurl({
                            'url': `https://api.m.jd.com/client.action?functionId=getShopHomeBaseInfo`,
                            'form': `functionId=getShopHomeBaseInfo&body=${this.dumps({
                                shopId,
                                "source": "app-shop",
                                venderId,
                                "sourceRpc": "shop_app_home_home",
                                "RNVersion": "0.72.3",
                                "navigationAbTest": "1"
                            })}&uuid=a68fbedf6e53dad6&client=apple&clientVersion=15.1.53&st=1749714653347&sv=111&sign=d8b3b3c457a791ea5a6dc6ea03b922a3`,
                            algo: {
                                sign: true
                            }
                        }
                    )
                    if (this.haskey(info, 'result.shopInfo')) {
                        venderId = info.result.shopInfo.venderId
                        shopId = info.result.shopInfo.shopId
                        p.shopName = info.result.shopInfo.shopName
                    }
                }
                if (venderId) {
                    for (let user of this.help) {
                        let s = await this.autoCurl({
                                'url': `https://api.m.jd.com/client.action?functionId=getShopHomeActivityInfo`,
                                'form': `avifSupport=0&body=${this.dumps({
                                    "source": "app-shop",
                                    "sourceRpc": "shop_app_home_home",
                                    shopId,
                                    venderId,
                                })}&build=169896&client=apple&clientVersion=15.1.53`,
                                user,
                                algo: {
                                    sign: true
                                }
                            }
                        )
                        if (this.haskey(s, 'result.activityId')) {
                            p.activityId = s.result.activityId
                            p.shopId = shopId
                            p.venderId = venderId
                            break
                        }
                    }
                }
            }
        }
        return p
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let shopId = context.shopId || ''
        let venderId = context.venderId || ''
        let headers = context.headers || {}
        let algo = context.algo || {range: 6}
        let body = {
            "source": "app-shop",
            "displayWidth": "1098.000000",
            "sourceRpc": "shop_app_home_home",
            venderId,
            shopId
        }
        let activityId = context.activityId || await this.getTemp(context.venderId)
        let status = 0
        //
        // if (!activityId) {
        //     var s = await this.autoCurl({
        //             'url': `https://api.m.jd.com/client.action?functionId=getShopHomeActivityInfo`,
        //             'form': `avifSupport=0&body=${this.dumps(body)}&build=169736&client=apple&clientVersion=15.0.20&d_brand=apple`,
        //             user,
        //             algo: {
        //                 sign: true
        //             }
        //         }
        //     )
        //     activityId = this.haskey(s, 'result.giftBagDataResult.activityId') || this.haskey(s, 'result.activityId')
        //     if (activityId) {
        //         await this.setTemp(venderId, activityId)
        //     }
        // }
        if (activityId) {
            let body2 = {
                "follow": 0,
                "activityId": activityId.toString(),
                "sourceRpc": "shop_app_home_window",
                shopId: shopId.toString(),
                venderId: venderId.toString()
            }
            let drawShopGift = await this.autoCurl({
                'url': 'https://api.m.jd.com/client.action?g_ty=ls&g_tk=518274330',
                'form': `functionId=whx_drawShopGift&body=${this.dumps(body2)}&t=1670345201521&appid=wx_mini_app&clientVersion=11.0.0&client=wh5&uuid=0040a1e96b5d357ae888a0f18bb23968`,
                user,
                headers: {
                    'referer': 'https://servicewechat.com/wx91d27dbf599dff74/747/page-frame.html',
                    'user-agnet': 'wechat'
                },
                algo: {
                    expire: {
                        "code": "3",
                    }
                }
            })
            if (drawShopGift) {
                status = 1
                // 账号级限流熔断: 连续多个店铺都「活动太火爆」说明被风控软拒, 继续逐个请求只会喂高风控分
                // batch 下每个店铺独立调 main, 计数挂实例上, 中间有成功则重置
                let giftDesc = this.haskey(drawShopGift, 'result.giftDesc') || ''
                let drawStr = typeof drawShopGift === 'string' ? drawShopGift : this.dumps(drawShopGift)
                if (String(giftDesc).includes('活动太火爆') || String(drawStr).includes('活动太火爆')) {
                    this.hotCount = (this.hotCount || 0) + 1
                    p.log(`店铺限流(${this.hotCount}): ${context.shopName || venderId}`)
                    if (this.hotCount >= 3) {
                        p.log("连续3个店铺被限流, 账号被风控软拒, 本轮放弃剩余店铺")
                        throw 'End'
                    }
                    status = 0
                    return
                }
                this.hotCount = 0
                // 礼包每日限量被抢完是常态, 单独标注避免误读成报错; 已抢完时关注领奖无意义但仍完成关注动作
                if (String(giftDesc).includes('抢完') || String(drawStr).includes('抢完')) {
                    p.log(`礼包已抢完: ${context.shopName || venderId}`)
                }
                else {
                    p.log("正在关注", giftDesc || '没有领取到')
                }
                for (let g of this.haskey(drawShopGift, 'result.alreadyReceivedGifts') || []) {
                    if (g.prizeType == 4) {
                        // p.msg(`京豆: ${g.redWord}`)
                        p.award(g.redWord, 'bean')
                    }
                }
                await this.autoCurl({
                    'url': 'https://api.m.jd.com/client.action?g_ty=ls&g_tk=518274330',
                    'form': `functionId=whx_followShop&body={"shopId":"${context.shopId}","follow":"false"}&t=1670345201521&appid=wx_mini_app&clientVersion=11.0.0&client=wh5&uuid=0040a1e96b5d357ae888a0f18bb23968`,
                    user,
                    algo,
                    headers: {
                        'referer': 'https://servicewechat.com/wx91d27dbf599dff74/747/page-frame.html',
                        'user-aget': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.28(0x18001c2e) NetType/WIFI Language/zh_CN'
                    }
                })
            }
        }
        else {
            p.log("没获取到activityId...")
            let unfollow = await this.autoCurl({
                'url': 'https://api.m.jd.com/client.action?g_ty=ls&g_tk=518274330',
                'form': `functionId=whx_followShop&body={"shopId":"${context.shopId}","follow":"false"}&t=1670345201521&appid=wx_mini_app&clientVersion=11.0.0&client=wh5&uuid=0040a1e96b5d357ae888a0f18bb23968`,
                user,
                algo,
                headers: {
                    'referer': 'https://servicewechat.com/wx91d27dbf599dff74/747/page-frame.html',
                    'user-aget': 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.28(0x18001c2e) NetType/WIFI Language/zh_CN'
                }
            })
        }
        if (status) {
            p.info.work = true
        }
    }
}

