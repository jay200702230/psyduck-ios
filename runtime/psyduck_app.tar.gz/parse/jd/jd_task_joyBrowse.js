// 天降京豆浏览任务自动链 (linkId=scp32gzb8n5pl76d4r2ak, Joy 游记子活动)
// 链路(真机抓包 2026-10-26): loadAct -> apStartTaskTime(acb1e/activity_platform_se, 双真token) -> 15s -> apDoLimitTimeTask -> drawPrize
import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const SUB_LK = 'scp32gzb8n5pl76d4r2ak'
const PAGE = 'https://pro.m.jd.com/mall/active/3VeB2YCUT4XLVJKWM3W5wXMA7JXG/index.html?babelChannel=ttt11'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const EID2 = 'jdd03AEJINAIPWUEFEJ7BRW25JIDK447LPR3RIEQYSJT6RSIZF4W2FRZY4HQLDLZ6ETXOCU7AKOILZ6577SK6CKIUE6QHPEAAAANBO5TOKYQAAAAACLFCJN3VNHJVE4X'
const SDK2 = 'jdd01FF574CJP75YTVDSNMW77I4UT3GM76QTSBCFGOVG5B5UI5NIEKQ3TFWEUMP7JEE3PMLPAJBGXYVCE7MMCAG7VVPNA4Q7JVBKR3U5ZL5Y01234567'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '天降京豆浏览', pageUrl: PAGE, headers: {referer: PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        let cur = '', sections = {}
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1].trim(); continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) (sections[cur] ||= []).push(ln.trim())
        }
        // u 是 pin：优先按 pin 的 section 找，找不到回退 main
        for (const sec of [u, 'main']) {
            const arr = sections[sec]
            if (arr && arr.length) {
                const hit = arr.find(l => (l.match(/pt_pin\s*=\s*([^;]+)/) || [])[1] === u)
                if (hit) return hit
                return arr[0]
            }
        }
        return ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed && this._h2s.closeCode === undefined) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    async call(p, user, fn, bodyObj) {
        for (let k = 1; k <= 2; k++) {
            try {
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                if (!this._sg) this._sg = await import('./jd_signer_node.mjs')
                // 域码分离: apStartTaskTime=acb1e/activity_platform_se, 其余 activities_platform
                const algo = fn === 'apStartTaskTime' ? 'acb1e' : 'activities_platform'
                const appid = fn === 'apStartTaskTime' ? 'activity_platform_se' : 'activities_platform'
                const signed = this._sg.sign({functionId: fn, body: bodyObj || {}, ck, base: {appid, client: 'android', clientVersion: '15.10.50'}, appId: algo, slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('platform', '3'); f.append('loginType', '2'); f.append('loginWQBiz', 'wegame')
                f.append('eu', '3303461326131633'); f.append('fv', '2313731633939346'); f.append('eufv', '1'); f.append('cthr', '1')
                f.append('uuid', '3303461326131633-2313731633939346'); f.append('build', '102649'); f.append('screen', '360*800')
                f.append('networkType', 'wifi'); f.append('d_brand', 'OnePlus'); f.append('d_model', 'IN2010')
                f.append('lang', 'zh_CN'); f.append('osVersion', '13'); f.append('partner', 'oppo')
                f.append('xAPIScval2', 'lx')
                f.append('x-api-eid-token', EID2)
                f.append('wg-sdk-token', SDK2)
                f.append('ext', JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': EID2, 'wg-sdk-token': SDK2, pageUrl: PAGE}))
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE, 'x-referer-page': PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', () => { this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => fin(null), 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    static _inner(o) { return (((o || {}).data || {}).data) || {} }

    async main(p) {
        const user = p.data.user
        const home = await this.call(p, user, 'interact_act_invoke', {envType: 1, linkId: SUB_LK, actFlowCode: 'loadAct'})
        const d = Main._inner(home)
        const td = d.taskDetail || {}
        const pe = td.pipeExt || {}
        const items = (td.taskItemList || []).filter(x => x && x.itemId)
        p.log(`loadAct: ${td.taskDoTimes}/${td.taskLimitTimes} | assignmentId=${pe.assignmentId} | items=${items.length}`)
        if (!pe.assignmentId || !items.length) { p.log('无任务数据, 退出'); this._fails++; p.info.work = false; return }
        if (td.taskDoTimes >= td.taskLimitTimes) { p.log('今日次数已满'); p.info.work = true; return }
        await this.wait(2000)

        const it = items[0]
        const st = await this.call(p, user, 'apStartTaskTime', {
            linkId: SUB_LK, taskId: -9999, itemType: String(it.itemType || '1'), itemId: String(it.itemId), channel: 4,
            pipeExt: {taskType: 'BROWSE_RTB', encryptProjectId: pe.encryptProjectId, assignmentId: pe.assignmentId, itemId: (it.pipeExt || {}).itemId || ('null' + Date.now())},
            actFlowCode: 'apStartTaskTime'
        })
        const stc = st && st.data && Number(st.data.code)
        p.log('受理:', stc, String((st && st.data && st.data.errMsg) || '').slice(0, 30))
        if (stc !== 0) { this._fails++; p.info.work = false; return }

        await this.wait(Math.max(15, (td.timeLimitPeriod || 10)) * 1000 + 2000)
        const dor = await this.call(p, user, 'apDoLimitTimeTask', {linkId: SUB_LK, actFlowCode: 'apDoLimitTimeTask'})
        const dd = Main._inner(dor)
        p.log('收判: finished=', dd.finished, '/', dd.finishNeed, dd.alreadyGranted ? '(已发)' : '')
        if (dd.finished) {
            await this.wait(2000)
            const prize = await this.call(p, user, 'interact_act_invoke', {envType: 1, linkId: SUB_LK, actFlowCode: 'drawPrize'})
            p.log('领奖:', JSON.stringify(Main._inner(prize)).slice(0, 150))
        } else if (dor && String(dor.code) === '2031') {
            p.log('计时被服务端吞(风控), 下轮再试')
        }
        p.info.work = this._fails === 0
    }
}
