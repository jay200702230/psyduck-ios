import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const RP_PAGE = 'https://pro.m.jd.com/mall/active/3cBd5nBYb3JkLAcvTbCJ9bYQ8ZbE/index.html'
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

// 静态地理/设备参数 (2026-10-23 抓包实锤)
const AREA = '16-1315-3489-46816'
const GEO = {gcLat: 24.576403, gcLng: 118.230367}
const DEV = {uuid: '3303461326131633-2313731633939346', appBuild: '102649', eu: '3303461326131633', fv: '2313731633939346', screen: '1080*2268', osVersion: '13', networkType: 'wifi', openudid: '3303461326131633-2313731633939346'}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东权益红包任务', pageUrl: RP_PAGE, headers: {referer: RP_PAGE}, turn: 1, crontab: 3}
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _eid() {
        if (this._eidCache && Date.now() - this._eidAt < 600000) return this._eidCache
        for (const pt of ['/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', '/ql/data/psyduck/eid_pair.txt']) {
            try {
                const v = (fs.readFileSync(pt, 'utf8').match(/eid=(\S+)/) || ['', ''])[1]
                if (v) { this._eidCache = v; this._eidAt = Date.now(); return v }
            } catch (e) {}
        }
        return ''
    }

    _jarPin(user) {
        const ck = this._ckForUser(user)
        const m = String(ck || '').match(/pt_pin=([^;\s]+)/)
        return m ? decodeURIComponent(m[1]) : String(user || 'main')
    }
    _jarLoad(pin) {
        if (this._jarLoaded === pin) return this._jarMap
        this._jarMap = new Map()
        try {
            for (const ln of fs.readFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', 'utf8').split(/\r?\n/)) {
                const kv = ln.trim()
                if (kv.includes('=')) this._jarMap.set(kv.split('=')[0], kv)
            }
        } catch (e) {}
        this._jarLoaded = pin
        return this._jarMap
    }
    _jarSave(pin) {
        try {
            fs.mkdirSync('/ql/data/psyduck/ck_jar', {recursive: true})
            fs.writeFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', [...this._jarMap.values()].join('\n') + '\n')
        } catch (e) {}
    }
    _ckFull(user) {
        const ck = this._ckForUser(user)
        const jar = this._jarLoad(this._jarPin(user))
        const have = new Set(String(ck).split(';').map(s => s.split('=')[0].trim()).filter(Boolean))
        const extra = [...jar.values()].filter(kv => !have.has(kv.split('=')[0]))
        return extra.length ? ck + ';' + extra.join(';') : ck
    }
    _jarHarvest(user, res) {
        const sc = res.headers['set-cookie']
        if (!sc || !sc.length) return
        const jar = this._jarLoad(this._jarPin(user))
        for (const c of sc) {
            const kv = String(c).split(';')[0]
            if (kv.includes('=') && /^[!-~]+=/i.test(kv)) jar.set(kv.split('=')[0], kv)
        }
        this._jarSave(this._jarPin(user))
    }

    // redPackageTask 交互: b63ff 域, body 带 area/geo/deviceInfo (2026-10-23 抓包实锤)
    async rpCurl(opts) {
        const fn = opts.fn
        const bodyObj = opts.body
        const algoApp = opts.algo || 'b63ff'
        if (!this._rpSigner) {
            try { this._rpSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._rpSigner) return null
        const user = opts.user
        const ck = this._ckFull(user)
        if (!ck) return null
        const signed = this._rpSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: 'plus_business', client: 'android', clientVersion: '15.10.50'},
            appId: algoApp
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        // 设备参数组 (index 域需要; interaction 域按抓包不带)
        if (opts.devParams) {
            for (const k in DEV) f.append(k, DEV[k])
            f.append('xAPITz', '')
            f.append('xAPIRegion', 'CN')
            f.append('xAPICurrency', 'CNY')
        }
        const eid = this._eid()
        if (eid && opts.eidParam) f.append('x-api-eid-token', eid)
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn + '&scene=' + (opts.scene || 'index'), method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: RP_PAGE, 'user-agent': UA
                }
            }, rs => {
                this._jarHarvest(user, rs)
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    deviceInfo() {
        const eid = this._eid()
        const bare = eid.startsWith('jdd03') ? eid.slice(5) : eid
        return JSON.stringify({eid: bare, jsToken: eid})
    }

    async interaction(p, user, activityCode, actionType, assignmentId, itemId) {
        const body = Object.assign({
            scene: 'commonDoInteractiveAssignment',
            activityCode: activityCode,
            actionType: String(actionType),
            assignmentId: assignmentId,
            itemId: itemId,
            area: AREA
        }, GEO, {ext: JSON.stringify({deviceInfo: this.deviceInfo()})})
        return await this.rpCurl({fn: 'bff_rightsCenter_interaction', body, scene: 'commonDoInteractiveAssignment', user, algo: 'b63ff'})
    }

    async main(p) {
        let user = p.data.user
        // 探针模式: 打印 index 响应结构
        const body = Object.assign({baseVersion: '2.0.0', modelVersion: '2.0.0', queryTypes: 'TAB', scene: 'index', filterTab: 'couponTab', tabKind: '1', areaCode: '0'}, {})
        const r = await this.rpCurl({fn: 'bff_rights_center_index', body, scene: 'index', user, algo: '1ff7a', devParams: true, eidParam: true})
        p.log('INDEX原始:', JSON.stringify(r).slice(0, 3000))
    }
}
