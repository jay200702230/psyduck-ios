import fs from 'fs'
import net from 'net'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/DvFPmKRas9GYjDPZjT9NT14BAv6/index.html?babelChannel=ttt131'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const LBS = {mainChannel: '1', gps_area: '0_0_0_0', geoLng: '', geoLat: '', lng: '118.230367', lat: '24.576403'}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '王牌秒杀领京豆', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._acted = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // SecKill2020 网关 + h5st 域 2e500(实弹验证)
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._signer) {
                    try { this._signer = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._signer) { p.log('no signer'); return null }
                const ck = await this._ckFull(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._signer.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'SecKill2020', client: 'android', clientVersion: '15.10.50'}, appId: '2e500', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('loginType', '2')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    // app 内 RPC cookie 通道
    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpcCk = await this._rpcCk()
        if (rpcCk && rpcCk.includes('pt_key=')) {
            const pinOf = ck => { try { let m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            let want = pinOf(base)
            const got = pinOf(rpcCk)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpcCk
        }
        return base
    }

    async pool(p, user) {
        const r = await this.wg(p, user, 'common_task_list', {channelId: '7', babelChannel: 'ttt131', activityId: '01425483', ext: {channel: 0, queryReceiveTimes: 1}}, 2)
        return ((((r || {}).data || {}).result || {}).taskInfo || {}).taskList || []
    }

    async main(p) {
        const user = p.data.user
        const skip = new Set()
        for (let round = 1; round <= 12; round++) {
            const tl = await this.pool(p, user)
            if (!tl.length) { p.log('任务池空'); return }
            let did = 0
            const doneAids = new Map()
            for (const t of tl) {
                if (t.assignmentType !== 1 || t.completionFlag) continue
                const cnt = t.completionCnt || 0
                const lim = t.assignmentTimesLimit || 1
                if (cnt >= lim) continue
                if (skip.has(t.encryptAssignmentId)) continue
                const items = (t.ext || {}).shoppingActivity || []
                const it0 = items[0] || {}
                const url = String(it0.url || '')
                if (!it0.advId) continue
                if (url.startsWith('openapp.jdmobile')) { skip.add(t.encryptAssignmentId); continue }
                const wd = ((t.ext || {}).waitDuration || 10)
                // 服务端按真实 advId 计次; 时间戳伪造 itemId 会拒 105
                const rtb = url.includes('lps.jd.com') || url.includes('item.jd.com')
                const iid = it0.advId
                const mk1 = {channelId: '7', itemId: iid, assignmentId: t.encryptAssignmentId, ext: {jumpUrl: url}, actionType: 1, ...LBS, activeLink: W_PAGE}
                const mk0 = d => ({channelId: '7', itemId: iid, assignmentId: t.encryptAssignmentId, actionType: 0, ext: {doReceiveRewards: d}, ...LBS, activeLink: W_PAGE})
                const nm = (t.assignmentName || '').slice(0, 18)
                const r1 = await this.wg(p, user, 'common_do_task', mk1, 1)
                const c1 = String((((r1 || {}).data || {}).bizCode ?? (r1 || {}).code))
                if (c1 !== '0') {
                    const msg = String((((r1 || {}).data || {}).bizMsg) || '')
                    if (msg.includes('已完成') || msg.includes('上限')) skip.add(t.encryptAssignmentId)
                    else { p.log('  [1]拒:', nm, c1, msg.slice(0, 30)); this._fails++ }
                    continue
                }
                await this.wait((wd + 6) * 1000)
                const r0 = await this.wg(p, user, 'common_do_task', mk0(null), 1)
                const res = ((((r0 || {}).data || {}).result || {}).assignmentResult || {})
                const sub = String(res.subCode ?? (r0 || {}).code)
                if (sub === '0') {
                    p.log('  完成:', nm, cnt + 1 + '/' + lim)
                    doneAids.set(t.encryptAssignmentId, cnt)
                    did++
                    this._acted++
                    await this.wait(2500)
                    await this.wg(p, user, 'common_do_task', mk0(1), 1)
                } else { p.log('  [0]拒:', nm, sub, String(res.msg || '').slice(0, 40)); this._fails++ }
                await this.wait(3500)
            }
            // 轮末复查: 做了但服务端没计次(广告型曝光校验/份额尽) → 剔除防空转
            if (did) {
                const tl2 = await this.pool(p, user)
                for (const t2 of tl2) {
                    if (!doneAids.has(t2.encryptAssignmentId)) continue
                    if ((t2.completionCnt || 0) <= doneAids.get(t2.encryptAssignmentId)) {
                        skip.add(t2.encryptAssignmentId)
                        p.log('  不计次, 剔:', (t2.assignmentName || '').slice(0, 18))
                        did = 0
                    }
                }
            }
            if (!did) break
        }
        const fin = await this.pool(p, user)
        let total = 0
        for (const t of fin) {
            if (t.assignmentType === 1) total += Math.min(t.completionCnt || 0, t.assignmentTimesLimit || 1)
        }
        p.log('做任务领京豆: 本轮', this._acted, '发, 累计', total, '次')
        p.info.work = this._fails === 0
    }
}
