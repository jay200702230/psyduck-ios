import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/LXrBwmgGwkJs5GpTLn9qh2vhpeC/index.html?babelChannel=ttt350'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '天天领豆刮奖', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._drawn = 0
        this._skip = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // b63ff 域 (plus_business): 查卡/刮卡共用水线
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) { p.log('no signer'); return null }
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'plus_business', client: 'android', clientVersion: '15.10.50'}, appId: 'b63ff', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('loginType', '2'); f.append('loginWQBiz', ''); f.append('scval', 'test01')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn + '&scene=' + (fn === 'bff_rightsCenter_jdInteractTask' ? 'jdInteractTask' : 'commonDoInteractiveAssignment'), 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(3000 * k)
        }
        return null
    }

    // signed_wh5_ihub / ed9a2 域 / client.action 网关: 豆包余额
    async sceneNew(p, user) {
        try {
            if (!this._wgSigner) await import('./jd_signer_node.mjs')
            const ck = this._ckForUser(user)
            const signed = this._wgSigner.sign({functionId: 'findBeanSceneNew', body: {requestSource: 'normal', babelChannel: 'ttt350', actSecTraffic: '0'}, ck, base: {appid: 'signed_wh5_ihub', client: 'android', clientVersion: '15.10.50'}, appId: 'ed9a2', slim: true})
            const f = new URLSearchParams()
            for (const kk in signed) f.append(kk, String(signed[kk]))
            f.append('platform', '3'); f.append('loginType', '2'); f.append('loginWQBiz', 'wegame')
            const post = f.toString()
            const s = this._h2()
            if (!s) return null
            return await new Promise(resolve => {
                let done = false
                const fin = v => { if (!done) { done = true; resolve(v) } }
                let st = null
                try {
                    st = s.request({':method': 'POST', ':path': '/client.action?functionId=findBeanSceneNew', 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA})
                } catch (e) { return fin(null) }
                let d = ''
                st.on('data', c => d += c)
                st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                st.on('error', () => fin(null))
                st.end(post)
                setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
            })
        } catch (e) { return null }
    }

    async cards(p, user) {
        const r = await this.wg(p, user, 'bff_rightsCenter_jdInteractTask', {taskType: 'beanDailySign_newBeanTask', popFlag: '0', scene: 'jdInteractTask', commonScene: 'secKillChannel', needBeanSignStatus: '1'}, 2)
        return (((r || {}).rs || {}).beanTask || {}).taskList || []
    }

    // 刮卡: 1712001=已刮/无可刮(无害), 1714002=限流(等15s重试), code 0=中
    async scrape(p, user, t) {
        const items = ((t.ext || {}).shoppingActivity || [])
        const itemId = (items[0] || {}).advId || ''
        for (let k = 0; k < 3; k++) {
            const r = await this.wg(p, user, 'bff_rightsCenter_interaction', {scene: 'commonDoInteractiveAssignment', commonScene: 'secKillChannel', activityCode: 'newBeanTask', businessScenario: 'jingDouCenter', assignmentId: t.encryptAssignmentId, actionType: '100', itemId}, 1)
            const code = String((r || {}).code || '')
            if (code === '0' || code === '1711000') {
                this._drawn++
                let prize = ''
                try { prize = JSON.stringify((r || {}).rs || {}).slice(0, 80) } catch (e) {}
                p.log('  刮中:', t.assignmentName, prize)
                return true
            }
            if (code === '1712001') { this._skip++; return false }
            if (code === '1714002') {
                p.log('  限流, 等15s重试:', t.assignmentName)
                await this.wait(15000)
                continue
            }
            p.log('  刮异:', t.assignmentName, code, String((r || {}).msg || '').slice(0, 40))
            this._fails++
            return false
        }
        this._skip++
        p.log('  限流放弃:', t.assignmentName)
        return false
    }

    // 浏览任务动作探测: actionType=1 领取 → 等 waitDuration → 0 完成
    async doBrowse(p, user, t) {
        const items = ((t.ext || {}).shoppingActivity || [])
        if (!items.length) return false
        const wd = ((t.ext || {}).waitDuration || 5)
        const itemId = items[0].advId || ''
        const mk = at => ({scene: 'commonDoInteractiveAssignment', commonScene: 'secKillChannel', activityCode: 'newBeanTask', businessScenario: 'jingDouCenter', assignmentId: t.encryptAssignmentId, actionType: String(at), itemId})
        const r1 = await this.wg(p, user, 'bff_rightsCenter_interaction', mk(1), 1)
        const c1 = String((r1 || {}).code || '')
        if (c1 !== '0' && c1 !== '1711000') {
            p.log('  领取拒:', t.assignmentName, c1)
            return false
        }
        await this.wait((wd + 3) * 1000)
        const r2 = await this.wg(p, user, 'bff_rightsCenter_interaction', mk(0), 1)
        const c2 = String((r2 || {}).code || '')
        if (c2 !== '0' && c2 !== '1711000') {
            p.log('  完成拒:', t.assignmentName, c2)
            return false
        }
        p.log('  浏览完成:', t.assignmentName)
        return true
    }

    async main(p) {
        const user = p.data.user
        let tasks = await this.cards(p, user)
        if (!tasks.length) { p.log('任务池空'); return }
        p.log('任务卡', tasks.length, '张')
        for (let round = 0; round < 2; round++) {
            tasks = await this.cards(p, user)
            let acted = 0
            for (const t of tasks) {
                if (!t.completionFlag) continue
                const cnt = t.completionCnt || 0
                if (cnt >= t.assignmentTimesLimit) {
                    await this.scrape(p, user, t)
                    acted++
                    await this.wait(8000)
                }
            }
            for (const t of tasks) {
                if (t.completionFlag) continue
                if (/浏览/.test(t.assignmentDesc || '') && t.assignmentType === 1) {
                    p.log('做:', t.assignmentName, (t.completionCnt || 0) + '/' + t.assignmentTimesLimit)
                    const ok = await this.doBrowse(p, user, t)
                    if (ok) acted++
                    await this.wait(3000)
                }
            }
            if (!acted) break
        }
        tasks = await this.cards(p, user)
        let pend = 0
        for (const t of tasks) {
            if (!t.completionFlag) { p.log('未完成:', t.assignmentName, (t.completionCnt || 0) + '/' + t.assignmentTimesLimit); pend++ }
        }
        const sc = await this.sceneNew(p, user)
        const total = sc && sc.data && sc.data.totalBean ? sc.data.totalBean.beanNum : '?'
        p.log('刮中', this._drawn, '张, 已刮跳过', this._skip, ', 未完成', pend, '项, 豆包', total)
        p.info.work = true
    }
}
