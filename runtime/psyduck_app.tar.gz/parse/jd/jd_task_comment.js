import {Template} from '../../template.js'
import fs from 'fs'
import {spawnSync} from 'child_process'
import https from 'https'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

// 京东评价有礼(京豆) — 评价中心 H5 版
// 链路: 待评价订单 -> 逐单采集一条他人图文 -> 上传图片到 pic.jd.com -> pubComment 发布优质评价
//       -> getUserAggregateCommentList 查评价有礼任务 -> rate_app_task_startAwardTask 领京豆
// 说明: 评价中心接口 appId=m-rate-qa, 必须走 h5st 强签名; 图片走设备端 curl 做 multipart 上传。
export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东评价有礼(京豆)',
            prompt: {
                content: "评语1|评语2 (采集不到时用的兜底评语)",
                count: "单次评价个数",
                images: "(可选)备用图片URL池, 多个用 | 分隔"
            },
            keyExpire: 7200
        }
    }

    async prepare() {
        this.code = await this.getField('content')
        this.count = parseInt(await this.getField('count') || '') || 5
        this.images = await this.getField('images') || ''
    }

    // ================= 设备端 curl(支持 multipart 上传) =================
    sh(args) {
        let r = spawnSync(args[0], args.slice(1), {encoding: 'utf8', timeout: 60000, maxBuffer: 8 * 1024 * 1024})
        return {status: r.status, out: (r.stdout || '') + (r.stderr || '')}
    }

    curlBin() {
        let home = process.env.HOME || '/data/data/com.psyduck.jdtask/files/rt'
        return home + '/bin/psyduck-curl'
    }

    tmpDir() {
        return (process.env.HOME || '/data/data/com.psyduck.jdtask/files/rt') + '/tmp'
    }

    // 下载一张图再上传到 pic.jd.com, 返回 jfs 路径(msg); 失败返回 ''
    async uploadPic(url, cookie) {
        let bin = this.curlBin()
        let tmp = this.tmpDir() + '/rate_' + this.uuid(8, 'n') + '.jpg'
        try {
            let dl = this.sh([bin, '-s', '-m', '40', '-L', '-o', tmp, url])
            if (dl.status !== 0) return ''
            if (!fs.existsSync(tmp) || fs.statSync(tmp).size < 1024) return ''
        } catch (e) {
            return ''
        }
        try {
            let common = JSON.stringify({client: 'wh5', uuid: this.uuid(26, 'n'), forceLoginType: 2})
            let up = this.sh([bin, '-s', '-m', '40', '-X', 'POST',
                'https://pic.jd.com/2/8c399d10c3d640919e5e84a5b608c80a',
                '-H', 'Cookie: ' + cookie,
                '-H', 'Referer: https://comment.m.jd.com',
                '-H', 'Origin: https://comment.m.jd.com',
                '-F', 'file=@' + tmp + ';type=image/jpeg',
                '-F', 'common=' + common])
            let m = up.out.match(/"msg"\s*:\s*"([^"]+)"/)
            if (m && m[1]) return m[1]
        } catch (e) {
        }
        return ''
    }

    // ================= 评价中心 H5 接口(form appid=m-rate-qa, 签名 fasten=01a47) =================
    async rate(fn, obj, user) {
        let body = this.dumps(Object.assign({
            requestSource: 'h5', clientSource: 'h5', realVersion: '1.0.0',
            client: 'h5', clientVersion: '1.0.0',
            lang: 'zh_CN', xAPIClientLanguage: 'zh_CN', xAPIRegion: 'CN'
        }, obj))
        let form = `appid=m-rate-qa&enableCookies=true&functionId=${fn}&loginType=2`
            + `&client=h5&clientVersion=1.0.0&lang=zh_CN&xAPIClientLanguage=zh_CN&xAPIRegion=CN`
            + `&body=${encodeURIComponent(body)}`
        return await this.autoCurl({
            url: `https://api.m.jd.com/${fn}`,
            form,
            user,
            // 注意: 不能加 h5st:true, 该路径在框架内会静默失败并回显请求, 导致「返回内容为空」
            algo: {appId: '01a47'},
            response: 'all'
        })
    }

    rateJson(r) {
        let c = r && (r.content !== undefined ? r.content : r)
        if (typeof c === 'string') {
            try { return JSON.parse(c) } catch (e) { return {} }
        }
        return c || {}
    }

    // 组装可用图片 URL 列表: 优先采集到的图, 其次 ini 图片池
    pickPics(c) {
        let out = []
        let imgs = (c && (c.images || c.imageList)) || []
        for (let im of imgs) {
            let u = im.mainUrl || im.url || im.imageUrl || im.imgUrl || ''
            if (!u) continue
            if (u.indexOf('//') === 0) u = 'https:' + u
            if (/\.dpg(\?|$)/i.test(u)) continue
            out.push(u)
        }
        if (this.images) {
            for (let u of String(this.images).split('|')) {
                u = u.trim()
                if (!u) continue
                if (!/^https?:/i.test(u)) u = 'https://img30.360buyimg.com/shaidan/' + u.replace(/^\/+/, '')
                out.push(u)
            }
        }
        return out
    }

    // 从 commentEditInfo 提取发布所需店铺信息
    pickMeta(info) {
        let floors = (info && info.commentFloorList) || []
        let pf = null, mf = null
        for (let f of floors) {
            if (f.type === 'productCommentFloor') pf = f.productCommentFloor
            if (f.type === 'mediaEditFloor') mf = f.mediaEditFloor
        }
        let shop = (pf && pf.productAndScoreInfo && pf.productAndScoreInfo.shopInfo) || {}
        return {
            shopId: shop.shopId || '',
            shopType: shop.shopType || '',
            commentType: (mf && mf.commentType) || '',
            isCommentTagContent: (mf && mf.isCommentTagContent) || '0'
        }
    }

    // 逐条采集: 每次只取【一条】该商品下别人的评价(单步直连 GET, signer e4256 域真token)
    async fetchOne(sku, user, p) {
        let referer = `https://item.m.jd.com/product/${sku}.html`
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) { return null }
        }
        const ck = this._ckForUser(user)
        if (!ck) return null
        // token 预热: 首次 sign 是 tk06 兜底, SDK 异步拿真 tk03 需 3.5s (进程级只做一次)
        if (!globalThis.__acWarm) {
            try {
                this._acSigner.sign({
                    functionId: 'comment_getCommentList',
                    body: {externalLoginType: 1, callback: 'skuJDEval', version: 'v2', pagesize: '10', score: '0', sku: '0', sorttype: '5', page: '1', dlmh: '0', t: Date.now(), wsblcd: ''},
                    ck, base: {appid: 'm_core', client: 'android', clientVersion: '15.10.50'}, appId: 'e4256'
                })
            } catch (e) {}
            await this.wait(3500)
            globalThis.__acWarm = true
        }
        for (let page = 1; page <= 3; page++) {
            try {
                let bodyObj = {
                    externalLoginType: 1, callback: 'skuJDEval', version: 'v2',
                    pagesize: '10', score: '0', sku: String(sku),
                    sorttype: '5', page: String(page), dlmh: '0',
                    t: Date.now(), wsblcd: ''
                }
                const signed = this._acSigner.sign({
                    functionId: 'comment_getCommentList', body: bodyObj, ck,
                    base: {appid: 'm_core', client: 'android', clientVersion: '15.10.50'},
                    appId: 'e4256'
                })
                const qs = new URLSearchParams()
                for (const k in signed) qs.append(k, String(signed[k]))
                const url = `/ware/comment/getCommentList?${qs.toString()}&body=${encodeURIComponent(this.dumps(bodyObj))}`
                let r = await new Promise(resolve => {
                    const rq = https.request({
                        hostname: 'api.m.jd.com', path: url, method: 'GET',
                        headers: {cookie: ck, referer, 'user-agent': AC_UA, accept: '*/*'}
                    }, rs => {
                        let d = ''
                        rs.on('data', c => d += c)
                        rs.on('end', () => {
                            let out = null
                            try { out = JSON.parse(d) } catch (e) {
                                const jm = String(d).match(/skuJDEval\(([\s\S]*)\)/)
                                if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                            }
                            resolve(out)
                        })
                    })
                    rq.on('error', () => resolve(null))
                    rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
                    rq.end()
                })
                let list = this.haskey(r, 'result.comments') || this.haskey(r, 'comments') || []
                // 用户明令必须图文: 只认带图评价, 翻页找
                let c = list.find(x => x && (x.images || x.imageList || []).length && (x.content || '').trim().length >= 8)
                if (c) return c
                const rcode = String(this.haskey(r, 'code') || this.haskey(r, 'errcode') || '')
                const rmsg = String(this.haskey(r, 'msg') || this.haskey(r, 'errmsg') || '').slice(0, 40)
                if (rcode === '601') {
                    // 账号级频控: 硬打会加深, 直接放弃本单靠单间6s间隔自然恢复
                    p.log(`  采集被限流(601), 跳过本单: ${sku}`)
                    break
                }
                if (rcode !== '0' && rcode !== '') p.log(`  采集page${page}: code=${rcode} ${rmsg} 列表=${list.length}`)
                if (page >= 3) p.log(`  该商品3页内无带图评价: ${sku}`)
                else await this.wait(4000)
            } catch (e) {
                break
            }
        }
        return null
    }

    // 发布优质评价(必须带图, 用户明令禁止文字兜底); 无图不调用
    async pubComment(o, content, picUrls, meta, user) {
        let build = (pics) => ({
            orderId: o.orderId,
            productId: o.wareId,
            commentScore: '5',
            commentData: content,
            pictureInfoList: pics,
            videoInfoList: [],
            anonymousFlag: '1',
            addPictureFlag: '0',
            isCommentTagContent: meta.isCommentTagContent || '0',
            shopId: meta.shopId || '',
            shopType: meta.shopType || '',
            commentType: meta.commentType || ''
        })
        let r = this.rateJson(await this.rate('pubComment', build(picUrls), user))
        if (String(r.result) === '0') return {ok: true, r}
        return {ok: false, info: this.errInfo(r)}
    }

    // 失败摘要: 只留 HTTP 状态和正文前 120 字符, 绝不打印 headers/ep 等技术字段
    errInfo(r) {
        if (!r || typeof r !== 'object') return '接口无响应'
        let st = r.status || r.statusCode || ''
        let body = ''
        let c = r.content
        if (typeof c === 'string') body = c
        else if (c && typeof c === 'object') { try { body = this.dumps(c) } catch (e) {} }
        else if (r.error) body = String(r.error)
        body = String(body || '').replace(/\s+/g, ' ').trim().slice(0, 120)
        let echo = this.haskey(c && typeof c === 'object' ? c : {}, 'echo') || this.haskey(r, 'echo') || ''
        let why = body || (st ? '' : '返回内容为空(接口可能被风控拦截)')
        return (st ? 'HTTP' + st + ' ' : '') + why + (echo ? ' | ' + echo : '')
    }

    // 评价有礼/彩蛋 领京豆
    async claim(user, p) {
        try {
            let a = this.rateJson(await this.rate('getUserAggregateCommentList', {
                page: '0', pageSize: '10', needPopReward: '1'
            }, user))
            let t = this.haskey(a, 'result.userAwardTaskInfo')
            if (!t || String(t.status) !== '0') return
            let w = this.rateJson(await this.rate('rate_app_task_startAwardTask', {
                taskId: t.taskId, startTime: t.startTime, endTime: t.endTime
            }, user))
            if (String(w.code) === '0') p.msg(`评价有礼京豆领取成功: ${w.msg || ''}`)
            else p.log(`评价有礼领取失败: ${w.msg || ''}`)
        } catch (e) {
            p.log(`评价有礼领取异常: ${e && e.message}`)
        }
    }

    async main(p) {
        let user = p.data.user
        let count = this.count

        // 老app签名(client=apple+写死sign)已被京东禁(no access), 改走评价中心H5 h5st签名(同rate链)
        let s = this.rateJson(await this.rate('getCommentWareList', {
            status: '1', planType: '1', pageIndex: '1', pageSize: '400'
        }, user))
        let code = String(this.haskey(s, 'code') || '')
        if (code == '3' || code == '600') {
            p.log(`登录失效(code=${code}), 账号已被踢下线, 请重新登录京东App后再试`)
            return
        }
        let n = this.haskey(s, 'commentWareListInfo.wait4CommentCount')
        if (n === undefined || n === null || n === '') {
            p.log(`没有待评价订单!` + (code ? ` (code=${code})` : ''))
            return
        }
        p.log(`总共有:${n}个订单未评价`)

        let page = Math.ceil(parseInt(n) / 20)
        if (parseInt(n) % 10 < 3 && page > 1) page = page - 1
        let q = this.rateJson(await this.rate('getCommentWareList', {
            status: '1', planType: '1', pageIndex: String(page), pageSize: '20'
        }, user))
        if (!this.haskey(q, 'commentWareListInfo.commentWareList')) {
            p.log(`没有待评价订单!`)
            return
        }
        let orders = q.commentWareListInfo.commentWareList.reverse().splice(0, count)

        let cookie = ''
        try {
            cookie = (await this._userCookie(user)) || ''
        } catch (e) {
            p.log(`取cookie失败: ${e && e.message}`)
        }

        let fails = 0
        for (let o of orders) {
            // 1) 逐单采集一条他人评价
            let c = await this.fetchOne(o.wareId, user, p)
            let content = (c && (c.content || '').trim()) || this.random(this.code)
            let pics = this.pickPics(c)

            // 2) 评价中心编辑信息(店铺/评价类型)
            let meta = {}
            try {
                let info = this.rateJson(await this.rate('commentEditInfo', {
                    orderId: o.orderId, productId: o.wareId, qrType: '1'
                }, user))
                meta = this.pickMeta(info)
            } catch (e) {
                p.log(`取评价信息失败: ${e && e.message}`)
            }

            // 3) 上传图片(最多2张) — 必须带图, 无图直接跳过该单(用户明令禁止文字兜底)
            let picUrls = []
            for (let u of pics.slice(0, 2)) {
                let j = await this.uploadPic(u, cookie)
                if (j) picUrls.push({picUrl: j})
            }
            if (!picUrls.length) {
                p.log(`采集不到可用图片, 跳过(不发纯文字): ${o.wname || o.orderId}`)
                continue
            }

            p.log(`正在评价: ${o.wname} (带图${picUrls.length}张)`)

            // 4) 发布
            let r = await this.pubComment(o, content, picUrls, meta, user)
            if (r.ok) {
                p.msg(`订单: ${o.orderId} 评价成功(带图${picUrls.length}张)`)
                p.info.work = true
                // 5) 领京豆
                await this.wait(2000)
                await this.claim(user, p)
            } else {
                p.log(`评价失败: ${r.info || '未知原因'}`)
                if (++fails >= 2) {
                    p.log(`连续 ${fails} 单失败, 评价接口当前不可用(多半被风控拦截), 本轮跳过剩余评价`)
                    break
                }
            }
            await this.wait(6000)
        }
    }
}