import {Template} from '../../template.js'
import {execFile} from 'child_process'
import crypto from 'crypto'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

// 京东赚话费 v3: 纯协议 (psyduck-curl 指纹伪装直连, 无需京东App前台/RPC)
// WAF 卡 TLS 指纹: node OpenSSL 栈 403 死路, 设备 rt/bin/psyduck-curl (LibreSSL + 真机 JA3 cipher 顺序) 可过
// 接口无 h5st, 签名仅 encStr = md5(第一对象字段值拼接 + t + key)
// 状态机: view=0 上报+浏览+领 / view=2 直领 / view=1 本轮做完跳过
const DW_KEY = 'e9c398ffcb2d4824b4d0a703e38yffdd'
const DW_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const DW_CURL = '/data/user/0/com.psyduck.jdtask/files/rt/bin/psyduck-curl'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: "京东赚话费",
            crontab: 3,
            libressl: true
        }
        this._ckCache = ''
        this._ckAt = 0
    }

    async prepare() {
    }

    // 自读 cookie/jd.ini main 段 (10分钟缓存)
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.dwCk()
    }
    dwCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const ck = mainCk || any
            if (ck) { this._ckCache = ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache
    }

    async pageApi(fid, p1 = {}, p2 = {}) {
        const t = Date.now()
        let c = ''
        for (const k of Object.keys(p1)) c += String(p1[k])
        const body = JSON.stringify(Object.assign({}, p1, p2, {t, encStr: crypto.createHash('md5').update(c + t + DW_KEY).digest('hex')}))
        const form = new URLSearchParams()
        form.append('appid', 'h5-sep')
        form.append('body', body)
        form.append('client', 'm')
        form.append('clientVersion', '6.0.0')
        form.append('loginType', '2')
        const args = ['-sk', '-X', 'POST', `https://api.m.jd.com/api?functionId=${fid}`,
            '-H', 'Content-Type: application/x-www-form-urlencoded',
            '-H', `User-Agent: ${DW_UA}`,
            '-H', 'Referer: https://pro.m.jd.com/',
            '-H', `Cookie: ${this.dwCk()}`,
            '--data', form.toString(), '--max-time', '20']
        const raw = await new Promise(resolve => {
            execFile(DW_CURL, args, {timeout: 25000, maxBuffer: 4 * 1024 * 1024}, (err, stdout) => resolve(err ? '' : String(stdout || '')))
        })
        let j = null
        try { j = JSON.parse(raw) } catch (e) {}
        return {status: raw ? 200 : 0, json: j, raw}
    }

    async main(p) {
        let user = p.data.user
        const ck = this._ckForUser(user)
        if (!ck) { p.err("cookie/jd.ini 无 main 账号 cookie"); return }

        let cash = 0
        let li = null
        try {
            li = await this.pageApi('dwapp_task_dwList')
        } catch (e) {
            p.err("任务列表获取失败: " + String(e.message).slice(0, 80))
            return
        }
        if (!li.raw) { p.err("dwList 空响应(指纹链路异常)"); return }
        const tasks = (li.json && li.json.data) || []
        if (!tasks.length) { p.err("任务列表为空: " + li.raw.slice(0, 80)); return }
        p.log(`任务 ${tasks.length} 个`)

        for (const t of tasks) {
            try {
                if (t.viewStatus == 1) {
                    p.log("本轮已做完:", t.name)
                    continue
                }
                if (t.viewStatus == 2) {
                    const rv = await this.pageApi('dwapp_task_dwReceive', {id: t.id})
                    const rd = (rv.json && rv.json.data) || {}
                    const g = Number(rd.giveScoreNum || 0)
                    if (rd.success && g > 0) {
                        cash += g
                        p.log(`直领 ${t.name}: +${g}`)
                    } else {
                        p.log(`直领 ${t.name} fail: ` + String(rd.errorMsg || rv.raw.slice(0, 60)))
                    }
                    await this.wait(2000)
                    continue
                }
                const rc = await this.pageApi('dwapp_task_dwRecord', {id: t.id, taskType: t.taskType}, {agentNum: 'm', followChannelStatus: t.followChannelStatus || ''})
                const needBrowse = this.haskey(rc, 'json.data.dwUserTask')
                p.log(`上报 ${t.name}${needBrowse ? ' (浏览6.5s)' : ''}`)
                if (needBrowse) await this.wait(6500)
                const rv = await this.pageApi('dwapp_task_dwReceive', {id: t.id})
                const rd = (rv.json && rv.json.data) || {}
                const g = Number(rd.giveScoreNum || 0)
                if (rd.success || rd.errorCode == '200') {
                    cash += g
                    p.log(`领奖 ${t.name}: +${g}`)
                } else {
                    p.log(`领奖 ${t.name} fail: ` + String(rd.errorMsg || rv.raw.slice(0, 60)))
                }
            } catch (e) {
                p.log(`任务异常 ${t.name}: ` + String(e.message).slice(0, 80))
            }
            await this.wait(2000)
        }

        try {
            const sg = await this.pageApi('DATAWALLET_USER_SIGN')
            const sd = (sg.json && sg.json.data) || {}
            if (sd.signNum !== undefined && sd.signNum !== null) {
                cash += Number(sd.signNum || 0)
                p.log(`签到: +${sd.signNum}`)
            } else if (sg.json && sg.json.code == 302) {
                p.log('签到: 今日已签')
            } else {
                p.log('签到: ' + String(sg.raw).slice(0, 60))
            }
        } catch (e) {
            p.log("签到异常: " + String(e.message).slice(0, 60))
        }

        try {
            const si = await this.pageApi('DATAWALLET_USER_SIGN_INFO')
            const sid = (si.json && si.json.data) || {}
            if (sid.balanceNum !== undefined && sid.balanceNum !== null) {
                p.msg(`余额: ${sid.balanceNum} 本轮获得: ${cash.toFixed(2)}`)
            } else {
                p.msg(`本轮获得: ${cash.toFixed(2)}`)
            }
        } catch (e) {
            p.msg(`本轮获得: ${cash.toFixed(2)}`)
        }
        p.info.work = cash > 0
    }
}
