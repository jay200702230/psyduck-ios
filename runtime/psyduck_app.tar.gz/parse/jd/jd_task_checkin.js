import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const CK_PAGE = 'https://pro.m.jd.com/mall/active/jpeZLX5Lb3gpwH98tAaB8Y1HY99/index.html'
const ACTIVE_LINK = 'https://pro.m.jd.com/mall/active/DvFPmKRas9GYjDPZjT9NT14BAv6/index.html?babelChannel=ttt131'
const CK_UA_ONE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/' + encodeURIComponent(JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})).replace('%22ts%22%3A0', '"ts":0') + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = CK_UA_ONE.replace('"ts":0', '"ts":' + globalThis.__uaTs)
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

// common_task 引擎参数 (2026-10-23 抓包实锤: 秒杀页换代, 老 checkInTask 已废 jsf invalid)
const CT = {
    appid: 'SecKill2020',
    appId: '2e500',
    urlBase: '/?area=16_1315_3489_46816&clientVersion=15.10.50&client=android&loginType=2&t=TNOW&appid=SecKill2020&xAPIClientLanguage=zh_CN&functionId=FN&uuid=3303461326131633-2313731633939346&d_model=IN2010&d_brand=OnePlus&model=IN2010&osVersion=13&aid=30d1b1a3217a399d',
    listBody: {channelId: '7', babelChannel: 'ttt131', activityId: '01425483', ext: {channel: 0, queryReceiveTimes: 1}},
    geo: {mainChannel: '1', gps_area: '0_0_0_0', geoLng: '', geoLat: '', lng: '118.230367', lat: '24.576403', activeLink: ACTIVE_LINK}
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东秒杀签到任务',
            pageUrl: CK_PAGE,
            headers: {referer: CK_PAGE},
            turn: 1,
            crontab: 3
        }
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;\s]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return ln.trim()
                    }
                }
            }
        }
        return this._mainCk()
    }

    _mainCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const ck = mainCk || any
            if (ck) { this._ckCache = ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _jarPin(user) {
        const ck = this._ckForUser(user)
        const m = String(ck || '').match(/pt_pin=([^;\s]+)/)
        return m ? decodeURIComponent(m[1]) : String(user || 'main')
    }
    _jarLoad(pin) {
        if (this._jarLoaded === pin) return this._jarMap
        this._jarMap = new Map()
        try {
            for (const ln of fs.readFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', 'utf8').split(/\r?\n/)) {
                const kv = ln.trim()
                if (kv.includes('=')) this._jarMap.set(kv.split('=')[0], kv)
            }
        } catch (e) {}
        this._jarLoaded = pin
        return this._jarMap
    }
    _jarSave(pin) {
        try {
            fs.mkdirSync('/ql/data/psyduck/ck_jar', {recursive: true})
            fs.writeFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', [...this._jarMap.values()].join('\n') + '\n')
        } catch (e) {}
    }
    _ckFull(user) {
        const ck = this._ckForUser(user)
        const jar = this._jarLoad(this._jarPin(user))
        const have = new Set(String(ck).split(';').map(s => s.split('=')[0].trim()).filter(Boolean))
        const extra = [...jar.values()].filter(kv => !have.has(kv.split('=')[0]))
        return extra.length ? ck + ';' + extra.join(';') : ck
    }
    _jarHarvest(user, res) {
        const sc = res.headers['set-cookie']
        if (!sc || !sc.length) return
        const jar = this._jarLoad(this._jarPin(user))
        for (const c of sc) {
            const kv = String(c).split(';')[0]
            if (kv.includes('=') && /^[!-~]+=/i.test(kv)) jar.set(kv.split('=')[0], kv)
        }
        this._jarSave(this._jarPin(user))
    }

    // common_task 族: appid=SecKill2020 + h5st(2e500), token 预热后 tk03 (2026-10-23 抓包实锤)
    async ctCurl(p, user, fn, bodyObj) {
        if (!this._ctSigner) {
            try { this._ctSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._ctSigner) return null
        const ck = this._ckFull(user)
        if (!ck) return null
        if (!globalThis.__ctWarm) {
            try { this._ctSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: CT.appid, client: 'android', clientVersion: '15.10.50'}, appId: CT.appId}) } catch (e) {}
            await this.wait(3500)
            globalThis.__ctWarm = true
        }
        const signed = this._ctSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: CT.appid, client: 'android', clientVersion: '15.10.50'},
            appId: CT.appId
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        const urlPath = CT.urlBase.replace('FN', fn).replace('TNOW', String(Date.now()))
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: CK_PAGE, 'user-agent': UA,
                    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Android WebView";v="120", "Dong WebView";v="2.1.62"',
                    'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform': '"Android"'
                }
            }, rs => {
                this._jarHarvest(user, rs)
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async taskList(p, user) {
        return await this.ctCurl(p, user, 'common_task_list', JSON.parse(JSON.stringify(CT.listBody)))
    }

    async doTask(p, user, assignmentId, itemId, jumpUrl, actionType, doReward) {
        const body = Object.assign({channelId: '7', itemId: String(itemId || Date.now() * 10), assignmentId: assignmentId}, {actionType}, {ext: {doReceiveRewards: doReward === 1 ? 1 : null}}, CT.geo)
        if (actionType === 1 && jumpUrl) body.ext = {jumpUrl}
        return await this.ctCurl(p, user, 'common_do_task', body)
    }

    async rawGet(p, user, url, referer) {
        if (!url) return
        try {
            for (let hop = 0; hop < 2 && url; hop++) {
                const out = await new Promise(resolve => {
                    const u = new URL(url)
                    const rq = https.request({
                        hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
                        headers: {
                            cookie: this._ckFull(user), 'user-agent': UA,
                            referer: referer || CK_PAGE,
                            accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                        }
                    }, rs => {
                        this._jarHarvest(user, rs)
                        rs.resume()
                        rs.on('end', () => resolve({status: rs.statusCode, loc: rs.headers.location || ''}))
                    })
                    rq.on('error', () => resolve({status: 0, loc: ''}))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve({status: 0, loc: ''}) })
                    rq.end()
                })
                if (out.status === 302 && out.loc) { url = new URL(out.loc, url).href; referer = url } else { url = '' }
            }
        } catch (e) {}
    }

    async main(p) {
        let user = p.data.user
        await this.rawGet(p, user, CK_PAGE, '')
        let list = await this.taskList(p, user)
        if (!list) { p.log('task_list 空响应'); return }
        // 首跑探明结构: 打顶层键与列表粗况
        const keys = Object.keys(list)
        p.log('task_list 键:', keys.join(','), '| code:', list.code ?? list.errcode ?? '?')
        // 结构: data.result.taskInfo.taskList (2026-10-23 实锤)
        let tasks = (list.data && list.data.result && list.data.result.taskInfo && list.data.result.taskInfo.taskList) || []
        if (!tasks.length) {
            p.log('任务池结构:', JSON.stringify(list).slice(0, 600))
            return
        }
        let done = 0
        for (const t of tasks) {
            if (t.completionFlag || t.finished || +t.status === 3 || +t.status === 4) continue
            const aid = t.encryptAssignmentId || t.assignmentId || ''
            if (!aid) continue
            // 子项在 ext.<xxxActivity>[] (shoppingActivity/browseActivity/rtbActivity...), 通用扫数组
            let subs = []
            for (const k in (t.ext || {})) {
                if (Array.isArray(t.ext[k]) && t.ext[k].length && t.ext[k][0] && typeof t.ext[k][0] === 'object' && (t.ext[k][0].itemId || t.ext[k][0].advId)) { subs = t.ext[k]; break }
            }
            const sub = subs.find(s => +s.status === 2) || subs[0] || {}
            const itemId = sub.advId || sub.itemId || (Date.now() * 10)
            let jumpUrl = sub.url || sub.jumpUrl || t.forwardUrl || ''
            if (jumpUrl.includes('openapp.jdmobile')) {
                try { jumpUrl = JSON.parse(jumpUrl.split('params=')[1]).url || jumpUrl } catch (e) {}
            }
            if (!jumpUrl) {
                p.log('跳过(无浏览项):', t.assignmentName || aid)
                continue
            }
            p.log('做:', t.assignmentName, '| 子项:', subs.length)
            let r1 = await this.doTask(p, user, aid, itemId, jumpUrl, 1)
            p.log('  受理:', JSON.stringify(r1).slice(0, 120))
            if (jumpUrl) await this.rawGet(p, user, jumpUrl, CK_PAGE)
            await this.wait(((+t.waitDuration || +t.browseDuration || 5) + 2) * 1000)
            let r0 = await this.doTask(p, user, aid, itemId, '', 0)
            p.log('  完成:', JSON.stringify(r0).slice(0, 150))
            // 领奖步 (抓包: doReceiveRewards:1)
            await this.wait(2500)
            let r2 = await this.doTask(p, user, aid, itemId, '', 0, 1)
            p.log('  领奖:', JSON.stringify(r2).slice(0, 150))
            done++
            p.info.work = true
            await this.wait(6000)
        }
        p.log(`本轮完成 ${done} 个`)
    }
}
