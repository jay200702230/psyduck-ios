import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东天天抽好运',
            crontab: 3,
            sync: 1,
            verify: 1
        }
    }

    async prepare() {
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let s = await this.autoCurl({
                'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=queryInteractiveInfo&body={"encryptProjectId":"${context.encryptProjectId}","sourceCode":"${context.sourceCode}","ext":{"queryReceiveTimes":1}}`,
                user,
                algo: {
                    appId: '39e8e',
                    expire: {
                        login: false,
                    }
                }
            }
        )
        let data = this.haskey(s, 'assignmentList')
        if (!data) {
            const sub = String(this.haskey(s, 'subCode') || '')
            const msg = String(this.haskey(s, 'msg') || '')
            if (sub === '102' || sub === '1401' || msg.includes('结束') || msg.includes('不存在')) {
                p.log(`[${context.pid || ''}] 活动已结束/下线(subCode=${sub}), 分享数据待作者更新, 本项目跳过`)
            }
            else {
                p.err("没有获取到数据", JSON.stringify(s).slice(0, 150))
            }
            return
        }
        let lotteryId
        for (let i of data) {
            if (i.assignmentName == '抽奖') {
                lotteryId = i.encryptAssignmentId
            }
            else if (i.completionFlag) {
                p.log(`任务已经完成: ${i.assignmentName}`)
            }
            else {
                p.log("正在运行:", i.assignmentName)
                for (let j of Array(i.assignmentTimesLimit - i.completionCnt)) {
                    if (i.assignmentName.includes("首页")) {
                        await this.autoCurl({
                                'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":1,"itemId":"${i.ext.materialId}","ext":{}}`,
                                user,
                                algo: {
                                    appId: '39e8e'
                                }
                            }
                        )
                        var doTask = await this.autoCurl({
                                'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":0,"itemId":"${i.ext.materialId}","completionFlag":true,"ext":{}}`,
                                user,
                                algo: {
                                    appId: '39e8e'
                                }
                            }
                        )
                    }
                    else if (i.assignmentName.includes("签到")) {
                        var doTask = await this.autoCurl({
                                'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":0,"itemId":"1","ext":{}}`,
                                user,
                                algo: {
                                    appId: '39e8e'
                                }
                            }
                        )
                    }
                    else {
                        let extraType = this.haskey(i, 'ext.extraType')
                        if (this.haskey(i, `ext.${i.ext.extraType}`)) {
                            let extra = i.ext[extraType]
                            if (this.haskey(extra, '0.itemId') && ['shoppingActivity', 'productsInfo', 'browseShop', 'addCart', 'followShop', 'followChannel'].includes(extraType)) {
                                if (i.ext.waitDuration) {
                                    let waitTask = await this.autoCurl({
                                            'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":1,"itemId":"${extra[0].itemId}","ext":{"jumpUrl":"${encodeURIComponent(extra[0].url)}"}}`,
                                            user,
                                            algo: {
                                                appId: '39e8e'
                                            }
                                        }
                                    )
                                    p.log("等待:", i.ext.waitDuration)
                                    await this.wait(i.ext.waitDuration * 1000)
                                    var doTask = await this.autoCurl({
                                            'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":0,"itemId":"${extra[0].itemId}","ext":{"jumpUrl":"${encodeURIComponent(extra[0].url)}"}}`,
                                            user,
                                            algo: {
                                                appId: '39e8e'
                                            }
                                        }
                                    )
                                }
                                else {
                                    var doTask = await this.autoCurl({
                                            'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":0,"itemId":"${extra[0].itemId}","ext":{"jumpUrl":"${encodeURIComponent(extra[0].url)}"}}`,
                                            user,
                                            algo: {
                                                appId: '39e8e'
                                            }
                                        }
                                    )
                                }
                            }
                            else {
                                var doTask = await this.autoCurl({
                                        'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":0,"completionFlag":true,"ext":{}}`,
                                        user,
                                        algo: {
                                            appId: '39e8e'
                                        }
                                    }
                                )
                            }
                        }
                        else {
                            var doTask = await this.autoCurl({
                                    'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${i.encryptAssignmentId}","sourceCode":"${context.sourceCode}","actionType":0,"completionFlag":true,"ext":{}}`,
                                    user,
                                    algo: {
                                        appId: '39e8e'
                                    }
                                }
                            )
                        }
                    }
                    if (this.haskey(doTask, 'assignmentInfo.completionCnt')) {
                        p.log("success")
                    }
                    else {
                        p.log(doTask)
                    }
                    await this.wait(2000)
                }
            }
        }
        if (lotteryId) {
            p.log("抽奖中...")
            while (1) {
                let r = await this.autoCurl({
                        'form': `appid=SecKill2020&client=wh5&clientVersion=15.2.72&functionId=doInteractiveAssignment&body={"encryptProjectId":"${context.encryptProjectId}","encryptAssignmentId":"${lotteryId}","sourceCode":"${context.sourceCode}","actionType":0,"ext":{"exchangeNum":1,"interactNum":1}}`,
                        user,
                        algo: {
                            appId: '39e8e'
                        }
                    }
                )
                if (this.haskey(r, 'rewardsInfo.successRewards')) {
                    for (let g in r.rewardsInfo.successRewards) {
                        let data = r.rewardsInfo.successRewards[g]
                        if (g == '4') {
                            for (let k of data) {
                                p.award(k.discount, 'redpacket')
                            }
                        }
                        else if (g == '8') {
                            for (let k of data) {
                                p.log(k.useRange, '优惠券')
                            }
                        }
                        else {
                            for (let k of data) {
                                p.log(k)
                            }
                        }
                    }
                }
                else {
                    p.log(`什么也没有抽到`)
                }
                if (!this.haskey(r, 'rewardsInfo')) {
                    break
                }
                await this.wait(2000)
                p.info.work = true
            }
        }
    }
}

