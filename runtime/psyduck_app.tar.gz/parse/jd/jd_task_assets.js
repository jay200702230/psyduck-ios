import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东资产汇总',
            crontab: `${this.rand(0, 40)} ${this.rand(21, 23)} * * *`,
            interval: 1000,
            delay: 200
        }
    }

    async prepare() {
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        context.dict = {}
        await this._ecard(p)
        await this._redpacket(p)
        await this._bean(p)
        await this._farm(p)
        let t = []
        for (let i in context.dict) {
            let data = context.dict[i]
            switch (i) {
                case 'farm':
                    t.push(`💧 农场水滴: ${data.water}`)
                    if (data.tips) t.push(`💧 农场进度: ${data.tips}`)
                    break
                case 'card':
                    t.push(`🦁 京超市卡: ${data || 0}元`)
                    break
                case 'score':
                    t.push(`🐵 有京享值: ${data || 0}分`)
                    break
                case 'jingtie':
                    t.push(`🦁 账户京贴: ${data || 0}元`)
                    break
                case 'redpacket':
                    t.push(`🦊 当前红包: ${data.all}元`)
                    t.push(`🦊 即将到期: ${data.expire}元`)
                    t.push(`🦊 还未生效: ${data.disable}元`)
                    t.push(`🦊 通用红包: ${data.current[0]}元, 过期: ${data.current[1]}元`)
                    t.push(`🦊 商城红包: ${data.app[0]}元, 过期: ${data.app[1]}元`)
                    t.push(`🦊 特价红包: ${data.lite[0]}元, 过期: ${data.lite[1]}元`)
                    t.push(`🦊 微信红包: ${data.wechat[0]}元, 过期: ${data.wechat[1]}元`)
                    t.push(`🦊 健康红包: ${data.healthy[0]}元, 过期: ${data.healthy[1]}元`)
                    break
                case 'bean':
                    t.push(`🐶 当前京豆: ${data.all}京豆`)
                    t.push(`🐶 今日收入: ${data.today[0]}京豆${data.wuxianbao ? `(已剔除无线宝${data.wuxianbao})` : ''}, 支出: ${data.today[1]}京豆`)
                    t.push(`🐶 昨天收入: ${data.yesterday[0]}京豆, 支出: ${data.yesterday[1]}京豆`)
                    if (data.expire) {
                        for (let i of data.expire.reverse()) {
                            t.push(`🙊 即将过期: ${i.eventMassage} ${i.amount}京豆`)
                        }
                    }
                    else if (data.expireBean) {
                        t.push(`🙊 即将过期: ${data.expireBean}京豆`)
                    }
                    break
                default:
                    // console.log(i)
                    break
            }
        }
        p.msg(t.join("\n"))
    }

    async _bean(p) {
        let user = p.data.user;
        let context = p.context;
        let c = await this.autoCurl({
                'form': `functionId=myBeanHome&body={}&t=1742384177284&appid=jd-home-mybean&client=ios&clientVersion=15.0.65`,
                user,
                algo: {
                    appId: '502bc',
                    expire: {
                        code: 2
                    }
                }
            }
        )
        try {
            let x = this.getDate(this.timestamp, 0, '-')
            let y = this.getDate(this.timestamp, -1, '-')
            let r = new RegExp(`${x}|${y}`)
            let xs = []
            let ys = []
            let wxb = 0
            for (let i = 1; i<50; i++) {
                let params = {
                    "url": `https://api.m.jd.com/client.action?functionId=getJingBeanBalanceDetail`,
                    "form": `body=${escape(JSON.stringify({"pageSize": "20", "page": i.toString()}))}&appid=ld`,
                    user
                }
                let s = await this.autoCurl(params)
                if (!this.match(r, JSON.stringify(s))) {
                    break
                }
                for (let k of s.detailList) {
                    // 无线宝(京东云边缘云)返豆剔除, 不算任务收入
                    if (/无线宝|边缘云/.test(k.eventMassage || '')) {
                        if (k.amount > 0 && k.date.includes(x)) wxb += +k.amount
                        continue
                    }
                    if (k.date.includes(x)) {
                        xs.push(k.amount)
                    }
                    else if (k.date.includes(y)) {
                        ys.push(k.amount)
                    }
                }
            }
            let xsa = xs.filter(d => d>0)
            let xsb = xs.filter(d => d<0)
            let ysa = ys.filter(d => d>0)
            let ysb = ys.filter(d => d<0)
            let bean = {}
            bean.today = [this.sum(xsa) || 0, this.sum(xsb) || 0]
            bean.yesterday = [this.sum(ysa) || 0, this.sum(ysb) || 0]
            bean.wuxianbao = wxb
            if (this.haskey(c, 'data.beanAmount')) {
                bean.expireBean = c.data.expireSoonNum
                bean.all = c.data.beanAmount
            }
            else {
                let b = await this.autoCurl({
                    url: 'https://api.m.jd.com/client.action',
                    form: 'functionId=jingBeanDetail&body=%7B%7D&uuid=bbf7dd32710a04388eec3dd&client=android&clientVersion=15.2.8&st=1640919377235&sv=112&sign=8ddd454db0ddfa76947dab4c35cc07fb',
                    user,
                    algo: {
                        sign: true
                    }
                })
                if (this.haskey(b, 'others')) {
                    bean.expire = this.haskey(b, 'others.jingBeanExpiringInfo.detailList')
                    bean.all = this.haskey(b, 'others.jingBeanBalance.jingBeanCount')
                }
            }
            context.dict.bean = bean
        } catch (e) {
        }
    }

    async _farm(p) {
        let user = p.data.user;
        let context = p.context;
        try {
            let f = await this.autoCurl({
                    'form': `appid=signed_farm_mp&body={"version":21,"channelParam":"1"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                    user,
                    algo: {
                        appId: 'c57f6',
                        expire: {
                            code: -30001
                        }
                    }
                }
            )
            let home = this.haskey(f, 'data.result') || {}
            if (home.bottleWater !== undefined) {
                context.dict.farm = {
                    water: home.bottleWater,
                    tips: home.waterTips || ''
                }
            }
        } catch (e) {
        }
    }

    async _ecard(p) {
        let user = p.data.user;
        let context = p.context;
        let s = await this.autoCurl({
                'url': `https://api.m.jd.com/`,
                'form': `appid=JDC_APP_H5&loginType=2&loginWQBiz=ECard&body=&functionId=smt_exCard_supermarket&client=m&isLoading=true`,
                user
            }
        )
        if (this.haskey(s, 'exCardVos.balance')) {
            context.dict.card = s.exCardVos.balance
        }
    }

    async _redpacket(p) {
        let user = p.data.user;
        let context = p.context;
        let s = await this.autoCurl({
                'url': `https://api.m.jd.com/client.action?functionId=myhongbao_getUsableHongBaoList`,
                'form': 'functionId=myhongbao_getUsableHongBaoList&body=%7B%22fp%22%3A%22-1%22%2C%22appToken%22%3A%22apphongbao_token%22%2C%22childActivityUrl%22%3A%22-1%22%2C%22country%22%3A%22cn%22%2C%22openId%22%3A%22-1%22%2C%22childActivityId%22%3A%22-1%22%2C%22applicantErp%22%3A%22-1%22%2C%22platformId%22%3A%22appHongBao%22%2C%22isRvc%22%3A%22-1%22%2C%22orgType%22%3A%222%22%2C%22activityType%22%3A%221%22%2C%22shshshfpb%22%3A%22-1%22%2C%22platformToken%22%3A%22apphongbao_token%22%2C%22organization%22%3A%22JD%22%2C%22pageClickKey%22%3A%22-1%22%2C%22platform%22%3A%221%22%2C%22eid%22%3A%22-1%22%2C%22appId%22%3A%22appHongBao%22%2C%22childActiveName%22%3A%22-1%22%2C%22shshshfp%22%3A%22-1%22%2C%22jda%22%3A%22-1%22%2C%22extend%22%3A%22-1%22%2C%22shshshfpa%22%3A%22-1%22%2C%22activityArea%22%3A%22-1%22%2C%22childActivityTime%22%3A%22-1%22%7D&uuid=487f7b22f68312d2c1bbc93b1aea44&client=apple&clientVersion=10.0.10&st=1652335589917&sv=111&sign=e47eb0c72c2a8107c714daf91cb89a65',
                user
            }
        )
        let end = Math.round(new Date(new Date().setHours(23, 59, 59)).getTime() / 1000) + 1
        let r = {
            current: [],
            app: [],
            lite: [],
            pingou: [],
            healthy: [],
            wechat: [],
        }
        let dict = {
            current: [0],
            currentExpire: [0],
            app: [0],
            pingou: [0],
            lite: [0],
            healthy: [0],
            wechat: [0],
            appExpire: [0],
            pingouExpire: [0],
            liteExpire: [0],
            healthyExpire: [0],
            wechatExpire: [0],
            all: [0],
            expire: [0],
            disable: [0],
        }
        try {
            for (let i of this.haskey(s, 'hongBaoList')) {
                dict.all.push(i.balance)
                let expire = end>i.endTime / 1000
                let disable = end - 2>i.beginTime / 1000
                let orgLimitStr = i.orgLimitStr
                if (disable) {
                    if (orgLimitStr.includes("商城")) {
                        dict.app.push(i.balance)
                        if (expire) {
                            dict.appExpire.push(i.balance)
                            dict.expire.push(i.balance)
                        }
                    }
                    else if (orgLimitStr.includes("极速") || orgLimitStr.includes("特价")) {
                        dict.lite.push(i.balance)
                        if (expire) {
                            dict.liteExpire.push(i.balance)
                            dict.expire.push(i.balance)
                        }
                    }
                    else if (orgLimitStr.includes("京喜")) {
                        dict.pingou.push(i.balance)
                        if (expire) {
                            dict.pingouExpire.push(i.balance)
                            dict.expire.push(i.balance)
                        }
                    }
                    else if (orgLimitStr.includes("健康")) {
                        dict.healthy.push(i.balance)
                        if (expire) {
                            dict.healthyExpire.push(i.balance)
                            dict.expire.push(i.balance)
                        }
                    }
                    else if (orgLimitStr.includes("小程序")) {
                        dict.wechat.push(i.balance)
                        if (expire) {
                            dict.wechatExpire.push(i.balance)
                            dict.expire.push(i.balance)
                        }
                    }
                    else {
                        dict.current.push(i.balance)
                        if (expire) {
                            dict.currentExpire.push(i.balance)
                            dict.expire.push(i.balance)
                        }
                    }
                }
                else {
                    dict.disable.push(i.balance)
                }
            }
        } catch (e) {
        }
        for (let i in r) {
            r[i] = [this.sum(dict[i], 2), this.sum(dict[`${i}Expire`], 2)].map(d => d == '0.00' ? 0 : d)
        }
        r.all = this.sum(dict.all, 2)
        r.expire = this.sum(dict.expire, 2)
        r.disable = this.sum(dict.disable, 2)
        context.dict.redpacket = r
    }

    sum(array, n = 0) {
        let sum = eval(array.join("+"))
        if (n) {
            sum = sum.toFixed(n)
        }
        return sum
    }

    getDate(date, day, join = '-') {
        var dd = new Date(date);
        dd.setDate(dd.getDate() + day);
        var y = dd.getFullYear();
        var m = dd.getMonth() + 1<10 ? "0" + (dd.getMonth() + 1) : dd.getMonth() + 1;
        var d = dd.getDate()<10 ? "0" + dd.getDate() : dd.getDate();
        return y + join + m + join + d;
    }
}

