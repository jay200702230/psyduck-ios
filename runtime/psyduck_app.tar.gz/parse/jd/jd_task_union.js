import {Template} from "../../template.js";
import vm from 'vm'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: "京东京享红包",
            help: 't3',
            verify: 1,
            sync: 1,
            prompt: {
                shareUrl: '京享红包分享链接',
                unionShareId: '可选项,自定义unionShareId,请确保该id是基于shareUrl生成',
                know: '1 # 跳过proxy/relayApi/relayProxy检测'
            },
            readme: ["锁佣有验证浏览指纹,需使用proxy代理或者relayApi转发或者relayProxy代理", "风控较严,算法经常变动,锁佣需谨慎,如订单一直异常,请停用此脚本", "默认获取前3个账号分享码"],
            crontab: 2,
            interval: 8000,
            enhance: false
        }
    }

    async prepare() {
        try {
            let js = await this.autoCurl('https://storage.360buyimg.com/webcontainer/js_security_v3_lite_0.1.5.js')
            const script = new vm.Script(`
            var window = {
                    document: {
                        cookie: ""
                     }
                }
            var document = window.document
            var navigator = {};
            window.navigator = navigator;
            setTimeout=function(){};
            var Element=function(){}
            ${js};
            new ParamsSignLite();`);
            const result = script.runInNewContext();
            await this.algo.getAlgo(result._version)
            if (this.algo.version != result._version) {
                this.msg("当前H5ST版本可能不是最新A")
            }
            else if (this.algo.algos.MD5('11111').toString("") != result._algos.MD5('11111').toString()) {
                this.msg("当前H5ST版本可能不是最新B")
            }
            else {
                let shareUrl = this.random(await this.getField(
                    'shareUrl'
                ))
                if (shareUrl) {
                    this.profile.shareUrl = shareUrl
                    await this.field('shareUrl')
                }
                else {
                    this.jump = true
                    return
                }
            }
        } catch (e) {
        }
    }

    async batch(p) {
        let shareUrl = p.shareUrl
        let {ua, h5st} = await this.uuaa()
        let cookie = ''
        let jda = await this.autoCurl({
                url: shareUrl,
                response: `all`,
                headers: {
                    'user-agent': ua,
                    referer: null
                },
                cookie
            }
        )
        if (!this.haskey(jda, 'cookie')) {
            jda = await this.autoCurl({
                    url: shareUrl,
                    response: `all`,
                    headers: {
                        'user-agent': ua,
                        referer: null
                    },
                    cookie,
                    relay: false,
                    shell: true
                }
            )
        }
        if (!this.haskey(jda, 'cookie')) {
            this.err("获取Jda出错")
        }
        let jdaUrl = this.match([/hrl\s*='([^\']+)'/, /hrl\s*="([^\"]+)"/], jda.content)
        cookie = `${cookie};${jda.cookie}`
        let scheme = await this.autoCurl({
                'url': jdaUrl + `&h5st=${h5st}`,
                maxRedirects: 0,
                scheme: 'http',
                'response': `all`,
                cookie,
                ua,
                referer: shareUrl
            }
        )
        if (!this.haskey(scheme, 'location')) {
            scheme = await this.autoCurl({
                    'url': jdaUrl + `&h5st=${h5st}`,
                    maxRedirects: 0,
                    scheme: 'http',
                    'response': `all`,
                    cookie,
                    ua,
                    referer: shareUrl,
                    relay: false,
                    shell: true
                }
            )
        }
        if (!this.haskey(scheme, 'cookie')) {
            this.err("获取Scheme出错")
        }
        cookie = `${cookie};${scheme.cookie}`
        let linkUrl = scheme.location.split("\r")[0]
        let actId = this.match(/active\/(\w+)/, linkUrl)
        let unionActId = this.match(/unionActId=(\d+)/, linkUrl)
        let d = this.match(/com\/(\w+)/, shareUrl)
        let unionShareId = []
        let client = ua.includes('Android') ? 'android' : 'apple'
        if (this.profile.unionShareId) {
            for (let shareId of this.profile.unionShareId.split("|")) {
                unionShareId.push(shareId)
            }
        }
        else {
            for (let user of this.help) {
                let shareUnion = await this.autoCurl({
                        'url': `https://api.m.jd.com/api?functionId=shareUnionCoupon&appid=u_hongbao&_=1716943673297&loginType=2&body={"unionActId":"${unionActId}","actId":"${actId}","platform":5,"unionShareId":"","d":"${d}","supportPic":2}&client=${client}&clientVersion=1.1.0&osVersion=15.1.1&screen=390*844&d_brand=iPhone&d_model=iPhone&lang=zh-CN&networkType=wifi&openudid=`,
                        algo: {
                            appId: 'c10dc',
                            store: cookie,
                        },
                        referer: linkUrl,
                        ua,
                        user
                    }
                )
                if (this.haskey(shareUnion, 'data.shareUrl')) {
                    let shareId = this.match(/s=(\w+)/, shareUnion.data.shareUrl)
                    this.log("获取账户", user, shareId)
                    unionShareId.push(shareId)
                }
            }
        }
        if (unionShareId.length) {
            p.actId = actId
            p.d = d
            p.unionActId = unionActId
            p.unionShareId = unionShareId
        }
        else {
            this.err("没有获取到unionShareId")
            p.expired = true
        }
        return p
    }

    async main(p) {
        let user = p.data.user
        let context = p.context;
        if (!p.info.relay && !p.info.proxy && !this.profile.proxy) {
            if (!this.profile.know) {
                p.err("锁佣有验证浏览指纹,需使用proxy代理或者relayApi转发,不然极易流量异常. 为保障账号安全,结束本次运行. 如还需运行,请自行设置know脚本变量")
                this.jump = true
                return
            }
        }
        let algo = context.algo || {}
        let gift = function(getCoupons) {
            for (let i of this.haskey(getCoupons, 'data.couponList')) {
                if (i.type == 1) {
                    p.msg(`获得[红包]🧧${i.discount}元`)
                }
                else if (i.type == 3) {
                    p.log(`获得[优惠券]🎟️满${i.quota}减${i.discount}`)
                }
                else if (i.type == 6) {
                    p.log(`获得[打折券]🎫满${i.quota}打${i.discount * 10}折`)
                }
                else {
                    p.log(`获得[未知]🎉${i.quota || ''} ${i.discount}`)
                }
            }
        }
        try {
            var {ua, h5st} = await this.uuaa()
            var client = ua.includes('Android') ? 'android' : 'apple'
            var store, actId, unionActId, d, linkUrl
            let getCode = await this.shareId(context)
            for (let [kk, code] of Object.entries(getCode)) {
                store = ''
                let url = `https://u.jd.com/${code.d}?s=${code.unionShareId}`
                let jda = await this.autoCurl({
                    url,
                    "response": "all",
                    "redirect": "follow",
                    "headers": {"user-agent": ua, "referer": ""},
                    user
                })
                if (!this.haskey(jda, 'cookie')) {
                    jda = await this.autoCurl({
                        url,
                        response: `all`,
                        headers: {
                            'user-agent': ua,
                            referer: null
                        },
                        user,
                        relay: false,
                        shell: true
                    })
                }
                if (!this.haskey(jda, 'cookie')) {
                    p.err("获取Jda出错")
                    return
                }
                store = jda.cookie
                let jdaUrl = this.match([/hrl\s*='([^\']+)'/, /hrl\s*="([^\"]+)"/], jda.content)
                let scheme = await this.autoCurl({
                        'url': jdaUrl + `&h5st=${h5st}`,
                        maxRedirects: 0,
                        scheme: 'http',
                        'response': `all`,
                        user,
                        ua,
                        referer: url,
                        algo: {
                            store
                        }
                    }
                )
                if (!this.haskey(scheme, 'location')) {
                    scheme = await this.autoCurl({
                            'url': jdaUrl + `&h5st=${h5st}`,
                            maxRedirects: 0,
                            scheme: 'http',
                            'response': `all`,
                            user,
                            ua,
                            referer: url,
                            algo: {
                                store
                            },
                            relay: false,
                            shell: true
                        }
                    )
                }
                if (!this.haskey(scheme, 'cookie')) {
                    p.err("获取Scheme出错")
                    return
                }
                linkUrl = scheme.location.split("\r")[0]
                let query = (this.query(linkUrl, '&', 'split'))
                actId = this.match(/active\/(\w+)/, linkUrl)
                var {
                    unionActId, d, utm_source, utm_medium, utm_campaign, utm_term
                } = query
                let __jdv = `122270672|${utm_source}|${utm_campaign}|${utm_medium}|${utm_term}|${new Date().getTime()}`
                store = `${store};${scheme.cookie};__jdv=${encodeURIComponent(__jdv)}`
                await this.autoCurl({
                    url: linkUrl,
                    referer: url,
                    ua,
                    user,
                    algo: {store}
                })
                let unionShareId = kk == 0 ? "" : code.unionShareId
                // console.log(kk, unionShareId)
                unionShareId = code.unionShareId
                let getCoupons = await this.autoCurl({
                        url: `https://api.m.jd.com/api`,
                        form: `functionId=getCoupons&appid=u_hongbao&loginType=2&body={"platform":5,"unionActId":"${unionActId}","actId":"${actId}","d":"${d}","unionShareId":"${unionShareId}","type":1,"qdPageId":"MO-J2011-1","mdClickId":"jxhongbao_ck","actType":1,"sType":"","kolCommand":""}&client=${client}&clientVersion=1.1.0&stk=appid,body,client,clientVersion,functionId`,
                        user,
                        algo: {
                            appId: 'c822a', argv: true,
                            store,
                            // token: false,
                            expire: {
                                "code": -2,
                            }
                        },
                        ua,
                        referer: linkUrl
                    }
                )
                let msg = this.haskey(getCoupons, 'msg')
                if (msg.includes('领取成功')) {
                    gift.call(this, getCoupons)
                }
                else {
                    p.log("领取失败:", msg)
                    if (msg == '达到领取上限') {
                        break
                    }
                    if (msg == '活动未开始') {
                        this.jump = 1
                        return
                    }
                    if (msg.includes("用户未登录")) {
                        return
                    }
                }
            }
            let qry = await this.autoCurl({
                    'url': `https://api.m.jd.com/api?functionId=queryFullGroupInfoMap&appid=u_hongbao&_=1716946027013&loginType=2&body={"actId":"${actId}","unionActId":"${unionActId}","platform":5,"d":"${d}","taskType":1,"prstate":0}&client=${client}&clientVersion=15.6.10&osVersion=15.1.1&screen=390*844&d_brand=iPhone&d_model=iPhone&lang=zh-CN&networkType=wifi&openudid=&aid=&oaid=`,
                    user,
                    algo: {appId: '7b74b', store}
                }
            )
            if (!this.haskey(qry, 'data.dayGroupData.groupInfo')) {
                p.err("没有获取到任务列表")
                return
            }
            for (let i of this.haskey(qry, 'data.dayGroupData.groupInfo')) {
                if (i.info) {
                    if (i.status == 1) {
                        p.log("正在运行:", i.info)
                        if (i.info.includes("点击") && i.taskTargetUrl) {
                            let query = this.query(i.taskTargetUrl, '&', 'split')
                            let goods = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=unionSearchRecommend&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"funName":"getSkuByMaterialId","page":{"pageNo":1,"pageSize":20},"param":{"materialId":12354,"sortName":null,"sortType":"","keyword":"","category1":null,"batchId":"","requestScene":1,"source":20200,"clientPageId":"union_activity_265222","packageName":""}}`,
                                    user,
                                    algo: {
                                        appId: '66248',
                                        store
                                    }
                                }
                            )
                            let goodList = this.haskey(goods, 'result.goodsSynopsisList') || []
                            for (let z of goodList.slice(0, 6)) {
                                let couponUrl = this.haskey(z, `purchasePriceInfo.unionCouponList.0.couponLink`)
                                if (couponUrl) {
                                    p.log("正在浏览:", z.skuName)
                                    let free = await this.autoCurl({
                                            'url': `https://api.m.jd.com/api?functionId=getUnionFreeCoupon&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"couponUrl":"${couponUrl}","recommendCouponUrl":["${couponUrl}"],"skuPrice":${z.purchasePriceInfo.thresholdPrice},"pageId":${query.union_page_id},"pageType":5,"source":20221}`,
                                            user,
                                            algo: {
                                                appI: '66248',
                                                store
                                            }
                                        }
                                    )
                                    await this.wait(1000)
                                }
                            }
                            let complete = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=completeUnionTask&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"unionActTask":"${query.unionActTask}"}`,
                                    // 'form':``,
                                    user,
                                    algo: {
                                        appId: '66248', store
                                    }
                                }
                            )
                            p.log(complete)
                        }
                        else if (this.haskey(i, ['adInfo.target_url', 'taskTargetUrl'])) {
                            let apStart = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api`,
                                    'form': `functionId=apStartTiming&appid=u_hongbao&_=1716946560092&loginType=2&body={"timerId":"${i.componentId}","uniqueId":"${i.taskId}","jumpUrl":"${encodeURIComponent(this.haskey(i, ['adInfo.target_url', 'taskTargetUrl']))}","jumpType":1}&client=${client}&clientVersion=15.6.10&osVersion=15.1.1&screen=390*844&d_brand=iPhone&d_model=iPhone&lang=zh-CN&networkType=wifi&openudid=`,
                                    user,
                                    algo: {
                                        appId: '0d977'
                                    }
                                }
                            )
                            p.log(this.haskey(apStart, 'errMsg') || apStart)
                            if (this.match([/\d+秒/, /浏览\d+/], i.info)) {
                                let ts = (this.match([/(\d+)秒/, /浏览(\d+)/], i.info))
                                try {
                                    let z = await this.autoCurl({
                                        url: 'https://api.m.jd.com/client.action',
                                        form: `functionId=apResetTiming&body={"timerId":"${i.componentId}","uniqueId":"${i.taskId}"}&build=169498&client=${client}&clientVersion=13.2.8&d_brand=apple&d_model=iPhone13%2C3&ef=1`,
                                        user,
                                        algo: {
                                            sign: true
                                        }
                                    })
                                    p.log("等待", ts)
                                    await this.wait(parseInt(ts) * 1000)
                                    let y = await this.autoCurl({
                                        url: 'https://api.m.jd.com/client.action',
                                        form: `functionId=apCheckTimingEnd&body={"timerId":"${i.componentId}","uniqueId":"${i.taskId}"}&build=169498&client=${client}&clientVersion=13.2.8&d_brand=apple&d_model=iPhone13%2C3&ef=1`,
                                        user,
                                        algo: {
                                            sign: true
                                        }
                                    })
                                } catch (e) {
                                    p.log("等待", ts)
                                    await this.wait(parseInt(ts) * 1000)
                                    let apsDoTask = await this.autoCurl({
                                            'url': `https://api.m.jd.com/api`,
                                            'form': `functionId=apCheckTimingEnd&appid=activities_platform&_=1716946560092&loginType=2&body={"timerId":"${i.componentId}","uniqueId":"${i.taskId}"}&build=169498&client=${client}&clientVersion=13.2.8&d_brand=apple&d_model=iPhone13%2C3&ef=1`,
                                            user,
                                            algo: {
                                                appId: '0d977'
                                            }
                                        }
                                    )
                                }
                            }
                            await this.wait(1000)
                        }
                        else if (i.info.includes("分享")) {
                            let shareUnion = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=shareUnionCoupon&appid=u_hongbao&_=1716943673297&loginType=2&body={"unionActId":"${unionActId}","actId":"${actId}","platform":5,"unionShareId":"","d":"${d}","supportPic":2,"taskId":"${i.taskId}"}&client=${client}&clientVersion=15.6.10&osVersion=15.1.1&screen=390*844&d_brand=iPhone&d_model=iPhone&lang=zh-CN&networkType=wifi&openudid=`,
                                    user,
                                    algo: {
                                        appId: 'c10dc',
                                        store
                                    }
                                }
                            )
                            // p.log(shareUnion)/
                            let share = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=unionShare&appid=u_hongbao&_=1716949639549&loginType=2&body={"funName":"share","param":{"shareReq":[{"shareType":5,"plainUrl":"${this.haskey(shareUnion, 'data.shareUrl')}","command":1}]}}&client=${client}&clientVersion=15.6.10&osVersion=15.1.1&screen=390*844&d_brand=iPhone&d_model=iPhone&lang=zh-CN&networkType=wifi`,
                                    // 'form':``,
                                    user,
                                    algo: {
                                        appId: '18813',
                                        store
                                    }
                                }
                            )
                            let getCoupons = await this.autoCurl({
                                    url: `https://api.m.jd.com/api`,
                                    form: `functionId=getCoupons&appid=u_hongbao&_=1716912812082&loginType=2&body={"actId":"${actId}","unionActId":"${unionActId}","platform":5,"d":"${d}","unionShareId":"","type":8,"qdPageId":"MO-J2011-1","mdClickId":"jxhongbao_ck","actType":1,"taskId":"${i.taskId}","agreeState":0,"sType":"","kolCommand":""}&client=${client}&clientVersion=1.1.0&stk=appid,body,client,clientVersion,functionId`,
                                    user,
                                    algo: {
                                        appId: 'c822a', argv: true,
                                        store,
                                        // token: false,
                                        expire: {
                                            "code": -2,
                                        }
                                    },
                                    ua,
                                    referer: linkUrl
                                }
                            )
                            let getCoupons2 = await this.autoCurl({
                                    url: `https://api.m.jd.com/api`,
                                    form: `functionId=getCoupons&appid=u_hongbao&_=1716912812082&loginType=2&body={"actId":"${actId}","unionActId":"${unionActId}","platform":5,"d":"${d}","unionShareId":"","type":8,"qdPageId":"MO-J2011-1","mdClickId":"jxhongbao_ck","actType":1,"taskId":"${i.taskId}","agreeState":1,"sType":"","kolCommand":""}&client=${client}&clientVersion=1.1.0&stk=appid,body,client,clientVersion,functionId`,
                                    user,
                                    algo: {
                                        appId: 'c822a', argv: true,
                                        store,
                                        // token: false,
                                        expire: {
                                            "code": -2,
                                        }
                                    },
                                    ua,
                                    referer: linkUrl
                                }
                            )
                            gift.call(this, getCoupons2)
                        }
                        else if (i.info.includes("点击")) {
                            let unionActTask = this.match(/unionActTask=([^\&]+)/, i.taskTargetUrl)
                            this.set({
                                referer: i.taskTargetUrl
                            })
                            let rec = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=unionSearchRecommend&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"funName":"getSkuByMaterialId","page":{"pageNo":1,"pageSize":20},"param":{"materialId":12354,"sortName":null,"sortType":"","keyword":"","category1":null,"batchId":"","requestScene":1,"source":20200,"clientPageId":"union_activity_265222","packageName":""}}`,
                                    // 'form':``,
                                    user,
                                    algo: {
                                        appId: '66248', store
                                    }
                                }
                            )
                            let ik = 0
                            for (let i of this.random(this.haskey(rec, 'result.goodsSynopsisList') || [], 123)) {
                                if (this.haskey(i, 'purchasePriceInfo.unionCouponList.0.couponLink')) {
                                    p.log("正在浏览:", i.skuName)
                                    let getUnionActivity = await this.autoCurl({
                                            'url': `https://api.m.jd.com/api?functionId=getUnionActivity&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"id":"265222","qdPageId":"MO-J2011-1","mdClickId":"union_activity_paycoupon_expo","skuList":"","skuListSign":"","platform":3,"clientPageId":"union_activity","parentActivityId":"","parentCouponConfigId":""}`,
                                            // 'form':``,
                                            user,
                                        }
                                    )
                                    let free = await this.autoCurl({
                                            url: `https://api.m.jd.com/api?functionId=getUnionFreeCoupon&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"couponUrl":"${i.purchasePriceInfo.unionCouponList[0].couponLink}","recommendCouponUrl":["${i.purchasePriceInfo.unionCouponList[0].couponLink}"],"skuPrice":${i.wlPrice},"pageId":265222,"pageType":5,"source":20221}`,
                                            user,
                                            algo: {
                                                appId: '66248'
                                            }
                                        }
                                    )
                                    if (this.haskey(free, 'data')) {
                                        ik++
                                    }
                                    if (ik>=5) {
                                        break
                                    }
                                    await this.wait(1000)
                                }
                            }
                            let comp = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=completeUnionTask&appid=u_activity_h5&loginType=2&client=${client}&clientVersion=&body={"unionActTask":"${(unionActTask)}"}`,
                                    // 'form':``,
                                    user,
                                    algo: {
                                        appId: '66248'
                                    }
                                }
                            )
                            p.log(comp)
                        }
                    }
                    else {
                        p.log("任务完成:", i.info)
                    }
                }
            }
            qry = await this.autoCurl({
                    'url': `https://api.m.jd.com/api?functionId=queryFullGroupInfoMap&appid=u_hongbao&_=1716946027013&loginType=2&body={"actId":"${actId}","unionActId":"${unionActId}","platform":5,"d":"${d}","taskType":1,"prstate":0}&client=${client}&clientVersion=15.6.10&osVersion=15.1.1&screen=390*844&d_brand=iPhone&d_model=iPhone&lang=zh-CN&networkType=wifi&openudid=&aid=&oaid=`,
                    user,
                    algo: {appId: '7b74b'}
                }
            )
            let getCoupons = await this.autoCurl({
                    url: `https://api.m.jd.com/api`,
                    form: `functionId=getCoupons&appid=u_hongbao&_=1716912812082&loginType=2&body={"actId":"${actId}","unionActId":"${unionActId}","platform":5,"d":"${d}","unionShareId":"","type":3,"qdPageId":"MO-J2011-1","mdClickId":"jxhongbao_ck","actType":1,"sType":"","kolCommand":""}&client=${client}&clientVersion=1.1.0&stk=appid,body,client,clientVersion,functionId`,
                    user,
                    algo: {
                        appId: 'c822a', argv: true,
                        store,
                        expire: {
                            "code": -2,
                        }
                    },
                    ua,
                    referer: linkUrl
                }
            )
            gift.call(this, getCoupons)
            let join = this.haskey(qry, 'data.dayGroupData.joinNum')
            let getCoupons2 = await this.autoCurl({
                    url: `https://api.m.jd.com/api`,
                    form: `functionId=getCoupons&appid=u_hongbao&_=1716912812082&loginType=2&body={"actId":"${actId}","unionActId":"${unionActId}","platform":5,"d":"${d}","unionShareId":"","type":2,"qdPageId":"MO-J2011-1","mdClickId":"jxhongbao_ck","actType":1,"sType":"","kolCommand":""}&client=${client}&clientVersion=1.1.0&stk=appid,body,client,clientVersion,functionId`,
                    user,
                    algo: {
                        appId: 'c822a', argv: true,
                        store,
                        expire: {
                            "code": -2,
                        }
                    },
                    ua,
                    referer: linkUrl
                }
            )
            gift.call(this, getCoupons2)
            let isDo = 0
            for (let i of this.haskey(qry, 'data.dayGroupData.groupInfo')) {
                if (i.info) {
                    if (i.status == 1) {
                        isDo++
                    }
                }
            }
            if (!isDo) {
                p.info.work = true
            }
        } catch (e) {
            p.err(e)
        }
    }

    async uuaa() {
        let type = this.random(['weixin', 'wechat'])
        let ua = this.userAgents()[type]
        return {
            ua,
            h5st: this.algo.hashCode(ua)
        }
    }

    async shareId(context) {
        let code = []
        for (let unionShareId of context.unionShareId) {
            code.push({
                d: context.d,
                actId: context.actId,
                unionActId: context.unionActId,
                unionShareId
            })
        }
        try {
            if (this.syncStorage) {
                let syncStorages = this.syncStorage
                let range = syncStorages.range || 1
                let rand = this.rand(1, range)
                let syncStorage = this.random(syncStorages.data)
                if (rand == 1) {
                    for (let unionShareId of syncStorage.unionShareId) {
                        code.push({
                            d: syncStorage.d,
                            actId: syncStorage.actId,
                            unionActId: syncStorage.unionActId,
                            unionShareId
                        })
                    }
                    let c1 = code.slice(0, 2)
                    let c2 = code.slice(2)
                    let c3 = this.random(c2, c2.length)[0]
                    code = [...c1, ...[c3]]
                }
            }
        } catch (e) {
        }
        return code
    }
}


