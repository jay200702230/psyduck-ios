import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东超市对暗号',
            crontab: `${this.rand(0, 40)} ${this.rand(13, 18)},${this.rand(21, 22)} * * *`,
            sync: 1,
            readme: "可能存在答案未及时更新的情况,可以先用主号答题,其他账号会共享答案"
        }
    }

    async prepare() {
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let list = await this.autoCurl({
                'url': `https://api.m.jd.com/atop_channel_question_list`,
                'form': `appid=jd-super-market&t=1747200195200&functionId=atop_channel_question_list&client=m&body={"babelActivityId":"01718639","bizCode":"cn_retail_jdsupermarket","scenario":"free_order","babelChannel":"ttt5","isJdApp":"1","isWx":"0"}`,
                user
            }
        )
        let items = this.haskey(list, 'data.floorData.items')
        let status = 1
        if (items) {
            let dateGroupQuestionList = items[0].dateGroupQuestionList
            for (let i of dateGroupQuestionList) {
                for (let j of i.dateQuestionList) {
                    if (j.completionFlag) {
                        p.log("已答题:", j.question, j.answer)
                        await this.setTemp(j.encryptAssignmentId, j.answer, 864000)
                    }
                    else {
                        status = 0
                        p.log("正在答题:", j.question)
                        let answer = this.syncStorage[j.encryptAssignmentId] || await this.getTemp(j.encryptAssignmentId)
                        if (answer) {
                            p.log("命中答案:", answer)
                            let submit = await this.autoCurl({
                                    'url': `https://api.m.jd.com/atop_channel_submit_answer`,
                                    'form': `appid=jd-super-market&t=1747199104358&functionId=atop_channel_submit_answer&client=m&body={"babelActivityId":"01718639","encryptAssignmentId":"${j.encryptAssignmentId}","answer":"${answer}","bizCode":"cn_retail_jdsupermarket","scenario":"free_order","babelChannel":"ttt5","isJdApp":"1","isWx":"0"}`,
                                    user
                                }
                            )
                            if (this.haskey(submit, 'data.interactiveRewardVO')) {
                                status = 1
                                let rt = submit.data.interactiveRewardVO.rewardType
                                if (rt == 56) {
                                    p.award(submit.data.interactiveRewardVO.rewardValue, 'card')
                                }
                                else if (rt == 35) {
                                    p.award(submit.data.interactiveRewardVO.hongbaoAmount, 'redpacket')
                                }
                                else {
                                    p.log(submit.data.interactiveRewardVO)
                                }
                                if (this.haskey(submit, 'data.freeOrderTaskVoList')) {
                                    p.log(submit.data.freeOrderTaskVoList)
                                }
                            }
                            else {
                                p.log(submit)
                            }
                            await this.wait(2000)
                        }
                        else {
                            p.log("答案未更新...")
                            this.jump = true
                        }
                    }
                }
            }
        }
        else {
            status = 0
            p.log('没有获取到数据...')
        }
        if (status) {
            p.info.work = true
        }
    }
}

