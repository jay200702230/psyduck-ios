import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://h5static.m.jd.com/mall/active/3b86xJ8EVja357au9NNG6ZSeV3Fw/index.html'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东拍卖频道任务', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // auctionChannel 族: client=m, h5st 域 d8c25
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) { p.log('no signer'); return null }
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'auctionChannel', client: 'm', clientVersion: '1.1.0'}, appId: 'd8c25', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('loginType', '2'); f.append('loginWQBiz', '')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    _biz(r) {
        if (!r) return null
        if (r.data && r.data.result && r.data.result.bizCode != null) return r.data.result.bizCode
        if (r.data && r.data.bizCode != null) return r.data.bizCode
        return r.code
    }

    async getList(p, user) {
        const r = await this.wg(p, user, 'common_task_list', {channelId: '13', ext: {queryReceiveTimes: 1, channel: 0}}, 2)
        return ((((r || {}).data || {}).result || {}).taskInfo || {}).taskList || []
    }

    itemsOf(t) {
        return ((t.ext || {}).shoppingActivity || [])
    }

    async doJob(p, user, t, it) {
        const aid = t.encryptAssignmentId
        const item = it.advId || it.itemId || String(it.id || '1')
        const jump = it.url || ''
        const base = {channelId: '13', itemId: item, assignmentId: aid}
        const wd = (t.ext || {}).waitDuration || 5
        // 领取制(ot=9): 领取必须带 ext.jumpUrl+channel:0; 完成制: 直接 actionType=0
        if (t.assignmentType === 1 && jump) {
            const r1 = await this.wg(p, user, 'common_do_task', Object.assign({}, base, {actionType: 1, ext: {jumpUrl: jump, channel: 0}}), 1)
            const b1 = this._biz(r1)
            if (b1 !== 0 && b1 !== 103 && ![-100, 107, 110, 31].includes(b1)) this._fails++
            if (b1 === 31) return false
            await this.wait((wd + 6) * 1000)
        } else {
            await this.wait(3000)
        }
        const r2 = await this.wg(p, user, 'common_do_task', Object.assign({}, base, {actionType: 0, ext: jump ? {jumpUrl: jump, channel: 0} : {channel: 0}}), 1)
        const b2 = this._biz(r2)
        if (b2 !== 0 && b2 !== 103 && ![-100, 107, 110, 31].includes(b2)) this._fails++
        if (b2 === 31) return false
        if (b2 === 110) await this.wait(8000)
        await this.wait(2500)
        const r3 = await this.wg(p, user, 'common_do_task', Object.assign({}, base, {actionType: 0, ext: Object.assign({doReceiveRewards: 1}, jump ? {jumpUrl: jump, channel: 0} : {channel: 0})}), 1)
        const b3 = this._biz(r3)
        if (b3 !== 0 && b3 !== 103 && ![-100, 107, 110, 31].includes(b3)) this._fails++
        return true
    }

    async main(p) {
        const user = p.data.user
        for (let round = 0; round < 4; round++) {
            const tasks = await this.getList(p, user)
            if (!tasks.length) { p.log('任务池空或频控'); return }
            let acted = 0
            for (const t of tasks) {
                if (t.completionFlag) continue
                const cnt = t.completionCnt || 0
                if (cnt >= t.assignmentTimesLimit) continue
                const its = this.itemsOf(t)
                if (!its.length && t.assignmentType !== 0) continue
                p.log('做:', t.assignmentName, cnt + '/' + t.assignmentTimesLimit)
                const it = its[0] || {}
                const ok = await this.doJob(p, user, t, it)
                if (ok) acted++
                await this.wait(8000)
            }
            if (!acted) { p.log('本轮无动作, 收工'); break }
        }
        const fin = await this.getList(p, user)
        let bad = 0
        for (const t of fin) {
            if (!t.completionFlag && (t.completionCnt || 0) < t.assignmentTimesLimit) {
                p.log('未清:', t.assignmentName, (t.completionCnt || 0) + '/' + t.assignmentTimesLimit)
                bad++
            }
        }
        p.log(bad ? '剩余 ' + bad + ' 项(频控/native, 已完结)' : '全部清完')
        p.info.work = true
    }
}
