import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

// 运动馆抽奖机 (linkId=MrKB46kaB3CizIRRqnjB3A, 页面 oKAAQpTfmbKWmL338JdgxNDeWK2)
// 协议链路 (2026-10-20 实测全通):
//   lotteryMachineHome/lotteryMachineDraw + apsDoTask(SIGN, taskId=-9999)
//   关键: android 表单 platform=3 + 双token(ext.x-api-eid-token/wg-sdk-token) + pageUrl 逐字复刻
//   h5st appId=d7439 (jd_signer_node.mjs 本地签名), eid_pair 过期需重跑 pairdump.sh
const LID = 'MrKB46kaB3CizIRRqnjB3A'
const PAGE_URL = 'https://pro.m.jd.com/mall/active/oKAAQpTfmbKWmL338JdgxNDeWK2/index.html'
const EID = 'jdd03AEJINAIPWUEFEJ7BRW25JIDK447LPR3RIEQYSJT6RSIZF4W2FRZY4HQLDLZ6ETXOCU7AKOILZ6577SK6CKIUE6QHPEAAAANBK526UAQAAAAADIPJY25CC2OCNQX'
const SDK = 'jdd01P5UG2U4Z24XAYGUJ2Q5N43EHF62XG455SIN35WSCEGFTKHFVBAIY5LXLXTC5FILMGKVEOZSU6NND6FUV432KI63IU7JR73DB5ADUCTY01234567'
const UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东运动馆抽奖',
            turn: 1,
            crontab: 10,
            keyExpire: 300
        }
        this.INI = CK_INI
    }

    async prepare() {
        try { this.signer = await import('./jd_signer_node.mjs') } catch (e) { this.signer = null }
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(this.INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.freshCookie()
    }
    freshCookie() {
        if (this._ck && Date.now() - this._ckAt < 600000) return this._ck
        try {
            const txt = fs.readFileSync(this.INI, 'utf8')
            let cur = '', main = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !main) main = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = main || any
            if (ck) { this._ck = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) {}
        return this._ck || ''
    }

    // android 页面原版表单 (d7439 签名 + 双token + ext)
    apSend(fn, bodyObj, h5stApp) {
        if (!this.signer) return Promise.resolve(null)
        const body = JSON.stringify(bodyObj)
        const ext = JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': EID, 'wg-sdk-token': SDK, pageUrl: encodeURIComponent(PAGE_URL)})
        const signed = this.signer.sign({
            functionId: fn, appId: h5stApp || 'd7439', ck: this.freshCookie(), body,
            base: {
                appid: 'activities_platform', client: 'android', clientVersion: '15.10.50',
                t: String(Date.now()), body, functionId: fn,
                platform: '3', loginType: '2', loginWQBiz: 'wegame',
                uuid: '3303461326131633-2313731633939346', build: '102649', screen: '360*800', networkType: 'wifi',
                d_brand: 'OnePlus', d_model: 'IN2010', lang: 'zh_CN', osVersion: '13', partner: 'oppo',
                'wg-sdk-token': SDK, ext, eufv: '1', eu: '3303461326131633', fv: '2313731633939346', cthr: '1'
            }
        })
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        const ck = this.freshCookie()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: PAGE_URL, referer: PAGE_URL, 'user-agent': UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    if (!d) { resolve({__httpStatus: rs.statusCode, __emptyBody: true}); return }
                    try { resolve(JSON.parse(d)) } catch (e) { resolve(d) }
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    briefAward(dr) {
        const d = (dr && dr.data) || {}
        return d.prizeConfigName || d.prizeDesc || (d.prizeType === 0 ? '谢谢参与' : JSON.stringify(d).slice(0, 120))
    }

    async main(p) {
        if (!this.signer) { p.err('签名器缺失'); return }
        // 1. 任务先做完 (签到送次数)
        const tl = await this.apSend('apTaskList', {linkId: LID, queryType: 0, channel: 4})
        const tasks = (tl && tl.data) || []
        if (!tasks.length) { p.log('任务列表拉取失败: ' + JSON.stringify(tl).slice(0, 200)) }
        for (const t of tasks) {
            if (t.taskFinished) { p.log('任务已完成:', t.taskShowTitle || t.taskTitle); continue }
            if (t.taskType === 'SIGN') {
                const dr = await this.apSend('apsDoTask', {taskType: 'SIGN', taskId: -9999, channel: 4, checkVersion: true, linkId: LID, pipeExt: t.pipeExt || {}, taskInsert: false})
                p.log(`[签到] ${dr && dr.success ? '成功' : '失败 ' + JSON.stringify(dr).slice(0, 150)}`)
                await this.wait(1500)
            }
            else if (t.taskType === 'BROWSE_CHANNEL') {
                // 非计时直报制: 循环 do 吃满次数, 奖励随 do 直接发 (alreadyGranted), 领奖接口会 2014 属正常
                const pipeExt = {...(t.pipeExt || {})}
                const itemId = encodeURIComponent(PAGE_URL)
                const need = (t.taskLimitTimes || 3) - (t.taskDoTimes || 0)
                for (let k = 0; k < need; k++) {
                    const dr = await this.apSend('apsDoTask', {taskType: 'BROWSE_CHANNEL', taskId: -9999, channel: 4, checkVersion: true, linkId: LID, pipeExt, itemId}, '54ed7')
                    p.log(`[${t.taskShowTitle || t.taskTitle}] do${k + 1}/${need}: ` + (dr && dr.success ? `ok ${dr.data && dr.data.userFinishedTimes}/${dr.data && dr.data.finishNeed}` : JSON.stringify(dr).slice(0, 120)))
                    await this.wait(8000 + Math.floor(Math.random() * 4000))
                }
                await this.apSend('apTaskDrawAward', {taskType: 'BROWSE_CHANNEL', taskId: -9999, channel: 4, checkVersion: true, linkId: LID, pipeExt}, 'f0f3f')
            }
            else if (t.taskType !== 'SHARE_INVITE') {
                p.log(`[${t.taskShowTitle || t.taskTitle}] 类型 ${t.taskType} 未支持, 跳过`)
            }
            // SHARE_INVITE 邀请类不做
        }
        // 2. 抽奖吃干净 remainTimes
        let home = await this.apSend('lotteryMachineHome', {linkId: LID, taskId: '', inviter: ''})
        if (!(home && home.data)) { p.log('Home 失败: ' + JSON.stringify(home).slice(0, 200)); return }
        let num = home.data.remainTimes || 0
        p.log(`可抽奖次数: ${num}`)
        for (let i = 0; i < num; i++) {
            const dr = await this.apSend('lotteryMachineDraw', {linkId: LID})
            if (dr && dr.success) p.log(`[抽奖] ${this.briefAward(dr)}`)
            else if (dr && dr.code === 18002) { p.log('抽奖机会用完'); break }
            else { p.log('抽奖异常: ' + JSON.stringify(dr).slice(0, 200)); break }
            await this.wait(1500)
        }
        p.info.work = true
    }
}
