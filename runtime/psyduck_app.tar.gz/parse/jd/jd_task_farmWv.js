import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'

// 农场任务 v8 纯协议活动平台版 (2026-10-15):
// 手动抓包证实真通道 = 活动平台 apTaskList/apStartTaskTime/apsDoTask/apTaskDrawAward
// h5st = node 直跑京东 SDK + 真机 WQ_* seed, 按 functionId 分 appId/appid:
//   apTaskList/apsDoTask=54ed7  apStartTaskTime=acb1e  apTaskDrawAward=f0f3f
//   farm_water=28981  farm_home=c57f6 (signed_farm_mp)
// 说明: 框架 jdAlgo 签名链路的 activities_platform 写接口被服务端风控(空返回),
//   本脚本自带签名器直发请求特征干净可过, 浏览/关注/浇水任务全部走本链路。
// 签名器: ./jd_signer_node.mjs + farm_sign_sdk.js + farm_wq_seed.json (同目录)
const LINK_IDS = ['fWWo3YmB983abNOJPR7veg', '2O3VP9OxmzfMQU8WWKZ6aQ']
const PAGE_URL = 'https://pro.m.jd.com/mall/active/42HV4J3Q87B2xFQMJk81PCc1mEs3/index.html'
const EU = '3303461326131633', FV = '2313731633939346'
// [h5st签名appId, 表单appid]
const APPIDS = {
    apTaskList: ['54ed7', 'activities_platform'],
    apsDoTask: ['54ed7', 'activities_platform'],
    apStartTaskTime: ['acb1e', 'activity_platform_se'],
    apTaskDrawAward: ['f0f3f', 'activities_platform'],
    farm_water: ['28981', 'signed_farm_mp'],
    farm_home: ['c57f6', 'signed_farm_mp']
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东农场浏览任务',
            turn: 1,
            crontab: 4,
            keyExpire: 180
        }
        this.INI = (() => {
            for (const pt of ['/ql/data/psyduck/cookie/jd.ini', '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini']) {
                try { if (fs.existsSync(pt)) return pt } catch (e) {}
            }
            return '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini'
        })()
    }

    async prepare() {
        try { this.signer = await import('./jd_signer_node.mjs') } catch (e) { this.signer = null }
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(this.INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.freshCookie()
    }
    freshCookie() {
        if (this._ck && Date.now() - this._ckAt < 600000) return this._ck
        try {
            const txt = fs.readFileSync(this.INI, 'utf8')
            let cur = '', main = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !main) main = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['',''])[1]
            const ck = main || any
            if (ck) { this._ck = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) {}
        return this._ck || ''
    }

    eid() {
        if (this._eid !== undefined) return this._eid
        const m = this.freshCookie().match(/3AB9D23F7A4B3CSS=([^;\s]+)/)
        this._eid = m ? m[1] : ''
        return this._eid
    }

    // 活动平台/农场纯协议请求 (node h5st 签名, /api 通道)
    apReq(p, fn, bodyObj) {
        if (!this.signer) { p.err('签名器缺失(需同目录 jd_signer_node.mjs/farm_sign_sdk.js/farm_wq_seed.json)'); return Promise.resolve(null) }
        const cfg = APPIDS[fn] || ['54ed7', 'activities_platform']
        const ck = this._ckForUser(p.data.user)
        const body = JSON.stringify(bodyObj)
        const t = String(Date.now())
        const ext = JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': this.eid(), 'wg-sdk-token': '', pageUrl: encodeURIComponent(PAGE_URL)})
        const signed = this.signer.sign({
            functionId: fn, appId: cfg[0], ck, body,
            base: {
                appid: cfg[1],
                client: 'android', clientVersion: '15.10.50', t, body, functionId: fn,
                platform: '3', loginType: '2', loginWQBiz: 'wegame',
                uuid: EU + '-' + FV, build: '102649', screen: '360*800', networkType: 'wifi',
                d_brand: 'OnePlus', d_model: 'IN2010', lang: 'zh_CN', osVersion: '13', partner: 'oppo',
                'wg-sdk-token': '', ext, eufv: '1', eu: EU, fv: FV, cthr: '1'
            }
        })
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const form = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(form), cookie: ck,
                    origin: PAGE_URL, referer: PAGE_URL,
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(form); rq.end()
        })
    }

    brief(t) {
        return {
            asg: (t.pipeExt && t.pipeExt.assignmentId) || t.assignmentId || '',
            type: String(t.taskType || ''),
            src: t.taskSourceUrl || (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].itemId) || '',
            pipeItem: (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].pipeExt && t.taskItemList[0].pipeExt.itemId) || (t.pipeExt && t.pipeExt.itemId) || '',
            times: (t.taskDoTimes || 0), limit: (t.taskLimitTimes || 0),
            fin: t.taskFinished === true,
            title: String(t.taskShowTitle || t.taskTitle || '').slice(0, 14),
            tl: (t.timeLimitPeriod || 0),
            raw: t
        }
    }

    // 浇水任务: apsDoTask 直接上报即计数(实测无需受理, 服务端校验当天 farm_water 总数)
    // 策略: 先循环上报吃掉历史未上报的浇水记录(零水滴), 吃干了才 farm_water 补浇再报
    async doWater(p) {
        let total = 0
        for (const LINK_ID of LINK_IDS) {
            const lr = await this.apReq(p, 'apTaskList', {linkId: LINK_ID})
            const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
            const wt = tasks.find(t => t.taskType === 'CUMULATIVE_TIMES' && String(t.taskShowTitle || '').includes('浇水') && (t.taskDoTimes || 0) < (t.taskLimitTimes || 0))
            if (!wt) continue
            const left = (wt.taskLimitTimes || 0) - (wt.taskDoTimes || 0)
            p.log(`[${LINK_ID.slice(0, 6)}] 浇水任务还需 ${left} 次(直接上报, 无需受理)`)
            let doneN = 0, failN = 0, rate = 0
            while (doneN < left && failN < 2 && rate < 3) {
                const dr = await this.apReq(p, 'apsDoTask', {taskType: 'CUMULATIVE_TIMES', taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: wt.pipeExt || {}, taskInsert: false})
                if (dr && (dr.success === true || dr.code === 0)) {
                    failN = 0
                    doneN++; total++
                    const uf = (dr.data && dr.data.userFinishedTimes) || '?', fn = (dr.data && dr.data.finishNeed) || '?'
                    p.log(`[${LINK_ID.slice(0, 6)}] 上报[${doneN}/${left}] 进度:${uf}/${fn}${dr.data && dr.data.finished ? ' [任务完成!]' : ''}`)
                    if (dr.data && dr.data.finished) break
                    await this.wait(2000)
                    continue
                }
                // 上报被拒 = 无可吃的浇水记录, 浇一次水再报
                failN++
                const wr = await this.apReq(p, 'farm_water', {version: 21, channelParam: '1', waterType: 2, onlineGiftPackageFlg: true, babelChannel: 'ttt6', lbsSwitch: true})
                const bw = wr && wr.data && wr.data.result && wr.data.result.bottleWater
                if (!bw) {
                    const code = String((wr && wr.code) || (wr && wr.data && wr.data.bizCode) || '')
                    const msg = String((wr && wr.msg) || (wr && wr.data && wr.data.bizMsg) || '')
                    if (/405|火爆|稍后|频繁|繁忙/.test(code + msg)) {
                        rate++
                        p.log(`浇水限流(${msg || code}) 重试${rate}/3`)
                        await this.wait(20000)
                        continue
                    }
                    p.log(`水不足/浇水异常(${code} ${msg}), 本轮已上报${doneN}次, 攒够水滴下轮继续`)
                    break
                }
                p.log(`[${LINK_ID.slice(0, 6)}] 浇水1次(剩余:${bw}), 继续上报`)
                await this.wait(2500)
            }
            // 领分段奖励
            const aw = await this.apReq(p, 'apTaskDrawAward', {taskType: 'CUMULATIVE_TIMES', taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: wt.pipeExt || {}})
            const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
            if (awd) p.log(`[${LINK_ID.slice(0, 6)}] 浇水奖励 ${awd}`)
        }
        if (total) p.log(`本轮浇水任务共上报 ${total} 次`)
        return total
    }

    async main(p) {
        let lastRej = 0
        try { lastRej = +(await this.getTemp('farmWvReject')) || 0 } catch (e) {}
        if (lastRej && Date.now() - lastRej < 180000) {
            p.log('农场浏览: ' + Math.ceil((180000 - (Date.now() - lastRej)) / 60000) + '分钟前被软拒过, 本轮跳过')
            p.info.work = true
            return
        }

        // GAME/PLAY_/MINI_GAME 不再跳过: AI掼蛋/斗地主类「访问即完成」可协议做, do 拒自动落补领/跳过
        const skipType = /^(CUMULATIVE_TIMES|JOIN_OTHER_ACT|ADD_WIDGET|WECHAT_SHARE|ORDER_MARK|SUBSCRIBE|WECHAT|ACCUMULATE|SHOPPING|SIGN|WATER)/
        let done = 0, fails = 0

        // 1. 先跑浏览攒水滴
        linkLoop: for (const LINK_ID of LINK_IDS) {
        const skipAsg = new Set()
        let guard = 0
        while (guard++ < 40) {
            const lr = await this.apReq(p, 'apTaskList', {linkId: LINK_ID})
            const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
            if (!tasks.length) { p.err('apTaskList 无数据: ' + JSON.stringify(lr).slice(0, 100)); continue linkLoop }
            if (guard === 1) p.log(`[${LINK_ID.slice(0, 6)}] 任务池 ${tasks.length} 个`)

            const cur = tasks.map(t => this.brief(t)).find(b => !b.fin && !skipAsg.has(b.asg) && !skipType.test(b.type) && /^(BROWSE|FOLLOW|EXTERNAL_BROWSE|GAME|PLAY_|MINI_GAME)/.test(b.type))
            if (!cur) break

            let src = cur.src
            if (/^FOLLOW/.test(cur.type)) {
                // 关注类 itemId 用服务端原值(店铺/频道ID), 不拼 URL
            }
            else if (/^\d+$/.test(src)) src = 'http://item.jd.com/' + src + '.html'
            const itemId = src ? encodeURIComponent(src) : encodeURIComponent(PAGE_URL)
            // pipeExt 用服务端下发的原始对象(自拼会被严格任务校验拒「没有达到做任务条件」)
            const pipeExt = (cur.raw.pipeExt && Object.keys(cur.raw.pipeExt).length) ? {...cur.raw.pipeExt} : {taskType: cur.type, assignmentId: cur.asg}
            if (cur.pipeItem && !pipeExt.itemId) pipeExt.itemId = cur.pipeItem

            const st = await this.apReq(p, 'apStartTaskTime', {linkId: LINK_ID, taskId: -9999, itemId, channel: 4, pipeExt})
            if (!(st && (st.success === true || st.code === 0))) {
                const em = (st && (st.errMsg || st.msg)) || JSON.stringify(st).slice(0, 60)
                p.log(`[${cur.title}] 受理拒: ${em}`)
                skipAsg.add(cur.asg); fails++
                await this.wait(/太多|火爆|稍后|频繁/.test(em) ? 8000 : 3000)
                continue
            }
            await this.wait((cur.tl > 0 ? cur.tl : 10) * 1000 + 1500)

            const dr = await this.apReq(p, 'apsDoTask', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt, itemId})
            if (!(dr && (dr.success === true || dr.code === 0))) {
                const dm = (dr && (dr.errMsg || dr.msg)) || JSON.stringify(dr).slice(0, 60)
                p.log(`[${cur.title}] do拒: ` + dm)
                // 「任务已完成」「没有达到做任务条件」均不跳过: App内真实完成的任务 do 上报会被拒, 直接落 drawAward 补领
                if (!/已完成|没有达到做任务条件/.test(dm)) {
                    skipAsg.add(cur.asg); fails++
                    await this.wait(3000)
                    continue
                }
                await this.wait(1500)
            } else {
                await this.wait(2000 + Math.floor(Math.random() * 2000))
            }
            const aw = await this.apReq(p, 'apTaskDrawAward', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt})
            const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
            if (awd) { done++; p.log(`[${cur.title}] ${awd}`) }
            else {
                p.log(`[${cur.title}] 领奖: ` + ((aw && (aw.errMsg || aw.msg)) || JSON.stringify(aw).slice(0, 60)))
                if (aw && aw.success === true) done++
                else skipAsg.add(cur.asg)
            }
            await this.wait(3000 + Math.floor(Math.random() * 3000))
        }
        }

        // 2. 再跑浇水消耗水滴(浏览刚攒的 + 原有余额)
        await this.doWater(p)

        // 2.5 收尾扫荡: 全池补领悬赏(前轮做完没领的 canDrawAwardNum>0)
        try {
            for (const LID of LINK_IDS) {
                const lr2 = await this.apReq(p, 'apTaskList', {linkId: LID})
                const ts2 = (lr2 && lr2.data && (Array.isArray(lr2.data) ? lr2.data : lr2.data.taskList)) || []
                for (const t2 of ts2) {
                    if (!t2.canDrawAwardNum) continue
                    const pe2 = t2.pipeExt || {}
                    for (let k = 0; k < t2.canDrawAwardNum; k++) {
                        const aw2 = await this.apReq(p, 'apTaskDrawAward', {taskType: t2.taskType, taskId: t2.id === undefined ? -9999 : t2.id, channel: 4, checkVersion: true, linkId: LID, pipeExt: pe2})
                        const awd2 = aw2 && Array.isArray(aw2.data) ? aw2.data.map(x => '+' + x.awardGivenNumber + (x.awardTitle || x.awardName || '')).join(',') : ''
                        if (awd2) { done++; p.log(`[补领][${String(t2.taskShowTitle || t2.taskTitle || '').slice(0, 14)}] ${awd2}`) }
                        await this.wait(1500)
                    }
                }
            }
        } catch (e) { p.log('补领异常 ' + e) }

        // 3. 收尾: farm_home 水滴余额
        const hm = await this.apReq(p, 'farm_home', {version: 21, channelParam: '1'})
        const bw = hm && hm.data && hm.data.result && hm.data.result.bottleWater
        p.log(`浏览完成${done} 失败${fails} 水滴余额: ${bw === undefined ? '?' : bw}`)
        if (done === 0 && fails > 0) {
            await this.setTemp('farmWvReject', String(Date.now()))
            p.log('活动平台全拒, 3 分钟退避')
        }
        p.info.work = true
    }
}
