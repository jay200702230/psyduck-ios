import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const BSC_PAGE = 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html'
const BSC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '豆子中心刮卡',
            pageUrl: 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html',
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html'
            },
            turn: 1,
            crontab: 3
        }
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _bsCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        // ck_full 覆盖 (手动全量罐, 优先级最高): /ql/data/psyduck/ck_full/<pin>.txt
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._bsCk()
    }

    // Set-Cookie 自攒罐 (2026-10-23 实锤: 完整指纹罐是交互风控通行证, 服务端下发必接回传)
    _jarPin(user) {
        const ck = this._ckForUser(user)
        const m = String(ck || '').match(/pt_pin=([^;\s]+)/)
        return m ? decodeURIComponent(m[1]) : String(user || 'main')
    }
    _jarLoad(pin) {
        if (this._jarLoaded === pin) return this._jarMap
        this._jarMap = new Map()
        try {
            for (const ln of fs.readFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', 'utf8').split(/\r?\n/)) {
                const kv = ln.trim()
                if (kv.includes('=')) this._jarMap.set(kv.split('=')[0], kv)
            }
        } catch (e) {}
        this._jarLoaded = pin
        return this._jarMap
    }
    _jarSave(pin) {
        try {
            fs.mkdirSync('/ql/data/psyduck/ck_jar', {recursive: true})
            fs.writeFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', [...this._jarMap.values()].join('\n') + '\n')
        } catch (e) {}
    }
    _ckFull(user) {
        const ck = this._ckForUser(user)
        const jar = this._jarLoad(this._jarPin(user))
        const have = new Set(String(ck).split(';').map(s => s.split('=')[0].trim()).filter(Boolean))
        const extra = [...jar.values()].filter(kv => !have.has(kv.split('=')[0]))
        return extra.length ? ck + ';' + extra.join(';') : ck
    }
    _jarHarvest(user, res) {
        const sc = res.headers['set-cookie']
        if (!sc || !sc.length) return
        const jar = this._jarLoad(this._jarPin(user))
        for (const c of sc) {
            const kv = String(c).split(';')[0]
            if (kv.includes('=') && /^[!-~]+=/i.test(kv)) jar.set(kv.split('=')[0], kv)
        }
        this._jarSave(this._jarPin(user))
    }
    // 框架curl链路对api.m.jd.com被风控, weGame 请求改 h5st 自签名直连 (同 scratchBean 模式)
    async bsCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._bsSigner) {
            try { this._bsSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._bsSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._bsSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'wegame-hub', client: getv('client') || 'ios', clientVersion: getv('clientVersion') || '15.6.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: BSC_PAGE, 'user-agent': BSC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    // 豆子中心「天天刮京豆」linkId, 取自活动页 4E1fFrgX 楼层 00040037 boardParams, 会轮换, 可用 context.linkId 覆盖
    linkId(context) {
        return context.linkId || 'UKhQYIB970Wh-SnnX7-vQg'
    }

    // weGame 族通用请求: App 容器形态(envType=2/loginType=1) + 存活指纹
    // 2026-10 验证: a58c4/101aa/730a6 已失效, 02f8d/0cc57/0d977 可签通
    // 2026-10-20: 空 token 被网关空响应拦截, 注入 eid_pair 双真 token (scratchBean 同解)
    async wg(p, user, fn, bodyObj, retries) {
        let bsEid = '', bsSdk = ''
        for (const pt of ['/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', '/ql/data/psyduck/eid_pair.txt']) {
            try {
                const txt = fs.readFileSync(pt, 'utf8')
                bsEid = (txt.match(/eid=(\S+)/) || ['', ''])[1]
                bsSdk = (txt.match(/sdk=(\S+)/) || ['', ''])[1]
                if (bsEid) break
            } catch (e) {}
        }
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                let r = await this.bsCurl({
                    url: `https://api.m.jd.com/api?functionId=${fn}`,
                    form: `functionId=${fn}&body=${encodeURIComponent(this.dumps(Object.assign({envType: 2}, bodyObj)))}` +
                        `&extParams=${encodeURIComponent(this.dumps({loginType: 1, loginWQBiz: 'wegame'}))}` +
                        `&appid=wegame-hub&client=android&clientVersion=15.10.50&platform=3&build=102649&screen=360*800&networkType=wifi&d_brand=OnePlus&d_model=IN2010&lang=zh_CN&osVersion=13&partner=oppo&cthr=1` +
                        `&uuid=3303461326131633-2313731633939346&eufv=1&eu=3303461326131633&fv=2313731633939346` +
                        `&ext=${encodeURIComponent(this.dumps({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': bsEid, 'wg-sdk-token': bsSdk, pageUrl: encodeURIComponent('https://pro.m.jd.com/')}))}`,
                    user, algo: {appId: '02f8d'}, response: 'all'
                })
                let c = r && (r.content !== undefined ? r.content : r)
                let s = typeof c === 'string' ? c : JSON.stringify(c)
                if (s && s !== '(empty)') {
                    try { return JSON.parse(s) } catch (e) { return {raw: s} }
                }
                p.log(`${fn} 空响应(指纹可能失效), 第${k}次...`)
            } catch (e) {
                p.log(`${fn} 异常: ${String(e && e.message || e).slice(0, 120)}`)
            }
            await this.wait(3000 * k)
        }
        return null
    }

    // 浏览任务入口(豆子任务做一次给一张刮卡机会): 交给 beanBrowse, 这里只负责刮
    async main(p) {
        let user = p.data.user
        let linkId = this.linkId(p.context)

        // 1) 建轮次+查状态
        let home = await this.wg(p, user, 'weGameHome', {linkId: linkId}, 3)
        if (!home) {
            p.log('weGameHome 无响应, 本轮跳过')
            return
        }
        let sess = this.haskey(home, 'data.masterUserInfoVo.sessionInfoVo')
        if (sess) {
            p.log(`轮次: ${this.haskey(sess, 'sessionBeginTime') || ''} ~ ${this.haskey(sess, 'sessionEndTime') || ''} ing=${this.haskey(sess, 'ingFlag')}`)
        } else {
            p.log('无活动轮次(活动未开始或已结束): ' + JSON.stringify(home).slice(0, 150))
            return
        }

        // 2) 刮卡循环: 奖池限量, 刮到 504102(抢光)/无机会为止, 上限 12 次
        let got = false
        for (let k = 1; k <= 12; k++) {
            let d = await this.wg(p, user, 'weGameLottery', {linkId: linkId, lotteryType: 0}, 1)
            if (!d) {
                if (k === 1) p.log(`刮卡接口403限流中(weGameLottery独立风控), 退避重试...`)
                await this.wait(5000)
                continue
            }
            let code = String(this.haskey(d, 'code') || this.haskey(d, 'errMsg') || '')
            if (this.haskey(d, 'success')) {
                let award = this.haskey(d, 'data.awardResultVO') || this.haskey(d, 'data')
                let desc = this.haskey(award, 'prizeDesc') || JSON.stringify(award).slice(0, 120)
                got = true
                p.info.work = true
                p.log(`刮到: ${desc}`)
                let amount = this.haskey(award, 'amount') || this.haskey(award, 'prizeNum')
                let ptype = this.haskey(award, 'prizeType')
                if (amount && (String(desc).includes('京豆') || ptype == 3)) {
                    p.award(amount, 'bean')
                }
                await this.wait(2000)
                continue
            }
            // 业务终止态
            if (/抢光|不足|过期|结束|没有|次数/.test(JSON.stringify(d))) {
                p.log(`刮卡终止: ${this.haskey(d, 'errMsg') || code}`)
                break
            }
            p.log('刮卡返回异常: ' + JSON.stringify(d).slice(0, 180))
            break
        }
        if (!got) p.log('本轮未刮到(奖池已空或无刮卡机会)')
        else p.log('刮卡完成')
    }
}
