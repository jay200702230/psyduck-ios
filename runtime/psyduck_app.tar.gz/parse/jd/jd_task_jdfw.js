import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import http2 from 'http2'
import net from 'net'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://h5static.m.jd.com/mall/active/3b86xJ8EVja357au9NNG6ZSeV3Fw/index.html'
const EID = 'jdd03AEJINAIPWUEFEJ7BRW25JIDK447LPR3RIEQYSJT6RSIZF4W2FRZY4HQLDLZ6ETXOCU7AKOILZ6577SK6CKIUE6QHPEAAAANBNO4HDLAAAAAADALK2MX5HDC24IX'
const LBS = {gcLat: 24.576403, gcLng: 118.230367, lbsParamMap: {svcType: '', lbsLng: '118.10442505642247', lbsLat: '24.518401170085063', provinceId: 16, cityId: 1315, countyId: 3486, townId: 59642}, supportNewChannel: '2'}
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东服务天天签到抽奖', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // app 内 RPC cookie 通道: 127.0.0.1:28900 cmd=cookie 直出 app 存储的 19 字段全量 ck(含 shshsh 指纹), 2026-10-24 实锤
    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    // jjg 族专用 ck: home-marketing 域校验设备指纹 cookie, 瘦 ck(4字段)会「未登陆」; 优先 RPC 全量并校验 pin 一致防串号
    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpcCk = await this._rpcCk()
        if (rpcCk && rpcCk.includes('pt_key=')) {
            const pinOf = ck => { try { let m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            let want = pinOf(base)
            const got = pinOf(rpcCk)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpcCk
        }
        return base
    }


    // JDHOME_TARO 族: checkInTask 三件套, h5st 域 35fa0 (2026-10-24 抓包实锤)
    async wg(p, user, fn, checkInTaskParamMap, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) { p.log('no signer'); return null }
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const body = Object.assign({}, LBS, {checkInTaskParamMap, source: '38'})
                const signed = this._wgSigner.sign({functionId: fn, body, ck, base: {appid: 'JDHOME_TARO', client: 'android', clientVersion: '15.10.50'}, appId: '35fa0', slim: true})
                const q = new URLSearchParams()
                for (const kk in signed) q.append(kk, String(signed[kk]))
                q.append('platform', '3'); q.append('loginType', '2'); q.append('loginWQBiz', 'wegame')
                q.append('eu', '3303461326131633'); q.append('fv', '2313731633939346')
                q.append('x-api-eid-token', EID); q.append('x_app_key', 'vygmwcxg14ui3jxw')
                q.append('screen', '1080*2400'); q.append('area', '16_1315_3489_46816')
                const post = q.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://h5static.m.jd.com', referer: W_PAGE, 'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(3000 * k)
        }
        return null
    }

    async draw(p, user, t) {
        const r = await this.wg(p, user, 'checkInTaskLuckyDraw', {encryptAssignmentId: t.encryptAssignmentId, doReceiveRewards: 1, requestScene: 0}, 1)
        const ok = r && String(r.resultCode ?? r.code) === '0'
        p.log('  抽奖[' + (t.assignmentName || t.encryptAssignmentId) + ']:', ok ? '中' : JSON.stringify(r).slice(0, 100))
        if (!ok) this._fails++
        return ok
    }

    // 服饰美妆签到 (jxzy_active 族, 2026-10-24 实锤): signStr=HMAC-MD5(盐, key排序&拼接), querySign 无h5st / drawSign 域 c50cc
    _jxSign(bodyObj) {
        const obj = JSON.parse(JSON.stringify(bodyObj))
        const parts = []
        for (const k of Object.keys(obj).sort()) {
            let v = obj[k]
            if (v instanceof Object) v = JSON.stringify(v)
            if (v === null || v === undefined || v === '') continue
            parts.push(String(v))
        }
        return crypto.createHmac('md5', 'xtl_sqg_mall-^&*-damai_(789)_@#$').update(parts.join('&')).digest('hex')
    }

    async femSign(p, user) {
        const CRAFT = '69266d9f129fbf6b80a8b1cd'
        const doCall = async (fn, bodyObj, withH5st) => {
            for (let k = 1; k <= 2; k++) {
                try {
                    if (!this._wgSigner) { try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {} }
                    if (!this._wgSigner) { p.log('no signer'); return null }
                    const ck = this._ckForUser(user)
                    if (!ck) { p.log('no ck'); return null }
                    bodyObj.time = String(Date.now())
                    bodyObj.signStr = this._jxSign(bodyObj)
                    const q = new URLSearchParams()
                    q.append('functionId', fn)
                    q.append('appid', 'jx_h5_babel'); q.append('t', bodyObj.time)
                    q.append('channel', 'jxh5'); q.append('clientVersion', '1.2.5'); q.append('client', 'jxh5')
                    q.append('uuid', 'de1ff904-2d5c-402a-a44e-546b4e15431ba96f'); q.append('cthr', '1'); q.append('loginType', '2')
                    q.append('body', JSON.stringify(bodyObj))
                    if (withH5st) {
                        const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'jx_h5_babel', client: 'jxh5', clientVersion: '1.2.5', t: bodyObj.time}, appId: 'c50cc', slim: true})
                        q.append('h5st', String(signed.h5st || ''))
                        q.append('x-api-eid-token', EID)
                    }
                    const post = q.toString()
                    const s = this._h2()
                    if (!s) return null
                    const r = await new Promise(resolve => {
                        let done = false
                        const fin = v => { if (!done) { done = true; resolve(v) } }
                        let st = null
                        try {
                            st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: 'https://pro.m.jd.com/mall/active/2cphoHr3xhCkHzNP91huE9LCH1p8/index.html', 'user-agent': UA, 'x-referer-page': 'https://pro.m.jd.com/mall/active/2cphoHr3xhCkHzNP91huE9LCH1p8/index.html', 'x-rp-client': 'h5_2.4.0'})
                        } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                        let d = ''
                        st.on('data', c => d += c)
                        st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                        st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                        st.end(post)
                        setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                    })
                    if (r) return r
                } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
                await this.wait(3000 * k)
            }
            return null
        }
        const q = await doCall('jxzy_active_querySign', {source: 'jxzy', craftId: CRAFT, tttId: 'ttt343', sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}, false)
        if (!q || q.code !== 0) { p.log('服饰美妆签到查询失败:', JSON.stringify(q).slice(0, 100)); this._fails++; return }
        const st = (q.data || {}).status
        const days = (q.data || {}).alreadySignDays
        p.log('服饰美妆签到: status=' + st, '已签', days, '天')
        if (st === 2) return
        const d = await doCall('jxzy_active_drawSign', {itemId: '1', craftId: CRAFT, source: 'jxzy', sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}, true)
        const code = d ? d.code : 'null'
        p.log('  签到:', code === 0 ? '成功' : String(code) + ' ' + String(d && d.msg).slice(0, 24))
        if (String(code) !== '0' && String(code) !== '103') this._fails++
    }

    // 京东家政清池 (checkInTask 族 requestScene=2 变体, referer 绑女性专区页, 2026-10-24 实锤)
    async housekeeping(p, user) {
        const LBS = {source: '', gcLat: 24.576403, gcLng: 118.230367, lbsParamMap: {svcType: '', lbsLng: '118.10442505642247', lbsLat: '24.518401170085063', provinceId: 16, cityId: 1315, countyId: 3486, townId: 59642}, pageCode: 'service_housekeeping', identityCode: 'houseKeeping', supportNewChannel: '2'}
        const PAGE2 = 'https://pro.m.jd.com/mall/active/2cphoHr3xhCkHzNP91huE9LCH1p8/index.html?babelChannel=ttt63'
        const call2 = async (fn, bodyObj) => {
            for (let k = 1; k <= 2; k++) {
                try {
                    if (!this._wgSigner) { try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {} }
                    if (!this._wgSigner) return null
                    const ck = this._ckForUser(user)
                    if (!ck) return null
                    const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'JDHOME_TARO', client: 'android', clientVersion: '15.10.50'}, appId: '35fa0', slim: true})
                    const q = new URLSearchParams()
                    for (const kk in signed) q.append(kk, String(signed[kk]))
                    q.append('platform', '3'); q.append('loginType', '2'); q.append('loginWQBiz', 'wegame')
                    q.append('eu', '3303461326131633'); q.append('fv', '2313731633939346')
                    q.append('x-api-eid-token', EID); q.append('x_app_key', 'vygmwcxg14ui3jxw')
                    q.append('screen', '1080*2400'); q.append('area', '16_1315_3489_46816')
                    const post = q.toString()
                    const s = this._h2()
                    if (!s) return null
                    const r = await new Promise(resolve => {
                        let done = false
                        const fin = v => { if (!done) { done = true; resolve(v) } }
                        let st = null
                        try {
                            st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE2, 'user-agent': UA, 'x-referer-page': PAGE2, 'x-rp-client': 'h5_2.4.0'})
                        } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                        let d = ''
                        st.on('data', c => d += c)
                        st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                        st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                        st.end(post)
                        setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                    })
                    if (r) return r
                } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
                await this.wait(3000 * k)
            }
            return null
        }
        const getList = async () => (((await call2('checkInTaskList', Object.assign({}, LBS, {checkInTaskParamMap: {requestScene: 2}})) || {}).data || {}).browseTaskList) || []
        for (let round = 0; round < 3; round++) {
            const tasks = await getList()
            let acted = 0
            for (const t of tasks) {
                const now = Date.now()
                if (t.assignmentEndTime && new Date(t.assignmentEndTime.replace(' ', 'T') + '+08:00').getTime() < now) { p.log('跳过(已过期):', t.assignmentName); continue }
                const subs = (t.subTaskList || []).filter(s => s.status !== 2 && s.url)
                if (+t.canReceiveTimes > 0) {
                    const dr = await call2('checkInTaskLuckyDraw', Object.assign({}, LBS, {checkInTaskParamMap: {encryptAssignmentId: t.encryptAssignmentId, doReceiveRewards: 1, requestScene: 2}}))
                    p.log('家政抽奖[' + t.assignmentName + ']:', dr ? String(dr.resultCode ?? dr.code) : '空')
                    acted++; await this.wait(3000)
                }
                if (t.completionFlag) continue
                p.log('家政做:', t.assignmentName)
                const target = t.assignmentTimesLimit > 1 ? subs.slice(0, t.assignmentTimesLimit) : [subs[0] || null]
                for (const sub of target) {
                    if (!sub) break
                    const r1 = await call2('checkInTaskDo', Object.assign({}, LBS, {checkInTaskParamMap: {encryptAssignmentId: t.encryptAssignmentId, itemId: sub.itemId, jumpUrl: sub.url, actionType: 1, requestScene: 2}}))
                    if (!r1 || String(r1.resultCode ?? r1.code) !== '0') { this._fails++; await this.wait(20000); continue }
                    await this.wait(((t.waitDuration || 0) + 3) * 1000)
                    const r0 = await call2('checkInTaskDo', Object.assign({}, LBS, {checkInTaskParamMap: {encryptAssignmentId: t.encryptAssignmentId, itemId: sub.itemId, jumpUrl: sub.url, actionType: 0, requestScene: 2}}))
                    if (!r0 || String(r0.resultCode ?? r0.code) !== '0') this._fails++
                    acted++; await this.wait(3000)
                    const fresh = (await getList()).find(x => x.encryptAssignmentId === t.encryptAssignmentId) || {}
                    if (fresh.completionFlag) { if (+fresh.canReceiveTimes > 0) { await call2('checkInTaskLuckyDraw', Object.assign({}, LBS, {checkInTaskParamMap: {encryptAssignmentId: t.encryptAssignmentId, doReceiveRewards: 1, requestScene: 2}})) } break }
                }
            }
            if (!acted) break
        }
        const fin = await getList()
        for (const t of fin) if (!t.completionFlag) p.log('家政未清:', t.assignmentName)
    }

    // 京东家具 (jxzy_active_task 家具版, 2026-10-24 实锤): jx_h5_babel GET 无h5st, craftId=69ae8eb86a31c802e19f9f8f, 盐同款
    async jiajuTask(p, user) {
        const CRAFT = '69ae8eb86a31c802e19f9f8f'
        const PAGE_JJ = 'https://pro.m.jd.com/mall/active/2H8G6a7JecjqHH3t1ZWSoJjPtziP/index.html?babelChannel=ttt15'
        const callG = async (fn, bodyObj) => {
            for (let k = 1; k <= 2; k++) {
                try {
                    const ck = this._ckForUser(user)
                    if (!ck) return null
                    bodyObj.time = Date.now()
                    bodyObj.signStr = this._jxSign(bodyObj)
                    const q = new URLSearchParams()
                    q.append('functionId', fn)
                    q.append('appid', 'jx_h5_babel'); q.append('t', String(bodyObj.time))
                    q.append('channel', 'jxh5'); q.append('clientVersion', '1.2.5'); q.append('client', 'jxh5')
                    q.append('cthr', '1'); q.append('loginType', '2')
                    q.append('body', JSON.stringify(bodyObj))
                    const s = this._h2()
                    if (!s) return null
                    const r = await new Promise(resolve => {
                        let done = false
                        const fin = v => { if (!done) { done = true; resolve(v) } }
                        let st = null
                        try {
                            st = s.request({':method': 'GET', ':path': '/api?' + q.toString(), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE_JJ, 'user-agent': UA})
                        } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                        let d = ''
                        st.on('data', c => d += c)
                        st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                        st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                        st.end()
                        setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                    })
                    if (r) return r
                } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
                await this.wait(3000 * k)
            }
            return null
        }
        const BASE = {source: 'jxzy', craftId: CRAFT, tttId: 'ttt15', sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}
        for (let round = 0; round < 12; round++) {
            const r = await callG('jxzy_active_task_queryTaskList', Object.assign({}, BASE))
            const pool = ((r || {}).data || {}).taskInfoList || []
            if (!pool.length) { if (round === 0) p.log('家具池空'); break }
            const todo = pool.filter(t => t.taskType === 3 && t.taskStatus === 1 && t.taskId)
            if (!todo.length) { p.log('家具任务全部完成'); break }
            const t = todo[0]
            const prog = t.taskProgress || {}
            p.log('家具做:', t.taskName, (prog.current || 0) + '/' + (prog.total || 1))
            const body = {craftId: CRAFT, taskId: t.taskId, itemId: String(prog.itemId || ''), taskType: t.taskType, sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}
            const r1 = await callG('jxzy_active_task_completeTask', Object.assign({}, body))
            if (String((r1 || {}).code) !== '0') { p.log('  complete拒:', String((r1 || {}).code)); this._fails++; await this.wait(8000); continue }
            await this.wait(9500)
            const r2 = await callG('jxzy_active_task_rewardTask', Object.assign({}, body))
            const prize = (((r2 || {}).data || {}).prizeInfos || [])
            p.log('  reward:', String((r2 || {}).code), prize.length ? JSON.stringify(prize).slice(0, 60) : '')
            if (String((r2 || {}).code) !== '0') this._fails++
            await this.wait(7000)
        }
        // jdjj-channel 族: doInteractiveAssignment ×3 固定活动上报(无签名 GET) + doCooperationTask 首页进入(35fa0 签名, code 硬编码)
        const FIX3 = [
            {encryptProjectId: '2tEvSLBxEsUv3NT9mhgaWvJ2qqB9', encryptAssignmentId: '3iAUbPHHvCa5fUHXu6x9HX8xz9sQ', sourceCode: 'acejdjuljd0324'},
            {encryptProjectId: '31w93WAEpkQTZXneK4nGW9rjKDqq', encryptAssignmentId: '3gwrHdTL4WapkZekhpeoc4uXjSe3', sourceCode: 'acexfxd0410'},
            {encryptProjectId: '4AoxYXKWKKnKBePkEwS1CznFwvPg', encryptAssignmentId: '338uhBpVeYcqURw8BLNB6i7JQaZz', sourceCode: 'ddhxj0707'}
        ]
        for (const fx of FIX3) {
            const r = await this.wgJdjj(p, user, 'doInteractiveAssignment', Object.assign({}, fx, {completionFlag: true}))
            p.log('家具上报[' + fx.sourceCode + ']:', String((r || {}).code) + ' ' + String((r || {}).msg || '').slice(0, 20))
            await this.wait(4000)
        }
        try {
            if (!this._wgSigner) { try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {} }
            const ck = this._ckForUser(user)
            if (this._wgSigner && ck) {
                const bodyC = {code: 'bFQJlinL'}
                const signed = this._wgSigner.sign({functionId: 'doCooperationTask', body: bodyC, ck, base: {appid: 'jdjj-channel', client: 'android', clientVersion: '15.10.50'}, appId: '35fa0', slim: true})
                const q = new URLSearchParams()
                for (const kk in signed) q.append(kk, String(signed[kk]))
                q.append('platform', '3'); q.append('loginType', '2'); q.append('loginWQBiz', 'wegame')
                const s = this._h2()
                if (s) {
                    const r = await new Promise(resolve => {
                        let done = false
                        const fin = v => { if (!done) { done = true; resolve(v) } }
                        let st = null
                        try {
                            st = s.request({':method': 'POST', ':path': '/api?functionId=doCooperationTask', 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(q.toString())), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE_JJ, 'user-agent': UA})
                        } catch (e) { return fin(null) }
                        let d = ''
                        st.on('data', c => d += c)
                        st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                        st.on('error', () => fin(null))
                        st.end(q.toString())
                        setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                    })
                    const dv = (r || {}).data
                    p.log('家具首页进入(doCooperationTask):', JSON.stringify(dv).slice(0, 60), '-2=已完成 -1=新完成')
                }
            }
        } catch (e) { p.log('doCooperation 异常: ' + String(e && e.message || e).slice(0, 80)) }
    }

    // 京东家具馆 (jjg 族 home-marketing, 2026-10-24 实锤): 查询无签名, 领奖 74333 域签名+activityId='4', 风控 10014=账号级拦截
    async jjgGuanTask(p, user) {
        const PAGE_JG = 'https://pro.m.jd.com/mall/active/FxaS5JGmuJH65DB4HxF7rCRRewb/index.html?babelChannel=ttt32&linkTag=jiajuguan'
        const EXT = JSON.stringify({activityId: '00127564', pageId: '6517289', moduleId: 133538939, encodeActivityId: 'FxaS5JGmuJH65DB4HxF7rCRRewb', babelChannel: 'ttt32'})
        const call2 = async (fn, bodyObj, needSign) => {
            for (let k = 1; k <= 2; k++) {
                try {
                    if (!this._wgSigner) { try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {} }
                    if (!this._wgSigner) return null
                    const ck = await this._ckFull(user)
                    if (!ck) return null
                    const q = new URLSearchParams()
                    q.append('functionId', fn)
                    if (needSign) {
                        const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'home-marketing', client: 'android', clientVersion: '15.10.50'}, appId: '74333', slim: true})
                        for (const kk in signed) q.append(kk, String(signed[kk]))
                        q.append('x-api-eid-token', EID)
                    } else {
                        q.append('body', JSON.stringify(bodyObj))
                    }
                    q.append('appid', 'home-marketing'); q.append('loginType', '2')
                    q.append('client', 'android'); q.append('clientVersion', '15.10.50')
                    q.append('area', '16_1315_3489_46816'); q.append('gpsArea', '0_0_0_0')
                    q.append('osVersion', '13'); q.append('networkType', 'wifi')
                    q.append('d_model', 'IN2010'); q.append('d_brand', 'OnePlus')
                    q.append('screen', '360*800'); q.append('uuid', '3303461326131633-2313731633939346')
                    q.append('ext', EXT)
                    const post = q.toString()
                    const s = this._h2()
                    if (!s) return null
                    const r = await new Promise(resolve => {
                        let done = false
                        const fin = v => { if (!done) { done = true; resolve(v) } }
                        let st = null
                        try {
                            st = s.request({':method': 'POST', ':path': '/client.action?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE_JG, 'user-agent': UA, 'x-referer-page': PAGE_JG, 'x-rp-client': 'h5_2.4.0'})
                        } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                        let d = ''
                        st.on('data', c => d += c)
                        st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                        st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                        st.end(post)
                        setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                    })
                    if (r) return r
                } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
                await this.wait(3000 * k)
            }
            return null
        }
        const pool = await call2('jjg_queryInteractiveInfoV3', {activityId: '4', isDistinguishReceivedNewUserAward: false, reqSource: 1}, false)
        const imap = pool && pool.data ? (pool.data.hdInteractiveInfoDtoMap || {}) : {}
        if (!Object.keys(imap).length) { p.log('家具馆池空:', JSON.stringify(pool).slice(0, 80)); return }
        let risk = 0, done = 0
        const doTask = async (a, itemId) => {
            if (risk >= 3) return false
            const body = {projectId: a.projectId, assignmentId: a.encryptAssignmentId, itemId: String(itemId), type: a.assignmentType, activityId: '4'}
            const r = await call2('jjg_doInteractiveAssignment', body, true)
            const code = r ? (r.code ?? r.resultCode) : 'null'
            if (r && (String(code) === '0' || r.success)) {
                done++
                p.log('  家具馆[OK]', a.assignmentName, 'itemId=' + itemId)
                return true
            }
            const msg = String((r && (r.msg || r.resultMsg)) || '').slice(0, 40)
            p.log('  家具馆[--]', a.assignmentName, 'code=' + code, msg)
            if ([10014, 1403, 31, 104001].includes(Number(code))) risk++
            return false
        }
        for (const [grp, info] of Object.entries(imap)) {
            if (grp === 'rewardTask' || risk >= 3) continue
            for (const a of info.assignmentList || []) {
                if (a.completionFlag) continue
                const ext = a.ext || {}
                const et = ext.extraType
                if (et === 'sign' && ext.sign) { await doTask(a, ext.sign.itemId || '1'); await this.wait(1500) }
                else if (et === 'followChannel' && ext.followChannel) { await doTask(a, ext.followChannel[0].itemId); await this.wait(1500) }
                else if (et === 'followShop' && ext.followShop) { await doTask(a, ext.followShop[0].itemId); await this.wait(1500) }
                else if (et === 'shoppingActivity' && ext.shoppingActivity) {
                    const items = ext.shoppingActivity.filter(x => Number(x.status) === 1)
                    const limit = a.assignmentTimesLimit || 1
                    for (let i = 0; i < limit && i < items.length && risk < 3; i++) {
                        const ok = await doTask(a, items[i].itemId)
                        await this.wait(ok ? (ext.waitDuration || 10) * 1000 : 1500)
                    }
                }
                if (risk >= 3) { p.log('家具馆连续风控3次, 熔断'); break }
            }
        }
        p.log('家具馆完成: done=' + done, risk >= 3 ? '(风控熔断)' : '')
    }

    // jdjj-channel 无签名 GET 通道
    async wgJdjj(p, user, fn, bodyObj) {
        const PAGE_JJ = 'https://pro.m.jd.com/mall/active/2H8G6a7JecjqHH3t1ZWSoJjPtziP/index.html?babelChannel=ttt15'
        try {
            const ck = this._ckForUser(user)
            if (!ck) return null
            const q = new URLSearchParams()
            q.append('appid', 'jdjj-channel')
            q.append('functionId', fn)
            q.append('body', JSON.stringify(bodyObj))
            const s = this._h2()
            if (!s) return null
            return await new Promise(resolve => {
                let done = false
                const fin = v => { if (!done) { done = true; resolve(v) } }
                let st = null
                try {
                    st = s.request({':method': 'GET', ':path': '/?' + q.toString(), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE_JJ, 'user-agent': UA})
                } catch (e) { return fin(null) }
                let d = ''
                st.on('data', c => d += c)
                st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                st.on('error', () => fin(null))
                st.end()
                setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
            })
        } catch (e) { return null }
    }

    // 厨房好物 (jxzy_active 厨房版, 2026-10-24 实锤): 签到(querySign+drawSign c50cc) + 任务池三件套, craftId=6a6890eaa0c21743163fe444
    async chufangTask(p, user) {
        const CRAFT = '6a6890eaa0c21743163fe444'
        const PAGE_CF = 'https://pro.m.jd.com/mall/active/FEtAd86BW8TpiRKshRZX8PPEjpo/index.html?babelChannel=ttt137'
        const doCall = async (fn, bodyObj, withH5st) => {
            for (let k = 1; k <= 2; k++) {
                try {
                    if (!this._wgSigner) { try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {} }
                    if (!this._wgSigner) { p.log('no signer'); return null }
                    const ck = this._ckForUser(user)
                    if (!ck) return null
                    bodyObj.time = Date.now()
                    bodyObj.signStr = this._jxSign(bodyObj)
                    const q = new URLSearchParams()
                    q.append('functionId', fn)
                    q.append('appid', 'jx_h5_babel'); q.append('t', String(bodyObj.time))
                    q.append('channel', 'jxh5'); q.append('clientVersion', '1.2.5'); q.append('client', 'jxh5')
                    q.append('cthr', '1'); q.append('loginType', '2')
                    q.append('body', JSON.stringify(bodyObj))
                    if (withH5st) {
                        const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'jx_h5_babel', client: 'jxh5', clientVersion: '1.2.5', t: bodyObj.time}, appId: 'c50cc', slim: true})
                        q.append('h5st', String(signed.h5st || ''))
                        q.append('x-api-eid-token', EID)
                    }
                    const post = q.toString()
                    const s = this._h2()
                    if (!s) return null
                    const r = await new Promise(resolve => {
                        let done = false
                        const fin = v => { if (!done) { done = true; resolve(v) } }
                        let st = null
                        try {
                            st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE_CF, 'user-agent': UA, 'x-referer-page': PAGE_CF, 'x-rp-client': 'h5_2.4.0'})
                        } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                        let d = ''
                        st.on('data', c => d += c)
                        st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                        st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                        st.end(post)
                        setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                    })
                    if (r) return r
                } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
                await this.wait(3000 * k)
            }
            return null
        }
        const BASE = {source: 'jxzy', craftId: CRAFT, tttId: 'ttt137', sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}
        // 1) 签到
        const q = await doCall('jxzy_active_querySign', Object.assign({}, BASE), false)
        const st = q && q.code === 0 ? (q.data || {}).status : null
        p.log('厨房签到: status=' + st, '已签', q && q.data ? (q.data.alreadySignDays || 0) : '?', '天')
        if (st !== 2) {
            const d = await doCall('jxzy_active_drawSign', {itemId: '1', craftId: CRAFT, source: 'jxzy', sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}, true)
            const code = d ? d.code : 'null'
            p.log('  签到:', code === 0 ? '成功' : String(code) + ' ' + String(d && d.msg).slice(0, 24))
            if (String(code) !== '0' && String(code) !== '103') this._fails++
        }
        // 2) 任务池
        for (let round = 0; round < 12; round++) {
            const r = await doCall('jxzy_active_task_queryTaskList', Object.assign({}, BASE), false)
            const pool = ((r || {}).data || {}).taskInfoList || []
            if (!pool.length) { if (round === 0) p.log('厨房池空'); break }
            const todo = pool.filter(t => t.taskType === 3 && t.taskStatus === 1 && t.taskId)
            if (!todo.length) { p.log('厨房任务全部完成'); break }
            const t = todo[0]
            const prog = t.taskProgress || {}
            p.log('厨房做:', t.taskName, (prog.current || 0) + '/' + (prog.total || 1))
            const body = {craftId: CRAFT, taskId: t.taskId, itemId: String(prog.itemId || ''), taskType: t.taskType, sceneval: 2, buid: 325, appCode: 'ms1888ebbf'}
            const r1 = await doCall('jxzy_active_task_completeTask', Object.assign({}, body), false)
            if (String((r1 || {}).code) !== '0') { p.log('  complete拒:', String((r1 || {}).code)); this._fails++; await this.wait(8000); continue }
            await this.wait(9500)
            const r2 = await doCall('jxzy_active_task_rewardTask', Object.assign({}, body), false)
            const prize = (((r2 || {}).data || {}).prizeInfos || [])
            p.log('  reward:', String((r2 || {}).code), prize.length ? JSON.stringify(prize).slice(0, 60) : '')
            if (String((r2 || {}).code) !== '0') this._fails++
            await this.wait(7000)
        }
    }

    async main(p) {
        const user = p.data.user
        await this.femSign(p, user)
        await this.chufangTask(p, user)
        await this.jiajuTask(p, user)
        await this.jjgGuanTask(p, user)
        await this.housekeeping(p, user)
        const getList = async () => {
            const r = await this.wg(p, user, 'checkInTaskList', {requestScene: 0, showCustomTaskFlag: true}, 2)
            return ((r && (r.data || r)) || {}).browseTaskList || []
        }
        for (let round = 0; round < 4; round++) {
            const tasks = await getList()
            if (!tasks.length) { p.log('任务池空或限流'); return }
            let acted = 0
            for (const t of tasks) {
                const subs = (t.subTaskList || []).filter(s => s.status !== 2 && s.url)
                if (+t.canReceiveTimes > 0) {
                    await this.draw(p, user, t)
                    acted++
                    await this.wait(3000)
                }
                if (t.completionFlag) continue
                p.log('做:', t.assignmentName, 'lim=' + t.assignmentTimesLimit, '待逛=' + subs.length)
                const target = t.assignmentTimesLimit > 1 ? subs.slice(0, t.assignmentTimesLimit) : [subs[0] || null]
                for (const sub of target) {
                    if (!sub) break
                    const base = {encryptAssignmentId: t.encryptAssignmentId, itemId: sub.itemId, jumpUrl: sub.url, requestScene: 0}
                    const r1 = await this.wg(p, user, 'checkInTaskDo', Object.assign({}, base, {actionType: 1}), 1)
                    if (!r1 || String(r1.resultCode ?? r1.code) !== '0') { this._fails++; await this.wait(20000); continue }
                    await this.wait(((t.waitDuration || 5) + 3) * 1000)
                    const r0 = await this.wg(p, user, 'checkInTaskDo', Object.assign({}, base, {actionType: 0}), 1)
                    if (!r0 || String(r0.resultCode ?? r0.code) !== '0') this._fails++
                    acted++
                    await this.wait(3000)
                    const fresh = (await getList()).find(x => x.encryptAssignmentId === t.encryptAssignmentId) || {}
                    if (fresh.completionFlag) { if (+fresh.canReceiveTimes > 0) await this.draw(p, user, fresh); break }
                    if (fresh.assignmentTimesLimit > 1 && (fresh.subTaskList || []).filter(s => s.status !== 2).length === 0) break
                }
            }
            if (!acted) { p.log('本轮无动作, 收工'); break }
        }
        const fin = await getList()
        let bad = 0
        for (const t of fin) {
            if (!t.completionFlag || +t.canReceiveTimes > 0) { p.log('未清:', t.assignmentName, 'fin=' + t.completionFlag, 'canDraw=' + t.canReceiveTimes); bad++ }
        }
        p.log(bad ? '剩余 ' + bad + ' 项未清' : '全部清完')
        if (this._fails > 0) {
            p.log('存在 ' + this._fails + ' 个失败项, 本轮不写缓存')
            p.info.work = false
        } else {
            p.info.work = true
        }
    }
}
