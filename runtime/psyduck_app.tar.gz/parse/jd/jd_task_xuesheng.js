import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/3Q5H8xmBy4GyPT8xUgqwYYnAa2ns/index.html?babelChannel=ttt76'
const LK = 'iuBvJ0vs6AOpaEydO0FivA'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '学生特价任务', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // 无签名族: activities_platform + h5st=null
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const f = new URLSearchParams()
                f.append('functionId', fn)
                f.append('body', JSON.stringify(bodyObj))
                f.append('t', String(Date.now()))
                f.append('appid', 'activities_platform')
                f.append('client', 'android')
                f.append('clientVersion', '15.10.50')
                f.append('platform', '3'); f.append('loginType', '2'); f.append('loginWQBiz', 'wegame')
                f.append('h5st', 'null')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    // 抽奖: GET + 真签名(activities_platform)
    async drawOnce(p, user) {
        try {
            if (!this._drSigner) {
                try { this._drSigner = await import('./jd_signer_node.mjs') } catch (e) {}
            }
            if (!this._drSigner) { p.log('no signer for draw'); return null }
            const ck = this._ckForUser(user)
            const signed = this._drSigner.sign({functionId: 'inviteFissionDrawPrize', body: {linkId: LK, area: '0_0_0_0'}, ck, base: {appid: 'activities_platform', client: 'android', clientVersion: '15.10.50'}, appId: 'activities_platform', slim: true})
            const q = new URLSearchParams()
            for (const kk in signed) q.append(kk, String(signed[kk]))
            q.append('platform', '3'); q.append('loginType', '2'); q.append('loginWQBiz', 'wegame')
            const s = this._h2()
            if (!s) return null
            return await new Promise(resolve => {
                let done = false
                const fin = v => { if (!done) { done = true; resolve(v) } }
                let st = null
                try {
                    st = s.request({':method': 'GET', ':path': '/api?functionId=inviteFissionDrawPrize&' + q.toString(), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA})
                } catch (e) { return fin(null) }
                let d = ''
                st.on('data', c => d += c)
                st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                st.on('error', () => fin(null))
                st.end()
                setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
            })
        } catch (e) { return null }
    }

    async pollTimes(p, user) {
        const r = await this.wg(p, user, 'inviteFissionPoll', {linkId: LK, type: 2}, 1)
        return (((r || {}).data || {}).lotteryTimes)
    }

    async getList(p, user) {
        const r = await this.wg(p, user, 'apTaskList', {linkId: LK, queryType: 0, channel: 4, area: '0_0_0_0'}, 2)
        let d = (r || {}).data || []
        if (!Array.isArray(d)) d = []
        return d.map(t => ({
            id: t.id,
            n: t.taskShowTitle || t.taskTitle || '',
            lim: t.taskLimitTimes || 1,
            done: t.taskDoTimes || 0,
            fin: !!t.taskFinished,
            url: t.taskSourceUrl || t.taskUrl || t.taskJumpUrl || (t.taskExt || {}).jumpUrl || (t.ext || {}).jumpUrl || '',
            aid: (t.pipeExt || {}).assignmentId || '',
            raw: JSON.stringify(t).slice(0, 1600)
        }))
    }

    async detail(p, user, tid) {
        const r = await this.wg(p, user, 'apTaskDetail', {linkId: LK, taskId: tid}, 1)
        const d = (r || {}).data || {}
        let items = d.taskItemList || []
        let fallbackUrl = ''
        if (!items.length) {
            const sj = JSON.stringify(d)
            const i = sj.indexOf('http')
            if (i >= 0) {
                let j = i
                while (j < sj.length && sj[j] !== '"' && sj[j] !== '\\') j++
                fallbackUrl = sj.slice(i, j)
            }
        }
        return {
            items,
            times: ((d.status || {}).userFinishedTimes) || 0,
            need: ((d.status || {}).finishNeed) || 0,
            fin: !!((d.status || {}).finished),
            fallbackUrl,
            raw: JSON.stringify(d).slice(0, 1000)
        }
    }

    async doBrowse(p, user, t, itemIdEnc, pipeItemId) {
        const pipe = {taskType: 'BROWSE_CHANNEL', timeLimitSwitch: 1, assignmentId: t.aid}
        if (pipeItemId) pipe.itemId = pipeItemId
        const r1 = await this.wg(p, user, 'apStartTaskTime', {linkId: LK, taskId: t.id, itemId: itemIdEnc, taskInsert: false, channel: 4, pipeExt: pipe, actFlowCode: 'apStartTaskTime'}, 1)
        const c1 = String((r1 || {}).code)
        if (c1 !== '0') {
            p.log('  受理拒(' + c1 + ')', t.n)
            this._fails++
            return false
        }
        await this.wait(9500)
        await this.wg(p, user, 'apDoLimitTimeTask', {linkId: LK, actFlowCode: 'apDoLimitTimeTask'}, 1)
        await this.wait(3000)
        const r3 = await this.wg(p, user, 'apTaskDrawAward', {taskType: 'BROWSE_CHANNEL', taskId: t.id, channel: 4, checkVersion: true, linkId: LK, pipeExt: {taskType: 'BROWSE_CHANNEL', timeLimitSwitch: 1, assignmentId: t.aid}}, 1)
        return true
    }

    async main(p) {
        const user = p.data.user
        for (let round = 0; round < 6; round++) {
            const tasks = await this.getList(p, user)
            const todo = tasks.filter(t => !t.fin && t.done < t.lim)
            if (!todo.length) { p.log('学生特价任务全达标'); break }
            let acted = 0
            for (const t of todo) {
                p.log('做:', t.n, t.done + '/' + t.lim)
                if (t.url) {
                    const enc = encodeURIComponent(t.url)
                    const ok = await this.doBrowse(p, user, t, enc, null)
                    if (ok) acted++
                } else {
                    const dd = await this.detail(p, user, t.id)
                    const items = dd.items.filter(x => x && x.itemId)
                    if (!items.length && !dd.fallbackUrl) { p.log('  无子项无URL, 跳过 raw=' + dd.raw); continue }
                    if (!items.length && dd.fallbackUrl) {
                        p.log('  detail兜底URL:', t.n)
                        const ok = await this.doBrowse(p, user, t, encodeURIComponent(dd.fallbackUrl), null)
                        if (ok) acted++
                        await this.wait(7000)
                        continue
                    }
                    while (dd.times < dd.need) {
                        const it = items[(dd.times) % items.length]
                        const pipeItem = (it.pipeExt || {}).itemId
                        await this.doBrowse(p, user, t, encodeURIComponent(it.itemId), pipeItem)
                        acted++
                        const dd2 = await this.detail(p, user, t.id)
                        dd.times = dd2.times
                        dd.need = dd2.need || dd.need
                        if (dd2.fin) break
                    }
                    if (dd.times >= dd.need) p.log('  达标:', t.n, dd.times + '/' + dd.need)
                }
                await this.wait(7000)
            }
            if (!acted) break
        }
        // 抽奖
        let lt = await this.pollTimes(p, user)
        if (lt == null) lt = 0
        p.log('抽奖次数:', lt)
        for (let k = 0; k < lt + 2 && k < 12; k++) {
            const r = await this.drawOnce(p, user)
            const code = String((r || {}).code || '')
            const prize = ((((r || {}).data || {}).prizeInfo || {}).prizeName) || (((r || {}).data || {}).awardName) || ''
            p.log('抽' + (k + 1) + ':', code, prize || String((r || {}).errMsg || '').slice(0, 20))
            lt = await this.pollTimes(p, user)
            if (lt === 0) { p.log('次数抽完'); break }
            await this.wait(10000)
        }
        p.log('学生特价收工')
        p.info.work = true
    }
}
