import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'

// 活动平台任务链路常量(合并自 jd_task_farmWv v8 纯协议版):
// 浏览/关注/浇水任务走 node h5st 自签名直发(框架 jdAlgo 写接口被服务端风控), 按 apTaskList 动态匹配
const FW_LINKS = ['fWWo3YmB983abNOJPR7veg', '2O3VP9OxmzfMQU8WWKZ6aQ']
const FW_PAGE = 'https://pro.m.jd.com/mall/active/42HV4J3Q87B2xFQMJk81PCc1mEs3/index.html'
const FW_EU = '3303461326131633', FW_FV = '2313731633939346'
const FW_INI = (() => {
    for (const pt of ['/ql/data/psyduck/cookie/jd.ini', '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini']) {
        try { if (fs.existsSync(pt)) return pt } catch (e) {}
    }
    return '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini'
})()
const FW_APPIDS = {
    apTaskList: ['54ed7', 'activities_platform'],
    apsDoTask: ['54ed7', 'activities_platform'],
    apStartTaskTime: ['acb1e', 'activity_platform_se'],
    apTaskDrawAward: ['f0f3f', 'activities_platform'],
    farm_water: ['28981', 'signed_farm_mp'],
    farm_home: ['c57f6', 'signed_farm_mp']
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东新农场',
            help: 'main',
            prompt: {
                'tenWater': '1 #每天只做20次浇水任务',
                'stock': "200 #保留水滴数",
                'tree': '1 #如果检测到没有种树,自动选择一个商品进行种植',
                'inviteJson': 'true #使用自定义助力码',
                'times': '35 #最多助力人数'
            },
            headers: {
                'x-rp-client': "h5_1.0.0",
                'request-from': 'native',
                referer: 'https://h5.m.jd.com/pb/015686010/Bc9WX7MpCW7nW9QjZ5N3fFeJXMH/index.html'
            },
            tempExpire: 86400000,
            readme: `如要使用自定义助力码,请在框架目录/inviter创建jd_task_farmNew.json,按需修改[{"user":"a","inviteCode":"abc"},{"user":"b","inviteCode":"efg"}]`,
            turn: 4,
            crontab: 3,
            interval: 1000,
            libressl: true
        }
    }

    async prepare() {
    }

    async middle() {
        if (this.turnCount == 3) {
            for (let inviter of this.inviter) {
                inviter.category = 'inviteCode'
                inviter.times = parseInt(this.profile.times || 35)
                inviter.limit = 1
                this.shareCode(inviter)
            }
            for (let user of this.help) {
                let inviteCode = await this.getTemp(user)
                if (inviteCode) {
                    this.shareCode({
                        user,
                        inviteCode,
                        category: 'inviteCode',
                        times: parseInt(this.profile.times || 35),
                        limit: 1
                    })
                }
            }
        }
        else if (this.turnCount == 1) {
            this.shareCode({
                task: 'help'
            })
        }
    }

    async otherWork(p, linkId) {
        let user = p.data.user;
        let context = p.context;
        context.linkId = linkId || 'fWWo3YmB983abNOJPR7veg'
        let errId = {}
        let localBrowse = 0
        let localAct = 0
        for (let k of this.range(7)) {
            let isOk = 0
            let apTask = await this.farmCurl({
                    'url': `https://api.m.jd.com/api?functionId=apTaskList`,
                    'form': `functionId=apTaskList&body={"linkId":"${context.linkId}","queryType":0,"channel":4,"area":"16_1342_1357_45750"}&t=1787832238328&appid=activities_platform&client=ios&clientVersion=15.9.30&platform=3&loginType=2&loginWQBiz=wegame`,
                    user
                }
            )
            for (let i of this.haskey(apTask, 'data') || []) {
                if (i.canDrawAwardNum) {
                    let award = await this.farmCurl({
                            'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                            'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1787832238328&appid=activities_platform&client=ios&clientVersion=15.9.30&platform=3&loginType=2&loginWQBiz=wegame`,
                            user,
                            algo: {
                                appId: 'f0f3f'
                            }
                        }
                    )
                    if (this.haskey(award, 'data')) {
                        for (let j of award.data) {
                            if (j.awardName == 'WATER') {
                                p.log("获得水滴:", j.awardGivenNumber)
                            }
                        }
                    }
                    else {
                        p.err("领取失败...")
                    }
                    await this.wait(2000)
                }
                if (i.taskLimitTimes == i.taskDoTimes) {
                    if (k<2) {
                        p.log("任务已完成:", i.taskShowTitle)
                    }
                }
                else {
                    // console.log(i.taskShowTitle || i.taskTitle || i.subTitle, i.taskType)
                    // 注意: apTaskList 的 id 恒为 -9999, 不能用 id 作去重键, 用 taskType+标题
                    let dedupKey = i.taskType + '_' + (i.taskShowTitle || i.taskTitle || '')
                    if (errId[dedupKey]>1) {
                        continue
                    }
                    switch (i.taskType) {
                        case 'BROWSE_RTB':
                        case 'BROWSE_CHANNEL':
                        case 'FOLLOW_CHANNEL':
                        case 'FOLLOW_SHOP':
                        case 'BROWSE_PRODUCT':
                        case 'EXTERNAL_BROWSE':
                        case 'EXTERNAL_BROWSE_BI_LIVE':
                            // 浏览/关注类走 v7.1 纯协议(jd_task_farmWv 专职), 旧链路签名不过关只刷失败
                            continue
                            p.log(`正在运行:`, i.taskShowTitle || i.taskTitle || i.subTitle, i.taskType)
                            isOk++
                            // joyPark 已验证链路: apsDoTask(带h5st签名)直接起做, 绕过被服务端隔离的 apStartTaskTime
                            let doItemIds = []
                            if (i.taskSourceUrl) {
                                // EXTERNAL_BROWSE_BI_LIVE 直播类 itemId 需双重编码(原作者代码验证过的写法)
                                let item = i.taskType == 'EXTERNAL_BROWSE_BI_LIVE' ? encodeURIComponent(encodeURIComponent(i.taskSourceUrl)) : encodeURIComponent(i.taskSourceUrl)
                                doItemIds.push(item)
                            }
                            else {
                                let detail = await this.farmCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apTaskDetail`,
                                        form: `functionId=apTaskDetail&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"actFlowCode":"apTaskDetail"}&t=1787832238328&appid=activities_platform&client=ios&clientVersion=15.9.30&platform=3&loginType=2&loginWQBiz=wegame`,
                                        user,
                                    }
                                )
                                if (this.haskey(detail, 'data.taskItemList')) {
                                    for (let it of detail.data.taskItemList) {
                                        if (it.itemId) {
                                            doItemIds.push({ itemId: it.itemId, pipeExt: { ...(i.pipeExt || {}), ...(it.pipeExt || {}) } })
                                        }
                                    }
                                }
                                else {
                                    // 列表自带子项(如 BROWSE_RTB 的 taskItemList)
                                    for (let it of (i.taskItemList || [])) {
                                        if (it.itemId) {
                                            doItemIds.push({ itemId: it.itemId, pipeExt: { ...(i.pipeExt || {}), ...(it.pipeExt || {}) } })
                                        }
                                    }
                                }
                            }
                            if (!doItemIds.length) {
                                localBrowse++
                                errId[dedupKey] = 2
                                break
                            }
                            for (let [k, dit] of Object.entries(doItemIds)) {
                                let _itemId = typeof dit === 'string' ? dit : encodeURIComponent(dit.itemId)
                                let _pipe = typeof dit === 'string' ? (i.pipeExt || {}) : dit.pipeExt
                                let doTask = await this.farmCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                        'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(_pipe)},"taskInsert":false,"itemId":"${_itemId}"}&t=1738480908001&appid=activities_platform&client=ios&clientVersion=15.9.30&platform=3&loginType=2&loginWQBiz=wegame`,
                                        algo: {'appId': '54ed7'},
                                        user,
                                    }
                                )
                                if (this.haskey(doTask, 'success')) {
                                    p.log(`任务完成 [${parseInt(k) + 1}/${doItemIds.length}]`)
                                    if (i.timeLimitPeriod) {
                                        p.log(`等待${i.timeLimitPeriod}秒...`)
                                        await this.wait(i.timeLimitPeriod * 1000)
                                        await this.farmCurl({
                                                'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                                'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}"}&t=1738483906048&appid=activities_platform&client=ios&clientVersion=15.9.30&platform=3&loginType=2&loginWQBiz=wegame`,
                                                user,
                                                algo: {appId: 'ebecc'}
                                            }
                                        )
                                    }
                                    if (i.canDrawAwardNum) {
                                        let award = await this.farmCurl({
                                                'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1787832238328&appid=activities_platform&client=ios&clientVersion=15.9.30&platform=3&loginType=2&loginWQBiz=wegame`,
                                                user,
                                                algo: {appId: 'f0f3f'}
                                            }
                                        )
                                        if (this.haskey(award, 'data')) {
                                            for (let j of award.data) {
                                                if (j.awardName == 'WATER') {
                                                    p.log("获得水滴:", j.awardGivenNumber)
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (this.haskey(doTask, 'code', 2018) || this.haskey(doTask, 'code', 2031) || this.haskey(doTask, 'code', 2014)) {
                                    p.log(`需真机浏览(限时任务): ${i.taskShowTitle || i.taskTitle}`)
                                    localBrowse++
                                    errId[dedupKey] = 2
                                    break
                                }
                                else {
                                    p.err(`任务失败: ${this.haskey(doTask, 'errMsg') || '接口异常'}`)
                                    errId[dedupKey] = errId[dedupKey] || 0
                                    errId[dedupKey]++
                                    break
                                }
                                await this.wait(3000)
                            }
                            break
                        case 'CUMULATIVE_TIMES':
                            // 浇水任务走 farmWv 自签名链路(jdAlgo 的受理/上报被服务端风控空返回)
                            // farmWv 先跑(1:25/7:25/13:25/19:25)做完浇水, 这里扫到 taskLimitTimes==taskDoTimes 自动跳过
                            continue
                        default:
                            localAct++
                            break
                    }
                }
            }
            if (isOk == 0) {
                break
            }
            else {
                await this.wait(1000)
            }
        }
        if (localBrowse) {
            p.log(`另有 ${localBrowse} 个浏览任务需在京东App内手动打开页面完成(限时任务需真实页面停留, 脚本无法代做)`)
        }
        if (localAct) {
            p.log(`另有 ${localAct} 个任务需打开外部App/小游戏/下单/添加小组件, 脚本无法代做`)
        }
    }

    // ============ 活动平台任务链路(合并自 jd_task_farmWv v8 纯协议版) ============
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(FW_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.fwCookie()
    }
    fwCookie() {
        if (this._fwCk && Date.now() - this._fwCkAt < 600000) return this._fwCk
        try {
            const txt = fs.readFileSync(FW_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._fwCk = guid ? guid + ';' + ck : ck; this._fwCkAt = Date.now() }
        } catch (e) {}
        return this._fwCk || ''
    }

    fwEid() {
        if (this._fwEid !== undefined) return this._fwEid
        const m = this.fwCookie().match(/3AB9D23F7A4B3CSS=([^;\s]+)/)
        this._fwEid = m ? m[1] : ''
        return this._fwEid
    }

    async apReq(p, fn, bodyObj) {
        if (!this._fwSigner) {
            try { this._fwSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._fwSigner) { p.err('签名器缺失(需 parse/jd 下 jd_signer_node.mjs/farm_sign_sdk.js/farm_wq_seed.json)'); return null }
        const cfg = FW_APPIDS[fn] || ['54ed7', 'activities_platform']
        const ck = this._ckForUser(p.data.user)
        const body = JSON.stringify(bodyObj)
        const t = String(Date.now())
        const ext = JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': this.fwEid(), 'wg-sdk-token': '', pageUrl: encodeURIComponent(FW_PAGE)})
        const signed = this._fwSigner.sign({
            functionId: fn, appId: cfg[0], ck, body,
            base: {
                appid: cfg[1],
                client: 'android', clientVersion: '15.10.50', t, body, functionId: fn,
                platform: '3', loginType: '2', loginWQBiz: 'wegame',
                uuid: FW_EU + '-' + FW_FV, build: '102649', screen: '360*800', networkType: 'wifi',
                d_brand: 'OnePlus', d_model: 'IN2010', lang: 'zh_CN', osVersion: '13', partner: 'oppo',
                'wg-sdk-token': '', ext, eufv: '1', eu: FW_EU, fv: FW_FV, cthr: '1'
            }
        })
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const form = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(form), cookie: ck,
                    origin: FW_PAGE, referer: FW_PAGE,
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(form); rq.end()
        })
    }

    // 框架curl兼容层: 框架网络链路被服务端拒(2026-10-16 实测全空响应), 农场/活动接口改走 signer 自签名
    // 入参与 this.curl 一致({form, user, algo}), 内部解析 form 提取 functionId/body/appid 后自签自发
    async farmCurl(opts) {
        if (!this._fwSigner) {
            try { this._fwSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._fwSigner) return null
        const form = String(opts.form || '')
        const getv = k => { const m = form.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const t = String(Date.now())
        const base = {
            appid: getv('appid') || 'signed_farm_mp',
            client: getv('client') || 'apple', clientVersion: getv('clientVersion') || '15.1.35',
            t, body, functionId: fn, networkType: 'wifi'
        }
        const signed = this._fwSigner.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || 'c57f6', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: FW_PAGE, referer: FW_PAGE,
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    fwBrief(t) {
        return {
            asg: (t.pipeExt && t.pipeExt.assignmentId) || t.assignmentId || '',
            type: String(t.taskType || ''),
            src: t.taskSourceUrl || (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].itemId) || '',
            pipeItem: (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].pipeExt && t.taskItemList[0].pipeExt.itemId) || (t.pipeExt && t.pipeExt.itemId) || '',
            times: (t.taskDoTimes || 0), limit: (t.taskLimitTimes || 0),
            fin: t.taskFinished === true,
            title: String(t.taskShowTitle || t.taskTitle || '').slice(0, 14),
            tl: (t.timeLimitPeriod || 0)
        }
    }

    // 浇水任务: apsDoTask 直接上报即计数(无需受理, 服务端校验当天 farm_water 总数)
    // 先循环上报吃掉历史未上报的浇水记录(零水滴), 吃干了才 farm_water 补浇再报
    async fwWater(p) {
        let total = 0
        for (const LINK_ID of FW_LINKS) {
            const lr = await this.apReq(p, 'apTaskList', {linkId: LINK_ID})
            const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
            const wt = tasks.find(t => t.taskType === 'CUMULATIVE_TIMES' && String(t.taskShowTitle || '').includes('浇水') && (t.taskDoTimes || 0) < (t.taskLimitTimes || 0))
            if (!wt) continue
            const left = (wt.taskLimitTimes || 0) - (wt.taskDoTimes || 0)
            p.log(`[${LINK_ID.slice(0, 6)}] 浇水任务还需 ${left} 次(直接上报, 无需受理)`)
            let doneN = 0, failN = 0, rate = 0
            while (doneN < left && failN < 2 && rate < 3) {
                const dr = await this.apReq(p, 'apsDoTask', {taskType: 'CUMULATIVE_TIMES', taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: wt.pipeExt || {}, taskInsert: false})
                if (dr && (dr.success === true || dr.code === 0)) {
                    failN = 0
                    doneN++; total++
                    const uf = (dr.data && dr.data.userFinishedTimes) || '?', fn = (dr.data && dr.data.finishNeed) || '?'
                    p.log(`[${LINK_ID.slice(0, 6)}] 上报[${doneN}/${left}] 进度:${uf}/${fn}${dr.data && dr.data.finished ? ' [任务完成!]' : ''}`)
                    if (dr.data && dr.data.finished) break
                    await this.wait(2000)
                    continue
                }
                failN++
                const wr = await this.apReq(p, 'farm_water', {version: 21, channelParam: '1', waterType: 2, onlineGiftPackageFlg: true, babelChannel: 'ttt6', lbsSwitch: true})
                const bw = wr && wr.data && wr.data.result && wr.data.result.bottleWater
                if (!bw) {
                    const code = String((wr && wr.code) || (wr && wr.data && wr.data.bizCode) || '')
                    const msg = String((wr && wr.msg) || (wr && wr.data && wr.data.bizMsg) || '')
                    if (/405|火爆|稍后|频繁|繁忙/.test(code + msg)) {
                        rate++
                        p.log(`浇水限流(${msg || code}) 重试${rate}/3`)
                        await this.wait(20000)
                        continue
                    }
                    p.log(`水不足/浇水异常(${code} ${msg}), 本轮已上报${doneN}次, 攒够水滴下轮继续`)
                    break
                }
                p.log(`[${LINK_ID.slice(0, 6)}] 浇水1次(剩余:${bw}), 继续上报`)
                await this.wait(2500)
            }
            const aw = await this.apReq(p, 'apTaskDrawAward', {taskType: 'CUMULATIVE_TIMES', taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: wt.pipeExt || {}})
            const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
            if (awd) p.log(`[${LINK_ID.slice(0, 6)}] 浇水奖励 ${awd}`)
        }
        if (total) p.log(`本轮浇水任务共上报 ${total} 次`)
        return total
    }

    // 浏览/关注任务: 双活动池遍历, apStartTaskTime 受理 → 停留 → apsDoTask 上报 → apTaskDrawAward 领奖
    // 游戏类(JOIN_OTHER_ACT)由游戏侧小程序服务端上报进度, 客户端伪造不了(实测 2018), 跳过
    async doActivityTasks(p) {
        let lastRej = 0
        try { lastRej = +(await this.getTemp('farmWvReject')) || 0 } catch (e) {}
        if (lastRej && Date.now() - lastRej < 180000) {
            p.log('农场活动任务: ' + Math.ceil((180000 - (Date.now() - lastRej)) / 60000) + '分钟前被软拒过, 本轮跳过')
            return
        }
        const skipType = /^(CUMULATIVE_TIMES|JOIN_OTHER_ACT|ADD_WIDGET|WECHAT_SHARE|ORDER_MARK|SUBSCRIBE|WECHAT|ACCUMULATE|SHOPPING|SIGN|WATER|GAME|PLAY_|MINI_GAME)/
        let done = 0, fails = 0
        linkLoop: for (const LINK_ID of FW_LINKS) {
            const skipAsg = new Set()
            let guard = 0
            while (guard++ < 40) {
                const lr = await this.apReq(p, 'apTaskList', {linkId: LINK_ID})
                const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
                if (!tasks.length) { p.err('apTaskList 无数据: ' + JSON.stringify(lr).slice(0, 100)); continue linkLoop }
                if (guard === 1) p.log(`[${LINK_ID.slice(0, 6)}] 活动任务池 ${tasks.length} 个`)
                const cur = tasks.map(t => this.fwBrief(t)).find(b => !b.fin && !skipAsg.has(b.asg) && !skipType.test(b.type) && /^(BROWSE|FOLLOW|EXTERNAL_BROWSE)/.test(b.type))
                if (!cur) break
                let src = cur.src
                if (!/^FOLLOW/.test(cur.type) && /^\d+$/.test(src)) src = 'http://item.jd.com/' + src + '.html'
                const itemId = src ? encodeURIComponent(src) : encodeURIComponent(FW_PAGE)
                const pipeExt = {taskType: cur.type, assignmentId: cur.asg}
                if (cur.pipeItem) pipeExt.itemId = cur.pipeItem
                const st = await this.apReq(p, 'apStartTaskTime', {linkId: LINK_ID, taskId: -9999, itemId, channel: 4, pipeExt})
                if (!(st && (st.success === true || st.code === 0))) {
                    const em = (st && (st.errMsg || st.msg)) || JSON.stringify(st).slice(0, 60)
                    p.log(`[${cur.title}] 受理拒: ${em}`)
                    skipAsg.add(cur.asg); fails++
                    await this.wait(/太多|火爆|稍后|频繁/.test(em) ? 8000 : 3000)
                    continue
                }
                await this.wait((cur.tl > 0 ? cur.tl : 10) * 1000 + 1500)
                const dr = await this.apReq(p, 'apsDoTask', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt, itemId})
                if (!(dr && (dr.success === true || dr.code === 0))) {
                    const dm = (dr && (dr.errMsg || dr.msg)) || JSON.stringify(dr).slice(0, 60)
                    p.log(`[${cur.title}] do拒: ` + dm)
                    if (!/已完成/.test(dm)) {
                        skipAsg.add(cur.asg); fails++
                        await this.wait(3000)
                        continue
                    }
                    await this.wait(1500)
                } else {
                    await this.wait(2000 + Math.floor(Math.random() * 2000))
                }
                const aw = await this.apReq(p, 'apTaskDrawAward', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt})
                const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
                if (awd) { done++; p.log(`[${cur.title}] ${awd}`) }
                else {
                    p.log(`[${cur.title}] 领奖: ` + ((aw && (aw.errMsg || aw.msg)) || JSON.stringify(aw).slice(0, 60)))
                    if (aw && aw.success === true) done++
                    else skipAsg.add(cur.asg)
                }
                await this.wait(3000 + Math.floor(Math.random() * 3000))
            }
        }
        await this.fwWater(p)
        const hm = await this.apReq(p, 'farm_home', {version: 21, channelParam: '1'})
        const bw = hm && hm.data && hm.data.result && hm.data.result.bottleWater
        p.log(`活动任务: 浏览完成${done} 失败${fails} 水滴余额: ${bw === undefined ? '?' : bw}`)
        if (done === 0 && fails > 0) {
            await this.setTemp('farmWvReject', String(Date.now()))
            p.log('活动平台全拒, 3 分钟退避')
        }
        p.info.work = true
    }
    // ============ 活动平台任务链路结束 ============

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        if (this.turnCount == 0) {
            if (this.turnCount == 0) {
                let signIn = await this.farmCurl({
                        'form': `functionId=dongDongFarmSignIn&body={"linkId":"LCH-fV7hSnChB-6i5f4ayw"}&t=1740546479554&appid=activities_platform&client=ios&clientVersion=15.0.20&build=169736&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                        user, algo: {
                            appId: '65f9d'
                        }
                    }
                )
                if (this.haskey(signIn, 'success')) {
                    p.log('签到成功')
                }
                else if (this.haskey(signIn, 'code', 210000)) {
                    p.log('非东东农场用户/树种植状态异常!')
                    let tree = await this.farmCurl({
                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.11&body={"version":21,"channelParam":"1","level":3,"type":"plantLevel"}&functionId=farm_plant_tree`,
                            user
                        }
                    )
                    if (this.haskey(tree, 'data.bizCode', -10)) {
                        await this.farmCurl({
                                'form': `appid=signed_farm_mp&body={"version":21,"channelParam":"1"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                                user,
                                algo: {
                                    appId: 'c57f6',
                                }
                            }
                        )
                    }
                    else {
                        return
                    }
                }
                else if (this.haskey(signIn, 'code', 16510)) {
                    p.log('今日已签到(16510)')
                }
                else {
                    p.log('签到失败:', JSON.stringify(signIn).slice(0, 260) || '空响应')
                }
            }
            await this.farmCurl({
                    'form': `appid=signed_farm_mp&client=apple&clientVersion=15.1.35&body={"version":21,"channelParam":"1","noviceGuidanceShouldShow":false,"pageVisit":true,"babelChannel":"ttt85","showDesktopTask":true,"lbsSwitch":true}&functionId=farm_red_dot`,
                    user
                }
            )
            await this.otherWork(p, 'fWWo3YmB983abNOJPR7veg')
            await this.otherWork(p, '2O3VP9OxmzfMQU8WWKZ6aQ')
            let farmHome = null, bizCode = null
            for (let retry = 0; retry < 3; retry++) {
                farmHome = await this.farmCurl({
                        'form': `appid=signed_farm_mp&body={"version":21,"channelParam":"1"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                        user,
                        algo: {
                            appId: 'c57f6',
                            expire: {
                                code: -30001
                            }
                        }
                    }
                )
                bizCode = this.haskey(farmHome, 'data.bizCode')
                if (bizCode == -1001) {
                    p.log(`活动太火爆(限流), 等30秒后重试 ${retry + 1}/3`)
                    await this.wait(30000)
                    continue
                }
                break
            }
            if (bizCode == -1001) {
                p.err('活动太火爆, 重试3次仍被限流, 本轮放弃')
                return
            }
            if (!farmHome) {
                p.err('farm_home 无响应(3次重试后), bizCode=' + bizCode)
                return
            }
            let home = this.haskey(farmHome, 'data.result') || {}
            if (!farmHome.data) {
                p.log('农场首页无数据(接口返回异常)，跳过本轮')
                return
            }
            let treeFullStage = home.treeFullStage
            let stock = Math.max(parseInt(this.profile.stock || 200), 210)
            if (treeFullStage == 5) {
                p.msg(`商品可兑换`)
            }
            if (treeFullStage == 5 && this.profile.tree) {
                p.log('没有种树')
                let board = await this.farmCurl({
                        'form': `appid=signed_farm_mp&body={"version":21,"channelParam":"1","boardType":"level"}&client=apple&clientVersion=15.0.11&functionId=farm_tree_board`,
                        user,
                    }
                )
                try {
                    let skus = board.data.result.farmTreeLevels[2].farmLevelTrees[0]
                    p.log("正在种树,选择商品:", skus.skuName)
                    let plantTree = await this.farmCurl({
                            'form': `appid=signed_farm_mp&body=${this.dumps({
                                "version": 13,
                                "channelParam": "1",
                                "uid": skus.uid,
                                "type": "plantSku"
                            })}&client=apple&clientVersion=15.0.11&functionId=farm_plant_tree`,
                            user,
                        }
                    )
                    let tree = await this.farmCurl({
                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.11&body={"version":21,"channelParam":"1","level":3,"type":"plantLevel"}&functionId=farm_plant_tree`,
                            user
                        }
                    )
                    if (this.haskey(tree, 'data.success')) {
                        farmHome = await this.farmCurl({
                                'form': `appid=signed_farm_mp&body={"version":21,"channelParam":"1"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                                user,
                                algo: {
                                    appId: 'c57f6',
                                }
                            }
                        )
                        if (!farmHome) {
                            return
                        }
                        home = this.haskey(farmHome, 'data.result') || {}
                    }
                    else {
                        p.log("种树失败")
                        return
                    }
                } catch (e) {
                    p.log("种树失败2")
                }
            }
            let inviteCode = home.farmHomeShare.inviteCode
            let bottleWater = home.bottleWater
            p.log("当前进度:", home.waterTips)
            if (this.profile.tenWater) {
                p.log("跳过浇水: 检测到配置了tenWater参数,跳过浇水")
            }
            else {
                p.log("剩余水滴:", bottleWater, '保留水滴数:', stock)
                if (bottleWater>stock) {
                    while (true) {
                        let water = await this.farmCurl({
                                'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.20&body={"version":21,"channelParam":"1","waterType":2,"onlineGiftPackageFlg":true,"babelChannel":"ttt6","lbsSwitch":true}&functionId=farm_water`,
                                user,
                                algo: {
                                    appId: '28981',
                                }
                            }
                        )
                        let bottleWater = this.haskey(water, 'data.result.bottleWater')
                        if (bottleWater) {
                            p.log("浇水中D,剩余水滴:", bottleWater)
                            if (bottleWater<=stock) {
                                break
                            }
                            await this.wait(3000)
                        }
                        else {
                            p.log('浇水失败D:', this.haskey(water, 'data.bizMsg'))
                            break
                        }
                    }
                }
            }
            let waterConut = 0
            let status = 1
            let vcs = [
                {"version": 21, "channelParam": "1"},
                // {"version": 30, "channelParam": "1"},
                {"version": 30, "channelParam": "6"}
            ]
            for (let vc of vcs) {
                let version = vc.version
                let channelParam = vc.channelParam
                for (let __ of Array(2)) {
                    let taskList = await this.farmCurl({
                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&t=1740322939720&body={"version":${version},"channelParam":"${channelParam}","channel":0,"pushSwitch":false,"showSubscribe":true,"babelChannel":"ttt6","lbsSwitch":false}&functionId=farm_task_list&rfs=0000`,
                            user
                        }
                    )
                    for (let i of this.haskey(taskList, 'data.result.taskList')) {
                        if (i.mainTitle.includes("助力")) {
                        }
                        else if (i.taskType.match("WECHAT_SHARE|JOIN_OTHER_ACT|BROWSE_SEARCH|ORDER_MARK")) {
                        }
                        else if (i.mainTitle.includes("通知")) {
                            //13 1
                            let doTask = await this.farmCurl({
                                    'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"SUBSCRIBE_WITH_RECEIVE","taskId":${i.taskId},"taskInsert":false,"itemId":"","channel":0,"pipeExt":${this.dumps(i.pipeExt)}}&functionId=farm_do_task`,
                                    user,
                                    algo: {
                                        appId: '28981'
                                    }
                                }
                            )
                            if (this.haskey(doTask, 'data.success')) {
                                let award = await this.farmCurl({
                                        'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0,"pipeExt":${this.dumps(i.pipeExt)}}&functionId=farm_task_receive_award`,
                                        user, algo: {'appId': '33e0f'},
                                    }
                                )
                                // console.log(666, award)
                                if (this.haskey(award, 'data.result.taskAward')) {
                                    status = 1
                                    // p.log("获得奖励:", award.data.result.taskAward)
                                    for (let kk of award.data.result.taskAward) {
                                        if (this.haskey(kk, 'awardType', 1)) {
                                            bottleWater += kk.awardValue
                                            p.log(`获得水滴:`, kk.awardValue)
                                        }
                                    }
                                }
                                else {
                                    p.err("获取失败:", this.haskey(award, 'data.bizMsg'))
                                }
                            }
                            else {
                                p.err("任务失败:", this.haskey(doTask, 'data.bizMsg'))
                            }
                        }
                        else if (i.mainTitle.match(/下单|下1单|定时|小游戏/)) {
                        }
                        else if (i.taskType == 'FIXED_CHANNEL_DRAINAGE') {
                            let report = await this.farmCurl({
                                    'form': `appid=signed_farm_mp_ihub&client=apple&clientVersion=15.1.50&screen=390*2723&wqDefault=false&build=169892&osVersion=15.1.1&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&partner=&openudid=674ce0d97511f5ed054c3dc0af093b3b245ab68d&t=1748760248487&body={"version":${version},"channelParam":"${channelParam}","taskType":"FIXED_CHANNEL_DRAINAGE","taskId":${i.taskId},"popType":"fixChannelReward","babelChannel":"ttt6"}&functionId=farm_pop_window_show_report`,
                                    user
                                }
                            )
                            await this.farmCurl({
                                    'form': `appid=signed_farm_mp&body={"version":${version},"channelParam":"${channelParam}"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                                    user,
                                    algo: {
                                        appId: 'c57f6',
                                        expire: {
                                            code: -30001
                                        }
                                    }
                                }
                            )
                            await this.farmCurl({
                                    'form': `appid=signed_farm_mp&client=apple&clientVersion=15.1.50&screen=390*2723&wqDefault=false&build=169892&osVersion=15.1.1&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&partner=&t=1748760247773&body={"version":${version},"channelParam":"${channelParam}","noviceGuidanceShouldShow":false,"pageVisit":true,"babelChannel":"ttt6","showDesktopTask":true,"lbsSwitch":true}&functionId=farm_red_dot`,
                                    user
                                }
                            )
                            await this.farmCurl({
                                    'form': `appid=signed_farm_mp&body={"version":${version},"channelParam":"${channelParam}"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                                    user,
                                    algo: {
                                        appId: 'c57f6',
                                        expire: {
                                            code: -30001
                                        }
                                    }
                                }
                            )
                            let award = await this.farmCurl({
                                    'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0,"pipeExt":${this.dumps(i.pipeExt)}}&functionId=farm_task_receive_award`,
                                    user,
                                    algo: {'appId': '33e0f'},
                                }
                            )
                            if (this.haskey(award, 'data.result.taskAward')) {
                                p.log(award.data.result.taskAward)
                            }
                        }
                        else if (i.mainTitle.includes("浇水")) {
                            if (i.taskDoTimes != i.taskLimitTimes) {
                                p.log("正在运行:", i.mainTitle)
                                let isOk = 1
                                status = 0
                                for (let n of Array(parseInt((i.taskLimitTimes - i.taskDoTimes) / 5))) {
                                    let water = await this.farmCurl({
                                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.20&body={"version":21,"channelParam":"1","waterType":2,"onlineGiftPackageFlg":true,"babelChannel":"ttt6","lbsSwitch":true}&functionId=farm_water`,
                                            user,
                                            algo: {
                                                appId: '28981'
                                            }
                                        }
                                    )
                                    let bottleWater = this.haskey(water, 'data.result.bottleWater')
                                    if (bottleWater) {
                                        p.log("浇水中A,剩余水滴:", bottleWater)
                                        if (bottleWater<=stock) {
                                            isOk = 0
                                            break
                                        }
                                        await this.wait(1000)
                                    }
                                    else {
                                        p.log('浇水失败A:', this.haskey(water, 'data.bizMsg'))
                                        isOk = 0
                                        status = 0
                                        break
                                    }
                                }
                                // while (1) {
                                for (let n of Array(((i.taskLimitTimes - i.taskDoTimes) % 5))) {
                                    let water = await this.farmCurl({
                                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.20&body={"version":21,"channelParam":"1","waterType":2,"onlineGiftPackageFlg":true,"babelChannel":"ttt6","lbsSwitch":true}&functionId=farm_water`,
                                            user,
                                            algo: {
                                                appId: '28981'
                                            }
                                        }
                                    )
                                    let bottleWater = this.haskey(water, 'data.result.bottleWater')
                                    if (bottleWater) {
                                        p.log("浇水中B,剩余水滴:", bottleWater)
                                        if (bottleWater<stock) {
                                            // isOk = 0
                                            break
                                        }
                                        await this.wait(1000)
                                    }
                                    else {
                                        p.log('浇水失败B:', this.haskey(water, 'data.bizMsg'))
                                        // isOk = 0
                                        break
                                    }
                                }
                                if (isOk) {
                                    let award = await this.farmCurl({
                                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_receive_award`,
                                            user,
                                            algo: {'appId': '33e0f'},
                                        }
                                    )
                                    // console.log(663, award)
                                    if (this.haskey(award, 'data.result.taskAward')) {
                                        status = 1
                                        // p.log("获得奖励:", award.data.result.taskAward)
                                        for (let kk of award.data.result.taskAward) {
                                            if (this.haskey(kk, 'awardType', 1)) {
                                                bottleWater += kk.awardValue
                                                p.log(`获得水滴:`, kk.awardValue)
                                            }
                                        }
                                    }
                                    else {
                                        status = 0
                                        p.err("获取失败:", this.haskey(award, 'data.bizMsg'))
                                    }
                                }
                                if (bottleWater<200) {
                                    status = 0
                                }
                            }
                        }
                        else if (i.taskDoTimes != i.taskLimitTimes) {
                            status = 0
                            p.log("正在运行:", i.mainTitle)
                            let itemId = i.taskSourceUrl
                            let taskDetaiList = []
                            if (itemId) {
                                taskDetaiList.push({'itemId': itemId})
                            }
                            else {
                                let detail = await await this.farmCurl({
                                        'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_detail`,
                                        user
                                    }
                                )
                                if (this.haskey(detail, 'data.result.taskDetaiList')) {
                                    taskDetaiList = detail.data.result.taskDetaiList
                                }
                            }
                            if (!taskDetaiList.length) {
                                p.log("任务无子项,需在App内手动完成")
                            }
                            for (let kk of taskDetaiList) {
                                if (i.timePeriod) {
                                    p.log("等待:", i.timePeriod, 's')
                                    await this.wait(i.timePeriod * 1000)
                                }
                                let doTask = await this.farmCurl({
                                        'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"${i.taskType}","taskId":${i.taskId},"taskInsert":${kk.taskInsert || false},"itemId":"${new Buffer.from(kk.itemId).toString('base64')}","channel":0}&functionId=farm_do_task`,
                                        user,
                                        algo: {
                                            appId: '28981'
                                        }
                                    }
                                )
                                // console.log(664, award)
                                if (this.haskey(doTask, 'data.success')) {
                                    let award = await this.farmCurl({
                                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":${version},"channelParam":"${channelParam}","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_receive_award`,
                                            user, algo: {'appId': '33e0f'},
                                        }
                                    )
                                    if (this.haskey(award, 'data.result.taskAward')) {
                                        status = 1
                                        // p.log("获得奖励:", award.data.result.taskAward)
                                        for (let kk of award.data.result.taskAward) {
                                            if (this.haskey(kk, 'awardType', 1)) {
                                                bottleWater += kk.awardValue
                                                p.log(`获得水滴:`, kk.awardValue)
                                            }
                                        }
                                    }
                                    else {
                                        p.err("获取失败:", this.haskey(award, 'data.bizMsg'))
                                    }
                                }
                                else {
                                    p.err("任务失败:", this.haskey(doTask, 'data.bizMsg'))
                                }
                            }
                        }
                        else if (i.taskStatus == 2) {
                            // console.log(i)
                            let award = await this.farmCurl({
                                    // 'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body={"version":21,"channelParam":"1","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_receive_award`,
                                    form: `appid=signed_farm_mp&client=apple&clientVersion=15.0.15&body=${this.dumps({
                                        "version": version,
                                        "channelParam": channelParam,
                                        "taskType": i.taskType,
                                        "taskId": i.taskId,
                                        "channel": 0,
                                        "pipeExt": i.pipeExt || {}
                                    })}&functionId=farm_task_receive_award`,
                                    user,
                                    algo: {'appId': '33e0f'},
                                    referer: 'https://pro.m.jd.com/mall/active/42HV4J3Q87B2xFQMJk81PCc1mEs3/index.html'
                                }
                            )
                            // console.log(665, award)
                            if (this.haskey(award, 'data.result.taskAward')) {
                                status = 1
                                // p.log("获得奖励:", award.data.result.taskAward)
                                for (let kk of award.data.result.taskAward) {
                                    if (this.haskey(kk, 'awardType', 1)) {
                                        bottleWater += kk.awardValue
                                        p.log(`获得水滴:`, kk.awardValue)
                                    }
                                }
                            }
                            else {
                                status = 0
                                p.err("获取失败:", this.haskey(award, 'data.bizMsg'))
                            }
                            await this.wait(4000)
                        }
                        else {
                            p.log("任务已完成:", i.mainTitle)
                            status = 1
                        }
                    }
                }
            }
            let s1 = 1
            if (this.profile.tenWater) {
                p.log("跳过浇水: 检测到配置了tenWater参数,跳过浇水")
            }
            else {
                let farmHome = await this.farmCurl({
                        'form': `appid=signed_farm_mp&body={"version":21,"channelParam":"1"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                        user,
                        algo: {
                            appId: 'c57f6',
                            expire: {
                                code: -30001
                            }
                        }
                    }
                )
                let bottleWater = this.haskey(farmHome, 'data.result.bottleWater') || 0
                p.log("剩余水滴:", bottleWater, '保留水滴数:', stock)
                if (bottleWater>stock) {
                    while (true) {
                        s1 = 0
                        let water = await this.farmCurl({
                                'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.20&body={"version":21,"channelParam":"1","waterType":2,"onlineGiftPackageFlg":true,"babelChannel":"ttt6","lbsSwitch":true}&functionId=farm_water`,
                                user,
                                algo: {
                                    appId: '28981',
                                }
                            }
                        )
                        // console.log(water)
                        let bottleWater = this.haskey(water, 'data.result.bottleWater')
                        if (bottleWater) {
                            s1 = 1
                            p.log("浇水中C,剩余水滴:", bottleWater)
                            if (bottleWater<=stock) {
                                break
                            }
                            await this.wait(3000)
                        }
                        else {
                            s1 = 0
                            p.log('浇水失败C:', this.haskey(water, 'data.bizMsg'))
                            break
                        }
                    }
                }
            }
            await this.setTemp(user, inviteCode)
            let detail = await this.farmCurl({
                    'form': `appid=signed_farm_mp&client=apple&clientVersion=15.1.50&screen=390*2754&wqDefault=false&build=169892&osVersion=15.1.1&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&partner=&t=1748907985657&body={"version":21,"channelParam":"1","type":1}&functionId=farm_award_detail`,
                    user
                }
            )
            if (this.haskey(detail, 'data.result.plantAwards')) {
                for (let i of detail.data.result.plantAwards) {
                    if (i.awardStatus == 1) {
                        p.msg("当前还有实物奖品可兑换")
                    }
                }
            }
            if (status && s1) {
                p.info.work = true
            }
        }
        else if (this.turnCount == 3) {
            if (context.user == user) {
                p.log("不能助力自己")
            }
            else {
                let farmHome = await this.farmCurl({
                        'form': `appid=signed_wh5&body={"version":30,"channelParam":"1","inviteCode":"${context.inviteCode}","babelChannel":"ttt19"}&client=apple&clientVersion=15.0.11&functionId=farm_home`,
                        user,
                        algo: {
                            appId: 'c57f6',
                            expire: {
                                code: -30001
                            }
                        }
                    }
                )
                let help = await this.farmCurl({
                        'form': `appid=signed_wh5&body=${this.dumps({
                            "version": 30,
                            "channelParam": "1",
                            "inviteCode": context.inviteCode,
                            "shareChannel": "ttt19",
                            "assistChannel": "",
                            "inviteChannel": "1"
                        })}&client=apple&clientVersion=15.0.11&functionId=farm_assist`,
                        user,
                        algo: {
                            appId: '28981',
                            expire: {
                                "code": -30001,
                            }
                        },
                        rererer: "https://pro.m.jd.com/mall/active/42HV4J3Q87B2xFQMJk81PCc1mEs3/index.html?utm_term=QRCode_shareid8f5076042d149f60178981073486381100_%E4%B8%9C%E4%B8%9C%E5%86%9C%E5%9C%BA_NewDDFarm&utm_source=androidapp&babelChannel=ttt19&un_area=16_1342_1357_45750&ad_od=share&utm_medium=appshare&tttparams=ZJwGOiIIeyJyZnMiOiIwMDAwIiwicG9zTG5nIjoiMTE3LjYxMzA4OCIsImRfYnJhbmQiOiJhcHBsZSIsImdMbmciOiIxMTcuNjEzMDg4IiwidWVtcHMiOiIwLTItMCIsImdMYXQiOiIyMy45NDAwNjEiLCJsbmciOiIwLjAwMDAwMCIsIm9yaWVudCI6InAiLCJvcyI6IjE1LjEuMSIsImxic0xhdCI6IjIzLjk0MDA2MSIsImxic0xuZyI6IjExNy42MTMwODgiLCJwcnN0YXRlIjoiMCIsImdwc19hcmVhIjoiMF8wXzBfMCIsInNjYWxlIjoiMy4wMDAwMDAiLCJhZGRyZXNzSWQiOiI4NjUzMzkyNTYyIiwidW5fYXJlYSI6IjE2XzEzNDFfMTM0N180NDc1MCIsIndpZHRoIjoiMTE3MCIsImxic0FyZWEiOiIxNl8xMzQxXzEzNDdfNDQ3NTAiLCJsYXQiOiIwLjAwMDAwMCIsIm1vZGVsIjoiaVBob25lMTMsMyIsImNvcm5lciI6MSwiYXJlYUNvZGUiOiIwIiwicG9zTGF0IjoiMjMuOTQwMDYxIiwiZGwiOj8J9&hybrid_err_view=1&inviteCode=ycXdOaS1kgrOCBdTKJytJb97gcNaeGuIhQ&_ts=1789810732364&inviteChannel=1&utm_campaign=t_335139774&gx=RnAomTM2bjLZyplH-oB_DEAMEED-TS8&sid=&stath=47&navh=44&jwebprog=0&gxd=RnAoyzFcaDPfy5wX-4VzVAfOuM81j1Q"
                    }
                )
                let bizCode = this.haskey(help, 'data.bizCode')
                if (bizCode == 5003) {
                    p.log("今天已经帮过TA啦")
                    p.info.help = true
                }
                else if (bizCode == 5004) {
                    p.info.complete = true
                    p.log("今天不能再助力啦")
                }
                else if (bizCode == 5005) {
                    p.log("助力满了,跳过助力")
                    p.context.finish = true
                }
                else if (bizCode == -1001) {
                    p.log("活动火爆")
                    p.info.jump = true
                }
                else if (this.haskey(help, 'data.success')) {
                    p.info.help = true
                    p.log(`助力成功: ${context.user || context.inviteCode}`)
                }
                else {
                    p.log(this.haskey(help, 'data') || help)
                }
                await this.wait(1000)
            }
        }
        else if (this.turnCount == 2) {
            p.lottery = function(lottery) {
                let data = lottery.data
                let prizeType = data.prizeType || data.rewardType
                let amount = data.amount || data.rewardValue
                if (prizeType == 0) {
                    p.log('没抽到奖品')
                }
                else if (prizeType == 1) {
                    p.log('优惠券:', data.codeDesc || data.prizeCode, data.prizeDesc || data.prizeName)
                }
                else if (prizeType == 2) {
                    p.draw(`红包: ${amount}`)
                }
                else if (prizeType == 3) {
                    p.draw(`京豆: ${amount}`)
                }
                else if (prizeType == 17) {
                    p.log('谢谢参与')
                }
                else if (prizeType == 18) {
                    p.log(`水滴: ${amount}`)
                }
                else if (prizeType == 22) {
                    p.draw(`超市卡: ${amount}`)
                }
                else if (prizeType) {
                    p.draw(`抽到类型: ${prizeType} ${data.codeDesc || data.prizeCode} ${data.prizeDesc || data.prizeName}`)
                }
                else {
                    p.log("什么也没有")
                }
            }
            let linkId = "VssYBUKJOen7HZXpC8dRFA"
            let localBrowse = 0
            let apTask = await this.farmCurl({
                    'url': `https://api.m.jd.com/api`,
                    'form': `functionId=apTaskList&body={"linkId":"${linkId}","channel":4}&t=1738479849113&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                    user,
                }
            )
            if (!apTask) {
                p.err("没有获取到转盘数据, 跳过转盘直接执行活动任务")
                await this.doActivityTasks(p)
                return
            }
            let isOk = 1
            for (let i of this.haskey(apTask, 'data')) {
                if (i.taskLimitTimes == i.taskDoTimes) {
                    p.log("任务已完成:", i.taskShowTitle)
                }
                else {
                    isOk = 0
                    // 浏览类旧签名被服务端拒, 跳过交给 jd_task_farmWv 纯协议链路
                    if (/^(BROWSE_CHANNEL|BROWSE_PRODUCT|FOLLOW_SHOP)$/.test(i.taskType)) continue
                    p.log(`正在运行:`, i.taskTitle, i.taskType)
                    switch (i.taskType) {
                        case 'SIGN':
                            let sign = await this.farmCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                    'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${linkId}","pipeExt":${this.dumps(i.pipeExt)}}&appid=activities_platform&client=ios&clientVersion=15.0.11&loginType=2&loginWQBiz=wegame`,
                                    algo: {
                                        appId: '54ed7'
                                    },
                                    user
                                }
                            )
                            if (this.haskey(sign, 'data.finished')) {
                                p.log("任务完成...")
                            }
                        case 'ORDER_MARK':
                        case 'SUBSCRIBE_WITH_RECEIVE':
                            break
                        case 'BROWSE_CHANNEL':
                        case  'BROWSE_PRODUCT':
                        case 'FOLLOW_SHOP':
                            // 转盘子流程浏览类旧签名被服务端拒, 从未成功过, 跳过不再刷失败
                            continue
                            if (i.taskSourceUrl) {
                                var doTask = await this.farmCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                        'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${linkId}","pipeExt":${this.dumps(i.pipeExt)},"taskInsert":false,"itemId":"${encodeURIComponent(i.taskSourceUrl)}"}&t=1738480908001&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                        algo: {'appId': '54ed7'},
                                        user
                                    }
                                )
                                if (this.haskey(doTask, 'success')) {
                                    p.log("任务完成")
                                }
                                else {
                                    p.log("任务失败:", this.haskey(doTask, 'errMsg') || doTask)
                                }
                                if (i.canDrawAwardNum) {
                                    let award = await this.farmCurl({
                                            'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                            'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${linkId}"}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                            user,
                                            algo: {
                                                appId: 'f0f3f'
                                            }
                                        }
                                    )
                                    if (this.haskey(award, 'data')) {
                                        p.log(`抽奖次数+1`)
                                    }
                                    else {
                                        p.err("抽奖领取失败")
                                    }
                                }
                            }
                            else {
                                let apTaskDetail = await this.farmCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apTaskDetail`,
                                        'form': `functionId=apTaskDetail&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1738480907628&appid=activities_platform&client=ios&clientVersion=15.0.11&`,
                                        user
                                    }
                                )
                                let taskItemList = this.haskey(apTaskDetail, 'data.taskItemList')
                                if (taskItemList) {
                                    for (let j in Array.from(Array(i.taskLimitTimes - i.taskDoTimes), (_val, index) => index)) {
                                        if (taskItemList[j] && taskItemList[j].itemId) {
                                            // apStartTaskTime 已被服务端隔离, 一律 apsDoTask 起做
                                            var doTask = await this.farmCurl({
                                                    'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                                    'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${linkId}","pipeExt":${this.dumps({
                                                        ...i.pipeExt, ...taskItemList[j].pipeExt
                                                    })},"taskInsert":false,"itemId":"${encodeURIComponent(taskItemList[j].itemId)}"}&t=1738480908001&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                    algo: {'appId': '54ed7'},
                                                    user
                                                }
                                            )
                                            if (this.haskey(doTask, 'success')) {
                                                p.log("任务完成", `[${parseInt(j) + 1}/${i.taskLimitTimes - i.taskDoTimes}]`)
                                                if (i.timeLimitPeriod) {
                                                    p.log(`等待${i.timeLimitPeriod}秒...`)
                                                    await this.wait(i.timeLimitPeriod * 1000)
                                                    await this.farmCurl({
                                                        'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                                        'form': `functionId=apDoLimitTimeTask&body={"linkId":"${linkId}"}&t=1738483906048&appid=activities_platform&client=ios&clientVersion=15.0.11&platform=3&loginType=2&loginWQBiz=wegame`,
                                                        user,
                                                        algo: {appId: 'ebecc'}
                                                    })
                                                }
                                            }
                                            else if (this.haskey(doTask, 'code', 2018) || this.haskey(doTask, 'code', 2031) || this.haskey(doTask, 'code', 2014)) {
                                                localBrowse++
                                                break
                                            }
                                            else {
                                                p.log("任务失败:", this.haskey(doTask, 'errMsg') || '接口异常')
                                            }
                                            if (i.canDrawAwardNum) {
                                                let award = await this.farmCurl({
                                                        'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                        'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${linkId}"}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                        user,
                                                        algo: {
                                                            appId: 'f0f3f'
                                                        }
                                                    }
                                                )
                                                if (this.haskey(award, 'data')) {
                                                    p.log(`抽奖次数+1`)
                                                }
                                                else {
                                                    p.err("抽奖领取失败")
                                                }
                                            }
                                            await this.wait(3000)
                                        }
                                    }
                                }
                            }
                            break
                    }
                }
            }
            let home = await this.farmCurl({
                    'url': `https://api.m.jd.com/api`,
                    'form': `functionId=wheelsHome&body={"linkId":"${linkId}","inviteActId":"","inviterEncryptPin":"","inviteCode":""}&t=1739590571889&appid=activities_platform&client=ios&clientVersion=15.0.15&cthr=1&loginType=&loginWQBiz=wegame`,
                    user,
                    algo: {'appId': 'c06b7',},
                }
            )
            if (!home) {
                isOk = 0
            }
            let drawNum = this.haskey(home, 'data.lotteryChances') || 0
            p.log("可抽奖次数:", drawNum)
            let lotteryRetry = 0
            while (drawNum > 0 && lotteryRetry <= 3) {
                try {
                    let lottery = await this.farmCurl({
                        url: 'https://api.m.jd.com/api',
                        form: `functionId=wheelsLottery&body={"linkId":"${linkId}"}&t=1739590600753&appid=activities_platform&client=ios&clientVersion=15.0.15&cthr=1&loginType=&loginWQBiz=wegame`,
                        algo: {
                            'appId': 'bd6c8',
                            expire: {
                                code: 1000
                            },
                            status: true
                        },
                        referer: `https://lotterydraw-new.jd.com/?id=${linkId}`,
                        user
                    })
                    if (this.haskey(lottery, 'code', 4000)) {
                        p.log('抽奖机会用完啦')
                        break
                    }
                    if (this.haskey(lottery, 'data')) {
                        drawNum--
                        lotteryRetry = 0
                        p.lottery(lottery)
                    }
                    else {
                        let biz = String(this.haskey(lottery, 'bizMsg') || this.haskey(lottery, 'data.bizMsg') || this.haskey(lottery, 'message') || '')
                        if (/火爆|稍后再试|繁忙|频繁/.test(biz)) {
                            lotteryRetry++
                            p.log(`转盘限流(${biz || '活动太火爆'}), 等20秒重试 ${lotteryRetry}/3`)
                            await this.wait(20000)
                            continue
                        }
                        p.err(`抽奖错误: ${biz || '返回异常'}`)
                        break
                    }
                    await this.wait(2000)
                } catch (e) {
                    break
                }
            }
            if (isOk && drawNum == 0) {
                p.info.work = true
            }
            if (localBrowse) {
                p.log(`另有 ${localBrowse} 个浏览任务需在京东App内手动打开完成(需真实页面停留, 脚本无法代做)`)
            }
            // 活动平台浏览/浇水任务链路(合并自 jd_task_farmWv)
            await this.doActivityTasks(p)
        }
        else if (this.turnCount == 1) {
            let helpInfo = await this.farmCurl({
                    'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.11&screen=820*1110&wqDefault=false&build=169714&osVersion=16.6&networkType=wifi&d_brand=iPhone&d_model=iPad13,18&partner=&t=1740556273015&body={"version":21,"channelParam":"1"}&functionId=farm_assist_init_info`,
                    user
                }
            )
            if (!helpInfo) {
                p.err("没有获取到助力数据")
            }
            else {
                p.log("正在领取助力奖励")
            }
            for (let i of this.haskey(helpInfo, 'data.result.assistStageList')) {
                if (i.stageStaus == 2) {
                    let award = await this.farmCurl({
                            'form': `appid=signed_farm_mp&client=apple&clientVersion=15.0.11&screen=820*1110&wqDefault=false&build=169714&osVersion=16.6&networkType=wifi&d_brand=iPhone&d_model=iPad13,18&partner=&t=1740556273015&body={"version":21,"channelParam":"1"}&functionId=farm_assist_receive_award`,
                            user,
                            algo: {'appId': 'c4332'},
                        }
                    )
                    if (this.haskey(award, 'data.success')) {
                        p.log("获取助力奖励成功:", award.data.result.amount)
                    }
                    else {
                        p.log("获取助力奖励失败")
                    }
                    await this.wait(4000)
                }
            }
        }
    }
}

