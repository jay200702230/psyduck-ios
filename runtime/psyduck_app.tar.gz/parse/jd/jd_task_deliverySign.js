import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: "京东天天领豆",
            crontab: 4,
            sync: 1,
            prompt: {
                activityId: '活动id1|id2'
            },
            delay: 800,
            interval: 2000,
            verify: 1,
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/3Q5H8xmBy4GyPT8xUgqwYYnAa2ns/index.html'
            }
        }
    }

    async prepare() {
        await this.field('activityId')
    }

    async main(p) {
        let user = p.data.user
        let context = p.context
        let algo = context.algo || {}
        let sign = await this.autoCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `functionId=bean_deliverySign_sign&appid=signed_wh5_ihub&body={"activityId":"${context.activityId}"}&rfs=0000&client=apple&uuid=&build=169743&clientVersion=15.0.25&d_model=&osVersion=15.1.53`,
                user,
                algo: {
                    ...{
                        expire: {
                            'data.bizCode': -102
                        },
                        appId: '987dd'
                    }, ...algo
                }
            }
        )
        let bizCode = this.haskey(sign, 'data.bizCode')
        if (this.haskey(sign, 'data.result.value')) {
            p.info.work = true
            // p.msg(`京豆: ${sign.data.result.value}`)
            p.award(sign.data.result.value, 'bean')
        }
        else if (bizCode == -2002) {
            p.info.work = true
            p.log("您已经签到过了")
        }
        else {
            let bizMsg = this.haskey(sign, 'data.bizMsg') || this.haskey(sign, 'message') || ''
            p.log(`签到未成功: ${bizMsg || '接口返回异常'} (bizCode: ${bizCode})`)
        }
        let s = await this.autoCurl({
                'form': `functionId=bean_deliverySign_continue_award&appid=signed_wh5_ihub&body={"activityId":"${context.activityId}"}&rfs=0000&client=apple&uuid=&build=169743&clientVersion=15.1.53&d_model=&osVersion=15.1.1`,
                algo: {
                    appId: '0cc57'
                },
                user
            }
        )
        if (this.haskey(s, 'data.result.value')) {
            p.award(s.data.result.value, 'bean')
        }
    }
}

