import fs from 'fs'
import path from 'path'
import net from 'net'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const PAGE = 'https://pro.m.jd.com/mall/active/5RHCkauZkojcxkmpWiwY1BJ83Ew/index.html?babelChannel=ttt1&dmChl=hsdj'
const POOLS = [
    {activityId: '34703', appKey: '250141600001', name: '在线医生'},
    {activityId: '37252', appKey: '250520900001', name: '护士节'}
]
const FALLBACK_SCALE = '100951509229568'
const FALLBACK_FUN = 'emotionqingxu'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/;jdSupportDarkMode/0;lang/zh_CN;site/CN;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东健康看病买药任务', pageUrl: PAGE, headers: {referer: PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._h2s = null
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    // app 内 RPC 全量 ck 通道(home-marketing/jdh 族校验设备指纹, 瘦 ck 部分接口拒)
    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpcCk = await this._rpcCk()
        if (rpcCk && rpcCk.includes('pt_key=')) {
            const pinOf = ck => { try { let m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            let want = pinOf(base)
            const got = pinOf(rpcCk)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpcCk
        }
        return base
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    async callG(p, user, fn, bodyObj, appid) {
        for (let k = 1; k <= 2; k++) {
            try {
                const ck = await this._ckFull(user)
                if (!ck) return null
                const q = new URLSearchParams()
                q.append('functionId', fn)
                q.append('body', JSON.stringify(bodyObj))
                q.append('appid', appid)
                q.append('client', 'wh5')
                q.append('clientVersion', '15.10.50')
                const s = this._h2()
                if (!s) return null
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    let st = null
                    try {
                        st = s.request({':method': 'GET', ':path': '/api?' + q.toString(), cookie: ck, origin: 'https://laputa.jd.com', referer: PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end()
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
            } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
            await this.wait(3000 * k)
        }
        return null
    }

    mkUuid() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
            const r = Math.random() * 16 | 0
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16)
        })
    }

    // 答卷获取: 优先任务原量表(plus免单通道), 1802/1803 则跨量表 fallback(活动映射免单卷); 各步打码防黑盒
    async getSheet(p, user, scaleId, tenantUnid) {
        const pin = await this._pin(user)
        const buyBody = (sid, fun) => ({scaleId: sid, funAssessment: fun, screenWidth: 360, screenHeight: 800, client: 'android', backUrl: '', osVersion: 'noVersion', backName: '开始答题', clientVersion: '15.10.50', uuid: this.mkUuid(), payType: 4, payParam: {}, submitBeneficialCategory: 1})
        let buy = await this.callG(p, user, 'health_scale_buyAnswerSheet', buyBody(scaleId, 'emotion'), 'health-scale')
        p.log('  [buy原]', String((buy || {}).code), String((buy || {}).msg || '').slice(0, 24))
        let sheetId = buy && buy.data ? (buy.data.answerSheetId || null) : null
        let ansScale = scaleId
        if (!sheetId) {
            const op = await this.callG(p, user, 'health_scale_saveAnswerSheet', {"0": {"appUnid": 'jd-health-scale', "tenantUnid": tenantUnid, "class": 'com.jd.health.scale.export.dto.TenantDTO'}, "scaleId": scaleId, "userSourceId": pin, "isAnswerContinued": true}, 'health-scale')
            sheetId = op && op.data ? (op.data.answerSheetId || null) : null
            const st = op && op.data ? op.data.answerStatus : null
            if (sheetId) p.log('  [save原]', String((op || {}).code), '续卷 sheet=' + sheetId, 'status=' + st)
            if (String(st) === '2') return {sheetId, ansScale, submitted: true}
        }
        if (!sheetId) {
            const fbMeta = await this.callG(p, user, 'health_scale_queryScaleInfo', {"scaleId": FALLBACK_SCALE}, 'health-scale')
            const fbTenant = fbMeta && fbMeta.data ? fbMeta.data.tenantUnid : tenantUnid
            for (let k = 1; k <= 3 && !sheetId; k++) {
                buy = await this.callG(p, user, 'health_scale_buyAnswerSheet', buyBody(FALLBACK_SCALE, FALLBACK_FUN), 'health-scale')
                p.log('  [buy免单]', String((buy || {}).code), String((buy || {}).msg || '').slice(0, 24), k > 1 ? '(第' + k + '次)' : '')
                sheetId = buy && buy.data ? (buy.data.answerSheetId || null) : null
                if (!sheetId) await this.wait(5000)
            }
            ansScale = FALLBACK_SCALE
            if (!sheetId) {
                const op2 = await this.callG(p, user, 'health_scale_saveAnswerSheet', {"0": {"appUnid": 'jd-health-scale', "tenantUnid": fbTenant, "class": 'com.jd.health.scale.export.dto.TenantDTO'}, "scaleId": FALLBACK_SCALE, "userSourceId": pin, "isAnswerContinued": true}, 'health-scale')
                sheetId = op2 && op2.data ? (op2.data.answerSheetId || null) : null
                const st2 = op2 && op2.data ? op2.data.answerStatus : null
                if (sheetId) p.log('  [save免单]', String((op2 || {}).code), 'sheet=' + sheetId, 'status=' + st2)
                if (String(st2) === '2') return {sheetId, ansScale, submitted: true}
            }
            if (sheetId) p.log('  跨量表免单卷 sheet=' + sheetId, 'scale=' + FALLBACK_SCALE)
        }
        return {sheetId, ansScale, submitted: false}
    }

    async _pin(user) {
        const ck = this._ckForUser(user)
        let pin = ''
        try { const m = String(ck).match(/pt_pin=([^;\s]+)/); pin = m ? decodeURIComponent(m[1]) : '' } catch (e) {}
        return pin || String(user || '')
    }

    async answerAll(p, user, ansScale, sheetId) {
        const pin = await this._pin(user)
        const meta = await this.callG(p, user, 'health_scale_queryScaleInfo', {"scaleId": ansScale}, 'health-scale')
        const tenant = meta && meta.data ? meta.data.tenantUnid : null
        const total = meta && meta.data ? (meta.data.questionTotal || 30) : 30
        let answered = 0, lastQid = null
        for (let i = 0; i < total + 6; i++) {
            const q1 = await this.callG(p, user, 'health_scale_queryStartQuestionInfo', {"answerSheetId": sheetId, "scaleId": Number(ansScale), "userSourceId": pin, "tenantUnid": tenant, "appUnid": 'jd-health-scale'}, 'health-scale')
            const qd = (q1 || {}).data || {}
            if (!qd.questionId || qd.questionId === lastQid) break
            const opts = qd.questionOptionDTOs || []
            if (!opts.length) break
            const pick = opts[0]
            const d1 = await this.callG(p, user, 'health_scale_saveAnswerDraftInfo', {"answerSheetId": sheetId, "scaleId": Number(ansScale), "questionId": qd.questionId, "questionOptionDTOs": [{"id": pick.optionId, "value": pick.content, "type": 1, "optionId": pick.optionId, "content": pick.content}]}, 'health-scale')
            if (String((d1 || {}).code) !== '0000') { p.log('  草稿拒:', String((d1 || {}).msg || '').slice(0, 40)); this._fails++; break }
            lastQid = qd.questionId
            answered++
            await this.wait(300)
        }
        return answered
    }

    async main(p) {
        const user = p.data.user
        for (const P of POOLS) {
            p.log('== 池[' + P.name + '] activity=' + P.activityId)
            const pool = await this.callG(p, user, 'jdh_bff_queryTaskList', {"activityId": P.activityId, "appKey": P.appKey, "channel": 'jdhapp'}, 'JDHAPP')
            const groups = (pool || {}).result || []
            const todo = []
            for (const g of groups) {
                for (const t of g.taskVoList || []) {
                    if ((t.completeNum || 0) >= 1) { p.log('已完成:', t.mainTitle); await this.claimAward(p, user, P, t); continue }
                    const ju = t.jumpUrl || ''
                    const ms = ju.match(/scaleId=(\d+)/)
                    const mt = ju.match(/queryToken=([^&]+)/)
                    if (!ms || !mt || !t.id) { p.log('跳过(无scaleId/token,如AI拍照类):', t.mainTitle); continue }
                    todo.push({taskId: String(t.id), scaleId: ms[1], queryToken: mt[1], encodeId: t.encodeId, name: t.mainTitle})
                }
            }
            for (const t of todo) {
                p.log('做:', t.name, 'scale=' + t.scaleId)
                const meta = await this.callG(p, user, 'health_scale_queryScaleInfo', {"scaleId": t.scaleId}, 'health-scale')
                const tenant = meta && meta.data ? meta.data.tenantUnid : null
                if (!tenant) { p.log('  无tenant, 跳过'); this._fails++; continue }
                const sh = await this.getSheet(p, user, t.scaleId, tenant)
                if (!sh.sheetId) { p.log('  无答卷, 跳过'); this._fails++; await this.wait(3000); continue }
                if (!sh.submitted) {
                    const n = await this.answerAll(p, user, sh.ansScale, sh.sheetId)
                    p.log('  答题:', n, '题')
                    if (n <= 0) { this._fails++; await this.wait(3000); continue }
                    const sub = await this.callG(p, user, 'health_scale_submitAnswerSheet', {"answerSheetId": sh.sheetId, "scaleId": Number(sh.ansScale)}, 'health-scale')
                    p.log('  提交:', String((sub || {}).code), String((sub || {}).msg || '').slice(0, 24))
                    if (String((sub || {}).code) !== '0000') { this._fails++; await this.wait(3000); continue }
                } else {
                    p.log('  卷已提交过, 直接上报')
                }
                await this.wait(1500)
                const dt = await this.callG(p, user, 'jdh_msoa_doTaskGw', {"queryToken": t.queryToken, "scaleId": t.scaleId, "hy_entry": 'HSDJ_qiandao', "appKey": P.appKey, "channel": 'jdhapp', "taskId": t.taskId, "encodeId": t.encodeId, "infoId": String(sh.sheetId), "platform": 3}, 'laputa')
                const dv = dt && dt.result ? (dt.result.result || {}) : {}
                const biz = dv.bizCode ?? ''
                const ok = String(dv.msg || '').includes('完成') && [2, 4].includes(Number(biz))
                p.log('  上报:', String(dv.msg || '').slice(0, 50), 'biz=' + biz)
                if (!ok) this._fails++
                await this.wait(3000)
                const fresh = await this.callG(p, user, 'jdh_bff_queryTaskList', {"activityId": P.activityId, "appKey": P.appKey, "channel": 'jdhapp'}, 'JDHAPP')
                const fts = ((fresh || {}).result || []).flatMap(g => g.taskVoList || [])
                const ft = fts.find(x => String(x.id) === t.taskId)
                if (ft) await this.claimAward(p, user, P, ft)
            }
        }
        if (this._fails > 0) {
            p.log('存在 ' + this._fails + ' 个失败项, 本轮不写缓存')
            p.info.work = false
        } else {
            p.info.work = true
        }
    }

    // 领奖: sendAwardGw 对齐页面协议(extParam+platform); 8001=服务端发奖受限(状态3死态, doTask不可重报), 仅重试等放开
    async claimAward(p, user, P, t) {
        const st = Number(t.status)
        if (st === 4) { p.log('已领奖:', t.mainTitle); return }
        if ((t.completeNum || 0) < 1) return
        const aw = await this.callG(p, user, 'jdh_msoa_sendAwardGw', {"queryToken": t.queryToken, "appKey": P.appKey, "channel": 'jdhapp', "activityId": Number(P.activityId), "taskId": Number(t.id), "infoId": "", "extParam": {}, "platform": 3}, 'JDHAPP')
        const rv = aw && aw.result ? (aw.result.result || aw.result) : {}
        const msg = String(rv.mainTitle || rv.message || (aw && aw.result && aw.result.message) || '').slice(0, 40)
        const ok = String(rv.status) === '4' || msg.includes('恭喜')
        p.log(ok ? '领奖[OK]:' : '领奖[--]:', t.mainTitle, msg, ok ? '' : '(服务端发奖受限)')
    }
}
