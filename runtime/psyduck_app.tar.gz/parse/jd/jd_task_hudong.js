import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const HD_PAGE = 'https://prodev.m.jd.com/mall/active/index.html'
const HD_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
const HD_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
// eid_pair 双真 token (2026-10-20 运动馆/joyPark 验证: 空sdk=写接口403, android UA+双真token全通)
const HD_PAIR = '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东互动整合',
            crontab: 12,
            sync: 1,
            verify: ['linkId'],
            tempExpire: 3 * 86400,
            prompt: {
                id: "活动Id #url里的那部分id,暂只支持部分类型"
            },
            headers: {
                'x-rp-client': "h5_1.0.0",
                'request-from': 'native',
                referer: 'https://h5.m.jd.com/pb/015686010/Bc9WX7MpCW7nW9QjZ5N3fFeJXMH/index.html'
            }
        }
    }

    async prepare() {
        await this.field('id')
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(HD_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._hdCk()
    }
    _hdCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(HD_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    async hdCurl(opts) {
        const form = opts && opts.form
        if (!form) {
            const url = String((opts && opts.url) || (typeof opts === 'string' ? opts : ''))
            if (!url) return null
            return new Promise(resolve => {
                const rq = https.get(url, {headers: {'user-agent': HD_UA}}, rs => {
                    let d = ''
                    rs.on('data', c => d += c)
                    rs.on('end', () => resolve(d))
                })
                rq.on('error', () => resolve(null))
                rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            })
        }
        if (!this._hdSigner) {
            try { this._hdSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._hdSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        // android 页面形态注入: 双真 token + platform=3 (form 里已带的参数优先)
        let hdEid = '', hdSdk = ''
        try {
            const pt = fs.readFileSync(HD_PAIR, 'utf8')
            hdEid = (pt.match(/eid=(\S+)/) || ['', ''])[1]
            hdSdk = (pt.match(/sdk=(\S+)/) || ['', ''])[1]
        } catch (e) {}
        const curClient = getv('client') || 'ios'
        const curCV = getv('clientVersion') || '15.0.11'
        const base = {
            appid: getv('appid') || 'activities_platform',
            client: curClient, clientVersion: curCV,
            t: String(Date.now()), body, functionId: fn, networkType: 'wifi'
        }
        if (curClient !== 'ios') {
            // 非 ios client = android 形态请求, 补齐双 token 设备组 (缺 token 的写接口 403)
            const hdPage = (formStr.match(/pageUrl=([^&]*)/) || ['', encodeURIComponent(HD_PAGE)])[1]
            const ext = JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': hdEid, 'wg-sdk-token': hdSdk, pageUrl: hdPage})
            Object.assign(base, {
                platform: '3', loginType: '2', loginWQBiz: 'wegame',
                uuid: '3303461326131633-2313731633939346', build: '102649', screen: '360*800',
                d_brand: 'OnePlus', d_model: 'IN2010', lang: 'zh_CN', osVersion: '13', partner: 'oppo',
                'wg-sdk-token': hdSdk, ext, eufv: '1', eu: '3303461326131633', fv: '2313731633939346', cthr: '1'
            })
        }
        const signed = this._hdSigner.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || 'b4imf', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: HD_PAGE, referer: HD_PAGE,
                    'user-agent': HD_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    if (!d) { resolve({__httpStatus: rs.statusCode, __emptyBody: true}); return }
                    try { resolve(JSON.parse(d)) } catch (e) { resolve(d) }
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async batch(p) {
        p = await this.getTemp(p.pid) || p
        if (!p.linkId && !p.enAwardK) {
            let url = `https://prodev.m.jd.com/mall/active/${p.id}/index.html?utm_medium=tuiguang&tttparams=zZ1qguleyJnTGF0IjozOS45NjEwNTQsInVuX2FyZWEiOiIxXzI4MDBfNTU4MzhfMCIsImRMYXQiOiIiLCJwcnN0YXRlIjoiMCIsImFkZHJlc3NJZCI6IjUzODg3NDg3NyIsImxhdCI6IiIsInBvc0xhdCI6MzkuOTYxMDU0LCJwb3NMbmciOjExNi4zMjIwNjEsImdwc19hcmVhIjoiMF8wXzBfMCIsImxuZyI6IiIsInVlbXBzIjoiMC0wLTAiLCJnTG5nIjoxMTYuMzIyMDYxLCJtb2RlbCI6ImlQaG9uZTEzLDMiLCJkTG5nIjoiIn70=&utm_source=kong&cu=true`
            let html = await this.hdCurl(url)
            let mainJs = this.unique(this.matchAll(/src="(.*?\.js)"/g, html).filter(d => d.includes('main.')))
            let js = ''
            for (let j of mainJs) {
                js += await this.hdCurl({
                    url: j.includes('http') ? j : `https://${j}`
                })
            }
            let lids = this.unique(this.matchAll([/"linkId"\s*:\s*"([^\"]+)"/g, /"linkid"\s*:\s*"([^\"]+)"/g], html))
            if (html.includes('lottery-machine')) {
                for (let linkId of lids) {
                    let lottery = await this.hdCurl({
                            'url': `https://api.m.jd.com/api`,
                            'form': `functionId=lotteryMachineHome&body={"linkId":"${linkId}","taskId":"","inviter":""}&t=1713449252402&appid=activities_platform&client=ios&clientVersion=15.1.1&uuid=de21c6604748f97dd3977153e51a47f4efdb9a47&build=168960&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13%2C3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                            delay: 1,
                            algo: {
                                appId: "d7439",
                            }
                        }
                    )
                    if (this.haskey(lottery, 'data.prizeItems')) {
                        p.linkId = linkId
                        p.category = 'lotteryMachine'
                    }
                }
            }
            else if (js.includes('inviteFission')) {
                for (let linkId of lids) {
                    let pl = await this.hdCurl({
                            'url': `https://api.m.jd.com/api`,
                            form: `appid=activities_platform&body={"linkId":"${linkId}","taskId":"","inviter":""}&client=ios&clientVersion=12.3.4&functionId=inviteFissionBeforeHome&t=1718017177605&osVersion=16.2.1&build=169143&rfs=0000`,
                            algo: {
                                appId: '02f8d'
                            },
                        }
                    )
                    if (this.haskey(pl, 'data')) {
                        p.linkId = linkId
                        p.category = 'inviteFission'
                        break
                    }
                }
            }
            else if (js.includes('superLeague')) {
                for (let linkId of lids) {
                    let pl = await this.hdCurl({
                            'url': `https://api.m.jd.com/api`,
                            form: `appid=activities_platform&body={"linkId":"${linkId}","taskId":"","inviter":""}&client=ios&clientVersion=12.3.4&functionId=superLeagueHome&t=1718017177605&osVersion=16.2.1&build=169143&rfs=0000`,
                            algo: {
                                appId: 'b7d17'
                            },
                        }
                    )
                    if (this.haskey(pl, 'data')) {
                        p.linkId = linkId
                        p.category = 'superLeague'
                        break
                    }
                }
            }
            else if (js.includes('wheelsLottery')) {
                for (let linkId of lids) {
                    let pl = await this.hdCurl({
                            'url': `https://api.m.jd.com/api`,
                            'form': `functionId=wheelsHome&body={"linkId":"${linkId}","inviteActId":"","inviterEncryptPin":"","inviteCode":""}&t=1739590571889&appid=activities_platform&client=ios&clientVersion=15.0.15&cthr=1&loginType=&loginWQBiz=wegame`,
                            algo: {'appId': 'c06b7'},
                        }
                    )
                    if (this.haskey(pl, 'data')) {
                        p.linkId = linkId
                        p.category = 'wheels'
                        break
                    }
                }
            }
            else if (html.includes('enAwardK') && html.includes('encryptAssignmentId')) {
                p.encryptAssignmentId = this.match(/"encryptAssignmentId"\s*:\s*"(\w+)"/, html)
                p.enAwardK = this.match(/"enAwardK"\s*:\s*"([^\"]+)"/, html)
                p.mid = this.match(/"moduleId"\s*:\s*(\d+)/, html)
                p.aid = this.match(/"activityId"\s*:\s*"(\d+)"/, html)
                p.encryptProjectId = this.match(/"encryptProjectId"\s*:\s*"(\w+)"/, html)
                p.category = 'babelGet'
            }
            else if (lids) {
                for (let linkId of lids) {
                    let s = await this.hdCurl({
                            'url': `https://api.m.jd.com/api?functionId=apTaskList`,
                            'form': `functionId=apTaskList&body={"linkId":"${linkId}","queryType":0,"channel":4}&t=1748310951632&appid=activities_platform&client=ios&clientVersion=15.1.25`,
                            cookie: this.tester()
                        }
                    )
                    if (this.haskey(s, 'data.0')) {
                        p.category = 'apTask'
                        p.linkId = linkId
                    }
                }
            }
            else {
            }
        }
        return p
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        p.lottery = function(lottery) {
            let data = lottery.data
            let prizeType = data.prizeType || data.rewardType
            let amount = data.amount || data.rewardValue
            if (prizeType == 0) {
                p.log('没抽到奖品')
            }
            else if (prizeType == 1) {
                p.log('优惠券:', data.limitStr || data.codeDesc || data.prizeCode, data.prizeDesc || data.prizeName)
            }
            else if (prizeType == 2) {
                p.award(amount, 'redpacket')
            }
            else if (prizeType == 3) {
                p.award(amount, 'bean')
            }
            else if (prizeType == 5) {
                p.award(data.prizeDesc || data.prizeName || data.limitStr, 'reward')
            }
            else if (prizeType == 17) {
                p.log('谢谢参与')
            }
            else if (prizeType == 18) {
                p.log(`水滴: ${amount}`)
            }
            else if (prizeType == 22) {
                p.award(amount, 'card')
            }
            else if (prizeType == 24) {
                p.log('奖票:', data.prizeName)
            }
            else if (prizeType) {
                p.draw(`抽到类型: ${prizeType} ${data.limitStr || data.codeDesc || data.prizeCode} ${data.prizeDesc || data.prizeName}`)
            }
            else {
                p.log("什么也没有")
            }
        }
        await this.wait(3000)
        if (this[`_${context.category}`]) {
            try {
                await this[`_${context.category}`](p)
            } catch (e) {
                p.log(`[${context.category || '无分类'}] 活动异常: ` + String(e && e.message || e).slice(0, 80))
            }
        }
        else {
            p.log(`[${context.category || '无分类'}] 无处理方法, 跳过`)
            p.context.jump = true
        }
        if (p.prize.length) {
            p.prize.unshift(`linkId: ${context.linkId}`)
            p.msg(p.prize.join("\n"))
            p.prize = []
        }
    }

    async doTask(p) {
        let user = p.data.user;
        let context = p.context;
        let algo = context.algo || {}
        let apTask = await this.hdCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `functionId=apTaskList&body={"linkId":"${context.linkId}","channel":4}&t=1738479849113&appid=activities_platform&client=android&clientVersion=15.10.50`,
                user,
                algo
            }
        )
        if (!apTask) {
            return {
                finish: false
            }
        }
        let isOk = 1
        let userFinishedTimes
        // 池级熔断: 计时被服务端吞掉后, 后续 BROWSE 类任务同样会被吞, 直接跳过省得烧时间喂风控
        let browseFuse = false
        // 连续空响应计数: 高频连打触发限流吞包, 连续3次熔断本池
        let browseFail = 0
        for (let i of this.haskey(apTask, 'data')) {
            if (browseFuse && String(i.taskType).match("BROWSE")) {
                continue
            }
            if (i.taskLimitTimes == i.taskDoTimes) {
                p.log("任务已完成:", i.taskShowTitle)
            }
            else {
                isOk = 0
                p.log(`正在运行:`, i.taskTitle || i.subTitle, i.taskType)
                switch (i.taskType) {
                    case 'SUBSCRIBE':
                        let getSub = await this.hdCurl({
                                'form': `appid=MessageCenter&avifSupport=0&body={"subId":"${this.haskey(i, 'pipeExt.itemId')}"}&build=169896&client=apple&clientVersion=15.1.53&functionId=getSubContent`,
                                algo: {
                                    encrypt: true
                                },
                                user
                            }
                        )
                        let sub = await this.hdCurl({
                                'form': `functionId=querySubStatus&body={"subId":"${this.haskey(i, 'pipeExt.itemId')}"}&t=1750345993057&appid=activities_platform&client=ios&clientVersion=15.1.53&platform=3&loginType=2`,
                                user
                            }
                        )
                        let dt = await this.hdCurl({
                                'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1738480459228&appid=activities_platform&client=android&clientVersion=15.10.50&loginType=2&loginWQBiz=wegame`,
                                algo: {
                                    appId: '54ed7'
                                },
                                user
                            }
                        )
                        if (this.haskey(dt, 'data.userFinishedTimes')) {
                            p.log("任务完成")
                            let aw = await this.hdCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                    'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                    user,
                                    algo: {
                                        appId: 'f0f3f'
                                    }
                                }
                            )
                            if (this.haskey(aw, 'data.0')) {
                                for (let j of aw.data) {
                                    if (j.awardName == "BEAN") {
                                        p.award(j.awardGivenNumber, 'bean')
                                    }
                                    else if (j.awardName == "REDPACKET") {
                                        p.award(j.awardGivenNumber, 'redpacket')
                                    }
                                    else {
                                        p.log(j)
                                    }
                                }
                            }
                        }
                        break
                    case 'SIGN':
                        let sign = await this.hdCurl({
                                'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1738480459228&appid=activities_platform&client=android&clientVersion=15.10.50&loginType=2&loginWQBiz=wegame`,
                                algo: {
                                    appId: '54ed7'
                                },
                                user
                            }
                        )
                        if (this.haskey(sign, 'data.finished')) {
                            p.log("任务完成...")
                        }
                    case 'ORDER_MARK':
                    case 'SUBSCRIBE_WITH_RECEIVE':
                    case 'FOLLOW_CHANNEL':
                    case 'JOIN_BRAND':
                        break
                    case 'BROWSE_CHANNEL':
                    case  'BROWSE_PRODUCT':
                    case 'FOLLOW_SHOP':
                        // 「没有需要查询的计时任务」= apStartTaskTime 的计时被服务端吞了(风控), 等待与领奖全是白烧
                        var timerSwallowed = false
                        if (i.taskSourceUrl) {
                            var doTask = await this.hdCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                    'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"taskInsert":false,"itemId":"${encodeURIComponent(i.taskSourceUrl)}"}&t=1738480908001&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                    algo: {'appId': '54ed7'},
                                    user
                                }
                            )
                            if (this.haskey(doTask, 'success')) {
                                p.log("任务完成")
                            }
                            else if (this.haskey(doTask, "code", 2018)) {
                                let st = await this.hdCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                                        'form': `functionId=apStartTaskTime&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"taskInsert":false,"itemId":"${encodeURIComponent(i.taskSourceUrl)}"}&t=1748099560933&appid=activity_platform_se&client=ios&clientVersion=15.1.25`,
                                        user,
                                        algo: {
                                            appId: 'acb1e'
                                        }
                                    }
                                )
                                if (this.haskey(st, 'success') && st.data) {
                                    if (i.timeLimitPeriod) {
                                        p.log(`等待${context.timeLimitPeriod || i.timeLimitPeriod}秒...`)
                                        await this.wait((context.timeLimitPeriod || i.timeLimitPeriod) * 1000)
                                        let ltA = await this.hdCurl({
                                                'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                                'form': `functionId=apDoLimitTimeTask&body={"linkId":"1sPvvx2KAcIQ8otdQ_3pvQ"}&t=1748099576535&appid=activities_platform&client=ios&clientVersion=15.1.25&platform=3&loginType=2&loginWQBiz=wegame`,
                                                user,
                                                algo: {
                                                    appId: 'ebecc'
                                                }
                                            }
                                        )
                                        if (String(this.haskey(ltA, 'errMsg') || '').includes('没有需要查询的计时任务')) {
                                            p.log("服务端未记录计时, 浏览被风控吞了, 跳过该任务及后续浏览")
                                            timerSwallowed = true
                                            browseFuse = true
                                        }
                                    }
                                }
                            }
                            else {
                                const em = String(this.haskey(doTask, 'errMsg') || this.haskey(doTask, 'msg') || '')
                                if (!doTask || doTask.__emptyBody) {
                                    // HTTP 403=apsDoTask 写接口动态频控(累积触发有冷却期): 熔断本池等下轮
                                    browseFail++
                                    p.log(`任务失败: 空响应(HTTP ${doTask && doTask.__httpStatus || '?'})`)
                                    if (browseFail >= 3 || (doTask && doTask.__httpStatus === 403)) {
                                        p.log(`do 写接口频控冷却(HTTP 403), 本池浏览任务熔断 [linkId=${context.linkId}]`)
                                        browseFuse = true
                                    }
                                    await this.wait(5000)
                                }
                                else if (em) {
                                    browseFail = 0
                                    p.log("任务失败:", em)
                                }
                                else {
                                    browseFail = 0
                                    p.log("任务失败:", this.dumps(doTask).slice(0, 100))
                                }
                            }
                            if (i.canDrawAwardNum && !timerSwallowed) {
                                for (let kkk of Array(i.canDrawAwardNum)) {
                                    let award = await this.hdCurl({
                                            'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                            'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                            user,
                                            algo: {
                                                appId: 'f0f3f'
                                            }
                                        }
                                    )
                                    if (this.haskey(award, 'data')) {
                                        p.log(`抽奖次数+1`)
                                    }
                                    else {
                                        p.err("抽奖领取失败")
                                    }
                                    await this.wait(1000)
                                }
                            }
                        }
                        else {
                            let apTaskDetail = await this.hdCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apTaskDetail`,
                                    'form': `functionId=apTaskDetail&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1738480907628&appid=activities_platform&client=android&clientVersion=15.10.50&`,
                                    user,
                                    algo: {
                                        expire: {"code": 1000}
                                    }
                                }
                            )
                            let taskItemList = this.haskey(apTaskDetail, 'data.taskItemList')
                            if (taskItemList.length) {
                                for (let j in Array.from(Array(i.taskLimitTimes - i.taskDoTimes), (_val, index) => index)) {
                                    if (taskItemList[j] && taskItemList[j].itemId) {
                                        if (i.timeLimitPeriod) {
                                            let start = await this.hdCurl({
                                                    'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                                                    'form': `functionId=apStartTaskTime&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps({
                                                        ...i.pipeExt, ...taskItemList[j].pipeExt
                                                    })},"taskInsert":false,"itemId":"${encodeURIComponent(taskItemList[j].itemId)}"}&t=1738483884373&appid=activity_platform_se&client=android&clientVersion=15.10.50&platform=3&loginType=2&loginWQBiz=wegame`,
                                                    user,
                                                    algo: {
                                                        appId: 'acb1e'
                                                    }
                                                }
                                            )
                                            if (this.haskey(start, 'code', 1)) {
                                                p.log("计时受理被拒:", JSON.stringify(start).slice(0, 130))
                                                break
                                            }
                                            p.log(`等待${context.timeLimitPeriod || i.timeLimitPeriod}秒...`)
                                            await this.wait((context.timeLimitPeriod || i.timeLimitPeriod) * 1000)
                                            var doTask = await this.hdCurl({
                                                'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                                'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}"}&t=1738483906048&appid=activities_platform&client=android&clientVersion=15.10.50&platform=3&loginType=2&loginWQBiz=wegame`,
                                                user,
                                                algo: {
                                                    appId: 'ebecc'
                                                }
                                            })
                                        }
                                        else {
                                            var doTask = await this.hdCurl({
                                                    'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                                    'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps({
                                                        ...i.pipeExt, ...taskItemList[j].pipeExt
                                                    })},"taskInsert":false,"itemId":"${encodeURIComponent(taskItemList[j].itemId)}"}&t=1738480908001&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                                    algo: {'appId': '54ed7'},
                                                    user
                                                }
                                            )
                                        }
                                        if (this.haskey(doTask, 'success')) {
                                            p.log("任务完成", `[${parseInt(j) + 1}/${i.taskLimitTimes - i.taskDoTimes}]`)
                                        }
                                        else {
                                            let emB = String(this.haskey(doTask, 'errMsg') || this.haskey(doTask, 'msg') || '')
                                            if (!doTask || doTask.__emptyBody) {
                                                // HTTP 403=apsDoTask 写接口动态频控(累积触发有冷却期, 手动低频不受影响): 熔断本池等下轮
                                                browseFail++
                                                p.log(`任务失败: 空响应(HTTP ${doTask && doTask.__httpStatus || '?'})`)
                                                if (browseFail >= 3 || (doTask && doTask.__httpStatus === 403)) {
                                                    p.log(`do 写接口频控冷却(HTTP 403), 本池浏览任务熔断 [linkId=${context.linkId}]`)
                                                    browseFuse = true
                                                    break
                                                }
                                                await this.wait(5000)
                                            }
                                            else {
                                                browseFail = 0
                                                p.log("任务失败:", emB || this.dumps(doTask).slice(0, 100))
                                                // apDoLimitTimeTask 说没有计时任务 = 计时被风控吞了, 剩余次数全放弃, 别再烧时间喂风控
                                                if (emB.includes('没有需要查询的计时任务')) {
                                                    p.log("服务端未记录计时, 放弃该任务剩余浏览, 后续浏览任务跳过")
                                                    browseFuse = true
                                                    break
                                                }
                                            }
                                        }
                                        if (i.canDrawAwardNum) {
                                            for (let kkk of Array(i.canDrawAwardNum)) {
                                                let award = await this.hdCurl({
                                                        'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                        'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                                        user,
                                                        algo: {
                                                            appId: 'f0f3f'
                                                        }
                                                    }
                                                )
                                                if (this.haskey(award, 'data')) {
                                                    p.log(`抽奖次数+1`)
                                                }
                                                else {
                                                    p.err("抽奖领取失败")
                                                }
                                                await this.wait(1500)
                                            }
                                        }
                                        // 子项间隔: do 写接口有累积频控(403 冷却), 逐项留 6s 降触发概率
                                        await this.wait(6000)
                                    }
                                }
                            }
                            else if (this.haskey(apTaskDetail, 'data.status.userFinishedTimes', 0)) {
                                userFinishedTimes = true
                            }
                        }
                        break
                }
            }
        }
        if (!isOk) {
            isOk = 1
            apTask = await this.hdCurl({
                    'url': `https://api.m.jd.com/api`,
                    'form':
                        `functionId=apTaskList&body={"linkId":"${context.linkId}","channel":4}&t=1738479849113&appid=activities_platform&client=android&clientVersion=15.10.50`,
                    user
                }
            )
            for (let i of this.haskey(apTask, 'data')) {
                if (i.taskLimitTimes == i.taskDoTimes) {
                    if (i.canDrawAwardNum) {
                        for (let kkk of Array(i.canDrawAwardNum)) {
                            let award = await this.hdCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                    'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                    user,
                                    algo: {
                                        appId: 'f0f3f',
                                        expire: {
                                            code: 1000
                                        }
                                    }
                                }
                            )
                            if (this.haskey(award, 'data')) {
                                p.log(`抽奖次数+1`)
                            }
                            else {
                                if (i.subTitle && i.pipeExt) {
                                    let award = await this.hdCurl({
                                            'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                            'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1739360342034&appid=activities_platform&client=android&clientVersion=15.10.50`,
                                            user,
                                            algo: {
                                                appId: 'f0f3f'
                                            }
                                        }
                                    )
                                    if (this.haskey(award, 'data')) {
                                        for (let kk of award.data) {
                                            if (kk.awardTitle.includes("京豆")) {
                                                p.award(kk.awardGivenNumber, 'bean')
                                            }
                                            else {
                                                p.log(kk)
                                            }
                                        }
                                    }
                                    else {
                                        p.err("抽奖领取失败")
                                    }
                                }
                            }
                            await this.wait(1000)
                        }
                    }
                }
                else {
                    switch (i.taskType) {
                        case'ORDER_MARK':
                        case 'SHARE_INVITE':
                        case 'SUBSCRIBE_WITH_RECEIVE':
                        case 'JOIN_OTHER_ACT':
                        case 'FOLLOW_CHANNEL':
                        case 'JOIN_BRAND':
                        case 'FOLLOW_SHOP':
                            break
                        case  'BROWSE_CHANNEL':
                            isOk = userFinishedTimes ? 1 : 0
                            break
                        default:
                            isOk = 0
                            break
                    }
                }
            }
        }
        return {
            finish: isOk
        }
    }

    async _apTask(p) {
        let user = p.data.user;
        let context = p.context;
        let doIt = await this.doTask(p)
        if (doIt.finish) {
            p.info.work = true
        }
    }

    async _wheels(p) {
        let user = p.data.user;
        let context = p.context;
        let doIt = await this.doTask(p)
        let home = await this.hdCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `functionId=wheelsHome&body={"linkId":"${context.linkId}","inviteActId":"","inviterEncryptPin":"","inviteCode":""}&t=1739590571889&appid=activities_platform&client=ios&clientVersion=15.0.15&cthr=1&loginType=&loginWQBiz=wegame`,
                user,
                algo: {'appId': 'c06b7',},
            }
        )
        if (this.haskey(home, 'code', 12)) {
            p.context.finish = true
            await this.hsetTemp(context.pid, 'expired', true)
            return
        }
        let drawNum = this.haskey(home, 'data.lotteryChances') || 0
        p.log("可抽奖次数:", drawNum)
        for (let i of Array(drawNum)) {
            try {
                let lottery = await this.hdCurl({
                    url: 'https://api.m.jd.com/api',
                    form: `functionId=wheelsLottery&body={"linkId":"${context.linkId}"}&t=1739590600753&appid=activities_platform&client=ios&clientVersion=15.0.15&cthr=1&loginType=&loginWQBiz=wegame`,
                    algo: {
                        'appId': 'bd6c8',
                        expire: {
                            code: 1000
                        },
                        status: true
                    },
                    user
                })
                if (this.haskey(lottery, 'code', 4000)) {
                    p.log('抽奖机会用完啦')
                    break
                }
                if (this.haskey(lottery, 'data')) {
                    drawNum--
                    p.lottery(lottery)
                }
                else if (this.haskey(lottery, 'success')) {
                    drawNum--
                    p.log("啥也没有抽到")
                }
                else {
                    p.err("抽奖错误: " + JSON.stringify(lottery).slice(0, 120))
                    break
                }
                await this.wait(1500)
            } catch (e) {
                p.log(e)
            }
        }
        if (drawNum != 0) {
            home = await this.hdCurl({
                    'url': `https://api.m.jd.com/api`,
                    'form': `functionId=wheelsHome&body={"linkId":"${context.linkId}","inviteActId":"","inviterEncryptPin":"","inviteCode":""}&t=1739590571889&appid=activities_platform&client=ios&clientVersion=15.0.15&cthr=1&loginType=&loginWQBiz=wegame`,
                    user,
                    algo: {'appId': 'c06b7'},
                }
            )
            drawNum = this.haskey(home, 'data.lotteryChances')
        }
        if (doIt.finish && drawNum == 0 && home) {
            p.info.work = true
        }
    }

    async _inviteFission(p) {
        let user = p.data.user;
        let context = p.context;
        await this.hdCurl({
                'url': `http://api.m.jd.com/api`,
                form: `functionId=inviteFissionBeforeHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                user,
                algo: {
                    appId: '02f8d'
                }
            }
        )
        await this.hdCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `functionId=inviteFissionHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                user,
                algo: {'appId': 'eb67b', status: true},
            }
        )
        let doIt = await this.doTask(p)
        let home = await this.hdCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `functionId=inviteFissionHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                user,
                algo: {'appId': 'eb67b', status: true},
            }
        )
        if (this.haskey(home, 'code', 12)) {
            p.context.finish = true
            await this.hsetTemp(context.pid, 'expired', true)
            return
        }
        let drawNum = this.haskey(home, 'data.prizeNum') || 0
        p.log("可抽奖次数:", drawNum)
        for (let i of Array(drawNum)) {
            try {
                let lottery = await this.hdCurl({
                    url: 'https://api.m.jd.com/api',
                    form: `functionId=inviteFissionDrawPrize&body={"linkId":"${context.linkId}"}&t=1739359908592&appid=activities_platform&client=android&clientVersion=15.10.50&loginType=2&loginWQBiz=wegame`,
                    algo: {
                        'appId': 'c02c6',
                        expire: {
                            code: 1000
                        }
                    },
                    user
                })
                if (this.haskey(lottery, 'code', 18002)) {
                    p.log('抽奖机会用完啦')
                    break
                }
                if (this.haskey(lottery, 'data')) {
                    drawNum--
                    p.lottery(lottery)
                }
                else if (this.haskey(lottery, 'success')) {
                    drawNum--
                    p.log("啥也没有抽到")
                }
                else if (this.haskey(lottery, "code", 80202)) {
                    drawNum--
                    p.log("活动太火爆")
                }
                else {
                    p.err("抽奖错误")
                    break
                }
                await this.wait(1000)
            } catch (e) {
                p.log(e)
            }
        }
        if (drawNum != 0) {
            home = await this.hdCurl({
                    'url': `https://api.m.jd.com/api`,
                    'form': `functionId=inviteFissionHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                    user,
                    algo: {'appId': 'eb67b', status: true},
                }
            )
            drawNum = this.haskey(home, 'data.prizeNum')
        }
        if (doIt.finish && drawNum == 0 && home) {
            p.info.work = true
        }
    }

    async _superLeague(p) {
        let user = p.data.user;
        let context = p.context;
        let doIt = await this.doTask(p)
        let home = await this.hdCurl({
                'url': `https://api.m.jd.com/api?functionId=superLeagueHome`,
                'form': `functionId=superLeagueHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                user,
                algo: {'appId': 'b7d17', status: true},
            }
        )
        if (this.haskey(home, 'code', 12)) {
            p.context.finish = true
            await this.hsetTemp(context.pid, 'expired', true)
            return
        }
        let drawNum = this.haskey(home, 'data.remainTimes') || 0
        p.log("可抽奖次数:", drawNum)
        for (let i of Array(drawNum)) {
            try {
                let lottery = await this.hdCurl({
                    url: 'https://api.m.jd.com/api?functionId=superLeagueLottery',
                    form: `functionId=superLeagueLottery&body={"linkId":"${context.linkId}"}&t=1738481447131&appid=activities_platform&client=android&clientVersion=15.10.50`,
                    algo: {
                        'appId': '60dc4',
                        expire: {
                            code: 1000
                        }
                    },
                    user
                })
                if (this.haskey(lottery, 'code', 18002)) {
                    p.log('抽奖机会用完啦')
                    break
                }
                if (this.haskey(lottery, 'data')) {
                    drawNum--
                    p.lottery(lottery)
                }
                else if (this.haskey(lottery, 'success')) {
                    drawNum--
                    p.log("啥也没有抽到")
                }
                else {
                    p.err("抽奖错误")
                    break
                }
                await this.wait(1000)
            } catch (e) {
                p.log(e)
            }
        }
        if (drawNum != 0) {
            home = await this.hdCurl({
                    'url': `https://api.m.jd.com/api?functionId=superLeagueHome`,
                    'form': `functionId=superLeagueHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                    user,
                    algo: {'appId': 'b7d17'},
                }
            )
            drawNum = this.haskey(home, 'data.remainTimes')
        }
        if (doIt.finish && drawNum == 0 && home) {
            p.info.work = true
        }
    }

    async _lotteryMachine(p) {
        let user = p.data.user;
        let context = p.context;
        let doIt = await this.doTask(p)
        let home = await this.hdCurl({
                'url': `https://api.m.jd.com/api?functionId=lotteryMachineHome`,
                'form': `functionId=lotteryMachineHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                user,
                algo: {'appId': 'd7439'},
            }
        )
        if (this.haskey(home, 'code', 12)) {
            p.context.finish = true
            await this.hsetTemp(context.pid, 'expired', true)
            return
        }
        let drawNum = this.haskey(home, 'data.remainTimes') || 0
        // let num = drawNum>5 ? 6 : drawNum
        p.log("可抽奖次数:", drawNum)
        for (let i of Array(drawNum)) {
            try {
                let lottery = await this.hdCurl({
                    url: 'https://api.m.jd.com/api?functionId=lotteryMachineDraw',
                    form: `functionId=lotteryMachineDraw&body={"linkId":"${context.linkId}"}&t=1738481447131&appid=activities_platform&client=android&clientVersion=15.10.50`,
                    algo: {
                        'appId': 'd7439',
                        expire: {
                            code: 1000
                        },
                        status: true
                    },
                    user
                })
                if (this.haskey(lottery, 'code', 18002)) {
                    p.log('抽奖机会用完啦')
                    break
                }
                if (this.haskey(lottery, 'data')) {
                    drawNum--
                    p.lottery(lottery)
                }
                else if (this.haskey(lottery, 'success')) {
                    drawNum--
                    p.log("啥也没有抽到")
                }
                else {
                    p.err("抽奖错误")
                    break
                }
                await this.wait(1000)
            } catch (e) {
                p.log(e)
            }
        }
        if (drawNum != 0) {
            home = await this.hdCurl({
                    'url': `https://api.m.jd.com/api?functionId=lotteryMachineHome`,
                    'form': `functionId=lotteryMachineHome&body={"linkId":"${context.linkId}","taskId":"","inviter":""}&t=1738481450815&appid=activities_platform&client=android&clientVersion=15.10.50`,
                    user,
                    algo: {'appId': 'd7439'},
                }
            )
            drawNum = this.haskey(home, 'data.remainTimes')
        }
        if (doIt.finish && drawNum == 0 && home) {
            p.info.work = true
        }
    }

    async _babelGet(p) {
        let user = p.data.user;
        let context = p.context;
        while (true) {
            let lottery = await this.hdCurl({
                    'url': `https://api.m.jd.com/client.action?functionId=babelGetLottery`,
                    'form': `body=%7B%22enAwardK%22%3A%22${encodeURIComponent(context.enAwardK)}%22%2C%22awardSource%22%3A%221%22%2C%22srv%22%3A%22%7B%5C%22bord%5C%22%3A%5C%220%5C%22%2C%5C%22fno%5C%22%3A%5C%220-0-2%5C%22%2C%5C%22mid%5C%22%3A%5C%22${context.mid}%5C%22%2C%5C%22bi2%5C%22%3A%5C%222%5C%22%2C%5C%22bid%5C%22%3A%5C%220%5C%22%2C%5C%22aid%5C%22%3A%5C%22${context.aid}%5C%22%7D%22%2C%22encryptProjectId%22%3A%22${context.encryptProjectId}%22%2C%22encryptAssignmentId%22%3A%22${context.encryptAssignmentId}%22%2C%22authType%22%3A%222%22%7D&screen=1170*2259&client=wh5&clientVersion=15.1.1&appid=wh5&functionId=babelGetLottery`,
                    user,
                    algo: {
                        appId: '35fa0',
                        expire: {
                            "code": "3",
                        }
                    }
                }
            )
            let num = parseInt(this.haskey(lottery, 'chances') || 0)
            if (this.haskey(lottery, 'prizeType')) {
                if (lottery.prizeName.includes("京豆")) {
                    p.award(lottery.prizeName, 'bean')
                }
                else if (lottery.prizeName.includes("优惠券")) {
                    p.award(lottery.prizeName, 'coupon')
                }
                else {
                    p.log(lottery.prizeName)
                }
            }
            else {
                p.log(this.haskey(lottery, 'promptMsg') || lottery)
            }
            if (!num) {
                p.info.work = true
                break
            }
            await this.wait(1000)
        }
    }
}

