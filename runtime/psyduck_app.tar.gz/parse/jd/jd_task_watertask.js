import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/42HV4J3Q87B2xFQMJk81PCc1mEs3/index.html'
const LINKID = 'fWWo3YmB983abNOJPR7veg'
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '东东农场水滴限时任务', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _eid() {
        if (this._eidCache && Date.now() - this._eidAt < 600000) return this._eidCache
        for (const pt of ['/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', '/ql/data/psyduck/eid_pair.txt']) {
            try {
                const v = (fs.readFileSync(pt, 'utf8').match(/eid=(\S+)/) || ['', ''])[1]
                if (v) { this._eidCache = v; this._eidAt = Date.now(); return v }
            } catch (e) {}
        }
        return ''
    }

    // activities_platform 族请求: appid=activities_platform + 各函数独立签名域 (ebecc/acb1e/54ed7)
    async wg(p, user, fn, bodyObj, algo, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) return null
                const ck = this._ckForUser(user)
                if (!ck) return null
                const signed = this._wgSigner.sign({
                    functionId: fn, body: bodyObj, ck,
                    base: {appid: 'activities_platform', client: 'android', clientVersion: '15.10.50'},
                    appId: algo
                })
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('platform', '4')
                f.append('loginType', '2')
                f.append('loginWQBiz', '')
                f.append('uuid', '3303461326131633-2313731633939346')
                f.append('build', '102649')
                f.append('screen', '360*800')
                f.append('networkType', 'wifi')
                f.append('d_brand', 'OnePlus')
                f.append('d_model', 'IN2010')
                f.append('lang', 'zh_CN')
                f.append('osVersion', '13')
                f.append('partner', 'oppo')
                f.append('ext', '{"appType":"jdapp","systemType":"android"}')
                f.append('eufv', '1')
                f.append('eu', '3303461326131633')
                f.append('fv', '2313731633939346')
                f.append('cthr', '1')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    const rq = https.request({
                        hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                        headers: {
                            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'content-length': Buffer.byteLength(post), cookie: ck,
                            origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA
                        }
                    }, rs => {
                        let d = ''
                        rs.on('data', c => d += c)
                        rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
                    })
                    rq.on('error', () => resolve(null))
                    rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
                    rq.write(post); rq.end()
                })
                if (r) return r
                p.log(`${fn} 空响应, 第${k}次...`)
            } catch (e) {
                p.log(`${fn} 异常: ${String(e && e.message || e).slice(0, 120)}`)
            }
            await this.wait(3000 * k)
        }
        return null
    }

    async rawGet(p, user, url, referer) {
        if (!url) return
        try {
            for (let hop = 0; hop < 2 && url; hop++) {
                const out = await new Promise(resolve => {
                    const u = new URL(url)
                    const rq = https.request({
                        hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
                        headers: {cookie: this._ckForUser(user), 'user-agent': UA, referer: referer || W_PAGE, accept: 'text/html,*/*'}
                    }, rs => {
                        rs.resume()
                        rs.on('end', () => resolve({status: rs.statusCode, loc: rs.headers.location || ''}))
                    })
                    rq.on('error', () => resolve({status: 0, loc: ''}))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve({status: 0, loc: ''}) })
                    rq.end()
                })
                if (out.status === 302 && out.loc) { url = new URL(out.loc, url).href; referer = url } else { url = '' }
            }
        } catch (e) {}
    }

    async main(p) {
        let user = p.data.user
        const list = await this.wg(p, user, 'apTaskList', {linkId: LINKID, queryType: 0, channel: 4, area: '16-1315-0-0'}, 'ebecc', 2)
        const tasks = (list && list.data) || []
        if (!tasks.length) { p.log('无任务池:', JSON.stringify(list).slice(0, 150)); return }
        for (const t of tasks) {
            // 只做 EXTERNAL_BROWSE (可协议浏览); JOIN_OTHER_ACT 等需外部 App, 跳过
            if (t.taskType !== 'EXTERNAL_BROWSE') {
                p.log('跳过:', t.taskTitle || t.taskType, '(type=' + t.taskType + ')')
                continue
            }
            if (t.taskFinished) { p.log('已完成:', t.taskTitle || t.taskType); continue }
            const sub = (t.taskItemList || [])[0] || {}
            const itemId = sub.url || t.forwardUrl || ''
            const pe = t.pipeExt || {}
            p.log('做:', t.taskTitle || t.taskType, '| 奖:', (t.configBaseList || [])[0] ? (t.configBaseList[0].awardName + 'x' + t.configBaseList[0].awardGivenNumber) : '?')
            // 1 开始计时
            let r1 = await this.wg(p, user, 'apStartTaskTime', {linkId: LINKID, taskId: t.id, itemId: itemId, channel: 4, pipeExt: pe}, 'acb1e', 2)
            p.log('  计时:', JSON.stringify(r1).slice(0, 100))
            // 2 浏览落地页 + 停留
            await this.rawGet(p, user, itemId, W_PAGE)
            await this.wait(9000)
            // 3 完成任务
            let r2 = await this.wg(p, user, 'apsDoTask', {taskType: t.taskType, taskId: t.id, channel: 4, checkVersion: true, linkId: LINKID, pipeExt: pe, itemId: itemId}, '54ed7', 2)
            p.log('  完成:', JSON.stringify(r2).slice(0, 150))
            p.info.work = true
            await this.wait(5000)
        }
    }
}
