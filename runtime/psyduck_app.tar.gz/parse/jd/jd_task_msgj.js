import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/jpeZLX5Lb3gpwH98tAaB8Y1HY99/index.html'
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const APPID = 'plus_business'
const H5ST_APP = 'b63ff'
const RATE_CODES = ['1426', '1714002', '1711000']

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '秒杀天天刮京豆', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    // bff_rightsCenter 族 (2026-10-23 抓包实锤): appid=plus_business, h5st 域 b63ff, query 带 body
    async bffCurl(p, user, fn, bodyObj, appId) {
        if (!this._bffSigner) {
            try { this._bffSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        const ck = this._ckForUser(user)
        if (!ck || !this._bffSigner) { p.log('no ck/signer'); return null }
        if (appId) {
            if (!globalThis.__bffWarm) {
                try { this._bffSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: APPID}, appId}) } catch (e) {}
                await this.wait(3500)
                globalThis.__bffWarm = true
            }
        }
        const signed = this._bffSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: APPID, loginType: '2', loginWQBiz: '', scval: 'test01', xAPIClientLanguage: 'zh_CN', d_brand: 'OnePlus'},
            appId: appId || H5ST_APP
        })
        const qs = new URLSearchParams()
        for (const k of ['appid', 'functionId', 'body', 'loginType', 'loginWQBiz', 'scval', 'xAPIClientLanguage', 'd_brand', 'h5st']) qs.set(k, String(signed[k] ?? ''))
        const q = qs.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?' + q, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded', 'content-length': 0, cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: W_PAGE, 'x-rp-client': 'h5_2.4.0',
                    'x-referer-page': W_PAGE, 'x-babel-ihub': '00042291', mark: 'true', withCredentials: 'true', 'user-agent': UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.end()
        })
    }

    async rawGet(p, user, url) {
        if (!url) return
        try {
            const u = new URL(url)
            await new Promise(resolve => {
                const rq = https.request({hostname: u.hostname, path: u.pathname + u.search, method: 'GET', headers: {cookie: this._ckForUser(user), 'user-agent': UA, referer: W_PAGE, accept: 'text/html,*/*'}}, rs => {
                    rs.resume()
                    rs.on('end', () => resolve())
                })
                rq.on('error', () => resolve())
                rq.setTimeout(12000, () => { rq.destroy(); resolve() })
                rq.end()
            })
        } catch (e) {}
    }

    // 刮卡 (抓包实锤): actionType=100, itemId=为你推荐+ts, ext.jumpUrl 商品页
    async scratch(p, user, t) {
        const body = {
            scene: 'commonDoInteractiveAssignment', commonScene: 'secKillChannel', activityCode: 'newBeanTask',
            businessScenario: 'jingDouCenter', assignmentId: t.encryptAssignmentId, actionType: '100',
            itemId: '为你推荐' + Date.now(), ext: JSON.stringify({jumpUrl: 'http://item.jd.com/100012043978.html'})
        }
        const r = await this.bffCurl(p, user, 'bff_rightsCenter_interaction', body)
        if (!r) { p.log('  刮卡空响应:', t.assignmentName); return false }
        if (RATE_CODES.includes(String(r.code))) { p.log('  刮卡限流(' + r.code + '):', t.assignmentName); return false }
        const rw = r.rs && r.rs.rewardsInfo
        let prize = ''
        if (rw && rw.successRewards) {
            for (const k in rw.successRewards) {
                for (const it of (rw.successRewards[k] || [])) {
                    prize += (it.rewardName || it.prizeName || it.quantity || '') + 'x' + (it.beanNum || it.rewardValue || 1) + ' '
                }
            }
        }
        p.log('  刮卡:', t.assignmentName, '→', r.code, r.msg || '', prize ? '| 奖:' + prize : '')
        return String(r.code) === '0'
    }

    // 浏览任务: 受理(1) → GET 落地页 → 停留 → 完成(0)
    async doBrowse(p, user, t) {
        const id = t.encryptAssignmentId
        const ext = t.ext || {}
        let subs = []
        for (const k in ext) {
            if (Array.isArray(ext[k]) && ext[k].length && ext[k][0] && typeof ext[k][0] === 'object' && (ext[k][0].itemId || ext[k][0].toUrl)) { subs = ext[k]; break }
        }
        const s0 = subs[0] || {}
        let jumpUrl = s0.toUrl || s0.url || s0.jumpUrl || t.forwardUrl || ''
        let itemId = s0.itemId || t.assignmentFirstItemId || ('每日推荐' + Date.now())
        if (jumpUrl.includes('openapp.jdmobile')) {
            try { jumpUrl = JSON.parse(jumpUrl.split('params=')[1]).url || jumpUrl } catch (e) {}
        }
        const r1 = await this.bffCurl(p, user, 'bff_rightsCenter_interaction', {
            scene: 'commonDoInteractiveAssignment', commonScene: 'secKillChannel', activityCode: 'newBeanTask',
            businessScenario: 'jingDouCenter', assignmentId: id, actionType: '1', itemId, ext: JSON.stringify({jumpUrl})
        })
        if (!r1) { p.log('  受理空响应:', t.assignmentName); return }
        if (RATE_CODES.includes(String(r1.code))) { p.log('  受理限流(' + r1.code + '):', t.assignmentName); return }
        p.log('  受理:', r1.code, r1.msg || '')
        if (jumpUrl) await this.rawGet(p, user, jumpUrl)
        await this.wait(12000)
        const r0 = await this.bffCurl(p, user, 'bff_rightsCenter_interaction', {
            scene: 'commonDoInteractiveAssignment', commonScene: 'secKillChannel', activityCode: 'newBeanTask',
            businessScenario: 'jingDouCenter', assignmentId: id, actionType: '0', itemId
        })
        if (!r0) { p.log('  完成空响应:', t.assignmentName); this._fails = (this._fails || 0) + 1; return }
        if (RATE_CODES.includes(String(r0.code))) { p.log('  完成限流(' + r0.code + '):', t.assignmentName); this._fails = (this._fails || 0) + 1; return }
        const rw = r0.rs && r0.rs.rewardsInfo
        p.log('  完成:', r0.code, r0.msg || '', rw ? '| 得刮卡次数' : '')
        if (String(r0.code) === '0' || String(r0.code) === '103') {
            p.info.work = true
        } else {
            this._fails = (this._fails || 0) + 1
        }
    }

    async main(p) {
        let user = p.data.user
        const r = await this.bffCurl(p, user, 'bff_rightsCenter_jdInteractTask', {
            taskType: 'beanDailySign_newBeanTask', popFlag: '0', scene: 'jdInteractTask',
            commonScene: 'secKillChannel', needBeanSignStatus: '1', otherApis: []
        })
        if (!r) { p.log('任务列表空响应'); return }
        if (String(r.code) !== '1711000') { p.log('列表异常:', JSON.stringify(r).slice(0, 200)); return }
        const tasks = (r.rs && r.rs.beanTask && r.rs.beanTask.taskList) || []
        if (!tasks.length) { p.log('任务池空'); return }
        p.log('任务数:', tasks.length)
        let scratched = 0, done = 0, scratchFails = 0
        // 第一轮: 先刮所有可刮的卡 (canReceiveTimes>0)
        for (const t of tasks) {
            if (+t.canReceiveTimes > 0) {
                for (let i = 0; i < +t.canReceiveTimes; i++) {
                    if (await this.scratch(p, user, t)) scratched++
                    else scratchFails++
                    await this.wait(5000)
                }
            }
        }
        if (scratchFails) this._fails = (this._fails || 0) + scratchFails
        // 第二轮: 补完未完成浏览任务 (type 1)
        for (const t of tasks) {
            if (t.completionFlag) continue
            if (+t.assignmentType !== 1) { p.log('跳过(非浏览):', t.assignmentName || t.encryptAssignmentId); continue }
            if (+t.completionCnt >= +t.assignmentTimesLimit) continue
            await this.doBrowse(p, user, t)
            done++
            await this.wait(6000)
        }
        p.log(`本轮刮卡 ${scratched} 次, 补任务 ${done} 个`)
        if ((this._fails || 0) > 0) {
            p.log(`存在 ${this._fails} 个频控/失败项, 不写完成缓存, 下轮 cron 重试`)
            p.info.work = false
        }
    }
}
