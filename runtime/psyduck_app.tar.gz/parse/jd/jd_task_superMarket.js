import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东超市',
            crontab: 4,
            help: 'main'
        }
    }

    async prepare() {
        this.shareCode({
            id: '3nh7HzSjYemGqAHSbktTrf8rrH8M'
        })
        for (let user of this.help) {
            let itemId = await this.getTemp(user)
            if (itemId) {
                this.dict[user] = itemId
            }
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let status = 0
        let isOk
        await this.autoCurl({
                'url': `https://api.m.jd.com/atop_channel_newcomer_interactive_info`,
                'form': `appid=jd-super-market&t=1748874023489&functionId=atop_channel_newcomer_interactive_info&client=m&body={"babelChannel":"ttt32","isJdApp":"1","isWx":"0"}`,
                user,
                algo: {
                    appId: '35fa0',
                    refresh: true
                }
            }
        )
        let info = await this.autoCurl({
                'url': `https://api.m.jd.com/atop_channel_interactive_info`,
                'form': `appid=jd-super-market&t=1748855058331&functionId=atop_channel_interactive_info&client=m&body={"bizCode":"cn_retail_jdsupermarket","scenario":"sign","babelChannel":"ttt32","isJdApp":"1","isWx":"0"}`,
                user,
                algo: {
                    appId: '33c74'
                }
            }
        )
        let items = this.haskey(info, 'data.floorData.items')
        if (!items) {
            p.err("没有获取到数据")
        }
        for (let i of items) {
            status = 0
            if (i.completionFlag) {
                status = 1
                p.log(`任务已经完成: ${i.assignmentName}`)
                if (i.assignmentName.includes('邀请')) {
                    isOk = 1
                }
            }
            else {
                p.log(`正在运行: ${i.assignmentName}`)
                let extraType = i.ext.extraType
                if (i.assignmentName.includes('邀请')) {
                    status = 1
                    isOk = 0
                    if (this.haskey(i, 'ext.assistTaskDetail.itemId')) {
                        await this.setTemp(user, i.ext.assistTaskDetail.itemId, 86400000)
                    }
                    let users = Object.keys(this.dict)
                    if (users) {
                        let itemId = ''
                        let u = users[this.n % users.length]
                        this.n++
                        if (u == user) {
                            u = users[this.n % users.length]
                        }
                        itemId = this.dict[u]
                        let help = await this.autoCurl({
                                'form': `appid=jd-super-market&t=1742122986378&functionId=atop_channel_complete_task&client=m&body={"bizCode":"cn_retail_jdsupermarket","scenario":"sign","assignmentType":"${i.assignmentType}","encryptAssignmentId":"${i.encryptAssignmentId}","itemId":"${itemId}","assistFlag":true,"babelChannel":"ttt1","isJdApp":"0","isWx":"1"}`,
                                user,
                                algo: {
                                    appId: '51113'
                                }
                            }
                        )
                        let subCode = this.haskey(help, 'data.subCode')
                        if (subCode == '104') {
                            p.log("您已经助力过了")
                            isOk = 1
                        }
                        else if (subCode == '0') {
                            p.log("助力成功")
                            isOk = 1
                        }
                        if (subCode == '109') {
                            p.log("不能自己给自己助力")
                        }
                    }
                    else {
                        isOk = 1
                    }
                }
                else if (this.haskey(i, `ext.${i.ext.extraType}`)) {
                    let extra = i.ext[extraType]
                    try {
                        for (let j of extra.slice(0, i.assignmentTimesLimit)) {
                            if (['shoppingActivity', 'productsInfo', 'browseShop'].includes(extraType)) {
                                let d = await this.autoCurl({
                                        'form': `appid=jd-super-market&body=${this.dumps(
                                            {
                                                "bizCode": "cn_retail_jdsupermarket",
                                                "scenario": "sign",
                                                "assignmentType": i.assignmentType,
                                                "encryptAssignmentId": i.encryptAssignmentId,
                                                "itemId": j.itemId || j.advId,
                                                "actionType": 1,
                                                "babelChannel": "ttt1",
                                                "isJdApp": "0",
                                                "isWx": "1"
                                            }
                                        )}&sign=11&t=1653132222710&client=m&functionId=atop_channel_complete_task`,
                                        user,
                                        algo: {
                                            appId: '51113',
                                        }
                                    }
                                )
                                let msg = this.haskey(d, ['data.msg', 'message']) || "'"
                                p.log(msg)
                                if (msg.includes('火爆')) {
                                    return
                                }
                                await this.wait((i.ext.waitDuration || 0) * 1000 + 500)
                            }
                            let s = await this.autoCurl({
                                    'form': `appid=jd-super-market&body=${this.dumps(
                                        {
                                            "bizCode": "cn_retail_jdsupermarket",
                                            "scenario": "sign",
                                            "assignmentType": i.assignmentType,
                                            "encryptAssignmentId": i.encryptAssignmentId,
                                            "itemId": j.itemId || j.advId,
                                            "babelChannel": "ttt1",
                                            "isJdApp": "0",
                                            "isWx": "0"
                                        }
                                    )}&sign=11&t=1653132222710&client=m&functionId=atop_channel_complete_task`,
                                    user, algo: {
                                        appId: '51113',
                                    },
                                }
                            )
                            let message = this.haskey(s, ['data.msg', 'message']) || ""
                            p.log(i.assignmentName, this.haskey(s, 'data.msg') || this.haskey(s, 'message'))
                            if (this.haskey(s, 'message', '风险等级未通过')) {
                                return
                            }
                            if (message.includes("火爆")) {
                                break
                            }
                            if (this.haskey(s, 'data.doTaskRewardsInfo.successRewards')) {
                                for (let kkk in s.data.doTaskRewardsInfo.successRewards) {
                                    for (let kkkk of s.data.doTaskRewardsInfo.successRewards[kkk]) {
                                        p.log(`获得:`, kkkk.quantity, kkkk.rewardName)
                                    }
                                }
                                status = 1
                            }
                            await this.wait(1000)
                        }
                    } catch (e) {
                    }
                }
                else {
                }
            }
        }
        let calendar = await this.autoCurl({
                'url': `https://api.m.jd.com/atop_channel_sign_calendar`,
                'form': `appid=jd-super-market&t=1748931681904&functionId=atop_channel_sign_calendar&client=m&body={"bizCode":"cn_retail_jdsupermarket","scenario":"sign","babelChannel":"ttt32","isJdApp":"1","isWx":"0"}&clientVersion=15.1.50`,
                user
            }
        )
        if (this.haskey(calendar, 'data.floorData.items')) {
            for (let i of calendar.data.floorData.items) {
                if (i.signToken) {
                    let sign = await this.autoCurl({
                            'url': `https://api.m.jd.com/atop_channel_sign_in`,
                            'form': `appid=jd-super-market&t=1713230766545&functionId=atop_channel_sign_in&client=m&body={"signToken":"${i.signToken}","channelFollowStatus":1,"bizCode":"cn_retail_jdsupermarket","scenario":"sign","babelChannel":"ttt1","isJdApp":"1","isWx":"0"}`,
                            user,
                            algo: {
                                appId: 'b8fc7',
                                expire: {
                                    "code": "11001"
                                }
                            }
                        }
                    )
                    if (this.haskey(sign, 'success')) {
                        status = 1
                        p.log(`签到成功`)
                        for (let i of sign.data.rewards) {
                            p.log(`获得: ${i.rewardDesc}`)
                        }
                    }
                    else if (this.haskey(sign, "code", "14013")) {
                        p.log(`您今天已经签过到了`)
                        status = 1
                    }
                    else {
                        p.log(this.haskey(sign, 'message') || sign)
                    }
                }
            }
        }
        if (status) {
            p.info.work = true
        }
    }
}

