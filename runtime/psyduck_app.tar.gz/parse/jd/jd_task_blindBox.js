import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const PLUS_PAGE = 'https://plus.m.jd.com/'
const PLUS_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东PLUS会员天天开盲盒',
            crontab: 3
        }
    }

    async prepare() {
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _plusCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._plusCk()
    }
    // 框架curl链路对api.m.jd.com被风控空响应, 改 h5st 自签名直连 (同 joyPark/farmNew 模式)
    async plusCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._plusSigner) {
            try { this._plusSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._plusSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._plusSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'plus_business', client: 'android', clientVersion: '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: PLUS_PAGE, referer: PLUS_PAGE, 'user-agent': PLUS_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let plus = await this.plusCurl({
                'form': `appid=plus_business&functionId=bff_rights_points&body={"scene":"records","dataType":"index","page":1,"pageSize":10}&loginType=2`,
                user
            }
        )
        let rs = this.haskey(plus, 'rs') || {}
        if (rs.usedPoints + rs.balancePoints<6) {
            p.log("非plus会员,跳过运行...")
            p.info.work = true
            return
        }
        let list = await this.plusCurl({
                'form': `appid=plus_business&functionId=bff_marketing_interaction&body={"scene":"commonInteractiveInfo","activityCode":"blindBox","queryTypes":"2,3"}&loginType=2&xAPIClientLanguage=zh_CN`,
                user
            }
        )
        let info = this.haskey(list, 'rs.taskInfo')
        if (!this.haskey(info, 'assignmentList')) {
            let code = this.haskey(list, 'code') || this.haskey(list, 'rs.subCode') || ''
            p.err("没有获取到活动数据...", code ? `code=${code}` : '响应为空(风控/网络)', JSON.stringify(list).slice(0, 200))
            return
        }
        // getInfo 走框架数据层, 真机环境可能抛「接口数据变了」炸掉整个任务; eid 是可选参数, 失败留空
        let eid = ''
        try {
            let jsTk = await this.getInfo(user, 'jsTk') || {}
            eid = jsTk.eid || ''
        } catch (e) { }
        let isOk = true
        for (let i of info.assignmentList) {
            if (i.completionFlag) {
                p.log("任务已完成:", i.assignmentName)
            }
            else {
                p.log("正在运行:", i.assignmentName)
                let extraType = i.ext.extraType
                if (extraType) {
                    let extra = i.ext[extraType]
                    // console.log(extra)
                    if (['shoppingActivity', 'productsInfo', 'browseShop', 'addCart', 'followShop', 'followChannel'].includes(extraType)) {
                        if (!this.haskey(extra, '0.itemId')) {
                            continue
                        }
                        let doIt = await this.plusCurl({
                                'form': `appid=plus_business&functionId=bff_marketing_interaction&body={"scene":"commonDoInteractiveAssignment","activityCode":"blindBox","assignmentId":"${i.encryptAssignmentId}","actionType":"1","itemId":"${extra[0].itemId}"}&loginType=2&scval=test01&xAPIClientLanguage=zh_CN`,
                                user
                            }
                        )
                        if (this.haskey(doIt, 'code', '1')) {
                            if (i.ext.waitDuration) {
                                p.log("正在等待:", i.ext.waitDuration)
                                await this.wait(i.ext.waitDuration * 1000)
                            }
                            let reward = await this.plusCurl({
                                    'form': `appid=plus_business&functionId=bff_marketing_interaction&body={"scene":"commonDoInteractiveAssignment","activityCode":"blindBox","assignmentId":"${i.encryptAssignmentId}","actionType":"0","itemId":"${extra[0].itemId}"}&loginType=2&scval=test01&xAPIClientLanguage=zh_CN`,
                                    user
                                }
                            )
                            if (this.haskey(reward, 'code', '0')) {
                                p.log("任务完成")
                                let lottery = await this.plusCurl({
                                        'form': `appid=plus_business&functionId=bff_marketing_interaction_blindBox&body={"scene":"commonReceiveBlindBox","touchPoint":"purePlusIndex","eid":"${eid}","ext[sortCoupon]":"","ext[notFilterInvalidRights]":""}&loginType=2&xAPIClientLanguage=zh_CN`,
                                        user
                                    }
                                )
                                for (let i of this.haskey(lottery, 'rs.compInfoList')) {
                                    if (!this.haskey(i, 'data.rightResourceDetails')) {
                                        break
                                    }
                                    let detail = this.haskey(i, 'data.rightResourceDetails.0')
                                    if (detail.hongBaoInfo) {
                                        p.log("红包:", detail.hongBaoInfo)
                                    }
                                    if (detail.couponInfo) {
                                        p.log("优惠券:", detail.couponInfo.limitStr)
                                    }
                                    if (detail.beanInfo) {
                                        p.award(detail.beanInfo.beanNum, "bean",)
                                    }
                                }
                            }
                            else {
                                p.err("任务未完成:", reward)
                            }
                        }
                        else {
                            p.err("任务领取失败...")
                        }
                    }
                    else if (extraType == 'sign') {
                        let sign = await this.plusCurl({
                                'form': `appid=plus_business&functionId=bff_marketing_interaction&body={"scene":"commonDoInteractiveAssignment","activityCode":"blindBox","assignmentId":"${i.encryptAssignmentId}","itemId":"1"}&loginType=2&scval=test01&xAPIClientLanguage=zh_CN`,
                                user
                            }
                        )
                        if (this.haskey(sign, 'code', '0')) {
                            p.log("签到成功")
                            let lottery = await this.plusCurl({
                                    'form': `appid=plus_business&functionId=bff_marketing_interaction_blindBox&body={"scene":"commonReceiveBlindBox","touchPoint":"purePlusIndex","eid":"${eid}","ext[sortCoupon]":"","ext[notFilterInvalidRights]":""}&loginType=2&xAPIClientLanguage=zh_CN`,
                                    user
                                }
                            )
                            for (let i of this.haskey(lottery, 'rs.compInfoList')) {
                                if (!this.haskey(i, 'data.rightResourceDetails')) {
                                    break
                                }
                                let detail = this.haskey(i, 'data.rightResourceDetails.0')
                                if (detail.hongBaoInfo) {
                                    p.log("红包:", detail.hongBaoInfo)
                                }
                                if (detail.couponInfo) {
                                    p.log("优惠券:", detail.couponInfo.limitStr)
                                }
                                if (detail.beanInfo) {
                                    p.award(detail.beanInfo.beanNum, "bean",)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isOk) {
            p.info.work = true
        }
    }
}
