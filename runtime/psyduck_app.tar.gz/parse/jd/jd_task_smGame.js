import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东超市游戏',
            crontab: 4
        }
    }

    async prepare() {
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let temp = await this.autoCurl({
                'url': `https://api.m.jd.com/api/meta2GetRoomListByTemplateId`,
                'form': `appid=commonActivity&functionId=meta2GetRoomListByTemplateId&body={"templateId":"793888596"}&t=1713402796644`,
                user,
                algo: {
                    expire: {
                        'code': 201
                    }
                }
            }
        )
        let login = await this.autoCurl({
                'url': `https://api.m.jd.com/api/meta2LoginGame`,
                'form': `appid=commonActivity&functionId=meta2LoginGame&body={"channel":"2","roomId":"125"}&t=1713402797289`,
                user
            }
        )
        for (let i of Array(2)) {
            var getToken = await this.autoCurl({
                    'url': `https://api.m.jd.com/api/arvr_getRequestToken`,
                    'form': `appid=commonActivity&functionId=arvr_getRequestToken&body=${this.getBody({
                        "rewardType": 6,
                        "activityId": "ba6e852dd2bc05a1de75b2d2dc9fda305096bcc0",
                        "appId": "app_440",
                    })}&t=1713402797485`,
                    user
                }
            )
            if (this.haskey(getToken, 'data')) {
                break
            }
        }
        let accessToken = this.haskey(getToken, 'data')
        if (!accessToken) {
            p.err("获取accessToken失败...")
            return
        }
        // 奖项目-正式
        let info3 = await this.autoCurl({
                'url': `https://api.m.jd.com/api/arvr_queryInteractiveInfoNew`,
                'form': `appid=commonActivity&functionId=arvr_queryInteractiveInfoNew&body=${this.getBody({
                    "projectId": "2177780",
                    "projectKey": "2NjrCfgtPwoW8zjA7zjvKgvN3aSL",
                    "sourceCode": 5,
                    "channel": "2",
                    "queryTypes": 6,
                })}`,
                user
            }
        )
        if (this.haskey(info3, 'assignmentList.0.encryptAssignmentId')) {
            for (let i of Array(info3.assignmentList[0].assignmentTimesLimit - info3.assignmentList[0].completionCnt)) {
                let r = await this.autoCurl({
                        'url': `https://api.m.jd.com/api/arvr_rewardNew`,
                        'form': `appid=commonActivity&functionId=arvr_rewardNew&body=${this.getBody({
                            "projectId": "2177780",
                            "projectKey": "2NjrCfgtPwoW8zjA7zjvKgvN3aSL",
                            "sourceCode": 5,
                            "channel": "2",
                            "encryptAssignmentId": info3.assignmentList[0].encryptAssignmentId,
                            "completionFlag": true,
                            "rewardType": 1,
                        })}`,
                        user,
                        algo: {
                            appId: 'e3be6'
                        }
                    }
                )
                for (let g in this.haskey(r, 'rewardsInfo.successRewards')) {
                    let data = r.rewardsInfo.successRewards[g]
                    for (let k of data) {
                        p.log("抽奖获得:", k.rewardName)
                    }
                }
                await this.wait(1000)
            }
        }
        let info2 = await this.autoCurl({
                'url': `https://api.m.jd.com/api/arvr_queryInteractiveInfoNew`,
                'form': `appid=commonActivity&functionId=arvr_queryInteractiveInfoNew&body=${this.getBody({
                    "projectId": "1753589",
                    "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                    "sourceCode": 2,
                    "channel": "2",
                })}&t=1713402797485`,
                user
            }
        )
        for (let i of this.haskey(info2, 'assignmentList')) {
            if (i.completionFlag) {
                p.log(`任务已经完成: ${i.assignmentName}`)
            }
            else {
                p.log(`正在运行: ${i.assignmentName}`)
                let extraType = i.ext.extraType
                if ([7777].includes(i.assignmentType)) {
                    p.log("任务跳过")
                }
                else if (i.assignmentType == 9) {
                    p.log("正在分享...")
                    for (let __ of Array(3)) {
                        let s = await this.autoCurl({
                                'url': `https://api.m.jd.com/api/arvr_rewardNew`,
                                'form': `appid=commonActivity&functionId=arvr_rewardNew&body=${(await this.getBody(
                                    {
                                        "projectId": "1753589",
                                        "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                                        "sourceCode": 2,
                                        "channel": "2",
                                        "encryptAssignmentId": i.encryptAssignmentId,
                                        "completionFlag": true,
                                        "rewardType": 0,
                                    }
                                ))}&sign=11&t=1653132222710`,
                                user,
                                algo: {
                                    appId: 'e3be6'
                                }
                            }
                        )
                        p.log(this.haskey(s, 'msg'))
                        if (!this.haskey(s, 'assignmentInfo')) {
                            break
                        }
                        await this.wait(1000)
                    }
                }
                else if (this.haskey(i, `ext.${i.ext.extraType}`)) {
                    let extra = i.ext[extraType]
                    if (extraType == 'sign') {
                        let sign = await this.autoCurl({
                                'url': `https://api.m.jd.com/client.action?functionId=arvr_doInteractiveAssignmentNew`,
                                'form': `appid=commonActivity&body=${(await this.getBody(
                                    {
                                        "projectId": "1764671",
                                        "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                                        accessToken, "channel": "2",
                                        "sourceCode": 2,
                                        subTaskId: i.encryptAssignmentId,
                                        "completionFlag": true,
                                        "itemId": "1",
                                    }
                                ))}&sign=11&t=1653132222710`,
                                user,
                                algo: {
                                    appId: '84692'
                                }
                            }
                        )
                        p.log("签到:", this.haskey(sign, 'msg'))
                    }
                    else if (extraType == 'assistTaskDetail') {
                        let index = parseInt(p.index) + 1
                        for (let o of Array(i.assignmentTimesLimit)) {
                            for (let k of Array(0)) {
                                let assist = await this.autoCurl({
                                        'url': `https://api.m.jd.com/client.action?functionId=arvr_doInteractiveAssignmentNew`,
                                        'form': `appid=commonActivity&body=${(await this.getBody(
                                            {
                                                "projectId": "1764671",
                                                "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                                                accessToken, "channel": "2",
                                                "sourceCode": 2,
                                                subTaskId: i.encryptAssignmentId,
                                                "itemId": extra.itemId,
                                                "actionType": 0,
                                                "completionFlag": true,
                                                "ext": {
                                                    "assistEncryptAssignmentId": i.encryptAssignmentId,
                                                    "assistInfoFlag": 2,
                                                    "inviteId": ""
                                                },
                                            }
                                        ))}&sign=11&t=1653132222710`,
                                        user,
                                        algo: {
                                            appId: '84692'
                                        }
                                    }
                                )
                                index++
                                p.log(assist)
                                if (this.haskey(assist, 'msg', '任务完成')) {
                                    break
                                }
                            }
                        }
                    }
                    else {
                        try {
                            for (let j of extra.slice(0, i.assignmentTimesLimit)) {
                                if (['shoppingActivity', 'productsInfo', 'browseShop', 'brandMemberList'].includes(extraType)) {
                                    let d = await this.autoCurl({
                                            'url': `https://api.m.jd.com/client.action?functionId=arvr_doInteractiveAssignmentNew`,
                                            'form': `appid=commonActivity&body=${(await this.getBody(
                                                {
                                                    "projectId": "1764671",
                                                    "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                                                    accessToken, "channel": "2",
                                                    subTaskId: i.encryptAssignmentId,
                                                    "itemId": j.itemId || j.advId,
                                                    sourceCode: 2,
                                                    "actionType": 1,
                                                }
                                            ))}&sign=11&t=1653132222710`,
                                            user,
                                            algo: {
                                                appId: '84692'
                                            }
                                        }
                                    )
                                    await this.wait((i.ext.waitDuration || 0) * 1000 + 500)
                                    if (extraType == 'brandMemberList' && this.profile.openCard) {
                                        let jo = await this.autoCurl({
                                                'url': `https://api.m.jd.com/client.action`,
                                                'form': `functionId=bindWithVender&body={"venderId":"${j.vendorIds}","shopId":"${j.vendorIds}","bindByVerifyCodeFlag":1,"registerExtend":{},"writeChildFlag":0,"channel":4202,"appid":"27004","needSecurity":true,"bizId":"shopmember_m_jd_com"}&t=1715046616857&appid=shopmember_m_jd_com&clientVersion=9.2.0&client=H5&&x-api-eid-token=jdd03C3HUEKC6G2V5WV6SOXJV5E4J2ILKIIHLPARTU7DKUSMS72ICFUVMMF7ZVZXDON6VLTUCVU2GNZ2RZRMVIDXGF2FBMUAAAAMPKC6XVGYAAAAACHGDUSO4UHYMGEX`,
                                                user,
                                                algo: {
                                                    appId: '27004'
                                                }
                                            }
                                        )
                                        p.log('开卡', j.title, this.haskey(jo, 'message') || jo)
                                        await this.wait(1000)
                                    }
                                }
                                let s = await this.autoCurl({
                                        'url': `https://api.m.jd.com/client.action?functionId=arvr_doInteractiveAssignmentNew`,
                                        'form': `appid=commonActivity&body=${(await this.getBody(
                                            {
                                                "projectId": "1764671",
                                                "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                                                accessToken, "channel": "2",
                                                subTaskId: i.encryptAssignmentId,
                                                "itemId": j.itemId || j.advId,
                                                sourceCode: 2,
                                            }
                                        ))}&sign=11&t=1653132222710`,
                                        user,
                                        algo: {
                                            appId: '84692'
                                        }
                                    }
                                )
                                p.log(i.assignmentName, s.msg)
                                if (this.haskey(s, 'msg', '风险等级未通过')) {
                                    return
                                }
                                if (this.haskey(s, 'msg', '活动太火爆了')) {
                                    break
                                }
                                await this.wait(1000)
                            }
                        } catch (e) {
                        }
                    }
                }
                else if (i.assignmentName) {
                    let s = await this.autoCurl({
                            'url': `https://api.m.jd.com/client.action?functionId=arvr_doInteractiveAssignmentNew`,
                            'form': `appid=commonActivity&body=${(await this.getBody(
                                {
                                    "projectId": "1764671",
                                    "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                                    accessToken, "channel": "2",
                                    "sourceCode": 2,
                                    subTaskId: i.encryptAssignmentId,
                                    "completionFlag": true,
                                    "itemId": "1",
                                }
                            ))}&sign=11&t=1653132222710`,
                            user,
                            algo: {
                                appId: '84692'
                            }
                        }
                    )
                    p.log(i.assignmentName, s.msg)
                    await this.wait(1000)
                }
            }
        }
        let ri = await this.autoCurl({
                'url': `https://api.m.jd.com/api/arvr_queryInteractiveRewardInfo`,
                'form': `appid=commonActivity&functionId=arvr_queryInteractiveRewardInfo&body=${this.getBody({
                    "pageSize": 10,
                    "currentPage": 1,
                    "projectId": "1753589",
                    "projectKey": "4HT4fFeDbw11QaPmWvhdWctUQqn3",
                    "sourceCode": 2,
                    "needExchangeRestScore": 1
                })}`,
                user,
                algo: {appId: '84692'}
            }
        )
        var score = this.haskey(ri, 'scoreInfoMap.usable') || 0
        p.log("当前体力:", score)
        // 东东超市-汪贝任务
        let info1 = await this.autoCurl({
                'url': `https://api.m.jd.com/api/arvr_queryInteractiveInfoNew`,
                'form': `appid=commonActivity&functionId=arvr_queryInteractiveInfoNew&body=${this.getBody({
                    "projectId": "1764671",
                    "projectKey": "2nym8aW7jNKRbmxXLdbb75m3ebSH",
                    "sourceCode": 2,
                    "channel": "2",
                    "queryTypes": 6,
                })}&t=1713402797485`,
                user
            }
        )
        for (let i of this.haskey(info1, 'assignmentList')) {
            if (i.completionFlag) {
                p.log(`任务已经完成: ${i.assignmentName}`)
            }
            else {
                if (new Date(i.assignmentEndTime).getTime()>new Date().getTime() && i.assignmentName && this.match(/收银|解锁|升级|补货|离线/, i.assignmentName)) {
                    p.log(`正在运行: ${i.assignmentName}`)
                    if (score>=i.exchangeRate) {
                        let s = await this.autoCurl({
                                'url': `https://api.m.jd.com/client.action?functionId=arvr_doInteractiveAssignmentNew`,
                                'form': `appid=commonActivity&body=${(await this.getBody(
                                    {
                                        "projectId": "1764671",
                                        "projectKey": "2nym8aW7jNKRbmxXLdbb75m3ebSH",
                                        accessToken, "channel": "2",
                                        "sourceCode": 2,
                                        subTaskId: i.encryptAssignmentId,
                                        "completionFlag": true,
                                        "exchangeNum": "1",
                                    }
                                ))}&sign=11&t=1653132222710`,
                                user,
                                algo: {
                                    appId: '84692'
                                }
                            }
                        )
                        score = score - i.exchangeRate + (this.haskey(s, 'assignmentInfo.increUsedScore') || 0)
                        p.log("使用体力:", i.exchangeRate, s.msg, '当前体力:', score)
                        await this.wait(1000)
                    }
                    else {
                        p.log("体力不足...")
                        p.info.work = true
                    }
                }
            }
        }
    }

    getBody(params) {
        let str = "",
            map = Object.keys(params).sort(function(d, k) {
                return d.localeCompare(k);
            });
        for (let __i of map) {
            str = str.concat(params[__i]);
        }
        let t = Date.now();
        let r = "".concat("c4491f13dce9c71f").concat(str).concat(t);
        let md5 = this.md5(r)
        params.timestamp = t;
        params.sign = md5;
        params.signKey = "c4491f13dce9c71f";
        return this.dumps(params);
    }
}

