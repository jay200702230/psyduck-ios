import fs from 'fs'
import net from 'net'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const LK_FARM = 'fWWo3YmB983abNOJPR7veg'
const LK_HUB = 'Gd4HM9Vykj4F8eebabCw7g'
const PAGE = 'https://pro.m.jd.com/mall/active/42HV4J3Q87B2xFQMJk81PCc1mEs3/index.html'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';Mozilla/5.0 (Linux; Android 13; IN2010) AppleWebKit/537.36 Chrome/120.0.6099.188 Mobile Safari/537.36'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '农场游戏大厅', pageUrl: PAGE, headers: {referer: PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._acted = 0
    }

    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=')) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpc = await this._rpcCk()
        if (rpc && rpc.includes('pt_key=')) {
            const pinOf = ck => { try { const m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            const want = pinOf(base), got = pinOf(rpc)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpc
        }
        return base
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    async call(p, user, fn, bodyObj, appId, domain) {
        for (let k = 1; k <= 2; k++) {
            try {
                if (!this._signer) {
                    try { this._signer = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._signer) { p.log('no signer'); return null }
                const ck = await this._ckFull(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._signer.sign({functionId: fn, body: bodyObj, ck, base: {appid: appId, client: 'android', clientVersion: '15.10.50'}, appId: domain, slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('wqDefault', 'false')
                f.append('platform', '3')
                f.append('loginType', '2')
                f.append('loginWQBiz', 'wegame')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/client.action?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    async main(p) {
        const user = p.data.user
        // 1. 农场大厅签到 (weGameHome 730a6 同族, domain 101aa)
        const hm = await this.call(p, user, 'weGameHome', {version: 30, channelParam: '1', openPush: false, linkId: LK_HUB, supportPushFlag: 0}, 'wegame-hub', '101aa')
        const hd = (hm || {}).data || {}
        const btn = hd.buttonText || ((hd.signMainVo || {}).buttonText) || ''
        const signDays = hd.signDays || (hd.signMainVo || {}).signDays
        p.log('农场大厅:', btn, '| 连签', signDays, '天')
        // buttonText 含「明天/已」= 已领; 含「领/签」= 可领 → weGameLottery status:1
        if (/领奖励|签到/.test(btn) && !/明天|已/.test(btn)) {
            const lr = await this.call(p, user, 'weGameLottery', {envType: 1, linkId: LK_HUB, status: 1, markStr: ''}, 'wegame-hub', '730a6')
            p.log('大厅签到:', String((lr || {}).code), String((lr || {}).errMsg || '').slice(0, 40))
            if (String((lr || {}).code) === '0') this._acted++
            else if (String((lr || {}).code) !== '0') this._fails++
        }
        // 2. 农场任务面板 (apTaskListBatch)
        const bt = await this.call(p, user, 'apTaskListBatch', {version: 30, channelParam: '1', linkId: LK_FARM, modules: [{elementId: 'c927a4f5-59f7', taskStyle: 5}, {elementId: 'e033a10b-ae68', taskStyle: 5}]}, 'activities_platform', '2e349')
        const mods = (((bt || {}).data || {}).modules) || []
        for (const mo of mods) {
            for (const t of (mo.tasks || [])) {
                const nm = (t.taskShowTitle || t.taskTitle || '').slice(0, 20)
                if (t.taskFinished) { p.log('  已完成:', nm); continue }
                // ADD_WIDGET/小组件类跳过(需真实桌面组件)
                if (t.taskType === 'ADD_WIDGET') { p.log('  小组件类跳过:', nm); continue }
                // 浏览/进游类: apsDoTask 或 sendMarkInfo
                const aid = (t.pipeExt || {}).assignmentId
                const url = t.forwardUrl || t.taskSourceUrl || (t.taskItemList || [])[0]?.clickUrl || ''
                if (!aid) { p.log('  无aid跳过:', nm); continue }
                const mk = await this.call(p, user, 'apsDoTask', {taskType: t.taskType, taskId: t.id, channel: 4, checkVersion: true, linkId: LK_FARM, taskInsert: false, pingExt: t.pipeExt || {}, itemId: encodeURIComponent(url || 'https://pro.m.jd.com/')}, 'activities_platform', '2e349')
                const c1 = String((mk || {}).code) === '0' || (mk || {}).success
                p.log('  apsDoTask:', nm, '->', JSON.stringify(mk).slice(0, 100))
                if (c1) this._acted++
                else this._fails++
                await this.wait(4000)
                // 领奖
                const dw = await this.call(p, user, 'apTaskDrawAward', {taskType: t.taskType, taskId: t.id, channel: 4, checkVersion: true, linkId: LK_FARM, pipeExt: t.pipeExt || {}}, 'activities_platform', '2e349')
                p.log('  领奖:', String((dw || {}).code), JSON.stringify((dw || {}).data || {}).slice(0, 80))
                await this.wait(3000)
            }
        }
        p.log('农场游戏大厅: 动作', this._acted, '发, 失败', this._fails)
        p.info.work = this._fails === 0
    }
}
