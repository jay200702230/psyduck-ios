import fs from 'fs'
import path from 'path'
import net from 'net'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const PAGE = 'https://pro.m.jd.com/mall/active/2BGmkjr2mbi81R4ozsAR1ragZcyh/index.html?babelChannel=ttt333'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/;jdSupportDarkMode/0;lang/zh_CN;site/CN;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36'
const LBS = {viewStage: 'taskList', scene: 'jinquan', lat: '24.576403', lng: '118.230367', area: '16_1315_3486_59642', gcLat: '24.576403', gcLng: '118.230367', lbsParamMap: {svcType: 'lbs', lbsLng: '118.230367', lbsLat: '24.576403', provinceId: 16, cityId: 1315, countyId: 3486, townId: 59642}}
const UUID = '3303461326131633-2313731633939346'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '整点秒杀天天赚京豆', pageUrl: PAGE, headers: {referer: PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._h2s = null
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    // app 内 RPC cookie 通道(全量 19 字段含设备指纹)
    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpcCk = await this._rpcCk()
        if (rpcCk && rpcCk.includes('pt_key=')) {
            const pinOf = ck => { try { let m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            let want = pinOf(base)
            const got = pinOf(rpcCk)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpcCk
        }
        return base
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // sh_c 族(hourly-m, jinquan, 无签名门槛): query_task_list / do_task 两段式
    async callG(p, user, fn, bodyObj) {
        for (let k = 1; k <= 2; k++) {
            try {
                const ck = await this._ckFull(user)
                if (!ck) return null
                const f = new URLSearchParams()
                f.append('functionId', fn)
                f.append('body', JSON.stringify(bodyObj))
                f.append('appid', 'hourly-m')
                f.append('clientVersion', '15.10.50')
                f.append('uuid', UUID)
                f.append('openudid', UUID)
                f.append('client', 'android')
                f.append('loginType', '2')
                const post = f.toString()
                const s = this._h2()
                if (!s) return null
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/client.action?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
            } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
            await this.wait(3000 * k)
        }
        return null
    }

    async queryPool(p, user) {
        const r = await this.callG(p, user, 'sh_c_query_task_list', LBS)
        return r && r.code === 0 ? ((r.data || {}).taskList || []) : []
    }

    async doTask(p, user, extra) {
        const body = Object.assign({}, LBS, extra)
        const r = await this.callG(p, user, 'sh_c_do_task', body)
        const d = r && r.data ? r.data : {}
        return {sub: String(d.subCode ?? ''), msg: String(d.msg || '').slice(0, 40)}
    }

    async main(p) {
        const user = p.data.user
        for (let round = 0; round < 12; round++) {
            const pool = await this.queryPool(p, user)
            if (!pool.length) { p.log('秒杀池空或限流'); return }
            let acted = 0
            for (const t of pool) {
                const nm = t.assignmentName || '?'
                if (t.assignmentType !== 1) { p.log('跳过(非浏览):', nm, t.completionFlag ? 'done' : 'type' + t.assignmentType); continue }
                if (t.completionFlag) continue
                const ext = t.ext || {}
                const items = ext.shoppingActivity || ext.itemInfoList || []
                const it0 = items[0] || {}
                const itemId = it0.advId || it0.itemId || ''
                const jump = it0.url || ''
                if (!jump) { p.log('跳过(无jumpUrl):', nm); continue }
                const eid = t.encryptAssignmentId
                p.log('做:', nm, (t.completionCnt || 0) + '/' + (t.assignmentTimesLimit || 1))
                const s1 = await this.doTask(p, user, {actionType: 1, jumpUrl: jump, itemId, encryptAssignmentId: eid})
                if (s1.sub !== '1') { p.log('  [1]拒:', s1.sub, s1.msg); this._fails++; await this.wait(5000); continue }
                await this.wait(((ext.waitDuration || 5) + 6) * 1000)
                const s2 = await this.doTask(p, user, {actionType: 0, jumpUrl: jump, itemId, encryptAssignmentId: eid})
                if (s2.sub !== '0') { p.log('  [0]拒:', s2.sub, s2.msg); this._fails++; await this.wait(5000); continue }
                p.log('  完成')
                acted++
                await this.wait(3000)
            }
            if (!acted) break
        }
        const fin = await this.queryPool(p, user)
        const pend = fin.filter(t => t.assignmentType === 1 && !t.completionFlag).map(t => t.assignmentName)
        p.log(pend.length ? '未清浏览: ' + pend.join(',') : '秒杀浏览全清')
        if (this._fails > 0) {
            p.log('存在 ' + this._fails + ' 个失败项, 本轮不写缓存')
            p.info.work = false
        } else {
            p.info.work = true
        }
    }
}
