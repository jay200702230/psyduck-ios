import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东大牌集合任务',
            public: 'isv',
            sync: 1,
            prompt: {
                actId: '活动Id1|Id2',
            },
            verify: 1,
        }
    }

    async prepare() {
        await this.field('actId')
    }

    async fetchIsvToken(user) {
        // isvObfuscator 自签 (主包 SDK 同款): form 型 body=JSON, 带 pt_key 登录态
        const ck = this._ckForUser(user)
        if (!ck) return null
        const body = 'body=' + encodeURIComponent(JSON.stringify({
            url: 'https://jinggengjcq-isv.isvjcloud.com',
            id: 'wx_login_source',
            client: 'wxapp',
            wxappid: 'wx91d27dbf599dff74',
        }))
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'wxapplogin.m.jd.com',
                path: '/cgi-bin/login/isv/isvObfuscator',
                method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(body),
                    cookie: ck,
                    origin: 'https://pro.m.jd.com',
                    referer: 'https://pro.m.jd.com/',
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36',
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    try {
                        const j = JSON.parse(d)
                        resolve(j.token || null)
                    } catch (e) { resolve(null) }
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(body); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let isv = await p.getPublic('isv')
        if (!isv) {
            isv = await this.fetchIsvToken(user)
            if (isv) p.log('isvToken 自签成功')
        }
        if (isv) {
            for (let i of Array(2)) {
                var load = await this.autoCurl({
                        'url': `https://jinggengjcq-isv.isvjcloud.com/dm/front/jdJoinCardtf/activity/load?open_id=&mix_nick=&push_way=1&user_id=10299171`,
                        'json': {
                            "jsonRpc": "2.0",
                            "params": {
                                "commonParameter": {
                                    "oba": "259f36a73a857cfa37a7096fedb8bd60",
                                    "m": "POST",
                                    "timestamp": this.timestamp,
                                    "userId": 10299171,
                                },
                                "admJson": {
                                    "actId": p.context.actId,
                                    "userId": 10299171,
                                    "jdToken": isv,
                                    "source": "01",
                                    "method": "/openCardNew/activity_load",
                                    "buyerNick": ""
                                }
                            }
                        },
                        user
                    }
                )
                if (this.haskey(load, 'data.data.missionCustomer.buyerNick')) {
                    break
                }
                await this.wait(3000)
            }
            if (this.haskey(load, 'errorMessage', '获取京东用户信息失败~')) {
                p.log('获取京东用户信息失败~')
                return
            }
        }
        else {
            p.err('没有获取到isvToken')
        }
        let buyerNick = this.haskey(load, 'data.data.missionCustomer.buyerNick')
        if (buyerNick) {
            let missionCustome = load.data.data.missionCustomer
            let bean = 0
            let shopList = await this.autoCurl({
                    'url': `https://jinggengjcq-isv.isvjcloud.com/dm/front/jdJoinCardtf/shop/shopList?open_id=&mix_nick=${buyerNick}&push_way=1&user_id=10299171`,
                    json: {
                        "jsonRpc": "2.0",
                        "params": {
                            "commonParameter": {
                                "m": "POST",
                                "oba": "e4aae386ea7d1a32f77771570eea39cd",
                                "timestamp": this.timestamp,
                                "userId": 10299171
                            },
                            "admJson": {
                                "method": "/jdJoinCardtf/shop/shopList",
                                "userId": 10299171,
                                "actId": p.context.actId,
                                buyerNick,
                                "pushWay": 1
                            }
                        }
                    },
                    user
                }
            )
            for (let i of this.haskey(shopList, 'data.data')) {
                let goodsNumId = i.shopId
                p.log("正在浏览:", i.shopTitle)
                let s = await this.autoCurl({
                        'url': `https://jinggengjcq-isv.isvjcloud.com/dm/front/jdJoinCardtf/mission/completeMission?open_id=&mix_nick=${buyerNick}&push_way=1&user_id=10299171`,
                        json: {
                            "jsonRpc": "2.0",
                            "params": {
                                "commonParameter": {
                                    "m": "POST",
                                    "oba": "259f36a73a857cfa37a7096fedb8bd60",
                                    "timestamp": new Date().getTime(),
                                    "userId": 10299171
                                },
                                "admJson": {
                                    "missionType": "viewShop",
                                    "goodsNumId": goodsNumId,
                                    "method": "/jdJoinCardtf/mission/completeMission",
                                    "userId": 10299171,
                                    "actId": p.context.actId,
                                    buyerNick,
                                    "pushWay": 1
                                }
                            }
                        },
                        user
                    }
                )
                // console.log(this.dumps(s))
                let remark = this.haskey(s, 'data.data.remark') || ''
                if (this.haskey(s, 'data.data.sendStatus') == false) {
                    break
                }
                if (remark.includes("京豆")) {
                    p.award(remark, 'bean')
                }
                else {
                    p.log(remark)
                    if (this.dumps(s).includes("上限")) {
                        break
                    }
                }
                await this.wait(1000)
            }
            for (let _ of ['uniteAddCart', 'uniteCollectShop']) {
                if (_ == 'uniteAddCart' && missionCustome.hasAddCart) {
                    continue
                }
                else if (_ == 'uniteCollectShop' && missionCustome.hasCollectShop) {
                    continue
                }
                let collectShop = await this.autoCurl({
                        'url': `https://jinggengjcq-isv.isvjcloud.com/dm/front/jdJoinCardtf/mission/completeMission?open_id=&mix_nick=${buyerNick}&push_way=1&user_id=10299171`,
                        json: {
                            "jsonRpc": "2.0",
                            "params": {
                                "commonParameter": {
                                    "m": "POST",
                                    "oba": "b67770414453c05a26e57cde6ae600ab",
                                    "timestamp": new Date().getTime(),
                                    "userId": 10299171
                                },
                                "admJson": {
                                    "actId": p.context.actId,
                                    "missionType": _,
                                    "method": "/jdJoinCardtf/mission/completeMission",
                                    "userId": 10299171,
                                    buyerNick,
                                    "pushWay": 1
                                }
                            }
                        },
                        user
                    }
                )
                let remark = this.haskey(collectShop, 'data.data.remark') || ''
                p.log(remark)
                if (remark.includes("京豆")) {
                    p.award(remark, 'bean')
                }
                await this.wait(1000)
            }
            p.info.work = true
        }
        else {
            p.err("没有获取到buyerNickr")
        }
    }
}

