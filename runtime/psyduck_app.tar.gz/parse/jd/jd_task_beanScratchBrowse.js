import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const BSB_PAGE = 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1'
// App 容器形态 UA (2026-10-22 LSPosed 抓包实锤: 交互请求全部走 jdapp 容器 UA, ep 为本机加密设备指纹, ts 每次会话刷新)
const BSB_EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
// 本进程统一 UA: 请求头与 h5st env(navigator.userAgent) 必须同串; ep ts 进程级单例, 多模块共存时也保持同串
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const BSB_UA_ONE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/' + encodeURIComponent(BSB_EP.replace('"ts":0', '"ts":' + globalThis.__uaTs)) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = BSB_UA_ONE
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

// 前端(京豆频道 00041489 楼层)对齐的 timerId 广告浏览任务纯协议闭环:
// 受理(1, jumpUrl=sa.url) -> toUrl 解析真实落地页 -> GET 落地页 + click/exposal 打点
// -> 停 waitDuration -> 未入账则二次上报(0) -> 领奖(100)
async function rawGet(url, cookie, referer, harv) {
  // 302 跟一次 (lps.jd.com 偶发重定向, 断链会让行为流归因失效)
  let hops = 0, ref = referer
  while (url && hops < 2) {
    const out = await rawGet1(url, cookie, ref, harv)
    if (out.code === 302 && out.loc) {
      try { url = new URL(out.loc, url).href; ref = url; hops++; continue } catch (e) { return {code: 0, loc: '', body: ''} }
    }
    return out
  }
  return {code: 0, loc: '', body: ''}
}

function rawGet1(url, cookie, referer, harv) {
  return new Promise(resolve => {
    const u = new URL(url)
    const r = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
      headers: {
        'cookie': cookie,
        'user-agent': BSB_UA_ONE,
        'referer': referer || 'https://pro.m.jd.com/',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      }
    }, res => {
      if (harv) { try { harv(res) } catch (e) {} }
      let d = ''
      res.on('data', c => d += c)
      res.on('end', () => resolve({code: res.statusCode, loc: res.headers.location || '', body: d}))
    })
    r.on('error', e => resolve({code: 0, loc: '', body: ''}))
    r.end()
  })
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东刮卡timerId浏览任务',
            pageUrl: 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1',
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1'
            },
            turn: 1,
            crontab: 3
        }
        this.INI = (() => {
            for (const pt of ['/ql/data/psyduck/cookie/jd.ini', '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini']) {
                try { if (fs.existsSync(pt)) return pt } catch (e) {}
            }
            return '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini'
        })()
    }

    // 设备侧完整 cookie(落地页归因需要 App 指纹)
    deviceCookie() {
        try {
            let ini = fs.readFileSync(this.INI, 'utf8')
            return (ini.split(/\r?\n/).find(x => x.startsWith('guid=')) || '').trim()
        } catch (e) { return '' }
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _bsbCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        // ck_full 覆盖 (手动全量罐, 优先级最高): /ql/data/psyduck/ck_full/<pin>.txt
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._bsbCk()
    }

    // 设备身份 token (App 交互请求 form 尾必带, 2026-10-22 遥测实锤), 手机/青龙 双路径, 10分钟缓存
    _eid() {
        if (this._eidCache && Date.now() - this._eidAt < 600000) return this._eidCache
        for (const pt of ['/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', '/ql/data/psyduck/eid_pair.txt']) {
            try {
                const v = (fs.readFileSync(pt, 'utf8').match(/eid=(\S+)/) || ['', ''])[1]
                if (v) { this._eidCache = v; this._eidAt = Date.now(); return v }
            } catch (e) {}
        }
        return ''
    }

    // Set-Cookie 自攒罐 (2026-10-23 实锤: 完整指纹罐是交互风控通行证, 服务端下发必接回传)
    _jarPin(user) {
        const ck = this._ckForUser(user)
        const m = String(ck || '').match(/pt_pin=([^;\s]+)/)
        return m ? decodeURIComponent(m[1]) : String(user || 'main')
    }
    _jarLoad(pin) {
        if (this._jarLoaded === pin) return this._jarMap
        this._jarMap = new Map()
        try {
            for (const ln of fs.readFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', 'utf8').split(/\r?\n/)) {
                const kv = ln.trim()
                if (kv.includes('=')) this._jarMap.set(kv.split('=')[0], kv)
            }
        } catch (e) {}
        this._jarLoaded = pin
        return this._jarMap
    }
    _jarSave(pin) {
        try {
            fs.mkdirSync('/ql/data/psyduck/ck_jar', {recursive: true})
            fs.writeFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', [...this._jarMap.values()].join('\n') + '\n')
        } catch (e) {}
    }
    _ckFull(user) {
        const ck = this._ckForUser(user)
        const jar = this._jarLoad(this._jarPin(user))
        const have = new Set(String(ck).split(';').map(s => s.split('=')[0].trim()).filter(Boolean))
        const extra = [...jar.values()].filter(kv => !have.has(kv.split('=')[0]))
        return extra.length ? ck + ';' + extra.join(';') : ck
    }
    _jarHarvest(user, res) {
        const sc = res.headers['set-cookie']
        if (!sc || !sc.length) return
        const jar = this._jarLoad(this._jarPin(user))
        for (const c of sc) {
            const kv = String(c).split(';')[0]
            if (kv.includes('=') && /^[!-~]+=/i.test(kv)) jar.set(kv.split('=')[0], kv)
        }
        this._jarSave(this._jarPin(user))
    }
    // 框架curl链路对api.m.jd.com被风控, bff 请求改 h5st 自签名直连 (同 scratchBean 模式)
    async bsbCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._bsbSigner) {
            try { this._bsbSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._bsbSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const user = opts.user
        const ck = this._ckFull(user)
        if (!ck) return null
        const signed = this._bsbSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'plus_business', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        // App 实锤: 每次请求 form 尾部带设备身份凭证 x-api-eid-token (缺失 = 队列信任分垫底)
        const eid = this._eid()
        if (eid) f.append('x-api-eid-token', eid)
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性; mark/swimLane/headers 为 App 页面框架实锤头
                    origin: 'https://pro.m.jd.com', referer: BSB_PAGE, 'user-agent': BSB_UA_ONE,
                    'x-babel-ihub': '00041489', 'x-rp-client': 'h5_2.4.0',
                    'x-referer-page': 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html',
                    'mark': 'true', 'swimLane': 'undefined', 'headers': '[object Object]',
                    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Android WebView";v="120", "Dong WebView";v="2.1.62"',
                    'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform': '"Android"'
                }
            }, rs => {
                this._jarHarvest(user, rs)
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async fetchTasks(p, user) {
        let body = {
            taskType: 'beanDailySign_newBeanTask', popFlag: '0', scene: 'jdInteractTask',
            commonScene: 'beanChannel', needBeanSignStatus: '1', otherApis: []
        }
        for (let i = 1; i <= 4; i++) {
            let r = await this.bsbCurl({
                'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_jdInteractTask&scene=jdInteractTask`,
                'form': `appid=plus_business&functionId=bff_rightsCenter_jdInteractTask&body=${encodeURIComponent(this.dumps(body))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=OnePlus`,
                user, algo: {appId: 'b63ff'}
            })
            let tasks = this.haskey(r, 'rs.beanTask.taskList')
            if (tasks) return tasks
            let code = String(this.haskey(r, 'code') || '')
            if (code == '1714001' || code == '1714002') {
                p.log(`任务池限流(${code}), 第${i}次重试...`)
                await this.wait(9000 * i)
                continue
            }
            p.log('任务列表获取失败:', this.haskey(r, 'msg') || '')
            return null
        }
        return null
    }

    // 广告打点(im-x 曝光 / ccc-x 点击), 前端是裸 GET
    async dot(url) {
        if (!url) return
        try { await rawGet(url.replace('__POS_OFFSET__', '0'), this.deviceCookie(), 'https://pro.m.jd.com/') } catch (e) {}
    }

    // 受理响应 toUrl(openapp://virtual?params=) 解析: des=countdown 是 App 原生页(无 http 落地), 其余返回 taskUrl/url
    async resolveJump(rr, i) {
        let sa = this.haskey(i, 'ext.shoppingActivity.0') || {}
        let toUrl = this.haskey(rr, 'rs.assignmentInfo.toUrl') || ''
        let jump = ''
        let isNative = false
        if (/^openapp/i.test(toUrl)) {
            try {
                let obj = JSON.parse(decodeURIComponent(toUrl.split('?params=')[1] || ''))
                if (obj.des === 'countdown') isNative = true
                jump = obj.url || obj.taskUrl || ''
            } catch (e) {}
        }
        if (!jump) jump = sa.url || ''
        if (jump && sa.tasktoken && !jump.includes('tasktoken=')) {
            jump += (jump.includes('?') ? '&' : '?') + 'tasktoken=' + encodeURIComponent(sa.tasktoken) + '&mcInfo=' + encodeURIComponent(sa.mcInfo || '')
        }
        return isNative ? '' : jump
    }

    // 互动上报: atype 1=受理 0=浏览中续报 100=领奖
    async report(p, user, i, atype) {
        let ext = this.haskey(i, 'ext') || {}
        let sa = this.haskey(ext, 'shoppingActivity.0') || {}
        let body = {
            scene: 'commonDoInteractiveAssignment',
            activityCode: this.haskey(ext, 'taskType') || 'newBeanTask',
            businessScenario: 'jingDouCenter',
            assignmentId: i.encryptAssignmentId,
            actionType: atype,
            itemId: sa.itemId || this.haskey(ext, 'itemInfoList.0.itemId') || this.mkItemId(i, ext)
        }
        if (sa.url) body.ext = JSON.stringify({jumpUrl: sa.url})
        for (let k = 1; k <= 2; k++) {
            let r = await this.bsbCurl({
                'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_interaction&scene=commonDoInteractiveAssignment`,
                'form': `appid=plus_business&functionId=bff_rightsCenter_interaction&body=${encodeURIComponent(this.dumps(body))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=OnePlus`,
                user, algo: {appId: 'b63ff'}
            })
            let code = String(this.haskey(r, 'code') || '')
            if (['1426', '1714001', '1714002'].includes(code)) {
                // 频控: 只退避一次 15s, 密集磨蹭会加深惩罚 (2026-10-22 实测)
                p.log(`  上报${atype}限流${code}, 15s 后重试`)
                await this.wait(15000)
                continue
            }
            return r
        }
        return {}
    }

    // itemId 兜底: 楼层名+13位时间戳 (2026-10-22 手动抓包: 前端点击时动态生成)
    mkItemId(i, ext) {
        return String(i.assignmentName || i.encryptAssignmentId || '浏览').replace(/[\s:：,，]/g, '') + Date.now()
    }

    // timerId 广告浏览任务完整归因
    async doTimerBrowse(p, user, i) {
        let ext = this.haskey(i, 'ext') || {}
        // 1. 受理
        let rr = await this.report(p, user, i, '1')
        let code = String(this.haskey(rr, 'code') || '')
        if (!['0', '1', '2'].includes(code)) {
            p.log(`受理失败: ${i.assignmentName} code=${code} msg=${this.haskey(rr, 'msg') || ''}`)
            return false
        }
        // 2. 真实落地页(受理响应 toUrl 优先)
        let jump = await this.resolveJump(rr, i)
        if (jump && /^https?:/.test(jump)) {
            let g = await rawGet(jump, this._ckFull(user), 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1')
            p.log(`  落地页 http=${g.code} len=${(g.body || '').length}`)
        }
        // 3. click/exposal 打点
        await this.dot(this.haskey(ext, 'shoppingActivity.0.ext.click_url') || '')
        await this.dot(this.haskey(ext, 'shoppingActivity.0.ext.exposal_url') || '')
        // 4. 停留
        let wait = +(this.haskey(ext, 'waitDuration') || 6) + 3
        await this.wait(wait * 1000)
        // 5. 复查 -> 未入账二次上报(0)
        let fresh = (await this.fetchTasks(p, user) || []).find(x => x.encryptAssignmentId === i.encryptAssignmentId)
        if (!fresh) return false
        if (!fresh.completionFlag && +fresh.canReceiveTimes <= 0) {
            await this.report(p, user, fresh, '0')
            await this.wait(4000)
            fresh = (await this.fetchTasks(p, user) || []).find(x => x.encryptAssignmentId === i.encryptAssignmentId) || fresh
        }
        // 6. 领奖: 每完成1次 canReceiveTimes+1, 无需 completionFlag
        if (+fresh.canReceiveTimes > 0) {
            let r2 = await this.report(p, user, fresh, '100')
            let c2 = String(this.haskey(r2, 'code') || '')
            if (c2 == '1711000' || c2 == '0') {
                p.log('入账+领奖成功:', i.assignmentName, this.dumps(this.haskey(r2, 'rs.rewardsInfo') || {}).slice(0, 150))
                return true
            }
            p.log(`领奖失败: ${i.assignmentName} code=${c2} msg=${this.haskey(r2, 'msg') || ''}`)
        } else {
            p.log(`未入账: ${i.assignmentName} ${fresh.completionCnt}/${fresh.assignmentTimesLimit}`)
        }
        return false
    }

    async main(p) {
        let user = p.data.user
        // 2026-10-22 实测: weGameHome/heartbeat 是坏签名死重(青龙上恒 null)且喂频控, 全部拆除
        // 先访问任务页: 模拟 App webview 打开页面, Set-Cookie 回传养罐 (用户实锤方案)
        await rawGet(BSB_PAGE, this._ckFull(user), '', rs => this._jarHarvest(user, rs))
        for (let round = 1; round <= 3; round++) {
            let tasks = await this.fetchTasks(p, user)
            if (!tasks || !tasks.length) return
            let done = 0, left = 0
            for (const i of tasks) {
                if (!i.timerId) continue // 非 timerId 归 jd_task_beanBrowse
                if (i.completionFlag && +i.canReceiveTimes <= 0) continue
                if (+i.completionCnt >= +i.assignmentTimesLimit) continue
                if (i.completionFlag && +i.canReceiveTimes > 0) {
                    let ext = this.haskey(i, 'ext') || {}
                    let r = await this.report(p, user, i, '100')
                    let c = String(this.haskey(r, 'code') || '')
                    if (c == '1711000' || c == '0') p.log('补领:', i.assignmentName)
                    await this.wait(1500)
                    continue
                }
                let type = +i.assignmentType
                if ([1, 3, 4].includes(type)) {
                    p.log(`R${round} 做: ${i.assignmentName} (${i.completionCnt}/${i.assignmentTimesLimit})`)
                    if (await this.doTimerBrowse(p, user, i)) done++
                    else left++
                    await this.wait(2500)
                }
            }
            if (!done && round > 1) break
            if (done) await this.wait(3000)
        }
    }
}
