import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'

// 京东风控保活: 收割 x-rp-sdtoken 通行证回写 jd.ini; 探测 605 拦截与频控状态
// 原理: 服务端每个 api.m.jd.com 响应都带 x-rp-sdtoken(set;ttl;token), 真实页面由 babel-risk SDK 自动种 cookie,
//       脚本链路没人接这个头 -> sdtoken 缺失 -> 风险分升高. 本任务每 25min 续期一次.
const INI = '/data/data/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东风控保活(sdtoken续期)', prompt: {}, turn: 1, crontab: '*/25 * * * *'}
    }

    rawCall(fnId, appid, bodyObj, cookie) {
        const form = `functionId=${fnId}&appid=${appid}&client=ios&clientVersion=15.9.30&t=${Date.now()}&body=${encodeURIComponent(JSON.stringify(bodyObj))}`
        return new Promise(resolve => {
            const r = https.request({
                hostname: 'api.m.jd.com', path: '/api', method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded', 'content-length': Buffer.byteLength(form),
                    'cookie': cookie,
                    'user-agent': 'jdapp;iPhone;16.2.10;15.0.2;network/wifi;model/iPhone15,3;addressid/;supportApplePay/1;hasUPPay/0;pushNoticeIsOpen/1;hasOCPay/0;appBuild/168840;jdSupportDarkMode/0;Mozilla/5.0 (iPhone; CPU iPhone OS 15_0_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148;supportJDSHWK/1',
                    'referer': 'https://pro.m.jd.com/',
                    'x-referer-page': 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html',
                    'x-rp-client': 'h5_2.4.0'
                }
            }, res => {
                let d = ''
                res.on('data', c => d += c)
                res.on('end', () => resolve({headers: res.headers, body: d}))
            })
            r.on('error', e => resolve({headers: {}, body: JSON.stringify({err: e.message})}))
            r.setTimeout(15000, () => r.destroy(new Error('timeout')))
            r.write(form)
            r.end()
        })
    }

    async main(p) {
        let ini = fs.readFileSync(INI, 'utf8')
        let m = ini.match(/^(?:guid|pt_pin)=([^\r\n]+)/m)
        if (!m) { p.log('jd.ini cookie 行缺失'); return }
        let cookie = m[1].trim()

        // farm_home 只探风险不产生业务副作用(无权限也照样下发通行证)
        let r = await this.rawCall('farm_home', 'activities_platform', {version: 19}, cookie)

        let sd = r.headers['x-rp-sdtoken'] || ''
        let rpContent = r.headers['x-rp-content'] || ''
        if (rpContent) {
            try {
                let j = JSON.parse(Buffer.from(rpContent.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'))
                p.log(`风控拦截: code=${j.code} evType=${this.haskey(j, 'disposal.evType') || '?'}`)
            } catch (e) { p.log('x-rp-content 解码失败') }
        }

        if (/^set;/.test(sd)) {
            let token = sd.split(';')[2] || ''
            if (token) {
                // 2026-10-15: 新版 jd.ini 是 pt_pin=/pt_key= 开头, 旧正则只认 guid= 行 -> 追加静默失败
                let line = m[1]
                let newLine = /;sdtoken=/.test(line) ? line.replace(/;sdtoken=[^;]*/, ';sdtoken=' + token) : line + '; sdtoken=' + token
                let idx = ini.indexOf(line)
                if (idx >= 0) {
                    fs.writeFileSync(INI, ini.slice(0, idx) + newLine + ini.slice(idx + line.length))
                    p.log(`sdtoken 已续期(${Math.floor(token.length / 4) * 4}B, ttl=${sd.split(';')[1]}s)`)
                } else {
                    p.log('sdtoken 写入失败: 匹配行不在文件中')
                }
            }
        } else {
            p.log('响应未携带 x-rp-sdtoken: ' + (sd || 'none'))
        }

        // 顺带探测豆子接口状态
        let body = {taskType: 'beanDailySign_newBeanTask', popFlag: '0', scene: 'jdInteractTask', commonScene: 'beanChannel', needBeanSignStatus: '1', otherApis: []}
        let b = await this.rawCall('bff_rightsCenter_jdInteractTask', 'plus_business', body, cookie)
        p.log('豆子接口: ' + b.body.slice(0, 120).replace(/\s+/g, ' '))
        p.info.work = true
    }
}
