import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东月光宝盒',
            crontab: 2,
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/3MwGoRXcgfa3yFYKujMC2AsjmB3h/index.html'
            }
        }
    }

    async prepare() {
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let list = await this.autoCurl({
                'url': `https://api.m.jd.com/client.action?functionId=interact_executor`,
                'form': `functionId=interact_executor&appid=SecKillChannel&body={}&client=apple&clientVersion=15.5.15&d_model=iPhone13%2C3&d_brand=iPhone&model=iPhone13%2C3&osVersion=15.1.1&area=16_1342_1357_45750&channelCode=moonless&sceneCode=moonlight_box_task_list&mainChannel=&gps_area=16_1342_1357_45750&geoLng=117.543210&geoLat=23.987654&lng=117.543210&lat=23.987654&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&stk=appid,body,client,clientVersion,functionId`,
                user,
                algo: {
                    appId: "8b3f7",
                }
            }
        )
        let taskList = this.haskey(list, 'data.result.taskInfo.taskList')
        for (let i of taskList) {
            if (i.completionFlag) {
                p.log("任务已完成:", i.assignmentName)
            }
            else {
                if (['assistTaskDetail'].includes(i.ext.extraType)) {
                }
                else {
                    p.log("正在运行:", i.assignmentName)
                    let w = i.ext.waitDuration
                    let l = i.ext[i.ext.extraType]
                    if (!Array.isArray(l) || l.length === 0) {
                        p.log("跳过(暂无可用数据):", i.assignmentName)
                        continue
                    }
                    for (let j = i.completionCnt; j<i.assignmentTimesLimit; j++) {
                        let m = l[j]
                        if (!m) break
                        p.log("正在访问:", m.itemId)
                        let d = await this.autoCurl({
                                'url': `https://api.m.jd.com/client.action?functionId=interact_executor`,
                                'form': `functionId=interact_executor&appid=SecKillChannel&body={"itemId":"${m.itemId}","assignmentId":"${i.encryptAssignmentId}","jumpUrl":"${encodeURIComponent(m.url)}","actionType":1}&client=apple&clientVersion=15.5.15&d_model=iPhone13%2C3&d_brand=iPhone&model=iPhone13%2C3&osVersion=15.1.1&area=16_1342_1357_45750&channelCode=moonless&sceneCode=moonlight_box_do_task&mainChannel=&gps_area=16_1342_1357_45750&geoLng=117.543210&geoLat=23.987654&lng=117.543210&lat=23.987654&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&stk=appid,body,client,clientVersion,functionId`,
                                user,
                                algo: {
                                    appId: "8b3f7"
                                }
                            }
                        )
                        if (this.haskey(d, 'code', 0)) {
                            if (w) {
                                p.log("正在等待:", w)
                                await this.wait(w * 1000)
                            }
                            else {
                                await this.wait(1000)
                            }
                            let r = await this.autoCurl({
                                    'url': `https://api.m.jd.com/client.action?functionId=interact_executor`,
                                    'form': `functionId=interact_executor&appid=SecKillChannel&body={"itemId":"${m.itemId}","assignmentId":"${i.encryptAssignmentId}","actionType":0}&client=apple&clientVersion=15.5.15&d_model=iPhone13%2C3&d_brand=iPhone&model=iPhone13%2C3&osVersion=15.1.1&area=16_1342_1357_45750&channelCode=moonless&sceneCode=moonlight_box_do_task&mainChannel=&gps_area=16_1342_1357_45750&geoLng=117.543210&geoLat=23.987654&lng=117.543210&lat=23.987654&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&stk=appid,body,client,clientVersion,functionId`,
                                    user,
                                    algo: {
                                        appId: "8b3f7"
                                    }
                                }
                            )
                            if (this.haskey(r, 'code', 0)) {
                                p.log("任务完成")
                            }
                            else {
                                p.err("任务完成失败...")
                            }
                        }
                        else {
                            p.err("任务运行失败...", JSON.stringify(d).slice(0, 150))
                            break
                        }
                    }
                }
            }
        }
        // return
        let home = await this.autoCurl({
                'url': `https://api.m.jd.com/client.action?functionId=interact_executor`,
                'form': `functionId=interact_executor&appid=SecKillChannel&body={}&client=apple&clientVersion=15.5.15&d_model=iPhone13%2C3&d_brand=iPhone&model=iPhone13%2C3&osVersion=15.1.1&area=16_1342_1357_45750&channelCode=moonless&sceneCode=moonlight_box_home&mainChannel=&gps_area=16_1342_1357_45750&geoLng=117.543210&geoLat=23.987654&lng=117.543210&lat=23.987654&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&stk=appid,body,client,clientVersion,functionId`,
                user,
                algo: {
                    appId: "8b3f7"
                }
            }
        )
        let lotteryChances = this.haskey(home, 'data.result.lotteryChances')
        if (lotteryChances) {
            p.log("抽奖次数:", lotteryChances)
            for (let i of this.range(1, lotteryChances)) {
                p.log(`执行第${i}次抽奖...`)
                let d = await this.autoCurl({
                        'url': `https://api.m.jd.com/client.action?functionId=interact_executor`,
                        'form': `functionId=interact_executor&appid=SecKillChannel&body={}&client=apple&clientVersion=15.5.15&d_model=iPhone13%2C3&d_brand=iPhone&model=iPhone13%2C3&osVersion=15.1.1&area=16_1342_1357_45750&channelCode=moonless&sceneCode=moonlight_box_draw&mainChannel=&gps_area=16_1342_1357_45750&geoLng=117.543210&geoLat=23.987654&lng=117.543210&lat=23.987654&xAPIRegion=CN&xAPIClientLanguage=zh_CN&xAPIClientMode=0&xAPITz=Asia%2FShanghai&xAPICurrency=CNY&loginType=2&stk=appid,body,client,clientVersion,functionId`,
                        user,
                        algo: {
                            appId: "8b3f7"
                        }
                    }
                )
                if (this.haskey(d, 'data.result.assignmentResult.rewardsInfo.successRewards')) {
                    for (let i of Object.values(d.data.result.assignmentResult.rewardsInfo.successRewards)) {
                        for (let j of i) {
                            switch (j.rewardType) {
                                case 24:
                                    p.log(`获得: 宝物拼图 x ${j.total}`)
                                    break
                                case 4:
                                    p.award(j.discount, 'redpacket')
                                    break
                                case 8:
                                    p.log("获得: 优惠券")
                                    break
                                default:
                                    p.log(`获得: ${j.rewardName}`)
                                    break
                            }
                        }
                    }
                }
                await this.wait(2000)
            }
        }
        else {
            p.log("没有抽奖次数")
        }
        if (this.haskey(home, 'data.result')) {
            p.info.work = true
        }
    }
}
