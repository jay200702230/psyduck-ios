import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/3B6CgwugAyBR67P3MSNhykj5Eqyr/index.html?babelChannel=ttt11'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东校园签到', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // 校园族: 无签名裸接口, loginWQBiz=函数名
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const f = new URLSearchParams()
                f.append('appid', 'schoolChannelHome')
                f.append('functionId', fn)
                f.append('loginType', '2')
                f.append('loginWQBiz', fn)
                f.append('body', JSON.stringify(bodyObj))
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/client.action?functionId=' + fn + '&loginType=2&loginWQBiz=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(4000 * k)
        }
        return null
    }

    async load(p, user, rq, bc) {
        const r = await this.wg(p, user, 'campusTask_interact_load', {interactActId: '93', clientChannel: 0, requestType: rq, babelChannel: bc}, 2)
        return (r || {}).data || {}
    }

    async invoke(p, user, taskId, itemId, taskType, opt, bc) {
        const r = await this.wg(p, user, 'campusTask_interact_invoke', {interactActId: '93', taskId, itemId, optType: opt, taskType, clientChannel: 0, requestType: 1, babelChannel: bc}, 1)
        const code = String((r || {}).code || (r || {}).businessCode || '')
        const msg = String((r || {}).message || (r || {}).businessContext || '').slice(0, 30)
        const bean = (((r || {}).data || {}).rewardInfo || {}).rewardNum
        return {code, msg, bean, raw: r}
    }

    async main(p) {
        const user = p.data.user
        // 1) 签到池 ttt11
        const d = await this.load(p, user, 0, 'ttt11')
        if (!d || !d.signBeanModule) { p.log('校园 load 空'); p.info.work = true; return }
        const sign = d.signBeanModule
        let bean = ((sign.totalBean || {}).totalBeanNum) || '?'
        if (sign.todaySignStatus === 2) {
            p.log('今日已签, 连签', sign.continuousDays, '天, 豆包', bean)
        } else {
            const r = await this.invoke(p, user, sign.taskId, sign.itemId || '1', sign.taskType || 5, 1, 'ttt11')
            p.log('签到:', ['11000', '21001'].includes(r.code) ? 'OK ' + r.msg : '拒 ' + r.msg)
        }
        // 2) 浏览任务池 ttt113: 配额驱动 maxTimes/times; 同任务连续无进展3次熔断
        let total = 0
        let stall = 0
        let lastTimes = -1
        for (let round = 0; round < 20; round++) {
            const dl = await this.load(p, user, 1, 'ttt113')
            const seen = new Set()
            const jobs = []
            const walk = (o) => {
                if (!o || typeof o !== 'object') return
                if (Array.isArray(o)) { o.forEach(walk); return }
                if (o.taskId && o.taskType != null && o.taskType !== 5 && o.taskType !== 10234 && o.maxTimes) {
                    if (!seen.has(o.taskId)) { seen.add(o.taskId); jobs.push({n: o.taskName || o.taskId.slice(-6), id: o.taskId, it: o.itemId || '', max: o.maxTimes || 0, done: o.times || 0}) }
                }
                for (const k of Object.keys(o)) {
                    if (k === 'class') continue
                    walk(o[k])
                }
            }
            walk(dl)
            const todo = jobs.filter(t => t.done < t.max)
            if (!todo.length) { p.log('校园浏览任务全部达标'); break }
            const t = todo[0]
            if (t.done === lastTimes) {
                stall++
                if (stall >= 3) { p.log(t.n, '连续3轮无进展(' + t.done + '/' + t.max + '), 熔断'); break }
            } else {
                stall = 0
                lastTimes = t.done
            }
            const r1 = await this.invoke(p, user, t.id, t.it, 1, 1, 'ttt113')
            if (r1.code === '21003') { p.log(t.n, ': 今日上限'); continue }
            await this.wait(9500)
            await this.invoke(p, user, t.id, t.it, 1, 0, 'ttt113')
            await this.wait(3000)
            const r3 = await this.invoke(p, user, t.id, t.it, 1, 2, 'ttt113')
            if (r3.code === '21034') {
                total += Number(r3.bean || 1)
                p.log(t.n, ` [${t.done + 1}/${t.max}] +${r3.bean || 1}豆 (累计${total})`)
            } else if (r3.code === '21029') {
                p.log(t.n, ` [${t.done + 1}/${t.max}] 浏览校验未过(21029), 第${stall + 1}次`)
            } else {
                p.log(t.n, ` [${t.done + 1}/${t.max}] 奖 ${r3.code} ${r3.msg}`)
            }
            await this.wait(6000)
        }
        const d2 = await this.load(p, user, 0, 'ttt11')
        bean = d2 && d2.signBeanModule ? (((d2.signBeanModule.totalBean || {}).totalBeanNum) || '?') : '?'
        p.log('校园收工, 本轮', total, '豆, 豆包', bean)
        p.info.work = true
    }
}
