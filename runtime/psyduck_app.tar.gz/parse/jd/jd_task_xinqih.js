import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/4Va8jNzzHPqgTUhxwiTn9PHyVZCB/index.html?babelChannel=ttt163'
const CH = '8'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '新奇盲盒频道任务', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // Bigsale 族: common_task 引擎, h5st 域 7f3ea (2026-10-24 抓包实锤)
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                if (!this._wgSigner) {
                    try { this._wgSigner = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._wgSigner) { p.log('no signer'); return null }
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._wgSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'Bigsale', client: 'android', clientVersion: '15.10.50'}, appId: '7f3ea', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('platform', '3'); f.append('loginType', '2'); f.append('loginWQBiz', 'wegame')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(3000 * k)
        }
        return null
    }

    _biz(r) {
        if (!r) return null
        if (r.data && r.data.result && r.data.result.bizCode != null) return r.data.result.bizCode
        if (r.data && r.data.bizCode != null) return r.data.bizCode
        return r.code
    }

    itemsOf(t) {
        const ex = t.ext || {}
        return ex.shoppingActivity || ex.productsInfo || ex.followChannel || []
    }

    async main(p) {
        const user = p.data.user
        const getList = async () => {
            const r = await this.wg(p, user, 'common_task_list', {ext: {queryReceiveTimes: 1}, extMap: {sceneType: 2}, channelId: CH}, 2)
            return ((((r && r.data || {}).result || {}).taskInfo || {}).taskList) || []
        }
        for (let round = 0; round < 3; round++) {
            const tasks = await getList()
            if (!tasks.length) { p.log('任务池空或限流'); return }
            let acted = 0
            for (const t of tasks) {
                if (t.completionFlag) continue
                if (t.assignmentType !== 1 && t.assignmentType !== 3) continue
                const items = this.itemsOf(t)
                if (!items.length) continue
                const limit = t.assignmentTimesLimit > 0 ? t.assignmentTimesLimit : items.length
                const remain = limit - (t.completionCnt || 0)
                if (remain <= 0) continue
                p.log('做:', t.assignmentName, (t.completionCnt || 0) + '/' + limit)
                let doneFlag = true
                for (const it of items.slice(0, remain)) {
                    const itemId = it.itemId || it.skuId || it.id
                    const base = {channelId: CH, itemId: String(itemId), assignmentId: t.encryptAssignmentId}
                    const wd = ((t.ext || {}).waitDuration || 0)
                    // waitDuration>0 领取制任务: 领取必须带 ext.jumpUrl(浏览开始判定, 缺则完成步恒 110 浏览时间不足); -100 领取步为假失败(实际已领)继续走; 103=任务已完成幂等
                    if (wd > 0) {
                        const jump = it.url || it.jumpUrl || ''
                        const r1 = await this.wg(p, user, 'common_do_task', Object.assign({}, base, {actionType: 1, ext: jump ? {jumpUrl: jump} : {doReceiveRewards: null}}), 1)
                        const b1 = this._biz(r1)
                        if (b1 !== 0 && b1 !== 103 && ![-100, 107, 110, 31].includes(b1)) this._fails++
                        if (b1 === 31) { doneFlag = false; break }
                        await this.wait((wd + 6) * 1000)
                    } else {
                        await this.wait(3000)
                    }
                    const r2 = await this.wg(p, user, 'common_do_task', Object.assign({}, base, {actionType: 0, ext: {doReceiveRewards: null}}), 1)
                    const b2 = this._biz(r2)
                    if (b2 !== 0 && b2 !== 103 && ![-100, 107, 110, 31].includes(b2)) this._fails++
                    if (b2 === 31) { doneFlag = false; break }
                    if (b2 === 110) await this.wait(8000)
                    await this.wait(2500)
                    const r3 = await this.wg(p, user, 'common_do_task', Object.assign({}, base, {actionType: 0, ext: {doReceiveRewards: 1}}), 1)
                    const b3 = this._biz(r3)
                    if (b3 !== 0 && b3 !== 103 && ![-100, 107, 110, 31].includes(b3)) this._fails++
                    acted++
                    await this.wait(2500)
                    const fresh = (await getList()).find(x => x.encryptAssignmentId === t.encryptAssignmentId) || {}
                    if (fresh.completionFlag || (fresh.completionCnt || 0) >= limit) break
                }
                if (!doneFlag) { p.log('  限流, 本日放弃:', t.assignmentName); break }
            }
            if (!acted) { p.log('本轮无动作, 收工'); break }
        }
        const fin = await getList()
        let bad = 0
        for (const t of fin) {
            if (!t.completionFlag && (t.assignmentType === 1 || t.assignmentType === 3) && this.itemsOf(t).length) {
                p.log('未清:', t.assignmentName, (t.completionCnt || 0) + '/' + t.assignmentTimesLimit)
                bad++
            }
        }
        p.log(bad ? '剩余 ' + bad + ' 项(限流不可做, 已完结)' : '全部清完')
        p.info.work = true
    }
}
