import crypto from 'crypto'
import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/3skw64E2o8zoGcqm41gsewXHgdvR/index.html?babelChannel=ttt51&mTabId=8tHNdJLcqwqhkLNA8hqwNRaNu5f&linkTabId=219f9f6e86255a2f77e7d1dd88cc7cd9&embedMTab=1'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

const JX_KEY = 'xtl_sqg_mall-^&*-damai_(789)_@#$'
const CRAFT_ID = '6a66f5511177f59203da3347'
const AP_LINK_ID = '6l8gLCDM8lvssBmaBPCvzQ'
const AP_TASK_ID = 36159
const AP_ASSIGN_ID = '2AaWnCiRHua8FjG4HE2mz8LUUoHi'
const AP_ITEM_URL = 'https://pro.m.jd.com/mall/active/3skw64E2o8zoGcqm41gsewXHgdvR/index.html?babelChannel=ttt95&mTabId=8tHNdJLcqwqhkLNA8hqwNRaNu5f'
const FI_LINKS = ['6l8gLCDM8lvssBmaBPCvzQ', 'NSQSfVYLpEfSOmdbM1aByQ']

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: 'AI装备签到', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
    }

    _jxSign(body) {
        let t = ''
        for (const k of Object.keys(body).sort()) {
            let v = body[k]
            if (v instanceof Object) v = JSON.stringify(v)
            if (v === undefined || v === null) continue
            if (typeof v === 'string' && v === '') continue
            t += '&' + v
        }
        return crypto.createHmac('md5', JX_KEY).update(t.slice(1)).digest('hex')
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    _req(p, q, path_, headers, post, user) {
        return new Promise(resolve => {
            let done = false
            const fin = v => { if (!done) { done = true; resolve(v) } }
            const s = this._h2()
            if (!s) return fin(null)
            const ck = this._ckForUser(user)
            const h = Object.assign({':method': post ? 'POST' : 'GET', ':path': path_, 'user-agent': UA, cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0'}, headers || {})
            if (post) { h['content-type'] = 'application/x-www-form-urlencoded; charset=UTF-8'; h['content-length'] = String(Buffer.byteLength(post)) }
            let st = null
            try { st = s.request(h) } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
            let d = ''
            st.on('data', c => d += c)
            st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { if (q) p.log(q + ' raw: ' + d.slice(0, 200)); fin(null) } })
            st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
            if (post) st.end(post); else st.end()
            setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
        })
    }

    _qstr(o) {
        const f = new URLSearchParams()
        for (const k in o) f.append(k, String(o[k]))
        return f.toString()
    }

    async jx(p, user, fn, bodyObj) {
        const t = Date.now()
        const body = Object.assign({}, bodyObj, {sceneval: 2, buid: 325, appCode: 'ms1888ebbf', time: t, signStr: ''})
        body.signStr = this._jxSign(body)
        const qs = this._qstr({functionId: fn, appid: 'jx_h5_babel', t: t, channel: 'jxh5', clientVersion: '1.2.5', client: 'jxh5', uuid: '5858761804088816429', cthr: 1, loginType: 2, body: JSON.stringify(body)})
        const r = await this._req(p, fn, '/api?' + qs, {}, this._qstr({functionId: fn, appid: 'jx_h5_babel', t: t, channel: 'jxh5', clientVersion: '1.2.5', client: 'jxh5', uuid: '5858761804088816429', cthr: 1, loginType: 2, body: JSON.stringify(body)}), user)
        if (!r) { p.log(fn + ' 空响应'); return null }
        return r
    }

    async wg(p, user, fn, bodyObj) {
        const f = this._qstr({functionId: fn, body: JSON.stringify(bodyObj), t: Date.now(), appid: 'activities_platform', client: 'android', clientVersion: '15.10.50', platform: 3, loginType: 2, loginWQBiz: 'wegame', h5st: 'null'})
        return await this._req(p, fn, '/api?functionId=' + fn, {}, f, user)
    }

    async signedGet(p, user, fn, bodyObj) {
        try {
            if (!this._drSigner) {
                try { this._drSigner = await import('./jd_signer_node.mjs') } catch (e) {}
            }
            if (!this._drSigner) return null
            const ck = this._ckForUser(user)
            const signed = this._drSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'activities_platform', client: 'android', clientVersion: '15.10.50'}, appId: 'activities_platform', slim: true})
            const q = new URLSearchParams()
            for (const kk in signed) q.append(kk, String(signed[kk]))
            q.append('platform', '3'); q.append('loginType', '2'); q.append('loginWQBiz', 'wegame')
            return await this._req(p, fn, '/api?functionId=' + fn + '&' + q.toString(), {}, null, user)
        } catch (e) { return null }
    }

    async drawOnce(p, user, linkId) {
        return await this.signedGet(p, user, 'inviteFissionDrawPrize', {linkId, area: '0_0_0_0'})
    }

    async main(p, user) {
        const ck = this._ckForUser(user)
        if (!ck) { p.log('no ck, skip'); return }
        const pin = (ck.match(/pt_pin=([^;\s]+)/) || [])[1] || ''
        p.log('== ' + decodeURIComponent(pin))

        await this.doSign(p, user)
        await this.doTasks(p, user)
        await this.doBrowseDraw(p, user)
    }

    async doSign(p, user) {
        let r = await this.jx(p, user, 'jxzy_active_querySign', {source: 'jxzy', craftId: CRAFT_ID, tttId: 'ttt51'})
        if (!r) { p.log('签到查询失败'); return }
        p.log('querySign: ' + JSON.stringify(r).slice(0, 300))
        const d = r.data || r.result || {}
        const today = new Date().toISOString().slice(0, 10)
        const sl = Array.isArray(d.signList) ? d.signList.join(',') : ''
        if ((d.alreadySignDays || 0) > 0 && sl.includes(today) || String(d.status) === '2') { p.log(`签到: 今日已签 (${d.alreadySignDays}/${d.totalSignDays})`); return }
        const dr = await this.jx(p, user, 'jxzy_active_drawSign', {itemId: '1', craftId: CRAFT_ID, source: 'jxzy'})
        if (dr) {
            const dsj = JSON.stringify(dr)
            if (/已签到|无需重复/.test(dsj)) p.log('签到: 今日已签')
            else if (String(dr.code) === '0' || dr.success) p.log('签到: OK ' + dsj.slice(0, 200))
            else p.log('签到: 异常 ' + dsj.slice(0, 250))
        } else p.log('签到: drawSign 空响应')
    }

    async doTasks(p, user) {
        let r = await this.jx(p, user, 'jxzy_active_task_queryTaskList', {source: 'jxzy', craftId: CRAFT_ID, tttId: 'ttt51'})
        if (!r) { p.log('任务列表查询失败'); return }
        let d = r.data || r.result || {}
        let list = d.taskInfoList || []
        if (!Array.isArray(list)) { p.log('taskInfoList 异常 raw: ' + JSON.stringify(r).slice(0, 400)); return }
        for (const t of list) {
            const title = t.taskName || '?'
            const tt = t.taskType
            const st = String(t.taskStatus)
            const prog = t.taskProgress || {}
            if (t.showTask === 0) continue
            if (String(st) !== '1') { p.log(`[${title}] status=${st} 跳过`); continue }
            if (tt === 1) { p.log(`[${title}] 助力型, 跳过`); continue }
            const tid = t.taskId
            const iid = prog.itemId || (t.extInfo || {}).itemId
            if (!tid || !iid) { p.log(`[${title}] 无 taskId/itemId, 跳过`); continue }
            const rounds = Math.max(1, (parseInt(prog.total) || 1) - (parseInt(prog.current) || 0))
            for (let k = 1; k <= Math.min(rounds, 10); k++) {
                const c = await this.jx(p, user, 'jxzy_active_task_completeTask', {craftId: CRAFT_ID, taskId: tid, itemId: String(iid), taskType: tt})
                const cj = JSON.stringify(c || {})
                if (!c) { p.log(`[${title}] complete 空响应`); break }
                await this.wait(14000)
                const rw = await this.jx(p, user, 'jxzy_active_task_rewardTask', {craftId: CRAFT_ID, taskId: tid, itemId: String(iid), taskType: tt})
                const rj = JSON.stringify(rw || {})
                p.log(`[${title}] 第${k}次 complete:${cj.slice(0, 120)} reward:${rj.slice(0, 180)}`)
                if (/已|完成|max|limit|not/i.test(rj) && !/success/i.test(rj)) break
                await this.wait(2500)
            }
        }
    }

    async doBrowseDraw(p, user) {
        const pipe = {taskType: 'BROWSE_CHANNEL', timeLimitSwitch: 1, assignmentId: AP_ASSIGN_ID}
        let r1 = await this.wg(p, user, 'apStartTaskTime', {linkId: AP_LINK_ID, taskId: AP_TASK_ID, itemId: AP_ITEM_URL, taskInsert: false, channel: 4, pipeExt: pipe, actFlowCode: 'apStartTaskTime'})
        const c1 = String((r1 || {}).code)
        if (c1 === '0') {
            p.log('apStartTaskTime: OK, 等 15s 浏览...')
            await this.wait(15000)
            let r2 = await this.wg(p, user, 'apDoLimitTimeTask', {linkId: AP_LINK_ID})
            p.log('apDoLimitTimeTask: ' + JSON.stringify(r2).slice(0, 150))
        } else {
            p.log('apStartTaskTime code=' + c1 + ' (今日浏览任务已完结, 跳过)')
        }
        for (const lk of FI_LINKS) {
            let home = await this.signedGet(p, user, 'inviteFissionHome', {linkId: lk, inviter: ''})
            let times = (((home || {}).data || {}).prizeNum) || (((home || {}).data || {}).lotteryTimes) || 0
            p.log(`fission ${lk.slice(0, 6)}... 可抽次数=${times}`)
            let n = 0
            while (times > 0 && n < 8) {
                const dr = await this.drawOnce(p, user, lk)
                const dj = JSON.stringify(dr || {})
                p.log('抽奖: ' + dj.slice(0, 220))
                times--
                n++
                await this.wait(2500)
                const pol = await this.signedGet(p, user, 'inviteFissionPoll', {linkId: lk, type: 2})
                times = (((pol || {}).data || {}).lotteryTimes) || 0
                if (!times) break
            }
        }
    }
}
