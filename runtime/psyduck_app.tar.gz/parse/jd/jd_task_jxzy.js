import https from 'https'
import crypto from 'crypto'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/2iqSwv1JiDHxAkHAikfU6XAECFmo/index.html'
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const CRAFT = '6824629a7c46584759d39b78'
const SIGN_KEY = 'xtl_sqg_mall-^&*-damai_(789)_@#$'
const UUID = 'd805fadf-537c-2b3e-ba15-c0c58de0e924d762'

// signStr 生成 (jxzy 楼层 JS 逆向实锤): key 排序 → &value 拼接(对象stringify/空值跳过) → HMAC-MD5(盐)
function makeSignStr(bodyObj) {
    const obj = JSON.parse(JSON.stringify(bodyObj))
    const keys = Object.keys(obj).sort()
    const parts = []
    for (const k of keys) {
        let v = obj[k]
        if (v instanceof Object) v = JSON.stringify(v)
        if (v === null || v === undefined || v === '') continue
        parts.push(String(v))
    }
    return crypto.createHmac('md5', SIGN_KEY).update(parts.join('&')).digest('hex')
}

function baseBody(extra) {
    const body = Object.assign({
        sceneval: 2, buid: 325, appCode: 'ms1888ebbf', time: Date.now()
    }, extra)
    body.signStr = makeSignStr(body)
    return body
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京喜自营领京豆', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _eid() {
        if (this._eidCache && Date.now() - this._eidAt < 600000) return this._eidCache
        for (const pt of ['/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', '/ql/data/psyduck/eid_pair.txt']) {
            try {
                const v = (fs.readFileSync(pt, 'utf8').match(/eid=(\S+)/) || ['', ''])[1]
                if (v) { this._eidCache = v; this._eidAt = Date.now(); return v }
            } catch (e) {}
        }
        return ''
    }

    // jx_h5_babel 族: queryTaskList/querySign 无h5st; completeTask=cec1e / rewardTask=573fe
    async jxCurl(p, user, fn, bodyObj, appId) {
        if (!this._jxSigner) {
            try { this._jxSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        const ck = this._ckForUser(user)
        if (!ck || !this._jxSigner) return null
        const f = new URLSearchParams()
        f.append('functionId', fn)
        f.append('appid', 'jx_h5_babel')
        f.append('t', String(Date.now()))
        f.append('channel', 'jxh5')
        f.append('clientVersion', '1.2.5')
        f.append('client', 'jxh5')
        f.append('uuid', UUID)
        f.append('cthr', '1')
        f.append('xAPIRegion', 'CN')
        f.append('xAPIClientLanguage', 'zh_CN')
        f.append('xAPIClientMode', '0')
        f.append('xAPITz', 'Asia/Shanghai')
        f.append('xAPICurrency', 'CNY')
        f.append('loginType', '2')
        const eidTk = this._eid()
        if (eidTk) f.append('x-api-eid-token', eidTk)
        if (appId) {
            if (!globalThis.__jxWarm) {
                try { this._jxSigner.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'jx_h5_babel', client: 'jxh5', clientVersion: '1.2.5'}, appId}) } catch (e) {}
                await this.wait(3500)
                globalThis.__jxWarm = true
            }
            const signed = this._jxSigner.sign({
                functionId: fn, body: bodyObj, ck,
                base: {appid: 'jx_h5_babel', client: 'jxh5', clientVersion: '1.2.5'},
                appId
            })
            for (const k in signed) f.append(k, String(signed[k]))
        }
        f.append('body', JSON.stringify(bodyObj))
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async rawGet(p, user, url, referer) {
        if (!url) return
        try {
            for (let hop = 0; hop < 2 && url; hop++) {
                const out = await new Promise(resolve => {
                    const u = new URL(url)
                    const rq = https.request({
                        hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
                        headers: {cookie: this._ckForUser(user), 'user-agent': UA, referer: referer || W_PAGE, accept: 'text/html,*/*'}
                    }, rs => {
                        rs.resume()
                        rs.on('end', () => resolve({status: rs.statusCode, loc: rs.headers.location || ''}))
                    })
                    rq.on('error', () => resolve({status: 0, loc: ''}))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve({status: 0, loc: ''}) })
                    rq.end()
                })
                if (out.status === 302 && out.loc) { url = new URL(out.loc, url).href; referer = url } else { url = '' }
            }
        } catch (e) {}
    }

    async main(p) {
        let user = p.data.user
        let list = await this.jxCurl(p, user, 'jxzy_active_task_queryTaskList', baseBody({source: 'jxzy', craftId: CRAFT, tttId: 'ttt431', canInstall: 1, installed: 0}))
        if (!list) { p.log('queryTaskList 空响应'); return }
        let tasks = (list.data && list.data.taskInfoList) || []
        if (!tasks.length) { p.log('任务池:', JSON.stringify(list).slice(0, 600)); return }
        // 单任务结构探针
        const t0 = tasks.find(t => t.taskType === 3 && t.taskStatus !== 4) || tasks[0]
        if (t0) p.log('任务样例:', JSON.stringify(t0).slice(0, 700))
        let done = 0
        for (const t of tasks) {
            if (+t.taskStatus === 4 || +t.taskStatus === 3) continue
            // 分享/助力类(taskType 1/2)协议做不了
            if (+t.taskType === 1 || +t.taskType === 2) { p.log('跳过(助力类):', t.taskName); continue }
            const taskId = t.taskId || ''
            // itemId 实测在 taskProgress.itemId (2026-10-23 抓包/实跑实锤)
            const itemId = t.itemId || (t.taskProgress && t.taskProgress.itemId) || ''
            const need = +t.needsecond || +t.waitDuration || 10
            const jumpUrl = t.jumpUrl || t.url || t.forwardUrl || ''
            if (!taskId) continue
            p.log('做:', t.taskName || taskId, '| 需浏览', need + 's')
            // 浏览类: 先跳落地页停留 needsecond, 再完成上报 → 领奖
            if (jumpUrl) await this.rawGet(p, user, jumpUrl, W_PAGE)
            await this.wait((need + 2) * 1000)
            let rc = await this.jxCurl(p, user, 'jxzy_active_task_completeTask', baseBody({craftId: CRAFT, taskId, itemId, taskType: 3}), 'cec1e')
            p.log('  完成:', JSON.stringify(rc).slice(0, 120))
            await this.wait(2000)
            let rr = await this.jxCurl(p, user, 'jxzy_active_task_rewardTask', baseBody({craftId: CRAFT, taskId, itemId, taskType: 3}), '573fe')
            p.log('  领奖:', JSON.stringify(rr).slice(0, 150))
            done++
            p.info.work = true
            await this.wait(4000)
        }
        p.log(`本轮完成 ${done} 个`)
    }
}
