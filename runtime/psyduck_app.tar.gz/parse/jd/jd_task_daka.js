import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const DK_PAGE = 'https://pro.m.jd.com/mall/active/2tjjdsPLtUbUMagzpuWyzU2kGBLm/index.html'
const DK_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东打卡领京豆',
            verify: 1,
            help: 'main',
            interval: 1000,
            crontab: 4,
            sync: 1
        }
    }

    async prepare() {
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(DK_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._dkCk()
    }
    _dkCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(DK_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    async signCurl(opts) {
        if (!this._dkSigner) {
            try { this._dkSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._dkSigner) return null
        const form = String(opts.form || '')
        const getv = k => { const m = form.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const base = {
            appid: getv('appid') || 'activities_platform',
            client: getv('client') || 'apple', clientVersion: getv('clientVersion') || '15.0.65',
            t: String(Date.now()), body, functionId: fn, networkType: 'wifi'
        }
        const signed = this._dkSigner.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || '2c4bd', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType'])
        for (const seg of form.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: DK_PAGE, referer: DK_PAGE,
                    'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let algo = context.algo || {}
        let sign = await this.signCurl({
                form: `appid=activities_platform&loginType=2&loginWQBiz=&functionId=interact_game_sign&body={"encryptAssignmentId":"2VRGziZArS6SGUr3VVWnzFQLFhsJ","itemId":"1","version":"2.0"}&client=apple&osVersion=15.1.1&clientVersion=15.0.65&d_model=iPhone13,3&d_brand=iPhone&networkType=wifi&build=169770&partner=-1`,
                user,
                algo: {
                    ...{
                        expire: {
                            code: 3
                        },
                        appId: '2c4bd'
                    }, ...algo
                }
            }
        )
        if (this.haskey(sign, 'data.continueSignDay')) {
            p.log("签到成功")
            p.msg(`京豆: ${sign.data.quantity}`)
            p.info.work = true
        }
        else if (this.haskey(sign, 'code', -1)) {
            p.log(`已签到`)
            p.info.work = true
        }
        else {
            // code 406 + 活动页已降级商品流(2026-10-20 App 实测「活动迷路了」) = 活动下线, 勿再重试
            if (String(this.haskey(sign, 'code')) === '406') p.log('打卡活动已下线(code 406), 本任务待移除')
            else p.log(this.haskey(sign, 'message') || sign)
        }
    }
}
