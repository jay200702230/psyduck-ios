import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const SI_PAGE = 'https://pro.m.jd.com/mall/active/2tjjdsPLtUbUMagzpuWyzU2kGBLm/index.html'
const SI_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: "京东整合签到",
            crontab: 3,
            model: 'user'
        }
    }

    async prepare() {
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(SI_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._siCk()
    }
    _siCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(SI_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    async signCurl(opts) {
        if (!this._siSigner) {
            try { this._siSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._siSigner) return null
        const form = String(opts.form || '')
        const getv = k => { const m = form.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const base = {
            appid: getv('appid') || 'plus_business',
            client: getv('client') || 'apple', clientVersion: getv('clientVersion') || '15.1.35',
            t: String(Date.now()), body, functionId: fn, networkType: 'wifi'
        }
        const signed = this._siSigner.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || 'b63ff', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType'])
        for (const seg of form.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: SI_PAGE, referer: SI_PAGE,
                    'user-agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user;
        // ---- 主签到: beanRewardNode 点击式新通道 (beanHome 同款报文, 旧 beanDailySign 列表接口已废弃) ----
        const signBody = {scene: 'commonDoInteractiveAssignment', activityCode: 'beanRewardNode', businessScenario: 'jingDouCenter', assignmentId: '1', actionType: '0', itemId: ''}
        let sign = await this.signCurl({
                'form': `functionId=bff_rightsCenter_interaction&body=${encodeURIComponent(JSON.stringify(signBody))}&appid=plus_business&client=android&clientVersion=15.10.50`,
                user,
                referer: 'https://pro.m.jd.com/mall/active/25xqCADVDNAd1wTHojZv2p37yKBG/index.html',
                algo: {
                    appId: '90b26'
                }
            }
        )
        if (this.haskey(sign, 'code', '0') || sign && sign.code === 0) {
            p.info.work = true
            p.log('签到成功')
            if (this.haskey(sign, 'rs.rewardsInfo.successRewards')) {
                for (let [k, v] of Object.entries(sign.rs.rewardsInfo.successRewards)) {
                    if (k == '3') {
                        p.award(v[0].quantity, 'bean')
                    }
                    else if (k == '4') {
                        p.award(v[0].discount, 'redpacket')
                    }
                }
            }
        }
        else if (this.haskey(sign, 'code', ['1711001', '1711002', '103', '104', '3101'])) {
            p.info.work = true
            p.log('你已经签到过啦')
        }
        else {
            p.log('签到:', this.haskey(sign, 'msg') || this.haskey(sign, 'errMsg') || this.dumps(sign).slice(0, 80))
        }
        // ---- 旧列表任务 (jdInteractTask 已废弃, 保留兼容: 接口复活时自动恢复) ----
        const pullTask = () => this.signCurl({
                'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_jdInteractTask&scene=jdInteractTask`,
                'form': `appid=plus_business&functionId=bff_rightsCenter_jdInteractTask&body=${encodeURIComponent(this.dumps({
                    taskType: 'beanDailySign',
                    popFlag: '0',
                    scene: 'jdInteractTask',
                    commonScene: 'jingDouCenter',
                    needBeanSignStatus: '1'
                }))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=iPhone`,
                user,
                algo: {
                    appId: 'b63ff'
                }
            }
        )
        let tl = await pullTask()
        let tasks = this.haskey(tl, 'rs.beanTask.taskList')
        // 限流退避重试: 1714001/1714002 等 25s 重拉, 最多 3 次
        for (let retry = 0; !tasks && retry < 3; retry++) {
            let code = String(this.haskey(tl, 'code') || this.haskey(tl, 'rs.code') || '')
            if (code !== '1714001' && code !== '1714002') break
            p.log(`京豆频道限流(${code}), 第${retry + 1}次退避25秒后重试`)
            await this.wait(25000)
            tl = await pullTask()
            tasks = this.haskey(tl, 'rs.beanTask.taskList')
        }
        let hotCount = 0
        if (!tasks) {
            let code = String(this.haskey(tl, 'code') || this.haskey(tl, 'rs.code') || '')
            let msg = this.haskey(tl, 'msg') || this.haskey(tl, 'rs.msg') || ''
            if (code === '1714001' || code === '1714002') {
                p.log('京豆频道持续限流, 本轮放弃(下个定时槽位自动再来)')
            } else {
                p.log("没有获取到签到任务:", msg || this.dumps(tl).slice(0, 200))
            }
            return
        }
        for (let i of tasks) {
            if (i.completionFlag) {
                p.log(`已签到: ${i.assignmentName}`)
                p.info.work = true
                continue
            }
            let r = await this.signCurl({
                    'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_interaction&scene=commonDoInteractiveAssignment`,
                    'form': `appid=plus_business&functionId=bff_rightsCenter_interaction&body=${encodeURIComponent(this.dumps({
                        scene: 'commonDoInteractiveAssignment',
                        activityCode: 'beanDailySign',
                        businessScenario: 'jingDouCenter',
                        assignmentId: i.encryptAssignmentId,
                        actionType: '1'
                    }))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=iPhone`,
                    user,
                    algo: {
                        appId: 'b63ff'
                    }
                }
            )
            let code = this.haskey(r, 'code')
            if (code == '1711000') {
                p.log(`签到成功: ${i.assignmentName}`)
                p.info.work = true
                let bean = this.haskey(r, 'rs.rewardQuantity') || this.haskey(r, 'rs.quantity')
                if (bean) {
                    p.award(bean, 'bean')
                }
            }
            else if (code == '1711001') {
                p.log(`已签到: ${i.assignmentName}`)
                p.info.work = true
            }
            else if (code == '1714002') {
                p.log(`被限流(队伍有点长), 稍后再试: ${i.assignmentName}`)
            }
            else {
                let msgTxt = String(this.haskey(r, 'msg') || '')
                p.log(`签到失败: ${i.assignmentName}`, msgTxt || r)
                // 连续被「活动太火爆」软拒 = 账号被风控限流, 继续逐个请求只会喂高风控分
                if (msgTxt.includes('活动太火爆')) {
                    hotCount++
                    if (hotCount >= 3) {
                        p.log("连续3次被限流, 本轮放弃剩余签到")
                        break
                    }
                }
                else {
                    hotCount = 0
                }
            }
            await this.wait(1500)
        }
    }
}
