import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const WB_PAGE = 'https://pro.m.jd.com/mall/active/4Gck3RiwkxFEyA9ztVmQ2zwqjNRr/index.html'
const WB_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东小游戏签到',
            pageUrl: 'https://pro.m.jd.com/mall/active/4Gck3RiwkxFEyA9ztVmQ2zwqjNRr/index.html',
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/4Gck3RiwkxFEyA9ztVmQ2zwqjNRr/index.html'
            },
            crontab: 3
        }
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _wbCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._wbCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean/blindBox 模式)
    async wbCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._wbSigner) {
            try { this._wbSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._wbSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._wbSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'wegame-hub', client: getv('client') || 'ios', clientVersion: getv('clientVersion') || '15.6.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: WB_PAGE, 'user-agent': WB_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user
        // 种豆得豆页面内嵌的互动小游戏活动, 连签5天最高得180京豆+350收获值
        // 默认走种豆得豆的 linkId; 若配置了 context.linkId 则优先使用
        let linkId = p.context.linkId || '4HcenxuZM4XiHesOb1HG4g'
        let home = await this.wbCurl({
                'url': `https://api.m.jd.com/api?functionId=weGameHome`,
                'form': `functionId=weGameHome&body={"envType":1,"linkId":"${linkId}","appType":1}&appid=wegame-hub&client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame&build=170394&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone14,5&lang=zh_CN&osVersion=16.3&partner=-1&cthr=1`,
                user,
                algo: {
                    appId: '101aa',
                    expire: {
                        errMsg: '未登录',
                    }
                }
            }
        )
        let signMainVo = this.haskey(home, 'data.signMainVo')
        if (!signMainVo) {
            p.err("没有获取到小游戏数据")
            return
        }
        let markStr = signMainVo.markStr || ''
        if (signMainVo.currentStatus == 1) {
            p.log("正在签到...")
            let sign = await this.wbCurl({
                    'url': `https://api.m.jd.com/api?functionId=weGameLottery`,
                    'form': `functionId=weGameLottery&body={"envType":1,"linkId":"${linkId}","appType":1,"status":1,"markStr":"${markStr}"}&appid=wegame-hub&client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame&build=170394&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone14,5&lang=zh_CN&osVersion=16.3&partner=-1&cthr=1`,
                    user,
                    algo: {
                        appId: '730a6'
                    }
                }
            )
            if (this.haskey(sign, 'data.awardResultVO.amount')) {
                p.award(sign.data.awardResultVO.amount, 'bean')
                p.info.work = true
            }
            else if (this.haskey(sign, 'code', 0) == 0) {
                p.log("签到成功")
                p.info.work = true
            }
            else {
                p.log("签到失败:", this.haskey(sign, 'errMsg') || sign)
            }
        }
        else if (signMainVo.currentStatus == 3) {
            p.log("今日已签到,", signMainVo.headText || '明天再来')
            p.info.work = 1
        }
        else if (signMainVo.beforeTaskVo) {
            let bf = signMainVo.beforeTaskVo
            p.log("正在执行:", bf.taskShowTitle)
            for (let i of bf.taskItemList) {
                let bt = await this.wbCurl({
                        'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                        form: `functionId=apStartTaskTime&body={"linkId":"${linkId}","taskId":${bf.id},"itemType":"${i.itemType}","itemId":"${encodeURIComponent(i.itemId)}","channel":4,"pipeExt":${this.dumps({...bf.pipeExt, ...i.pipeExt})}}&appid=activity_platform_se&client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame&build=170394&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone14,5&lang=zh_CN&osVersion=16.3&partner=-1&cthr=1`,
                        algo: {
                            appId: 'acb1e'
                        },
                        user
                    }
                )
                if (this.haskey(bt, 'data.jumpUrl')) {
                    if (bf.timeLimitPeriod) {
                        p.log("正在等待:", bf.timeLimitPeriod)
                        await this.wait(bf.timeLimitPeriod * 1000)
                    }
                    let dt = await this.wbCurl({
                            'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                            form: `functionId=apDoLimitTimeTask&body={"linkId":"${linkId}"}&appid=activities_platform&client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame&build=170394&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone14,5&lang=zh_CN&osVersion=16.3&partner=-1&cthr=1`,
                            user,
                            algo: {
                                appId: 'ebecc'
                            }
                        }
                    )
                    if (this.haskey(dt, 'data.finished') || this.haskey(dt, 'code', 1) == 0) {
                        let sign = await this.wbCurl({
                                'url': `https://api.m.jd.com/api?functionId=weGameLottery`,
                                'form': `functionId=weGameLottery&body={"envType":1,"linkId":"${linkId}","appType":1,"status":1,"markStr":""}&appid=wegame-hub&client=ios&clientVersion=15.6.50&platform=3&loginType=2&loginWQBiz=wegame&build=170394&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone14,5&lang=zh_CN&osVersion=16.3&partner=-1&cthr=1`,
                                user,
                                algo: {
                                    appId: '730a6'
                                }
                            }
                        )
                        if (this.haskey(sign, 'data.awardResultVO.amount')) {
                            p.award(sign.data.awardResultVO.amount, 'bean')
                            p.info.work = true
                        }
                        else {
                            p.log("领奖失败:", this.haskey(sign, 'errMsg') || sign)
                        }
                    }
                    else {
                        if (String(this.haskey(dt, 'errMsg') || '').includes('没有需要查询的计时任务')) {
                            p.log("服务端未记录计时, 浏览被风控吞了")
                        }
                        else {
                            p.log("任务执行失败:", this.haskey(dt, 'errMsg') || dt)
                        }
                    }
                }
                break
            }
        }
        else {
            p.log("当前状态:", signMainVo.buttonText || signMainVo.currentStatus)
        }
    }
}
