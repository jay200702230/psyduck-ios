import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

// 国家补贴x超级补贴 (DvFPmKRas9GYjDPZjT9NT14BAv6, babelChannel=ttt131)
// 签到翻牌: billion_do_sign (channelId=6); 任务池: common_task_list (channelId=7, activityId=01425483)
// 执行: common_do_task {channelId, itemId, assignmentId, actionType:0, ext:{doReceiveRewards}}
const GB_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.0.0 Mobile Safari/537.36'
const GB_REF = 'https://pro.m.jd.com/mall/active/DvFPmKRas9GYjDPZjT9NT14BAv6/index.html?babelChannel=ttt131&mainChannel=1&billionSign=1'
const GB_CK = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '国补超级补贴',
            turn: 1,
            crontab: 3,
            model: 'user'
        }
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(GB_CK, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._gCk()
    }
    _gCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(GB_CK, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    async gCurl(fid, bodyObj) {
        if (!this._gSigner) {
            try { this._gSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._gSigner) return null
        const ck = this._gCk()
        if (!ck) return null
        const signed = this._gSigner.sign({
            functionId: fid, body: bodyObj, ck,
            appId: '2e500',
            base: {appid: 'SecKill2020', client: 'android', clientVersion: '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com',
                path: '/?area=16_1315_3489_46816&clientVersion=15.10.50&client=android&loginType=2&appid=SecKill2020&d_model=IN2010&d_brand=OnePlus&model=IN2010&osVersion=13&uuid=3303461326131633-2313731633939346&functionId=' + fid,
                method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: GB_REF, 'user-agent': GB_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {}
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async prepare() {
        this.signBody = {
            channelId: '6', encryptProjectId: '3iFuS7TyJpKixsa4tZj9EBMr1jxJ',
            encryptAssignmentId: 'bWLRWiLiFiyMtVuzcwn5zWCAfcz', todayAward: '1', mainChannel: '1',
            gps_area: '0_0_0_0', lng: '118.230367', lat: '24.576403'
        }
        this.listBody = {channelId: '7', babelChannel: 'ttt131', activityId: '01425483', ext: {channel: 0, queryReceiveTimes: 1}}
    }

    _beansOf(res) {
        let n = 0
        try {
            const ri = res && res.data && res.data.result && res.data.result.rewardsInfo
            if (ri) {
                for (const k of Object.keys(ri)) {
                    const arr = Array.isArray(ri[k]) ? ri[k] : []
                    for (const it of arr) if (it && it.quantity) n += Number(it.quantity) || 0
                }
            }
        } catch (e) {}
        return n
    }

    async main(p) {
        // 1. 签到翻牌
        const si = await this.gCurl('billion_sign_info', this.signBody)
        const signInfo = si && si.data && si.data.result && si.data.result.signInfo
        if (signInfo && String(signInfo.todaySign) !== '1') {
            let r = await this.gCurl('billion_do_sign', this.signBody)
            const b = this._beansOf(r)
            if (b > 0) { p.info.work = true; p.award(b, 'bean'); p.log('签到翻牌 +' + b + '豆') }
            else p.log('签到:', this.haskey(r, 'data.bizMsg') || JSON.stringify(r).slice(0, 100))
        } else if (signInfo) {
            p.log('今日已签到翻牌 (已签' + signInfo.signDays + '天)')
        } else {
            p.log('签到信息异常:', JSON.stringify(si).slice(0, 120))
        }

        let got = 0

        // 2. 任务池: 先做 (actionType=0)
        const tl = await this.gCurl('common_task_list', this.listBody)
        const tasks = tl && tl.data && tl.data.result && tl.data.result.taskInfo && tl.data.result.taskInfo.taskList
        if (!Array.isArray(tasks)) {
            p.log('任务池异常:', JSON.stringify(tl).slice(0, 120))
            return
        }
        for (const t of tasks) {
            if (!t || !t.encryptAssignmentId || t.completionFlag) continue
            const name = t.assignmentName || t.encryptAssignmentId.slice(0, 8)
            if (t.assignmentType === 2) { p.log('[' + name + '] 助力任务跳过'); continue }
            const rw = (t.rewards || [])[0]
            const beanReward = rw && (rw.rewardType === 3 || String(rw.rewardType) === '3') && rw.quantity
            const act = (t.ext && t.ext.shoppingActivity || [])[0] || {}
            const itemId = act.itemId || t.itemId || ''
            if (!itemId) { p.log('[' + name + '] 无itemId跳过'); continue }
            if (!beanReward && String(rw && rw.rewardName || '').includes('券')) { p.log('[' + name + '] 发券任务跳过'); continue }
            if (String(name).toLowerCase().includes('rtb')) { p.log('[' + name + '] rtb广告任务跳过'); continue }
            const wd = (t.ext && t.ext.waitDuration) || 0
            if (wd > 0) { p.log('[' + name + '] 浏览类任务(需真实曝光)跳过'); continue }

            const r = await this.gCurl('common_do_task', {
                channelId: '7', itemId, assignmentId: t.encryptAssignmentId,
                actionType: 0, ext: {doReceiveRewards: (t.canReceiveTimes > 0 ? 1 : null)}
            })
            const ok = this.haskey(r, 'data.bizCode') === 0 || this.haskey(r, 'data.bizMsg') === '任务完成'
            if (ok) p.log('[' + name + '] ' + (this.haskey(r, 'data.result.assignmentResult.msg') || '完成'))
            else p.log('[' + name + ']:', this.haskey(r, 'data.bizMsg') || JSON.stringify(r).slice(0, 100))
            await this.wait(1200)
        }

        // 3. 重拉任务池: 领取所有 canReceiveTimes>0 的奖励
        await this.wait(2500)
        const tl2 = await this.gCurl('common_task_list', this.listBody)
        const tasks2 = tl2 && tl2.data && tl2.data.result && tl2.data.result.taskInfo && tl2.data.result.taskInfo.taskList || []
        for (const t of tasks2) {
            if (!t || t.assignmentType === 2) continue
            if (!(t.canReceiveTimes > 0)) continue
            const name = t.assignmentName || t.encryptAssignmentId.slice(0, 8)
            const rw = (t.rewards || [])[0]
            const act = (t.ext && t.ext.shoppingActivity || [])[0] || {}
            const itemId = act.itemId || t.itemId || ''
            if (!itemId) { p.log('[' + name + '] 可领但无itemId, itemId=' + JSON.stringify(t.ext && t.ext.shoppingActivity)); continue }
            const r = await this.gCurl('common_do_task', {
                channelId: '7', itemId, assignmentId: t.encryptAssignmentId,
                actionType: 0, ext: {doReceiveRewards: 1}
            })
            const b = this._beansOf(r)
            if (b > 0) { got += b; p.info.work = true; p.award(b, 'bean'); p.log('[' + name + '] 领取 +' + b + '豆') }
            else p.log('[' + name + '] 领取:', this.haskey(r, 'data.bizMsg') || JSON.stringify(r).slice(0, 100))
            await this.wait(1500)
        }
        p.log('国补任务完成, 今日领取京豆:', got)
    }
}
