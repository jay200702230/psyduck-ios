// 京东健康「天天领京豆」每日任务 (appid=jdh-middle)
// 链路(真机 HAR 2026-10-26): market_daily_pageIndex -> completionFlag=false 逐个 market_daily_doCompleteTask -> 复查
import fs from 'fs'
import net from 'net'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const APPID = 'jdh-middle'
const EID = 'jdd03EOODCUKSFWEIRWMPGYR7AZ7AL52K7A7JZII4ROWCMUZTD42AQ64U7YWFHS7OSP5SPLMKQRMSYQ2SSWJMFX6CI2M2RAAAAANBO5C3XVQAAAAADVTN3XEDRKZ2CQX'
const REFERER = 'https://pro.m.jd.com/mall/active/3RLqT5qKR4uVAXKxezQTYL9ArSR2/index.html'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东健康每日任务', pageUrl: REFERER, headers: {referer: REFERER}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        let cur = '', sections = {}
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1].trim(); continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) (sections[cur] ||= []).push(ln.trim())
        }
        // u 是 pin：优先按 pin 的 section 找，找不到回退 main
        for (const sec of [u, 'main']) {
            const arr = sections[sec]
            if (arr && arr.length) {
                const hit = arr.find(l => (l.match(/pt_pin\s*=\s*([^;]+)/) || [])[1] === u)
                if (hit) return hit
                return arr[0]
            }
        }
        return ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed && this._h2s.closeCode === undefined) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    async call(p, user, fn, bodyObj) {
        for (let k = 1; k <= 2; k++) {
            try {
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                if (!this._sg) this._sg = await import('./jd_signer_node.mjs')
                const signed = this._sg.sign({functionId: fn, body: bodyObj || {}, ck, base: {appid: APPID, client: 'android', clientVersion: '15.10.50'}, appId: APPID, slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('x-api-eid-token', EID)
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: REFERER, 'x-rp-client': 'h5_2.4.0'})
                    } catch (e) { this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', () => { this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => fin(null), 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    async main(p) {
        const user = p.data.user
        const page = await this.call(p, user, 'market_daily_pageIndex', {taskVersion: 1, channel: 'daily'})
        if (!page || page.code !== '0000') { p.log('pageIndex 失败', JSON.stringify(page).slice(0, 120)); this._fails++; p.info.work = false; return }
        const al = (page.data || {}).assignmentList || []
        const todo = al.filter(a => !a.completionFlag)
        p.log(`任务 total=${al.length} todo=${todo.length}`)
        let done = 0
        for (const a of todo) {
            const name = a.assignmentName || a.encryptAssignmentId
            if ((a.url || '').includes('JDHDownload')) { p.log('  skip(下载类):', name); continue }
            const body = {assignmentType: a.assignmentType, encryptAssignmentId: a.encryptAssignmentId, actionType: 1, platform: 1, osVersion: '16.3', screen: '390*844'}
            if (a.itemId != null && a.itemId !== '') body.itemId = String(a.itemId)
            const r = await this.call(p, user, 'market_daily_doCompleteTask', body)
            const ok = r && r.code === '0000' && r.success !== false
            p.log(`  ${ok ? 'OK' : 'FAIL'} ${name} [${a.assignmentType}]`, ok ? '' : JSON.stringify(r).slice(0, 80))
            if (ok) done++
            await this.wait(2000)
        }
        const page2 = await this.call(p, user, 'market_daily_pageIndex', {taskVersion: 1, channel: 'daily'})
        const left = ((((page2 || {}).data || {}).assignmentList || [])).filter(a => !a.completionFlag).length
        p.log(`完成 ${done} | 剩余 ${left}`)
        p.info.work = this._fails === 0
    }
}
