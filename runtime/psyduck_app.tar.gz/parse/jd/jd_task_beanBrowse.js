import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const BB_PAGE = 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1'
// App 容器形态 UA (2026-10-22 LSPosed 抓包实锤: 交互请求全部走 jdapp 容器 UA, ep 为本机加密设备指纹, ts 每次会话刷新)
const BB_EP = JSON.stringify({
    hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1,
    cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='},
    ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'
})
// 本进程统一 UA: 请求头与 h5st env(navigator.userAgent) 必须同串; ep ts 进程级单例, 多模块共存时也保持同串
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const BB_UA_ONE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/' + encodeURIComponent(BB_EP.replace('"ts":0', '"ts":' + globalThis.__uaTs)) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = BB_UA_ONE
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东豆子中心浏览任务',
            pageUrl: 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1',
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html?babelChannel=ttt1'
            },
            turn: 1,
            crontab: 3
        }
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _bbCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        // ck_full 覆盖 (手动全量罐, 优先级最高): /ql/data/psyduck/ck_full/<pin>.txt
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._bbCk()
    }

    // 设备身份 token (App 交互请求 form 尾必带, 2026-10-22 遥测实锤), 手机/青龙 双路径, 10分钟缓存
    _eid() {
        if (this._eidCache && Date.now() - this._eidAt < 600000) return this._eidCache
        for (const pt of ['/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', '/ql/data/psyduck/eid_pair.txt']) {
            try {
                const v = (fs.readFileSync(pt, 'utf8').match(/eid=(\S+)/) || ['', ''])[1]
                if (v) { this._eidCache = v; this._eidAt = Date.now(); return v }
            } catch (e) {}
        }
        return ''
    }

    // Set-Cookie 自攒罐 (2026-10-23 实锤: 完整指纹罐是交互风控通行证, 服务端下发必接回传)
    _jarPin(user) {
        const ck = this._ckForUser(user)
        const m = String(ck || '').match(/pt_pin=([^;\s]+)/)
        return m ? decodeURIComponent(m[1]) : String(user || 'main')
    }
    _jarLoad(pin) {
        if (this._jarLoaded === pin) return this._jarMap
        this._jarMap = new Map()
        try {
            for (const ln of fs.readFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', 'utf8').split(/\r?\n/)) {
                const kv = ln.trim()
                if (kv.includes('=')) this._jarMap.set(kv.split('=')[0], kv)
            }
        } catch (e) {}
        this._jarLoaded = pin
        return this._jarMap
    }
    _jarSave(pin) {
        try {
            fs.mkdirSync('/ql/data/psyduck/ck_jar', {recursive: true})
            fs.writeFileSync('/ql/data/psyduck/ck_jar/' + encodeURIComponent(pin) + '.txt', [...this._jarMap.values()].join('\n') + '\n')
        } catch (e) {}
    }
    _ckFull(user) {
        const ck = this._ckForUser(user)
        const jar = this._jarLoad(this._jarPin(user))
        const have = new Set(String(ck).split(';').map(s => s.split('=')[0].trim()).filter(Boolean))
        const extra = [...jar.values()].filter(kv => !have.has(kv.split('=')[0]))
        return extra.length ? ck + ';' + extra.join(';') : ck
    }
    _jarHarvest(user, res) {
        const sc = res.headers['set-cookie']
        if (!sc || !sc.length) return
        const jar = this._jarLoad(this._jarPin(user))
        for (const c of sc) {
            const kv = String(c).split(';')[0]
            if (kv.includes('=') && /^[!-~]+=/i.test(kv)) jar.set(kv.split('=')[0], kv)
        }
        this._jarSave(this._jarPin(user))
    }
    // 框架curl链路对api.m.jd.com被风控, bff 请求改 h5st 自签名直连 (同 scratchBean 模式)
    async bbCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._bbSigner) {
            try { this._bbSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._bbSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const user = opts.user
        const ck = this._ckFull(user)
        if (!ck) return null
        const signed = this._bbSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'plus_business', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        // App 实锤: 每次请求 form 尾部带设备身份凭证 x-api-eid-token (缺失 = 队列信任分垫底)
        const eid = this._eid()
        if (eid) f.append('x-api-eid-token', eid)
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性; mark/swimLane/headers 为 App 页面框架实锤头
                    origin: 'https://pro.m.jd.com', referer: BB_PAGE, 'user-agent': BB_UA_ONE,
                    'x-babel-ihub': '00041489', 'x-rp-client': 'h5_2.4.0',
                    'x-referer-page': 'https://pro.m.jd.com/mall/active/4E1fFrgX1eGtWTc5KBNFzXMrh6xn/index.html',
                    'mark': 'true', 'swimLane': 'undefined', 'headers': '[object Object]',
                    'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Android WebView";v="120", "Dong WebView";v="2.1.62"',
                    'sec-ch-ua-mobile': '?1', 'sec-ch-ua-platform': '"Android"'
                }
            }, rs => {
                this._jarHarvest(user, rs)
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    // 豆子中心(天天刮京豆)任务池。2026-10 真机抓包: taskType 需带 beanDailyPlus 段, popFlag=1, 不带 commonScene/needBeanSignStatus
    async fetchTasks(p, user) {
        let body = {
            taskType: 'beanDailySign_beanDailyPlus_newBeanTask', popFlag: '1', scene: 'jdInteractTask',
            otherApis: []
        }
        for (let i = 1; i <= 4; i++) {
            let r = await this.bbCurl({
                'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_jdInteractTask&scene=jdInteractTask`,
                'form': `appid=plus_business&functionId=bff_rightsCenter_jdInteractTask&body=${encodeURIComponent(this.dumps(body))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=OnePlus`,
                user, algo: {appId: 'b63ff'}
            })
            let tasks = this.haskey(r, 'rs.beanTask.taskList')
            if (tasks) return tasks
            let code = String(this.haskey(r, 'code') || '')
            if (code == '1714001' || code == '1714002') {
                p.log(`豆子中心接口限流(${code}), 第${i}次重试...`)
                await this.wait(8000 * i)
                continue
            }
            p.log('任务列表获取失败:', this.haskey(r, 'msg') || r)
            return null
        }
        p.log('豆子中心接口持续限流, 本轮跳过')
        return null
    }

    // 落地页真实访问 + 广告打点 (2026-10-22 实测: 不 GET 落地页直接 0 上报会被 107 软拒, 落地页访问是完成判定的前置)
    // 302 需跟一次 (lps.jd.com 偶发重定向, 断链会让行为流归因失效)
    async rawGet(p, user, url, referer) {
        if (!url) return
        try {
            for (let hop = 0; hop < 2 && url; hop++) {
                const out = await new Promise(resolve => {
                    const u = new URL(url)
                    const rq = https.request({
                        hostname: u.hostname, path: u.pathname + u.search, method: 'GET',
                        headers: {
                            cookie: this._ckFull(user), 'user-agent': BB_UA_ONE,
                            referer: referer || BB_PAGE,
                            accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                        }
                    }, rs => {
                        this._jarHarvest(user, rs)
                        rs.resume()
                        rs.on('end', () => resolve({status: rs.statusCode, loc: rs.headers.location || ''}))
                    })
                    rq.on('error', () => resolve({status: 0, loc: ''}))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve({status: 0, loc: ''}) })
                    rq.end()
                })
                if (out.status === 302 && out.loc) { url = new URL(out.loc, url).href; referer = url } else { url = '' }
            }
        } catch (e) {}
    }

    // 前端 jt: otherParam 按 extraType 取字段
    buildExt(i) {
        let ext = this.haskey(i, 'ext') || {}
        let et = ext.extraType || ''
        let jump = ''
        if (et === 'productsInfo') jump = this.haskey(ext, 'productsInfo.0.skuId') || ''
        else if (et === 'browseShop') jump = this.haskey(ext, 'browseShop.0.shopId') || ''
        else if (this.haskey(ext, 'shoppingActivity.0.url')) jump = this.haskey(ext, 'shoppingActivity.0.url') || ''
        else if (this.haskey(ext, 'itemInfoList.0.toUrl')) jump = this.haskey(ext, 'itemInfoList.0.toUrl') || ''
        else if (this.haskey(ext, 'followShop.0.shopId')) jump = this.haskey(ext, 'followShop.0.shopId') || ''
        if (!jump) jump = this.pickJumpUrl(ext) || ''
        return jump ? {ext: JSON.stringify({jumpUrl: jump})} : null
    }

    // 精选活动类任务的 itemId = 楼层名+13位时间戳 (2026-10-22 手动抓包实锤: "发现惊喜17926617825790"), 前端点击时动态生成
    pickActItem(o, depth) {
        if (Array.isArray(o)) {
            for (const v of o) { const r = this.pickActItem(v, (depth || 0) + 1); if (r) return r }
            return ''
        }
        if (!o || typeof o !== 'object' || (depth || 0) > 5) return ''
        for (const k in o) {
            const v = o[k]
            if (typeof v === 'string' && /^[^\/\.\d]{2,20}\d{13}$/.test(v)) return v
            if (v && typeof v === 'object') {
                const r = this.pickActItem(v, (depth || 0) + 1)
                if (r) return r
            }
        }
        return ''
    }

    // itemId 终极兜底: 任务名(去空白)+当前13位时间戳, 模拟前端点击时生成
    mkItemId(i, ext) {
        return this.pickActItem(ext) || String(i.assignmentName || i.encryptAssignmentId || '浏览').replace(/[\s:：,，]/g, '') + Date.now()
    }

    // ext 递归找 item.jd.com 商品链 (领取时的 jumpUrl)
    pickJumpUrl(o, depth) {
        if (Array.isArray(o)) {
            for (const v of o) { const r = this.pickJumpUrl(v, (depth || 0) + 1); if (r) return r }
            return ''
        }
        if (!o || typeof o !== 'object' || (depth || 0) > 5) return ''
        for (const k in o) {
            const v = o[k]
            if (typeof v === 'string' && /item\.jd\.com\/\d+/.test(v)) return v
            if (v && typeof v === 'object') {
                const r = this.pickJumpUrl(v, (depth || 0) + 1)
                if (r) return r
            }
        }
        return ''
    }

    async report(p, user, i, atype) {
        let ext = this.haskey(i, 'ext') || {}
        let body = {
            scene: 'commonDoInteractiveAssignment',
            activityCode: this.haskey(ext, 'taskType') || 'newBeanTask',
            businessScenario: 'jingDouCenter',
            assignmentId: i.encryptAssignmentId,
            actionType: atype,
            itemId: this.haskey(ext, 'shoppingActivity.0.itemId') || this.haskey(ext, 'itemInfoList.0.itemId') || this.haskey(ext, 'productsInfo.0.itemId') || this.haskey(ext, 'browseShop.0.itemId') || this.haskey(ext, 'followShop.0.itemId') || this.mkItemId(i, ext)
        }
        // 领取(actionType 1)带 jumpUrl, 完成上报(0)/领奖(100)不带 (手动抓包实锤)
        let op = String(atype) === '1' ? this.buildExt(i) : null
        if (op) body.ext = op.ext
        for (let k = 1; k <= 3; k++) {
            let r = await this.bbCurl({
                'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_interaction&scene=commonDoInteractiveAssignment`,
                'form': `appid=plus_business&functionId=bff_rightsCenter_interaction&body=${encodeURIComponent(this.dumps(body))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=OnePlus`,
                user, algo: {appId: 'b63ff'}
            })
            let code = String(this.haskey(r, 'code') || '')
            if (code == '1714001' || code == '1714002') {
                p.log(`  限流(${code}), 第${k}次退避...`)
                await this.wait(8000 * k)
                continue
            }
            return r
        }
        return {}
    }

    // 单个浏览任务: 落地页访问+打点 -> 受理 -> 等待 -> 完成上报 -> 领奖 (2026-10-22 全链路实测通过)
    async doBrowse(p, user, i) {
        let ext = this.haskey(i, 'ext') || {}
        let sa = this.haskey(ext, 'shoppingActivity.0') || {}
        let landing = sa.url || ''
        // 真实访问落地页 + exposal/click 打点 (不 GET 落地页直接 0 上报会被 107 软拒)
        await this.rawGet(p, user, landing, BB_PAGE)
        await this.rawGet(p, user, this.haskey(sa, 'ext.exposal_url') || '', landing)
        await this.rawGet(p, user, this.haskey(sa, 'ext.click_url') || '', landing)
        let r = await this.report(p, user, i, '1')
        let code = String(this.haskey(r, 'code') || '')
        let msg = this.haskey(r, 'msg') || ''
        if (code == '0' && /已完成/.test(msg)) {
            p.log('浏览完成:', i.assignmentName)
            return true
        }
        if (['1', '2'].includes(code)) {
            // 受理成功, 等 waitDuration 后: 0完成上报 -> 100领奖
            let wait = +(this.haskey(ext, 'waitDuration') || 6) + 2
            await this.wait(wait * 1000)
            let r0 = await this.report(p, user, i, '0')
            let c0 = String(this.haskey(r0, 'code') || '')
            for (let k = 1; k <= 2 && ['107', '1426'].includes(c0); k++) {
                p.log(`  完成上报限流(${c0}), ${6 * k}s 后重试`)
                await this.wait(6000 * k)
                r0 = await this.report(p, user, i, '0')
                c0 = String(this.haskey(r0, 'code') || '')
            }
            p.log(`完成上报(0): ${i.assignmentName} code=${c0}`)
            return await this.claim(p, user, i)
        }
        if (code == '0') return await this.claim(p, user, i)
        if (code == '1426' || code == '1714002') {
            // 频控软拒: 单次短退避重试一次, 不磨蹭 (连续请求会加深惩罚)
            p.log(`频控(${code}), 15s 后重试一次: ${i.assignmentName}`)
            await this.wait(15000)
            let rr = await this.report(p, user, i, '1')
            let rc = String(this.haskey(rr, 'code') || '')
            if (rc == '0' && /已完成/.test(this.haskey(rr, 'msg') || '')) {
                p.log('浏览完成:', i.assignmentName)
                return true
            }
            if (['1', '2'].includes(rc)) {
                let wait2 = +(this.haskey(ext, 'waitDuration') || 6) + 2
                await this.wait(wait2 * 1000)
                let r0 = await this.report(p, user, i, '0')
                let c0 = String(this.haskey(r0, 'code') || '')
                for (let k = 1; k <= 2 && ['107', '1426'].includes(c0); k++) {
                    await this.wait(6000 * k)
                    r0 = await this.report(p, user, i, '0')
                    c0 = String(this.haskey(r0, 'code') || '')
                }
                p.log(`完成上报(0): ${i.assignmentName} code=${c0}`)
                return await this.claim(p, user, i)
            }
            p.log(`频控未解: ${i.assignmentName} (下轮自动重试)`)
            return false
        }
        p.log(`浏览失败: ${i.assignmentName} code=${code} msg=${msg || this.dumps(r).slice(0, 80)}`)
        return false
    }

    // 领奖: canReceiveTimes>0 时 actionType=100
    async claim(p, user, i) {
        let fresh = (await this.fetchTasks(p, user) || []).find(x => x.encryptAssignmentId === i.encryptAssignmentId)
        if (!fresh) return false
        if (+fresh.canReceiveTimes > 0) {
            let r = await this.report(p, user, fresh, '100')
            let code = String(this.haskey(r, 'code') || '')
            if (code == '1711000' || code == '0') {
                let qty = this.haskey(r, 'rs.rewardsInfo.successRewards')
                p.log('领奖成功:', i.assignmentName, this.dumps(qty || {}).slice(0, 120))
                return true
            }
            p.log(`领奖失败: ${i.assignmentName} code=${code} msg=${this.haskey(r, 'msg') || ''}`)
        }
        return false
    }

    async main(p) {
        let user = p.data.user
        // 2026-10-22 实测: interaction 有滚动频控("队伍有点长"1714002), weGame 心跳是坏签名死重还会喂频控,
        // 全部拆除; 请求越少越稀, 通过率越高 (22:15 稀疏请求全链路通过)
        // 先访问任务页: 模拟 App webview 打开页面, Set-Cookie 回传养罐 (用户实锤方案)
        await this.rawGet(p, user, BB_PAGE, '')
        for (let round = 1; round <= 3; round++) {
            let tasks = await this.fetchTasks(p, user)
            if (!tasks || !tasks.length) return
            let done = 0
            let failStreak = 0
            for (const i of tasks) {
                if (i.completionFlag && +i.canReceiveTimes <= 0) { continue }
                let type = +i.assignmentType
                let name = i.assignmentName
                // 已完成可领奖 -> 领奖
                if (i.completionFlag && +i.canReceiveTimes > 0) {
                    await this.claim(p, user, i)
                    await this.wait(3000)
                    continue
                }
                // 浏览类(1)/关注(3)/加购(4)带 itemId 的走协议
                if ([1, 3, 4].includes(type) && i.timerId !== undefined) {
                    if (+i.completionCnt >= +i.assignmentTimesLimit) { continue }
                    p.log(`R${round} 做: ${name} (${i.completionCnt}/${i.assignmentTimesLimit})`)
                    if (await this.doBrowse(p, user, i)) { done++; failStreak = 0 }
                    else {
                        // 连续失败多为频控软拒, 继续逐个请求只会加深惩罚
                        failStreak++
                        if (failStreak >= 2) {
                            p.log('连续2个浏览任务失败, 判定频控, 本轮放弃剩余浏览')
                            break
                        }
                    }
                    await this.wait(8000)
                    continue
                }
                if (round === 1 && !i.completionFlag) {
                    p.log(`跳过(不支持协议): ${name} type=${type}`)
                }
            }
            if (!done && round > 1) break
            if (done) await this.wait(5000)
        }
    }
}
