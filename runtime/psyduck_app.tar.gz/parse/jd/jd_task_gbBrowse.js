// 国补超级补贴·浏览任务自动化 v3 (2026-10-17 部署版)
// 链路: rootSh 唤醒+深链拉起京东 → 28900 eval 校验活动页 → 截屏像素扫「查看奖励」→ senetap 内核级 tap 开弹窗
//   → 28900 dump 弹窗任务行 CSS 坐标 → senetap tap (css*3) → 跳转停留 22s → 返回 → 轮换 → signer 协议领奖
// 关键经验 (kb_jz133~146 真机验证):
//   - 插件进程无 su 授权, root 操作必须走 /data/user/0/com.psyduck.jdtask/files/cmd.req 文件协议
//     (jdtask_exec.sh 常驻 root 执行器消费, PID 见 /data/adb/jdtask_exec.pid)
//   - root 直调 input 服务被拒: tap 走 /sdcard/jdtask_senetap.sh sendevent 内核注入(自带抖动),
//     keyevent 降权 su 2000 执行
//   - JS touch+click 派发对部分任务行无效, 物理 tap (css坐标*3) 全有效
//   - 弹窗行做完即隐藏轮换补位, 需多任务名列表轮询挑第一个可见行
//   - 「查看奖励」原生楼层按钮 y 随页面加载漂移 ±300px, 必须现截屏现扫描现 tap
//   - 跳转落地页多变 (ProductDetail/FloatView/Babel), 每轮校验活动 ID 重导航
//   - waitDuration 最大 20s, 停留统一取 22s 确保服务端计数
import {Template} from '../../template.js'
import fs from 'fs'
import net from 'net'
import https from 'https'

const APP = '/data/user/0/com.psyduck.jdtask/files'
const GB_PAGE = 'https://pro.m.jd.com/mall/active/DvFPmKRas9GYjDPZjT9NT14BAv6/index.html?babelChannel=ttt131&mainChannel=1&billionSign=1'
const GB_ID = 'DvFPmKRas9GYjDPZjT9NT14BAv6'
const GB_CK = APP + '/rt/psyduck/cookie/jd.ini'
const RAW = APP + '/rt/tmp/gb_scan.bin'
const SCREEN_W = 1080, SCREEN_H = 2400
const TASKS = ['点击3个商品', '点击5个商品', '逛天天赚现金', '每日签到', '逛新奇集市', '逛更多优选会场', '逛会场', '逛频道', '逛']
const GB_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.0.0 Mobile Safari/537.36'
const GB_REF = GB_PAGE

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '国补浏览任务',
            turn: 1,
            crontab: 5,
            model: 'user'
        }
        this.ck = ''
        this._signer = null
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(GB_CK, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._ck()
    }
    _ck() {
        if (this.ck) return this.ck
        try {
            const txt = fs.readFileSync(GB_CK, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const c = mainCk || any
            this.ck = c && guid ? guid + ';' + c : (c || '')
        } catch (e) { }
        return this.ck
    }

    async signer() {
        if (!this._signer) {
            try { this._signer = await import('./jd_signer_node.mjs') } catch (e) { }
        }
        return this._signer
    }

    gCurl(fid, bodyObj) {
        return new Promise(async resolve => {
            const sg = await this.signer()
            const ck = this._ck()
            if (!sg || !ck) return resolve(null)
            let post = ''
            try {
                const signed = sg.sign({
                    functionId: fid, body: bodyObj, ck,
                    appId: '2e500',
                    base: {appid: 'SecKill2020', client: 'android', clientVersion: '15.10.50'}
                })
                const f = new URLSearchParams()
                for (const k in signed) f.append(k, String(signed[k]))
                post = f.toString()
            } catch (e) { return resolve(null) }
            const rq = https.request({
                hostname: 'api.m.jd.com',
                path: '/?area=16_1315_3489_46816&clientVersion=15.10.50&client=android&loginType=2&appid=SecKill2020&d_model=IN2010&d_brand=OnePlus&model=IN2010&osVersion=13&uuid=3303461326131633-2313731633939346&functionId=' + fid,
                method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: GB_REF, 'user-agent': GB_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { let o = null; try { o = JSON.parse(d) } catch (e) { } resolve(o) })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    // ---- root 文件协议 (jdtask_exec.sh: cmd.req 消费 → cmd.sh root 执行 → cmd.out 回写) ----
    async rootSh(cmd, to = 15000) {
        const t0 = Date.now()
        try {
            fs.writeFileSync(APP + '/cmd.sh', cmd)
            try { fs.rmSync(APP + '/cmd.out') } catch (e) { }
            fs.writeFileSync(APP + '/cmd.req', '')
            while (Date.now() - t0 < to) {
                await this.wait(250)
                if (!fs.existsSync(APP + '/cmd.req') && fs.existsSync(APP + '/cmd.out')) {
                    return fs.readFileSync(APP + '/cmd.out', 'utf8')
                }
            }
        } catch (e) { }
        return ''
    }

    tap(x, y) { return this.rootSh(`sh /sdcard/jdtask_senetap.sh ${Math.round(x)} ${Math.round(y)}`, 8000) }

    key(k) { return this.rootSh(`su 2000 -c "input keyevent ${k}"`, 8000) }

    async focus() {
        const o = await this.rootSh('dumpsys window 2>/dev/null | grep mCurrentFocus', 8000)
        const m = String(o).match(/u0 ([^ }]+)/)
        return m ? m[1] : ''
    }

    async wakeUp() {
        await this.rootSh('su 2000 -c "input keyevent KEYCODE_WAKEUP"; sleep 1; su 2000 -c "input keyevent 82"', 12000)
        await this.wait(2000)
    }

    async launchApp() {
        const dl = 'openapp.jdmobile://virtual?params=' + encodeURIComponent(JSON.stringify({category: 'jump', des: 'm', url: GB_PAGE}))
        await this.rootSh(`am start -a android.intent.action.VIEW -d '${dl}' >/dev/null 2>&1`, 10000)
        await this.wait(12000)
    }

    async wait(ms) { return new Promise(r => setTimeout(r, ms)) }

    async evalJs(js, to = 22000) {
        const r = await this.rpc({cmd: 'eval', js}, to)
        return r && r.ok ? r.result : null
    }

    rpc(cmd, timeoutMs = 25000) {
        return new Promise(resolve => {
            const s = net.connect(28900, '127.0.0.1', () => s.write(JSON.stringify(cmd) + '\n'))
            let buf = ''
            s.on('data', d => { buf += d.toString(); if (buf.includes('\n')) { try { s.end() } catch (e) { } try { resolve(JSON.parse(buf.trim())) } catch (e) { resolve({ok: false}) } } })
            s.on('error', () => resolve({ok: false}))
            setTimeout(() => { try { s.destroy() } catch (e) { }; resolve({ok: false}) }, timeoutMs)
        })
    }

    haskey(o, path) {
        try { const ks = path.split('.'); let c = o; for (const k of ks) c = c[k]; return c } catch (e) { return undefined }
    }

    async modalOn() {
        const c = await this.evalJs(`(function(){try{return document.documentElement.outerHTML.indexOf('恭喜获得惊喜福利')>=0?'M':'N'}catch(e){return 'E'}})()`, 12000)
        return c === 'M'
    }

    async waitModal(sec) {
        const rounds = Math.ceil(sec / 0.9)
        for (let i = 0; i < rounds; i++) {
            if (await this.modalOn()) return true
            await this.wait(900)
        }
        return false
    }

    // 截屏像素扫描「查看奖励」橙色描边按钮 (x 160-380, w 150-200, h 25-130, y 500-1300)
    async scanEntry() {
        try {
            await this.rootSh(`mkdir -p ${APP}/rt/tmp; screencap ${RAW}`, 15000)
            if (!fs.existsSync(RAW)) return null
            const buf = fs.readFileSync(RAW)
            const off = buf.length - SCREEN_W * SCREEN_H * 4
            if (off < 0 || off > 64) return null
            const isOrange = i => { const r = buf[off + i], g = buf[off + i + 1], b = buf[off + i + 2]; return r > 210 && g > 60 && g < 175 && b < 115 && (r - b) > 105 }
            const rows = []
            for (let y = 500; y < 1300; y++) {
                let cnt = 0
                for (let x = 100; x < 430; x++) if (isOrange((y * SCREEN_W + x) * 4)) cnt++
                if (cnt > 15) rows.push(y)
            }
            if (!rows.length) return null
            const bands = []
            for (const y of rows) {
                const l = bands[bands.length - 1]
                if (l && y - l[1] <= 4) l[1] = y
                else bands.push([y, y])
            }
            for (const [y1, y2] of bands) {
                const h = y2 - y1 + 1
                if (h < 25 || h > 130) continue
                let minX = SCREEN_W, maxX = 0
                for (let y = y1; y <= y2; y++) for (let x = 100; x < 430; x++) if (isOrange((y * SCREEN_W + x) * 4)) { if (x < minX) minX = x; if (x > maxX) maxX = x }
                const w = maxX - minX + 1
                if (w >= 150 && w <= 200 && minX >= 160 && maxX <= 380) return {x: Math.round((minX + maxX) / 2), y: Math.round((y1 + y2) / 2)}
            }
            return null
        } catch (e) { return null }
    }

    async ensureModal(p) {
        if (await this.waitModal(2)) return true
        const pt = await this.scanEntry()
        if (pt) await this.tap(pt.x, pt.y)
        else await this.tap(270, 810)
        p.log('[弹窗] tap 入口', pt ? pt.x + ',' + pt.y : '盲探')
        return this.waitModal(6)
    }

    async navHome(p) {
        await this.evalJs(`location.href='${GB_PAGE}&t=' + Date.now();'NAV'`, 10000)
        await this.wait(6000)
    }

    // dump 弹窗内所有「去看看」按钮 CSS 坐标 + 任务名
    async dumpButtons() {
        const r = await this.evalJs(`(function(){
var all = document.querySelectorAll('*');
var out = [];
for (var i = 0; i < all.length; i++) {
  var el = all[i], t = (el.textContent || '').trim();
  if (!/^(去看看|去完成|去逛逛)$/.test(t)) continue;
  var r0 = el.getBoundingClientRect();
  if (r0.width < 30 || r0.height < 15) continue;
  var root = el, name = '';
  for (var up = 0; up < 6 && root; up++) {
    var tt = (root.textContent || '').replace(/\\s+/g, '');
    if (tt.length > 8) { name = tt.slice(0, 16); break }
    root = root.parentElement;
  }
  out.push({x: Math.round(r0.x + r0.width / 2), y: Math.round(r0.y + r0.height / 2), name: name});
}
return JSON.stringify(out.slice(0, 12));
})()`, 20000)
        if (!r) return []
        try { return JSON.parse(r) } catch (e) { return [] }
    }

    scrollTop() {
        return this.evalJs(`(function(){var all=document.querySelectorAll('*');for(var i=0;i<all.length;i++){var el=all[i],st=getComputedStyle(el);if((st.overflowY==='auto'||st.overflowY==='scroll')&&el.scrollHeight>el.clientHeight+80&&el.clientHeight>200){var r=el.getBoundingClientRect();if(r.height>250&&r.y>50)el.scrollTop=0}}})()`, 15000)
    }

    async claimAll(p) {
        const tl = await this.gCurl('common_task_list', {channelId: '7', babelChannel: 'ttt131', activityId: '01425483', ext: {channel: 0, queryReceiveTimes: 1}})
        const tasks = this.haskey(tl, 'data.result.taskInfo.taskList') || []
        let got = 0
        for (const t of tasks) {
            if (!t || t.assignmentType === 2) continue
            if (!(t.canReceiveTimes > 0)) continue
            const name = t.assignmentName || ''
            const act = (t.ext && t.ext.shoppingActivity || [])[0] || {}
            const itemId = act.itemId || t.itemId || ''
            if (!itemId) { p.log('[领]跳过无itemId:', name); continue }
            const r = await this.gCurl('common_do_task', {channelId: '7', itemId, assignmentId: t.encryptAssignmentId, actionType: 0, ext: {doReceiveRewards: 1}})
            const ri = this.haskey(r, 'data.result.rewardsInfo')
            let beans = 0
            try { for (const k of Object.keys(ri || {})) { const arr = Array.isArray(ri[k]) ? ri[k] : []; for (const it of arr) if (it && it.quantity) beans += Number(it.quantity) || 0 } } catch (e) { }
            if (beans > 0) { got += beans; p.info.work = true; p.award(beans, 'bean') }
            p.log('[领]', name, this.haskey(r, 'data.bizMsg') || '?', beans ? '+' + beans + '豆' : '')
            await this.wait(1500)
        }
        p.log('浏览任务领取合计:', got, '豆')
    }

    async main(p) {
        // 前置: 唤醒屏幕 + 深链拉起京东国补页 (5点定时场景京东可能不在前台)
        let f = await this.focus()
        if (!f.includes('jingdong.app.mall')) {
            p.log('[启动] 京东不在前台, 唤醒+深链拉起')
            await this.wakeUp()
            await this.launchApp()
            f = await this.focus()
        }
        if (!f.includes('jingdong.app.mall')) { p.log('[中断] 京东拉起失败:', f); return }

        const ROUNDS = 10
        let did = 0
        for (let round = 1; round <= ROUNDS; round++) {
            try {
                p.log(`===== 第 ${round}/${ROUNDS} 轮 =====`)
                const cur = await this.focus()
                if (!cur.includes('jingdong.app.mall')) { p.log('[中断] 京东不在前台:', cur); break }
                const u = await this.evalJs(`location.href.slice(0, 80)`, 12000)
                if (!u || !String(u).includes(GB_ID)) { p.log('[导航] 页面不对, 回国补页'); await this.navHome(p) }
                if (!(await this.ensureModal(p))) {
                    await this.navHome(p)
                    if (!(await this.ensureModal(p))) { p.log('[弹窗] 打不开, 结束本轮'); break }
                }
                await this.wait(1200)
                await this.scrollTop()
                await this.wait(800)
                // 只挑未完成行 (进度 n<m), 可见区没有就下翻列表找, 最多翻 5 屏
                let pick = null
                for (let hunts = 0; hunts < 5 && !pick; hunts++) {
                    const btns = await this.dumpButtons()
                    const pool = btns.filter(b => { const m = String(b.name).match(/\((\d+)\/(\d+)/); return !m || +m[1] < +m[2] })
                    for (const tk of TASKS) { pick = pool.find(b => b.name.includes(tk)); if (pick) break }
                    if (!pick && pool.length) pick = pool[0]
                    if (pick) break
                    const sr = await this.evalJs(`(function(){var all=document.querySelectorAll('*');for(var i=0;i<all.length;i++){var el=all[i],st=getComputedStyle(el);if((st.overflowY==='auto'||st.overflowY==='scroll')&&el.scrollHeight>el.clientHeight+80&&el.clientHeight>200){var r=el.getBoundingClientRect();if(r.height>250&&r.y>50){el.scrollTop+=450;return 'S'}}}return 'N'})()`, 15000)
                    if (sr !== 'S') break
                    p.log('[行] 可见行全完成, 下翻找 #' + (hunts + 1))
                    await this.wait(900)
                }
                if (!pick) { p.log('[行] 无未完成任务行, 收工'); break }
                p.log('[触发]', pick.name.slice(0, 14), 'css=(' + pick.x + ',' + pick.y + ')')
                await this.tap(pick.x * 3, pick.y * 3)
                let jumped = false
                for (let i = 0; i < 15; i++) {
                    await this.wait(1000)
                    const f2 = await this.focus()
                    if (!f2.includes('TTTMultiPage')) { jumped = true; p.log('[跳转]', f2.split('/').pop()); break }
                }
                if (!jumped) { p.log('[跳转] 未发生, 下一轮'); await this.wait(2500); continue }
                await this.wait(22000)
                await this.key(4)
                await this.wait(2500)
                const f3 = await this.focus()
                if (!f3.includes('TTTMultiPage') && !f3.includes('WebActivity')) { await this.key(4); await this.wait(2500) }
                p.log('[返回]', (await this.focus()).split('/').pop())
                did++
                await this.wait(2000)
            } catch (e) {
                p.log('[轮]异常:', String(e && e.message || e).slice(0, 80))
                await this.wait(3000)
            }
        }
        p.log('浏览轮数:', did, ', 查询领奖')
        await this.claimAll(p)
        p.info.work = true
    }
}
