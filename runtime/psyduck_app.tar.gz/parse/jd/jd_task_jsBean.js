import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const JS_PAGE = 'https://pro.m.jd.com/mall/active/G7sQ92vWSBsTHzk4e953qUGWQJ4/index.html'
const JS_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东特价限时惊喜',
            crontab: 3,
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/G7sQ92vWSBsTHzk4e953qUGWQJ4/index.html'
            },
            interval: 6000,
            readme: ['黑号没豆'],
            sync: 1,
            verify: true,
            prompt: {
                assignmentId: "活动id"
            }
        }
    }

    async prepare() {
        await this.field('assignmentId')
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _jsCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._jsCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean/wBean 模式)
    async jsCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._jsSigner) {
            try { this._jsSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._jsSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._jsSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'newtry', client: getv('client') || 'apple', clientVersion: getv('clientVersion') || '15.2.0'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: JS_PAGE, 'user-agent': JS_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        await this.curl({
                'url': `https://pro.m.jd.com/mall/active/G7sQ92vWSBsTHzk4e953qUGWQJ4/index.html`,
                user
            }
        )
        let a = await this.jsCurl({
                'form': `clientVersion=15.2.0&client=apple&loginType=2&t=1762614551397&appid=newtry&xAPIClientLanguage=zh_CN&functionId=common_do_task&body={"channelId":"20","itemId":"1","assignmentId":"${context.assignmentId}","actionType":"0","ext":{"queryReceiveTimes":1},"extMap":{"sceneType":1,"babelChannel":"ttt113"}}`,
                user,
                algo: {
                    appId: '35fa0'
                }
            }
        )
        if (this.haskey(a, 'data.bizCode', 103)) {
            p.info.work = true
            p.log("已领取过奖励")
            return
        }
        let r = await this.jsCurl({
                'form': `clientVersion=15.2.0&client=apple&loginType=2&t=1762614551397&appid=newtry&xAPIClientLanguage=zh_CN&functionId=common_do_task&body={"channelId":"20","itemId":"1","assignmentId":"${context.assignmentId}","actionType":"0","ext":{"queryReceiveTimes":1,"doReceiveRewards":1},"extMap":{"sceneType":1,"babelChannel":"ttt113"}}`,
                user,
                algo: {
                    appId: '35fa0'
                }
            }
        )
        if (this.haskey(r, 'data.result.assignmentResult.rewardsInfo.successRewards')) {
            p.info.work = true
            for (let g in r.data.result.assignmentResult.rewardsInfo.successRewards) {
                let data = r.data.result.assignmentResult.rewardsInfo.successRewards[g]
                if (g == '4') {
                    for (let k of data) {
                        p.award(k.discount, 'redpacket')
                    }
                }
                else if (g == '8') {
                    for (let k of data) {
                        p.log(k.useRange, '优惠券')
                    }
                }
                else if (g == '3') {
                    for (let k of data) {
                        p.award(k.quantity, 'bean')
                    }
                }
                else {
                    for (let k of data) {
                        p.log(k)
                    }
                }
            }
        }
        else {
            p.log(`没有幸运奖励`)
        }
    }
}
