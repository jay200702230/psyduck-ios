import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

// 京东秒杀频道「下单返豆」签到 + 浏览任务 (checkInTask 系, JDHOME_TARO, h5st 35c10)
// 页面: jpeZLX5Lb3gpwH98tAaB8Y1HY99; 执行: checkInTaskDo actionType=1 发起 / 0 返回领奖
const MIAO_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.0.0 Mobile Safari/537.36'
const MIAO_REF = 'https://pro.m.jd.com/mall/active/jpeZLX5Lb3gpwH98tAaB8Y1HY99/index.html?mTabId=jpeZLX5Lb3gpwH98tAaB8Y1HY99&babelChannel=ttt1&source=4'
const MIAO_CK = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东秒杀签到',
            turn: 1,
            crontab: 3,
            model: 'user'
        }
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(MIAO_CK, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._mCk()
    }
    _mCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(MIAO_CK, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    async miaoCurl(fid, bodyObj) {
        if (!this._mSigner) {
            try { this._mSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._mSigner) return null
        const ck = this._mCk()
        if (!ck) return null
        const signed = this._mSigner.sign({
            functionId: fid, body: bodyObj, ck,
            appId: '35c10',
            base: {appid: 'JDHOME_TARO', client: 'android', clientVersion: '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fid, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: 'https://pro.m.jd.com', referer: MIAO_REF, 'user-agent': MIAO_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {}
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async prepare() {
        this.lbs = {
            gcLat: 24.576403, gcLng: 118.230367,
            lbsParamMap: {
                svcType: '', lbsLng: '118.10442505642247', lbsLat: '24.518401170085063',
                provinceId: 16, cityId: 1315, countyId: 3486, townId: 59642
            },
            supportNewChannel: '2',
            checkInTaskParamMap: {requestScene: 0},
            extMap: {linkages: '[{"ruleId":"67","semiElasticLayer":false,"type":"11"}]'},
            source: '4'
        }
    }

    // 领奖解析: rewardsList/prizeList 里京豆合计
    _beansOf(res) {
        let n = 0
        const lists = []
        try {
            if (res && res.rewardsList) lists.push(res.rewardsList)
            if (res && res.failRewardsList) lists.push(res.failRewardsList)
            for (const arr of lists) {
                for (const it of arr || []) {
                    if (it && it.rewardType === 3 && it.rewardValue) n += Number(it.rewardValue) || 0
                }
            }
        } catch (e) {}
        return n
    }

    async main(p) {
        let user = p.data.user
        const list = await this.miaoCurl('checkInTaskList', this.lbs)
        if (!list || String(list.code) !== '0') {
            p.log('任务池异常:', this.dumps(list).slice(0, 120))
            return
        }
        const signTasks = list.checkInTaskList || []
        const browseTasks = list.browseTaskList || []
        let got = 0

        // 签到: actionType=0 直接领
        for (const t of signTasks) {
            if (t && t.encryptAssignmentId && !t.todayCheckIn) {
                let r = await this.miaoCurl('checkInTaskDo', {
                    checkInTaskParamMap: {
                        encryptAssignmentId: t.encryptAssignmentId, actionType: 0,
                        itemId: t.itemId || '', jumpUrl: t.jumpUrl || '', requestScene: 0
                    }
                })
                const b = this._beansOf(r)
                if (b > 0) { got += b; p.log('签到成功 +' + b + '豆') }
                else p.log('签到:', this.haskey(r, 'msg') || this.dumps(r).slice(0, 100))
            } else if (t && t.encryptAssignmentId) {
                p.log('今日已签到')
            }
        }

        // 浏览任务: 发起(含subTaskList的tasktoken/itemId) → 等9s → 领奖; 看视频/邀请类上游拒=硬边界
        for (const t of browseTasks) {
            if (!t || !t.encryptAssignmentId) continue
            const sub = (t.subTaskList && t.subTaskList[0]) || {}
            const realItemId = sub.itemId || t.itemId || ''
            const realJumpUrl = sub.jumpUrl || sub.url || t.jumpUrl || ''
            const paramMap = {
                encryptAssignmentId: t.encryptAssignmentId,
                itemId: realItemId, jumpUrl: realJumpUrl, requestScene: 0
            }
            if (sub.tasktoken) paramMap.tasktoken = sub.tasktoken
            const st1 = await this.miaoCurl('checkInTaskDo', {checkInTaskParamMap: {...paramMap, actionType: 1}})
            if (st1 && String(this.haskey(st1, 'resultCode') || '') !== '0') p.log('[发起]' + (this.haskey(st1, 'message') || this.dumps(st1).slice(0, 80)))
            await this.wait(9000)
            let r = await this.miaoCurl('checkInTaskDo', {checkInTaskParamMap: {...paramMap, actionType: 0}})
            const b = this._beansOf(r)
            if (b > 0) { got += b; p.log('[' + (t.assignmentName || t.encryptAssignmentId.slice(0, 8)) + '] +' + b + '豆') }
            else p.log('[' + (t.assignmentName || t.encryptAssignmentId.slice(0, 8)) + ']:', this.haskey(r, 'msg') || this.dumps(r).slice(0, 100))
        }

        // 复查: 未领完的再拉一次列表补领
        const list2 = await this.miaoCurl('checkInTaskList', this.lbs)
        const left = (list2 && (list2.browseTaskList || [])).length || 0
        if (got > 0) {
            p.info.work = true
            p.award(got, 'bean')
        }
        p.log('秒杀签到完成, 剩余浏览任务:', left)
    }
}
