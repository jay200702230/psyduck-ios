import fs from 'fs'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/3rCAkWwuxMbX5ptVJr6bKTq8j6bn/index.html'
const LK = '6l8gLCDM8lvssBmaBPCvzQ'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
globalThis.__signerUa = UA

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '王牌秒杀任务', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // 无签名族: activities_platform + h5st=null
    async wg(p, user, fn, bodyObj, retries) {
        for (let k = 1; k <= (retries || 2); k++) {
            try {
                const ck = this._ckForUser(user)
                if (!ck) { p.log('no ck'); return null }
                const f = new URLSearchParams()
                f.append('functionId', fn)
                f.append('body', JSON.stringify(bodyObj))
                f.append('t', String(Date.now()))
                f.append('appid', 'activities_platform')
                f.append('client', 'android')
                f.append('clientVersion', '15.10.50')
                f.append('platform', '3'); f.append('loginType', '2'); f.append('loginWQBiz', 'wegame')
                f.append('h5st', 'null')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: W_PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 120))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    async getList(p, user) {
        const r = await this.wg(p, user, 'apTaskList', {linkId: LK, queryType: 0, channel: 4, area: '0_0_0_0'}, 2)
        let d = (r || {}).data || []
        if (!Array.isArray(d)) d = []
        return d.map(t => ({
            id: t.id,
            n: t.taskShowTitle || t.taskTitle || '',
            lim: t.taskLimitTimes || 1,
            done: t.taskDoTimes || 0,
            fin: !!t.taskFinished,
            url: t.taskSourceUrl || t.taskUrl || t.taskJumpUrl || (t.taskExt || {}).jumpUrl || (t.ext || {}).jumpUrl || '',
            aid: (t.pipeExt || {}).assignmentId || ''
        }))
    }

    async detail(p, user, tid) {
        const r = await this.wg(p, user, 'apTaskDetail', {taskType: 'BROWSE_CHANNEL', taskId: tid, channel: 4, checkVersion: true, linkId: LK}, 1)
        const d = (r || {}).data || {}
        let items = d.taskItemList || []
        let fallbackUrl = ''
        if (!items.length) {
            const sj = JSON.stringify(d)
            const i = sj.indexOf('http')
            if (i >= 0) {
                let j = i
                while (j < sj.length && sj[j] !== '"' && sj[j] !== '\\') j++
                fallbackUrl = sj.slice(i, j)
            }
        }
        return {
            items,
            times: ((d.status || {}).userFinishedTimes) || 0,
            need: ((d.status || {}).finishNeed) || 1,
            fin: !!((d.status || {}).finished),
            fallbackUrl
        }
    }

    // 计时浏览(实弹定性): apStartTaskTime code=1/success:false 也是受理成功, 服务端真在计时;
    // 等 11s 后 apDoLimitTimeTask 结算(2031=未到时/已结, 无害), 以 detail 复查为准
    async doBrowse(p, user, t, itemIdEnc, pipeItemId) {
        const pipe = {taskType: 'BROWSE_CHANNEL', timeLimitSwitch: 1, assignmentId: t.aid}
        if (pipeItemId) pipe.itemId = pipeItemId
        const r1 = await this.wg(p, user, 'apStartTaskTime', {linkId: LK, taskId: t.id, itemId: itemIdEnc, taskInsert: false, channel: 4, pipeExt: pipe, actFlowCode: 'apStartTaskTime'}, 1)
        const c1 = String((r1 || {}).code)
        if (c1 !== '0' && c1 !== '1' && c1 !== 'undefined') {
            p.log('  受理拒(' + c1 + ')', t.n)
            this._fails++
            return false
        }
        await this.wait(11500)
        await this.wg(p, user, 'apDoLimitTimeTask', {linkId: LK, actFlowCode: 'apDoLimitTimeTask'}, 1)
        await this.wait(3000)
        return true
    }

    async main(p) {
        const user = p.data.user
        const t0 = Date.now()
        const BUDGET = 10 * 60 * 1000   // 10 分钟硬预算, 防截断
        const CAP = 25                  // 全局浏览动作总闸
        let acts = 0
        const stickyFail = new Set()    // 做了却不计次的卡, 本轮运行内不再碰
        for (let round = 0; round < 6; round++) {
            const tasks = await this.getList(p, user)
            const todo = tasks.filter(t => !t.fin && !stickyFail.has(t.id))
            if (!todo.length) { p.log('王牌秒杀任务全达标'); break }
            if (Date.now() - t0 > BUDGET || acts >= CAP) { p.log('预算/闸门到, 提前收工'); break }
            let acted = 0
            for (const t of todo) {
                if (Date.now() - t0 > BUDGET || acts >= CAP) { p.log('预算/闸门到, 提前收工'); break }
                p.log('做:', t.n)
                const dd = await this.detail(p, user, t.id)
                if (dd.fin) continue
                const items = dd.items.filter(x => x && x.itemId)
                if (!items.length && !dd.fallbackUrl && !t.url) { p.log('  无子项无URL, 跳过', t.n); continue }
                if (t.aid && (items.length || dd.fallbackUrl || t.url)) {
                    let guard = 0
                    let times = dd.times, need = dd.need
                    let countedBefore = times
                    while (times < need && guard++ < 10 && acts < CAP && Date.now() - t0 < BUDGET) {
                        const it = items[times % Math.max(items.length, 1)] || {}
                        const rawUrl = it.itemId || dd.fallbackUrl || t.url
                        const pipeItem = (it.pipeExt || {}).itemId
                        await this.doBrowse(p, user, t, encodeURIComponent(rawUrl), pipeItem)
                        acts++; acted++
                        const dd2 = await this.detail(p, user, t.id)
                        times = dd2.times
                        need = dd2.need || need
                        if (dd2.fin) break
                        await this.wait(2000)
                    }
                    if (times >= need) p.log('  达标:', t.n, times + '/' + need)
                    else if (times <= countedBefore) { p.log('  不计次, 本轮剔除:', t.n); stickyFail.add(t.id) }
                }
                await this.wait(3000)
            }
            if (!acted) break
        }
        const tasks = await this.getList(p, user)
        const pend = tasks.filter(t => !t.fin).map(t => t.n)
        p.log(pend.length ? '未清: ' + pend.join(',') : '王牌秒杀 7 卡全清')
        p.info.work = this._fails === 0
    }
}
