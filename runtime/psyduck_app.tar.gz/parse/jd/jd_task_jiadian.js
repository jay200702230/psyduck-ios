import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东家电家居超级抓抓机',
            crontab: 3,
            help: 'main',
            sync: 1,
            verify: 1
        }
    }

    async prepare() {
        for (let user of this.help) {
            let itemId = await this.getTemp(user)
            if (itemId) {
                this.dict[user] = itemId
            }
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let info = await this.autoCurl({
                'form': `appid=home-channel&functionId=queryInteractiveInfo&body={"encryptProjectId":"${context.encryptProjectId}","sourceCode":"ace454250"}&clientVersion=15.1.1`,
                user,
                algo: {
                    appId: "74333"
                }
            }
        )
        let lotteryId = null
        let status = 1
        for (let i of this.haskey(info, 'assignmentList')) {
            if (i.completionFlag) {
                p.log(`任务已经完成: ${i.assignmentName}`)
            }
            else if (i.assignmentName.includes("邀请")) {
                if (this.haskey(i, 'ext.assistTaskDetail.itemId')) {
                    await this.setTemp(user, i.ext.assistTaskDetail.itemId, 10000000)
                }
                let users = Object.keys(this.dict)
                if (users) {
                    let itemId = ''
                    let u = users[this.n % users.length]
                    this.n++
                    if (u == user) {
                        u = users[this.n % users.length]
                    }
                    itemId = this.dict[u]
                    let help = await this.autoCurl({
                            'form': `appid=home-channel&functionId=home.zzj.DoTask.finishTask&body={"encryptAssignmentId":"${i.encryptAssignmentId}","itemId":"${itemId}","encryptProjectId":"${context.encryptProjectId}"}&clientVersion=15.1.1`,
                            user,
                            algo: {
                                appId: '74333',
                                expire: {
                                    "code": 3,
                                }
                            }
                        }
                    )
                }
            }
            else if (i.assignmentName == '抓抓机') {
                lotteryId = i.encryptAssignmentId
            }
            else if (i.assignmentDesc.match(/duihuan/)) {
            }
            else if (i.assignmentName.match(/国补|首页|补贴/)) {
            }
            else {
                status = 0
                p.log(`正在运行: ${i.assignmentName}`)
                if ([0, 3, 4, 1].includes(i.assignmentType)) {
                    let extraType = i.ext.extraType
                    if (this.haskey(i, `ext.${i.ext.extraType}`)) {
                        let extra = i.ext[extraType]
                        if (extraType == 'sign1') {
                            status = 1
                        }
                        else if (extraType == 'assistTaskDetail') {
                            status = 1
                        }
                        else {
                            for (let j of extra.slice(0, i.assignmentTimesLimit)) {
                                if (['shoppingActivity', 'productsInfo', 'browseShop', 'addCart', 'followShop', 'followChannel'].includes(extraType)) {
                                    if (j.biclk) {
                                        let wait = Math.max(...[parseInt(this.match(/\d+/, j.biclk) || 1) + 1, 6])
                                        let doIt = await this.autoCurl({
                                                url: "https://api.m.jd.com/client.action?functionId=home.zzj.DoTask.finishTask",
                                                'form': `appid=home-channel&functionId=home.zzj.DoTask.finishTask&body=${this.dumps(
                                                    {
                                                        "encryptAssignmentId": i.encryptAssignmentId,
                                                        "itemId": j.itemId,
                                                        "actionType": 1,
                                                        "ext": {"jumpUrl": encodeURIComponent(j.url)},
                                                        "encryptProjectId": context.encryptProjectId,
                                                    }
                                                )}&clientVersion=15.1.1`,
                                                user, algo: {
                                                    appId: '74333',
                                                    expire: {
                                                        "code": 3,
                                                    },
                                                    error: {
                                                        code: 10003,
                                                    },
                                                }
                                            }
                                        )
                                        p.log(`正在等待: ${wait}秒`)
                                        await this.wait(wait * 1000)
                                    }
                                    let fi = await this.autoCurl({
                                            url: "https://api.m.jd.com/client.action?functionId=home.zzj.DoTask.finishTask",
                                            'form': `appid=home-channel&functionId=home.zzj.DoTask.finishTask&body=${this.dumps(
                                                {
                                                    "encryptAssignmentId": i.encryptAssignmentId,
                                                    "itemId": j.itemId, "ext": {"jumpUrl": encodeURIComponent(j.url)},
                                                    "encryptProjectId": context.encryptProjectId
                                                }
                                            )}&clientVersion=15.1.1`,
                                            user, algo: {
                                                appId: '74333',
                                                expire: {
                                                    "code": 3,
                                                },
                                                error: {
                                                    code: 10003,
                                                },
                                            }
                                        }
                                    )
                                    if (this.haskey(fi, 'data.subCode', '1403')) {
                                        p.log(fi.data.msg)
                                        return
                                    }
                                    if (this.haskey(fi, 'code', 10003)) {
                                        p.log(fi.msg)
                                        break
                                    }
                                    p.log("获得金币:", this.haskey(fi, 'data.rewardsDetail'))
                                    status = 1
                                    await this.wait(1000)
                                }
                            }
                        }
                    }
                    else {
                        let fi = await this.autoCurl({
                                'url': `https://api.m.jd.com/client.action?functionId=home.zzj.DoTask.finishTask`,
                                'form': `appid=home-channel&functionId=home.zzj.DoTask.finishTask&body=${this.dumps(
                                    {
                                        "encryptAssignmentId": i.encryptAssignmentId,
                                        "itemId": 1,
                                        "encryptProjectId": context.encryptProjectId
                                    }
                                )}&clientVersion=15.1.1`,
                                user,
                                algo: {
                                    appId: '74333',
                                    expire: {
                                        "code": 3,
                                    },
                                    error: {
                                        code: 10003,
                                    }
                                }
                            }
                        )
                        if (this.haskey(fi, 'data.subCode', '1403')) {
                            p.log(fi.data.msg)
                            return
                        }
                        if (this.haskey(fi, 'code', 10003)) {
                            p.log(fi.msg)
                            break
                        }
                        p.log("获得金币:", this.haskey(fi, 'data.rewardsDetail'))
                        status = 1
                    }
                }
                else {
                    // console.log(i)
                    let fi = await this.autoCurl({
                            'url': `https://api.m.jd.com/client.action`,
                            'form': `appid=home-channel&functionId=home.zzj.DoTask.finishTask&body=${this.dumps(
                                {
                                    "encryptAssignmentId": i.encryptAssignmentId,
                                    "itemId": 1,
                                    "encryptProjectId": context.encryptProjectId
                                }
                            )}&clientVersion=15.1.1`,
                            user, algo: {
                                appId: '74333',
                                expire: {
                                    "code": 3,
                                },
                                error: {
                                    code: 10003,
                                }
                            }
                        }
                    )
                    if (this.haskey(fi, 'data.subCode', '1403')) {
                        p.log(fi.data.msg)
                        return
                    }
                    if (this.haskey(fi, 'code', 10003)) {
                        p.log(fi.msg)
                        break
                    }
                    p.log("获得金币:", this.haskey(fi, 'data.rewardsDetail'))
                    status = 1
                    await this.wait(1000)
                }
            }
        }
        if (status) {
            p.info.work = true
        }
    }
}

