import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东互动游戏赚京豆',
            pageUrl: "https://pro.m.jd.com/mall/active/3fcyrvLZALNPWCEDRvaZJVrzek8v/index.html",
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/3fcyrvLZALNPWCEDRvaZJVrzek8v/index.html'
            },
            crontab: 3
        }
    }

    async prepare() {
        this.shareCode({
            "linkId": "6ylwhxlv346dqlaytc911",
        })
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let home = await this.autoCurl({
                'url': `https://api.m.jd.com/api?functionId=interact_act_invoke`,
                'form': `functionId=interact_act_invoke&body={"envType":1,"linkId":"${context.linkId}","actFlowCode":"actLoad"}&t=1783006018142&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&&cthr=1`,
                user,
                algo: {
                    appId: 'a2b4f'
                }
            }
        )
        if (!this.haskey(home, 'data.data.progressList')) {
            p.err("没有获取到奖励数据...")
            return
        }
        let apTask = await this.autoCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `functionId=apTaskList&body={"linkId":"${context.linkId}","queryType":0,"channel":4,"area":"16_1342_1357_45750","platform":"lingxiao","actFlowCode":"apTaskList"}&t=1782944834837&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&imei=&aid=&openudid=&adid=&cthr=1`,
                user,
            }
        )
        let isOk
        // 池级熔断: 计时被服务端吞掉后, 后续 BROWSE 类任务同样会被吞, 直接跳过省得烧时间喂风控
        let browseFuse = false
        // console.log(apTask)
        for (let i of this.haskey(apTask, 'data.data')) {
            if (browseFuse && String(i.taskType).match("BROWSE")) {
                continue
            }
            if (i.taskLimitTimes == i.taskDoTimes) {
                p.log("任务已完成:", i.taskShowTitle)
            }
            else {
                isOk = 0
                p.log(`正在运行:`, i.taskTitle || i.subTitle, i.taskType)
                switch (i.taskType) {
                    case 'BROWSE_RTB':
                        for (let [k, it] of Object.entries(i.taskItemList)) {
                            let st = await this.autoCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                                    'form': `functionId=apStartTaskTime&body={"linkId":"${context.linkId}","taskId":${i.id},"itemId":"${encodeURIComponent(it.itemId)}","pipeExt":${this.dumps({...i.pipeExt, ...it.pipeExt})},"channel":4,"actFlowCode":"apStartTaskTime"}&t=1782944789757&appid=activity_platform_se&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                                    user,
                                    algo: {
                                        appId: 'acb1e'
                                    }
                                }
                            )
                            if (this.haskey(st, 'data.code', 0)) {
                                if (i.timeLimitPeriod) {
                                    p.log("正在等待:", i.timeLimitPeriod)
                                    await this.wait(i.timeLimitPeriod * 1000)
                                }
                                let tt = await this.autoCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                        'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}","actFlowCode":"apDoLimitTimeTask"}&t=1782944797199&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                                        user,
                                        algo: {
                                            appId: 'ebecc'
                                        }
                                    }
                                )
                                if (this.haskey(tt, 'data.data.alreadyGranted')) {
                                    p.log("浏览成功")
                                }
                                else {
                                    if (String(this.haskey(tt, 'errMsg') || '').includes('没有需要查询的计时任务')) {
                                        p.err("服务端未记录计时, 放弃后续浏览任务")
                                        browseFuse = true
                                    }
                                    else {
                                        p.err("浏览失败...")
                                    }
                                    break
                                }
                            }
                            else {
                                p.err("浏览错误...", JSON.stringify(st).slice(0, 130))
                                break
                            }
                        }
                        break
                    case 'BROWSE_CHANNEL':
                        let detail = await this.autoCurl({
                                'url': `https://api.m.jd.com/api?functionId=apTaskDetail`,
                                form: `functionId=apTaskDetail&body={"taskType":"${i.taskType}","taskId":-9999,"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"actFlowCode":"apTaskDetail"}&t=1782944864089&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&imei=&aid=&openudid=&adid=&cthr=1`,
                                user,
                            }
                        )
                        if (this.haskey(detail, 'data.data.taskItemList')) {
                            let til = detail.data.data.taskItemList
                            for (let j = detail.data.data.status.userFinishedTimes; j<detail.data.data.status.finishNeed; j++) {
                                let it = til[j]
                                p.log("正在浏览:", it.itemName)
                                let st = await this.autoCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                                        'form': `functionId=apStartTaskTime&body={"linkId":"${context.linkId}","taskId":${i.id},"itemId":"${encodeURIComponent(it.itemId)}","pipeExt":${this.dumps({...i.pipeExt, ...it.pipeExt})},"channel":4,"actFlowCode":"apStartTaskTime"}&t=1782944789757&appid=activity_platform_se&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                                        user,
                                        algo: {
                                            appId: 'acb1e'
                                        }
                                    }
                                )
                                if (this.haskey(st, 'data.code', 0)) {
                                    if (i.timeLimitPeriod) {
                                        p.log("正在等待:", i.timeLimitPeriod)
                                        await this.wait(i.timeLimitPeriod * 1000)
                                    }
                                    let tt = await this.autoCurl({
                                            'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                            'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}","actFlowCode":"apDoLimitTimeTask"}&t=1782944797199&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                                            user,
                                            algo: {
                                                appId: 'ebecc'
                                            }
                                        }
                                    )
                                    // console.log(this.dumps(tt))
                                    if (this.haskey(tt, 'data.data.finished')) {
                                        p.log("浏览成功")
                                    }
                                    else {
                                        if (String(this.haskey(tt, 'errMsg') || '').includes('没有需要查询的计时任务')) {
                                            p.err("服务端未记录计时, 放弃后续浏览任务")
                                            browseFuse = true
                                        }
                                        else {
                                            p.err("浏览失败...")
                                        }
                                        break
                                    }
                                }
                                else {
                                    p.err("浏览错误...", JSON.stringify(st).slice(0, 130))
                                    break
                                }
                            }
                        }
                        break
                }
            }
        }
        let load = await this.autoCurl({
                'url': `https://api.m.jd.com/api?functionId=interact_act_invoke`,
                'form': `functionId=interact_act_invoke&body={"envType":1,"linkId":"${context.linkId}","actFlowCode":"actLoad"}&t=1783006018142&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&&cthr=1`,
                user,
                algo: {
                    appId: 'a2b4f'
                }
            }
        )
        let ss
        for (let i of this.haskey(load, 'data.data.progressList')) {
            ss = 1
            if (i.status == 2) {
                p.log(`分数段: ${i.score} 已领取 ${i.amount} 京豆`)
            }
            else if (i.status == 1) {
                p.log(`正在领取分数段: ${i.score} 奖励`)
                let invoke = await this.autoCurl({
                        'url': `https://api.m.jd.com/api?functionId=interact_act_invoke`,
                        'form': `functionId=interact_act_invoke&body={"envType":1,"linkId":"${context.linkId}","actFlowCode":"recevieAward","stage":${i.stage}}&t=1783006018142&appid=activities_platform&client=ios&clientVersion=15.8.30&platform=3&loginType=2&loginWQBiz=wegame&xAPIScval2=lx&uuid=&build=170515&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&&cthr=1`,
                        user,
                        algo: {
                            appId: 'a2b4f'
                        }
                    }
                )
                if (this.haskey(invoke, 'data.data.sendResult')) {
                    if (invoke.data.data.prizeType == 3) {
                        p.award(invoke.data.data.amount, 'bean')
                    }
                    else {
                        p.log(invoke.data.data)
                    }
                }
                else {
                    ss = 0
                    p.err("奖励领取失败...")
                    break
                }
                await this.wait(1000)
            }
            else {
                ss = 0
            }
        }
        if (ss) {
            p.info.work = true
        }
    }
}

