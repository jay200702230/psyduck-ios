import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东有奖投票',
            crontab: 3,
            headers: {
                referer: "https://prodev.m.jd.com/mall/active/UCAYQxqQV3mKZNfu8bG2t8wsYog/index.html"
            },
        }
    }

    async prepare() {
        let today = new Date();
        let year = today.getFullYear();
        let month = String(today.getMonth() + 1).padStart(2, '0');
        let day = String(today.getDate()).padStart(2, '0');
        let dateStr = `${year}-${month}-${day}`;
        for (let user of await this.getTeam("main")) {
            let rank = await this.autoCurl({
                    form: `functionId=hc_activity_vote_queryActivityRanking&body={"activityId":"9","rankType":2,"subRankId":10,"rankingDay":"${dateStr}","pageNo":1,"pageSize":10}&appid=home-marketing&loginType=2&area=16_1342_1357_45750&gpsArea=0_0_0_0&client=apple&osVersion=15.1.1&networkType=wifi&d_model=iPhone13,3&d_brand=iPhone&screen=390*844&openudid=&clientVersion=15.9.30&ext={"activityId":"02174862","pageId":"6387623","moduleId":131767320,"encodeActivityId":"UCAYQxqQV3mKZNfu8bG2t8wsYog"}&t=1787300142139`,
                    user,
                    algo: {
                        appId: '91a93',
                    }
                }
            )
            if (this.haskey(rank, 'data.rankingInfoDtoList')) {
                this.code = rank.data.rankingInfoDtoList
                break
            }
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let info = await this.autoCurl({
                'form': `functionId=hc_activity_vote_queryInteractiveInfo&body={"activityId":"9"}&appid=home-marketing&loginType=2&area=16_1342_1357_45750&gpsArea=0_0_0_0&client=apple&osVersion=15.1.1&networkType=wifi&d_model=iPhone13,3&d_brand=iPhone&screen=390*844&openudid=&clientVersion=15.9.30`,
                user,
                algo: {
                    appId: '91a93',
                    expire: {
                        "code": 3,
                    }
                }
            }
        )
        let list = this.haskey(info, 'data.0.assignmentList') || []
        if (!list) {
            p.err("没有获取到任务列表")
            return
        }
        for (let i of list) {
            if (i.completionFlag) {
                p.log("任务完成:", i.assignmentName)
            }
            else if (i.assignmentName.includes("逛逛")) {
                let activity = i.ext.shoppingActivity
                for (let j = 0; j<(i.assignmentTimesLimit - i.completionCnt); j++) {
                    let data = activity[j]
                    p.log("正在浏览:", data.title)
                    let doIt = await this.autoCurl({
                            form: `functionId=hc_activity_vote_doInteractive&body={"type":4,"encryptAssignId":"${i.encryptAssignmentId}","itemId":"${data.itemId}","actionType":1,"jumpUrl":"${encodeURIComponent(data.url)}","activityId":"9"}&appid=home-marketing&loginType=2&area=16_1342_1357_45750&gpsArea=0_0_0_0&client=apple&osVersion=15.1.1&networkType=wifi&d_model=iPhone13%2C3&d_brand=iPhone&screen=390%2A844&openudid=&clientVersion=15.9.30&ext={"activityId":"02174862","pageId":"6387623","moduleId":131767320,"encodeActivityId":"UCAYQxqQV3mKZNfu8bG2t8wsYog"}&t=1787300211334`,
                            user,
                            algo: {
                                appId: '91a93'
                            }
                        }
                    )
                    if (this.haskey(doIt, 'code', 500)) {
                        p.err("活动火爆")
                        return
                    }
                    let suc = this.haskey(doIt, 'success')
                    if (suc) {
                        let taskUrl = this.match(/"taskUrl":"([^\"]+)"/, doIt.data.assignmentInfo.toUrl)
                        await this.autoCurl({
                                'url': taskUrl,
                                user
                            }
                        )
                        if (i.ext.waitDuration) {
                            p.log('正在等待: ', i.ext.waitDuration)
                            await this.wait(i.ext.waitDuration * 1000)
                        }
                        let award = await this.autoCurl({
                                url: `https://api.m.jd.com/api?functionId=hc_activity_vote_doInteractive`,
                                'form': `functionId=hc_activity_vote_doInteractive&body={"type":4,"encryptAssignId":"${i.encryptAssignmentId}","itemId":"${data.itemId}","actionType":0,"jumpUrl":"${encodeURIComponent(data.url.split("?")[0])}","activityId":"9"}&appid=home-marketing&loginType=2&area=16_1342_1357_45750&gpsArea=0_0_0_0&client=apple&osVersion=15.1.1&networkType=wifi&d_model=iPhone13%2C3&d_brand=iPhone&screen=390%2A844&openudid=&clientVersion=15.9.30&ext={"activityId":"02174862","pageId":"6387623","moduleId":131767320,"encodeActivityId":"UCAYQxqQV3mKZNfu8bG2t8wsYog"}&t=1787300211334`,
                                user,
                                algo: {
                                    appId: '91a93',
                                }
                            }
                        )
                        if (this.haskey(award, 'data.rewardsInfo.successRewards.1')) {
                            p.log(`获得人气值:`, award.data.rewardsInfo.successRewards[1].quantity);
                        }
                        else {
                            p.log(this.haskey(award, 'msg'))
                        }
                    }
                }
            }
        }
        if (this.code) {
            let s = await this.autoCurl({
                    'form': `functionId=hc_activity_vote_queryFloatBar&body={"activityId":"9"}&appid=home-marketing&loginType=2&area=&client=m&screen=390*844&clientVersion=13.8.2&ext={"activityId":"02174862","pageId":"6387623","moduleId":131767320,"encodeActivityId":"UCAYQxqQV3mKZNfu8bG2t8wsYog"}&t=1787300132363`,
                    user,
                    algo: {
                        appId: '91a93',
                    }
                }
            )
            let remainBuff = this.haskey(s, 'data.remainBuff')
            if (remainBuff) {
                for (let i of this.code) {
                    let f = remainBuff>=6 ? 6 : remainBuff
                    remainBuff -= f
                    p.log("正在投票:", i.productName, f)
                    let vote = await this.autoCurl({
                            form: `functionId=hc_activity_vote_vote&body={"activityId":"9","subRankId":10,"voteId":"${i.voteId}","voteNum":${f}}&appid=home-marketing&loginType=2&area=16_1342_1357_45750&gpsArea=0_0_0_0&client=apple&osVersion=15.1.1&networkType=wifi&d_model=iPhone13,3&d_brand=iPhone&screen=390*844&openudid=&clientVersion=15.9.30&ext={"activityId":"02174862","pageId":"6387623","moduleId":131767320,"encodeActivityId":"UCAYQxqQV3mKZNfu8bG2t8wsYog"}&t=1787300259758`,
                            user
                        }
                    )
                    if (this.haskey(vote, 'data.voteCount')) {
                        p.log("总共投票:", vote.data.voteCount)
                    }
                    if (remainBuff<=0) {
                        break
                    }
                    await this.wait(2000)
                }
            }
            s = await this.autoCurl({
                    'form': `functionId=hc_activity_vote_queryFloatBar&body={"activityId":"9"}&appid=home-marketing&loginType=2&area=&client=m&screen=390*844&clientVersion=13.8.2&ext={"activityId":"02174862","pageId":"6387623","moduleId":131767320,"encodeActivityId":"UCAYQxqQV3mKZNfu8bG2t8wsYog"}&t=1787300132363`,
                    user,
                    algo: {
                        appId: '91a93',
                    }
                }
            )
            remainBuff = this.haskey(s, 'data.remainBuff')
            if (remainBuff == 0) {
                p.info.work = true
            }
        }
    }
}

