import fs from 'fs'
import crypto from 'crypto'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const W_PAGE = 'https://pro.m.jd.com/mall/active/2ZmJPVFw9P8uDQoeVgGV1dC6Dm73/index.html?babelChannel=ttt73'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';jdSupportDarkMode/0;lang/zh_CN;site/CN;elder/0;ccy/CNY;tz/;Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'

const JX_KEY = 'xtl_sqg_mall-^&*-damai_(789)_@#$'
const CRAFT_ID = '6824629a7c46584759d39b78'
const TTT_ID = 'ttt73'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '做任务领京豆', pageUrl: W_PAGE, headers: {referer: W_PAGE}, turn: 1, crontab: 3}
        this._acted = 0
        this._fails = 0
    }

    _jxSign(body) {
        let t = ''
        for (const k of Object.keys(body).sort()) {
            let v = body[k]
            if (v instanceof Object) v = JSON.stringify(v)
            if (v === undefined || v === null) continue
            if (typeof v === 'string' && v === '') continue
            t += '&' + v
        }
        return crypto.createHmac('md5', JX_KEY).update(t.slice(1)).digest('hex')
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    _qstr(o) {
        const f = new URLSearchParams()
        for (const k in o) f.append(k, String(o[k]))
        return f.toString()
    }

    async jx(p, user, fn, bodyObj) {
        const t = Date.now()
        const body = Object.assign({}, bodyObj, {sceneval: 2, buid: 325, appCode: 'ms1888ebbf', time: t, signStr: ''})
        body.signStr = this._jxSign(body)
        const qs = this._qstr({functionId: fn, appid: 'jx_h5_babel', t: t, channel: 'jxh5', clientVersion: '1.2.5', client: 'jxh5', uuid: '5858761804088816429', cthr: 1, loginType: 2, body: JSON.stringify(body)})
        const post = this._qstr({functionId: fn, appid: 'jx_h5_babel', t: t, channel: 'jxh5', clientVersion: '1.2.5', client: 'jxh5', uuid: '5858761804088816429', cthr: 1, loginType: 2, body: JSON.stringify(body)})
        const r = await new Promise(resolve => {
            let done = false
            const fin = v => { if (!done) { done = true; resolve(v) } }
            const s = this._h2()
            if (!s) return fin(null)
            let st = null
            try {
                st = s.request({':method': 'POST', ':path': '/api?' + qs, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: this._ckForUser(user), origin: 'https://pro.m.jd.com', referer: W_PAGE, 'x-referer-page': W_PAGE, 'x-rp-client': 'h5_2.4.0', 'user-agent': UA})
            } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
            let d = ''
            st.on('data', c => d += c)
            st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
            st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
            st.end(post)
            setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
        })
        if (!r) p.log(fn + ' 空响应')
        return r
    }

    async pool(p, user) {
        const r = await this.jx(p, user, 'jxzy_active_task_queryTaskList', {source: 'jxzy', craftId: CRAFT_ID, tttId: TTT_ID})
        return (((r || {}).data || {}).taskInfoList || [])
    }

    async main(p) {
        const user = p.data.user
        for (let round = 1; round <= 3; round++) {
            const tl = await this.pool(p, user)
            if (!tl.length) { p.log('任务池空'); return }
            let did = 0
            for (const t of tl) {
                if (t.taskType !== 3) continue
                const bt = (t.extInfo || {}).browseTask || {}
                if (bt.completionFlag || t.taskStatus !== 1) continue
                const it0 = (bt.shoppingActivityList || [])[0] || {}
                const itemId = (t.taskProgress || {}).itemId || it0.itemId || ''
                if (!t.taskId || !itemId) continue
                const wd = bt.browseTime || 10
                const nm = (t.taskName || '').slice(0, 16)
                const rc = await this.jx(p, user, 'jxzy_active_task_completeTask', {craftId: CRAFT_ID, taskId: t.taskId, itemId: String(itemId), taskType: 3})
                if (String((rc || {}).code) !== '0') { p.log('  [c]拒:', nm, JSON.stringify(rc).slice(0, 80)); this._fails++; continue }
                await this.wait((wd + 4) * 1000)
                const rw = await this.jx(p, user, 'jxzy_active_task_rewardTask', {craftId: CRAFT_ID, taskId: t.taskId, itemId: String(itemId), taskType: 3})
                const prize = JSON.stringify((rw || {}).data || {})
                if (String((rw || {}).code) === '0' && prize.includes('discount')) { p.log('  完成:', nm, '+豆'); did++; this._acted++ }
                else { p.log('  [r]拒:', nm, JSON.stringify(rw).slice(0, 80)); this._fails++ }
                await this.wait(3000)
            }
            if (!did) break
        }
        const fin = await this.pool(p, user)
        const left = fin.filter(t => t.taskType === 3 && !((t.extInfo || {}).browseTask || {}).completionFlag).map(t => (t.taskName || '').slice(0, 12))
        p.log('做任务领京豆: 本轮', this._acted, '发, 未清:', left.length ? left.join(',') : '无')
        p.info.work = this._fails === 0
    }
}
