import {Template} from '../../template.js'
import jsdom from "jsdom";
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东金融赚京豆',
            headers: {
                referer: 'https://member.jr.jd.com/'
            },
            sync: 1,
            verify: 1,
            crontab: 3,
            prompt: {
                channelCode: '活动id'
            }
        }
    }

    async prepare() {
        await this.field('channelCode')
        let ua = this.userAgents().jd
        let resourceLoader = new jsdom.ResourceLoader({
            userAgent: ua,
            "referer": "https://fc.jr.jd.com/",
        });
        let virtualConsole = new jsdom.VirtualConsole();
        this.jsConfig = {
            "url": "https://ms.jr.jd.com/",
            "referer": "https://fc.jr.jd.com/",
            "userAgent": ua,
            runScripts: "dangerously",
            resources: resourceLoader,
            includeNodeLocations: true,
            storageQuota: 10000000,
            pretendToBeVisual: true,
            virtualConsole
        }
        let JSDOM = jsdom.JSDOM
        let a = new JSDOM(`<body><script src="https://jrsecstatic.jdpay.com/jr-sec-dev-static/aar2-2.1.0.min.js"></script>`, this.jsConfig)
        await this.wait(2000)
        if (a.window.AAR2) {
            a.window.AAR2.init();
            this.crypto = {
                aar: new a.window.AAR2(),
            }
        }
        else {
            this.log("jsdom没有获取到aar2")
            this.jump = 1
        }
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        const aar = this.crypto.aar
        let info = await this.getInfo(user, 'jsTk') || {}
        let device = {
            deviceInfo: {
                "jsToken": "",
                "fp": info.fp || this.md5(new Date().getTime().toString()),
                "eid": info.eid || `FQ7Z2DTGYZSJM5FKY${this.rand(10, 99)}JLAURRHP2UZHK2ID7554EMNWWNNSK3JBCTLTR45IOP3Z5K3YJHOG${this.rand(10, 99)}SJAOB${this.rand(10, 99)}KVS3RH7G2U`,
            },
        }
        let newQuery = new URLSearchParams({
            "clientVersion": "8.1.10",
            "clientType": "ios",
            "ctp": 11189,
            "pageId": 11189,
            "pageNum": -1,
            "pageType": 11189,
            stk: 'clientType,clientVersion,ctp,pageId,pageNum,pageType'
        }).toString()
        let query = (await this.autoCurl({
                'form': newQuery,
                user,
                algo: {
                    appId: '73fdb',
                    h5st: true
                },
            }
        )).query
        let s = await this.autoCurl({
                'url': `https://ms.jr.jd.com/gw2/generic/legogw/h5/m/getPageInfoSafetyTranslate?pageType=11189`,
                json: {
                    reqData: this.dumps({
                        "clientVersion": "8.1.10",
                        "clientType": "ios",
                        "pageType": 11189,
                        "pageId": 11189,
                        "ctp": 11189,
                        "pageNum": -1,
                        "buildCodes": ["common", "topData", "float", "tag"],
                        "extParams": {
                            "clientVersion": "8.1.10",
                            "clientType": "ios",
                            "pageType": 11189,
                            "pageId": 11189,
                            "ctp": 11189,
                            "pageNum": -1,
                            "buildCodes": ["common", "topData", "float", "tag"],
                            "extParams": {
                                "channelCode": "inside",
                                "signData": {"sdkToken": ""},
                                "sdkToken": "",
                                "deviceInfos": "{\"sdkToken\":\"\"}",
                                "riskQdPageId": "gainJDbean",
                                "riskQdPageName": "赚京豆任务列表页",
                                "aarVersion": "2",
                                "osVersion": "15.1.1",
                                "itemIds": [],
                                "pageName": "pageCoinQuest",
                                "clientEnv": "2",
                                "jumpSource": "001",
                                "abTest": "",
                                "schemaList": ["freereader://", "cn.10086.app://"],
                                "platformFlag": "2",
                                "sourceVersion": "62",
                                "reqSource": "0",
                                "dynamicReq": true,
                                "pageUrl": "https:member.jr.jd.com/member/coinQuest/coin/",
                                "urlKey": "/member/coinQuest/coin/",
                                "clientName": "web"
                            }
                        }
                    }),
                    cco: this.dumps(query)
                },
                user
            }
        )
        let resultList = this.haskey(s, 'resultData.resultList')
        if (!resultList) {
            p.err('没有获取到数据列表, resp=' + this.dumps(s).slice(0, 200))
            return
        }
        let isOk = 1
        for (let i of resultList) {
            p.log(i.floorInstanceName)
            if (i.floorInstanceName.includes("京豆")) {
                for (let j of i.templateData.taskList) {
                    let doLink = this.haskey(j, 'button.jumpData.jumpUrl')
                    if (doLink && doLink.includes('juid')) {
                        p.log("正在运行:", j.title.text)
                        let T = aar.nonce()
                        let pp = this.query(doLink, '&', 1)
                        let query = await this.autoCurl({
                                'url': `https://ms.jr.jd.com/gw2/generic/mission/newh5/m/receiveMissionForNa`,
                                json: {
                                    "reqData": this.dumps({
                                        "environment": "2",
                                        "missionId": j.missionId,
                                        "channelCode": "CH202503192",
                                        "deviceInfo1": device.deviceInfo,
                                        "nonce": T,
                                        "signature": aar.sign(this.dumps({
                                            channelCode: context.channelCode,
                                            PIN: user,
                                            missionId: i.missionId,
                                        }), T),
                                        "clientType": "h5",
                                        "clientVersion": "8.1.10"
                                    }),
                                },
                                user,
                                algo: {
                                    expire: {
                                        "resultCode": 3,
                                    }
                                }
                            }
                        )
                        if (this.haskey(query, 'resultData.code', '0000')) {
                            await this.wait(1000)
                            let jump = await this.autoCurl({
                                    'url': `https://ms.jr.jd.com/gw2/generic/mission/h5/m/getJumpInfo?juid=${pp.juid}&signature=${aar.sign(this.dumps({
                                        juid: pp.juid,
                                        PIN: user,
                                    }), T)}&nonce=${T}&jrAppVersion=6.9.80&systemEnv=IOS`,
                                    user
                                }
                            )
                            if (this.haskey(jump, 'resultData.code', '0000')) {
                                p.award(1, 'bean')
                            }
                            else {
                                p.err("奖励领取失败")
                                isOk--
                                break
                            }
                        }
                        else {
                            isOk--
                            p.err("任务领取失败")
                            break
                        }
                        await this.wait(2000)
                    }
                    else {
                        let u = new URLSearchParams(doLink.split("?")[1])
                        if (u.get("missionId")) {
                            p.log("正在运行:", j.title.text)
                            let T = aar.nonce()
                            let qr = await this.autoCurl({
                                    'url': `https://ms.jr.jd.com/gw2/generic/Mission/h5/m/queryNextBrowseMissionAndReceiveV3`,
                                    json: {
                                        "missionId": u.get("missionId"),
                                        "readTime": 10,
                                        "nonce": T,
                                        "signature": aar.sign(this.dumps({
                                            channelCode: u.get("channelCode"),
                                            PIN: user,
                                            missionId: u.get("missionId"),
                                        }), T),
                                        "version": "2.2.4",
                                        "token": "iYhVPTDdcH",
                                        "appId": "jrmission",
                                        "channelCode": "xjfrwzx"
                                    },
                                    user,
                                    referer: doLink,
                                }
                            )
                            if (this.haskey(qr, 'resultData.data.doLink')) {
                                doLink = qr.resultData.data.doLink
                                let uu = new URLSearchParams(doLink.split("?")[1])
                                await this.autoCurl({
                                        'url': doLink,
                                        user,
                                        referer: "https://u.jr.jd.com/",
                                    }
                                )
                                let start = await this.autoCurl({
                                        'url': `https://ms.jr.jd.com/gw2/generic/Mission/h5/m/startReadMissionV3`,
                                        json: {
                                            "missionId": uu.get("missionId"),
                                            "readTime": parseInt(uu.get("readTime")),
                                            "nonce": T,
                                            "channelCode": uu.get("channelCode"),
                                            "signature": aar.sign(this.dumps({
                                                channelCode: uu.get("channelCode"),
                                                PIN: user,
                                                missionId: uu.get("missionId"),
                                            }), T),
                                            "version": "2.2.4",
                                            "token": "jBJHOIrRhm",
                                            "appId": "jrmission"
                                        },
                                        user,
                                        referer: doLink
                                    }
                                )
                                if (this.haskey(start, 'resultData.data.doLink')) {
                                    p.log("正在等待:", uu.get("readTime"))
                                    await this.wait(parseInt(uu.get("readTime")) * 1000)
                                    let finish = await this.autoCurl({
                                            'url': `https://ms.jr.jd.com/gw2/generic/Mission/h5/m/finishReadAndAwardV3`,
                                            json: {
                                                "missionId": uu.get("missionId"),
                                                "readTime": parseInt(uu.get("readTime")),
                                                "nonce": T,
                                                "signature": aar.sign(this.dumps({
                                                    channelCode: uu.get("channelCode"),
                                                    PIN: user,
                                                    missionId: uu.get("missionId"),
                                                }), T),
                                                "version": "2.2.4",
                                                "token": "EaGIdTGDdn",
                                                "appId": "jrmission",
                                                "channelCode": uu.get("channelCode"),
                                            },
                                            user,
                                            referer: doLink
                                        }
                                    )
                                    if (this.haskey(finish, 'resultData.data.doLink')) {
                                        p.award(1, 'bean')
                                        isOk = 1
                                    }
                                    else {
                                        isOk--
                                        p.err("任务失败了....")
                                        break
                                    }
                                }
                                else {
                                    isOk--
                                    p.err("任务失败")
                                    break
                                }
                            }
                            else {
                                isOk--
                                break
                            }
                        }
                    }
                }
            }
        }
        if (isOk) {
            p.info.work = true
        }
        else {
            p.log("任务已经跑过了...")
        }
    }
}

