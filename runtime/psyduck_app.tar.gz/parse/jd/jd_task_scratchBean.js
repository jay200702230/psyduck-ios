import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const SB_PAGE = 'https://pro.m.jd.com/mall/active/288wUsJsGP2YXwnBaVekVkj3PKRB/index.html'
const SB_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东秒杀刮京豆',
            pageUrl: 'https://pro.m.jd.com/mall/active/288wUsJsGP2YXwnBaVekVkj3PKRB/index.html',
            headers: {
                referer: 'https://pro.m.jd.com/mall/active/288wUsJsGP2YXwnBaVekVkj3PKRB/index.html'
            },
            turn: 1,
            crontab: 3
        }
    }

    // 秒杀频道互动刮卡的 linkId, 取自活动页 HTML 的 boardParams.linkId, 会轮换, 可用 context.linkId 覆盖
    linkId(context) {
        return context.linkId || '8jYGDpBm3JJ3awmVYKZ1Jg'
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._sbCk()
    }
    _sbCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    // 框架curl链路被风控: 任务接口恒返1714001限流码, 刮卡接口全空响应; 改 h5st 自签名直连 (同 blindBox/farmNew 模式)
    async sbCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._sbSigner) {
            try { this._sbSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._sbSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        // scene 必须带上: bff 系接口校验 URL 上的 scene 参数, 丢了直接 403
        const url = String((opts && opts.url) || '')
        const pathQs = url.includes('?') ? url.slice(url.indexOf('?')) : '?functionId=' + fn
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._sbSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'plus_business', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api' + pathQs, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性, 塞完整页面 URL 直接 403
                    origin: 'https://pro.m.jd.com', referer: SB_PAGE, 'user-agent': SB_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    // 京豆频道 bff 接口对脚本调用有强限流, 1714001(请稍后再试)/1714002(队伍有点长) 均为临时态, 需退避重试
    async fetchTasks(p, user) {
        let body = {
            taskType: 'beanDailySign_newBeanTask',
            popFlag: '0',
            scene: 'jdInteractTask',
            commonScene: 'secKillChannel',
            needBeanSignStatus: '1',
            otherApis: [{
                api: 'bff_exec_func',
                businessParam: {
                    firstDomain: 'rightsCenter',
                    secondDomain: 'userInfo',
                    contentType: '27',
                    scene: 'userInfo'
                }
            }]
        }
        for (let i = 1; i <= 4; i++) {
            let taskList = await this.sbCurl({
                'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_jdInteractTask&scene=jdInteractTask`,
                'form': `appid=plus_business&functionId=bff_rightsCenter_jdInteractTask&body=${encodeURIComponent(this.dumps(body))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=iPhone`,
                user,
                algo: {
                    appId: 'b63ff'
                }
            })
            let tasks = this.haskey(taskList, 'rs.beanTask.taskList')
            if (tasks) return tasks
            let code = String(this.haskey(taskList, 'code') || '')
            if (code == '1714001' || code == '1714002') {
                p.log(`京豆频道接口限流(${code}), 第${i}次重试...`)
                await this.wait(8000 * i)
                continue
            }
            p.log('没有获取到刮卡任务:', this.haskey(taskList, 'msg') || taskList)
            return null
        }
        p.log('京豆频道接口持续限流, 本轮跳过(稍后自动重试)')
        return null
    }

    // 完成一个「浏览页面 刮卡」任务
    async doTask(p, user, i) {
        let itemId = this.haskey(i, 'ext.shoppingActivity.0.itemId')
        if (!itemId) {
            p.log('跳过(无itemId):', i.assignmentName)
            return
        }
        p.log('正在浏览:', i.assignmentName)
        let doIt = await this.sbCurl({
            'url': `https://api.m.jd.com/api?functionId=bff_rightsCenter_interaction&scene=commonDoInteractiveAssignment`,
            'form': `appid=plus_business&functionId=bff_rightsCenter_interaction&body=${encodeURIComponent(this.dumps({
                scene: 'commonDoInteractiveAssignment',
                commonScene: 'secKillChannel',
                activityCode: this.haskey(i, 'ext.taskType') || 'newBeanTask',
                businessScenario: 'jingDouCenter',
                assignmentId: i.encryptAssignmentId,
                actionType: '1',
                itemId: itemId
            }))}&loginType=2&loginWQBiz=&scval=test01&xAPIClientLanguage=zh_CN&d_brand=iPhone`,
            user,
            algo: {
                appId: 'b63ff'
            }
        })
        let code = String(this.haskey(doIt, 'code') || '')
        if (['1711000', '0'].includes(code)) {
            p.log('浏览完成:', i.assignmentName)
            p.info.work = true
            return 'done'
        }
        else if (code == '1714002' || code == '1714001') {
            // 非真失败: 服务端排队受理, 稍后重新拉列表会看到 completionFlag 已翻 true (2026-10-16 实测)
            p.log('上报排队中(稍后自动确认):', i.assignmentName)
            return 'queued'
        }
        else {
            const msg = String(this.haskey(doIt, 'msg') || this.dumps(doIt).slice(0, 60))
            p.log('浏览失败:', msg)
            // 限流软拒连续3个 = 账号被风控, 继续逐个请求只会喂风控
            if (/人数多|太火爆|限流/.test(msg)) {
                this._lbStreak = (this._lbStreak || 0) + 1
                if (this._lbStreak >= 3) throw 'BrowseFuse'
            }
            else { this._lbStreak = 0 }
            return 'fail'
        }
    }

    // weGame 族通用请求(2026-10 修复): 指纹 a58c4/730a6 已失效, 存活 02f8d; App 容器形态 envType=2 + extParams
    // 2026-10-20: 空 token 被 weGame 网关空响应拦截, 注入 eid_pair 双真 token (运动馆/joyPark/hudong 同解)
    async wg(p, user, fn, bodyObj) {
        let sbEid = '', sbSdk = ''
        try {
            const pt = fs.readFileSync('/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt', 'utf8')
            sbEid = (pt.match(/eid=(\S+)/) || ['', ''])[1]
            sbSdk = (pt.match(/sdk=(\S+)/) || ['', ''])[1]
        } catch (e) {}
        let r = await this.sbCurl({
            'url': `https://api.m.jd.com/api?functionId=${fn}`,
            'form': `functionId=${fn}&body=${encodeURIComponent(this.dumps(Object.assign({envType: 2}, bodyObj)))}` +
                `&extParams=${encodeURIComponent(this.dumps({loginType: 1, loginWQBiz: 'wegame'}))}` +
                `&appid=wegame-hub&client=android&clientVersion=15.10.50&platform=3&build=102649&screen=360*800&networkType=wifi&d_brand=OnePlus&d_model=IN2010&lang=zh_CN&osVersion=13&partner=oppo&cthr=1` +
                `&uuid=3303461326131633-2313731633939346&eufv=1&eu=3303461326131633&fv=2313731633939346` +
                `&ext=${encodeURIComponent(this.dumps({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': sbEid, 'wg-sdk-token': sbSdk, pageUrl: encodeURIComponent('https://pro.m.jd.com/mall/active/288wUsJsGP2YXwnBaVekVkj3PKRB/index.html')}))}` +
                `&x-api-eid-token=${sbEid}&wg-sdk-token=${sbSdk}`,
            user,
            algo: {
                appId: '02f8d'
            },
            response: 'all'
        })
        let content = r && r.content !== undefined ? r.content : r
        if (typeof content === 'string' && !content) return null
        let obj = typeof content === 'string' ? (() => { try { return JSON.parse(content) } catch (e) { return null } })() : content
        return obj
    }

    // 查询刮卡状态: state=4 表示已寻到宝可领奖
    async icon(p, user, linkId) {
        let r = await this.wg(p, user, 'weGameIcon', {linkId: linkId, channelTag: 'miaosha', seekView: '', umcGuidance: ''})
        if (!r) return {}
        return {
            state: this.haskey(r, 'data.iconVo.state'),
            text: this.haskey(r, 'data.iconVo.text'),
            total: this.haskey(r, 'data.masterUserInfoVo.sessionInfoVo.ext.total'),
            current: this.haskey(r, 'data.masterUserInfoVo.sessionInfoVo.ext.current')
        }
    }

    // 刮卡: 返回 {award, empty, errMsg}
    async lottery(p, user, linkId) {
        let obj = await this.wg(p, user, 'weGameLottery', {linkId: linkId, channelTag: 'miaosha', lotteryType: 0, seekView: ''})
        if (!obj) return {empty: true}
        return {
            award: this.haskey(obj, 'data.awardResultVO'),
            errMsg: this.haskey(obj, 'errMsg') || this.haskey(obj, 'msg'),
            raw: obj
        }
    }

    async main(p) {
        let user = p.data.user
        let linkId = this.linkId(p.context)

        // 1) 京豆频道互动任务(「浏览页面 刮卡」), 带限流重试; 先做完任务再进场, 轮次快照才能带上抽奖次数
        let tasks = await this.fetchTasks(p, user)
        let queued = 0
        if (tasks) {
            for (let i of tasks) {
                if (i.completionFlag) {
                    p.log('任务已完成:', i.assignmentName)
                    continue
                }
                try {
                    let st = await this.doTask(p, user, i)
                    if (st === 'queued') queued++
                } catch (e) {
                    if (e === 'BrowseFuse') { p.log('连续限流, 剩余浏览本轮放弃'); break }
                    p.log('浏览异常(跳过):', i.assignmentName, String(e && e.message || e))
                }
                await this.wait(1500)
            }
            if (queued > 0) {
                // 排队上报是延迟受理(实测几分钟内入账): 等 30s 重拉列表确认, 没确认的下轮跑批生效
                await this.wait(30000)
                let re = await this.fetchTasks(p, user)
                if (re) {
                    let done = re.filter(x => x.completionFlag).length
                    p.log(`浏览确认: ${done}/${re.length} 已完成(排队入账有延迟, 未确认的稍后自动生效)`)
                }
            }
        }

        // 2) 进场建轮次: 必须用游戏自身 linkId 调 weGameHome, 否则当天没有会话, 刮卡恒报「轮次已过期」
        await this.wg(p, user, 'weGameHome', {linkId: linkId, checkProgressIncrFlag: true})

        // 3) 刮卡前置: 取当前刮卡状态 (state=4 表示已寻到宝)
        let st = await this.icon(p, user, linkId)
        p.log(`刮卡状态: state=${st.state} ${st.text || ''} (已刮${st.current || 0}/${st.total || 0})`)

        // 4) 刮卡: 空响应多为风控/限流, 退避重试; 连续4发空直接熔断(403网关拉黑, 继续喂只会延长封禁); 空卡(未中奖)继续刮, 最多 12 次
        let got = false
        let blank = 0
        let miss = 0
        for (let k = 1; k <= 12; k++) {
            let d = await this.lottery(p, user, linkId)
            if (d.empty) {
                miss++
                if (miss >= 4) {
                    p.log(`刮卡接口连续无响应(网关拦截), 本轮放弃, 寻宝机会保留待下轮自动再试`)
                    break
                }
                p.log(`刮卡接口无响应(疑似风控拦截), 第${k}次重试...`)
                await this.wait(6000 * k)
                continue
            }
            miss = 0
            if (d.award && d.award.prizeDesc) {
                got = true
                p.info.work = true
                p.log('刮到:', d.award.prizeDesc, d.award.amount || '', d.award.limitStr || '')
                // prizeType/prizeDesc 为京豆时才计入, 其余(优惠券等)仅打印
                if (this.haskey(d.award, 'prizeDesc', ['京豆']) || this.haskey(d.award, 'prizeType', [3])) {
                    p.award(d.award.amount, 'bean')
                }
                await this.wait(1500)
                continue
            }
            if (d.award) {
                got = true
                blank++
                p.log('刮了一张空卡(未中奖)')
                await this.wait(1500)
                continue
            }
            if (d.errMsg) {
                p.log('刮卡失败:', d.errMsg)
                break
            }
            p.log('刮卡返回:', this.dumps(d.raw).slice(0, 200))
            break
        }
        if (!got) p.log('本轮未刮到奖励(可能无刮卡机会或接口被风控, 稍后自动重试)')
        else if (got && blank && !p.info.work) p.log(`刮卡完成: ${blank} 张空卡, 未中实物/京豆`)
    }
}
