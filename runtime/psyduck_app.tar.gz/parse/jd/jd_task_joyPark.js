import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const JP_PAGE = 'https://joypark.jd.com/'
const JP_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/120.0.6099.188 Mobile Safari/537.36 DongWebView/2.1.62'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
// farmWv 同款设备特征: 裸 base 高频打 apsDoTask 会被网关按 403 空返回冷却
const JP_EU = '3303461326131633', JP_FV = '2313731633939346'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东汪汪庄园',
            crontab: 3,
            keyExpire: 12000,
            prompt: {
                // merge: '1 # 执行购买与合成任务',
            },
        }
    }

    async prepare() {
        this.shareCode({linkId: "99DZNpaCTAv8f4TuKXr0Ew"})
    }

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._jpCk()
    }
    _jpCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    async jpCurl(opts) {
        const form = opts && opts.form
        if (!form) return null
        if (!this._jpSigner) {
            try { this._jpSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._jpSigner) return null
        const formStr = String(form)
        const getv = k => { const m = formStr.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        // eid_pair 双真 token (2026-10-20 运动馆验证: 空sdk token=写接口403, 双真token全通)
        const PAIR = '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/eid_pair.txt'
        let eid = '', sdk = ''
        try {
            const pt = fs.readFileSync(PAIR, 'utf8')
            eid = (pt.match(/eid=(\S+)/) || ['', ''])[1]
            sdk = (pt.match(/sdk=(\S+)/) || ['', ''])[1]
        } catch (e) {}
        if (!eid) eid = (ck.match(/3AB9D23F7A4B3CSS=([^;\s]+)/) || ['', ''])[1]
        const ext = this._jpExt || (this._jpExt = JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': eid, 'wg-sdk-token': sdk, pageUrl: encodeURIComponent(JP_PAGE)}))
        const base = {
            appid: 'activities_platform',
            client: 'android', clientVersion: '15.10.50', t: String(Date.now()), body, functionId: fn,
            platform: '3', loginType: '2', loginWQBiz: 'wegame',
            uuid: JP_EU + '-' + JP_FV, build: '102649', screen: '360*800', networkType: 'wifi',
            d_brand: 'OnePlus', d_model: 'IN2010', lang: 'zh_CN', osVersion: '13', partner: 'oppo',
            'wg-sdk-token': sdk, ext, eufv: '1', eu: JP_EU, fv: JP_FV, cthr: 1
        }
        const signed = this._jpSigner.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || 'cd949', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType'])
        for (const seg of formStr.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: JP_PAGE, referer: JP_PAGE, 'user-agent': JP_UA
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(d) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        this.dict[user] = {}
        await this.jpCurl({
                'url': `https://api.m.jd.com/api`,
                'form': `appid=risk_h5_info&functionId=reportInvokeLog&body={"sdkClient":"handler","sdkVersion":"1.1.0","url":"aHR0cHM6Ly9qb3lwYXJrLmpkLmNvbS8","timestamp":${new Date().getTime()}}`,
                user
            }
        )
        await this.jpCurl({
                'url': `https://api.m.jd.com/?functionId=getStaticResource&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user
            }
        )
        await this.jpCurl({
                'url': `https://api.m.jd.com/?functionId=getStationMarquees&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user
            }
        )
        await this.baseInfo(p)
        await this.joyList(p)
        p.log("获取数据中...", this.dict[user])
        await this.shopList(p)
        await this.two(p)
        let list = await this.jpCurl({
            'url': `https://api.m.jd.com/`,
            'form': `functionId=apTaskList&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
            user
        })
        for (let i of this.haskey(list, 'data')) {
            if (i.taskDoTimes != i.taskLimitTimes) {
                let ok = 0
                for (let j = 0; j<i.taskLimitTimes - i.taskDoTimes; j++) {
                    if (ok) {
                        break
                    }
                    p.log(`正在做:`, i.taskShowTitle || i.taskTitle, i.taskType)
                    switch (i.taskType) {
                        case 'ORDER_MARK':
                            break
                        case 'SHARE_INVITE':
                            break
                        case 'SIGN':
                            let ss = await this.jpCurl({
                                'url': `https://api.m.jd.com/`,
                                'form': `functionId=apDoTask&body={"taskType":"SIGN","taskId":${i.id},"openUdId":"","cityId":"1234","provinceId":"16","countyId":"1234","linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                                user,
                                algo: {
                                    appId: 'cd949'
                                }
                            })
                            let dd = await this.jpCurl({
                                'url': `https://api.m.jd.com/`,
                                'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                                user,
                                algo: {
                                    appId: "55276"
                                }
                            })
                            if (this.haskey(dd, 'success')) {
                                p.log('任务完成:', dd.success)
                                if (!p.info.balck) {
                                    await this.baseInfo(p)
                                    await this.two(p)
                                }
                            }
                            break
                        case 'BROWSE_CHANNEL':
                            // apStartTaskTime 在 App 会话下被服务端隔离(恒返回空), 浏览类子任务改走 apsDoTask(plantBean 同款链路)
                            if (i.taskSourceUrl) {
                                var doTask = await this.jpCurl({
                                    'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                    'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"taskInsert":false,"itemId":"${encodeURIComponent(i.taskSourceUrl)}"}&t=1738480908001&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                    algo: {'appId': '54ed7'},
                                    user
                                })
                                if (this.haskey(doTask, 'success')) {
                                    p.log("任务完成")
                                    if (i.timeLimitPeriod) {
                                        p.log(`等待${i.timeLimitPeriod}秒...`)
                                        await this.wait(i.timeLimitPeriod * 1000)
                                        var lt = await this.jpCurl({
                                            'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                            'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}"}&t=1738483906048&appid=activities_platform&client=ios&clientVersion=15.0.11&platform=3&loginType=2&loginWQBiz=wegame`,
                                            user,
                                            algo: {
                                                appId: 'ebecc'
                                            }
                                        })
                                    }
                                    // 计时被服务端吞掉 = 浏览没生效, 领奖必失败, 别再发请求喂风控
                                    if (String(this.haskey(lt, 'errMsg') || '').includes('没有需要查询的计时任务')) {
                                        p.log("服务端未记录计时, 浏览被风控吞了, 跳过领奖")
                                    }
                                    else {
                                        let award = await this.jpCurl({
                                                'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                user,
                                                algo: {
                                                    appId: 'f0f3f'
                                                }
                                            }
                                        )
                                        if (this.haskey(award, 'data')) {
                                            if (!p.info.balck) {
                                                await this.baseInfo(p)
                                                await this.two(p)
                                            }
                                        }
                                    }
                                }
                                else {
                                    // 汪汪庄园对协议端浏览上报封堵: apsDoTask 恒空返回(真机beacon校验), 降噪+退避, 不高频喂风控
                                    if (!doTask || doTask === '' || (typeof doTask === 'object' && !this.haskey(doTask, 'errMsg') && !this.haskey(doTask, 'code'))) {
                                        p.log(`[${i.taskShowTitle || i.taskTitle}] 空返回(活动风控), 跳过`)
                                        p.context.riskSkip = (p.context.riskSkip || 0) + 1
                                        await this.wait(5000)
                                    }
                                    else if (this.haskey(doTask, 'code', 2018)) {
                                        // 2018=计时任务必须走受理制 (2026-10-20 运动馆/zBean 验证: 受理->等->上报->领奖 全通)
                                        const st2 = await this.jpCurl({
                                            'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                                            'form': `functionId=apStartTaskTime&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"taskInsert":false,"itemId":"${encodeURIComponent(i.taskSourceUrl)}"}&t=1748099560933&appid=activity_platform_se&client=ios&clientVersion=15.0.11&platform=3&loginType=2&loginWQBiz=wegame`,
                                            user,
                                            algo: {'appId': 'acb1e'}
                                        })
                                        if (!st2 || (typeof st2 === 'string' && st2.length === 0)) {
                                            p.log(`[${i.taskShowTitle || i.taskTitle}] 受理空返回(真机校验), 跳过`)
                                        }
                                        else if (this.haskey(st2, 'data.code', 0) || this.haskey(st2, 'success')) {
                                            p.log(`[${i.taskShowTitle || i.taskTitle}] 受理成功, 等${i.timeLimitPeriod || 30}秒...`)
                                            await this.wait((i.timeLimitPeriod || 30) * 1000)
                                            const lt2 = await this.jpCurl({
                                                'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                                'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}"}&t=1738483906048&appid=activities_platform&client=ios&clientVersion=15.0.11&platform=3&loginType=2&loginWQBiz=wegame`,
                                                user,
                                                algo: {'appId': 'ebecc'}
                                            })
                                            if (String(this.haskey(lt2, 'errMsg') || '').includes('没有需要查询的计时任务')) {
                                                p.log("服务端未记录计时, 浏览被风控吞了")
                                            }
                                            else {
                                                const aw2 = await this.jpCurl({
                                                    'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                    'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                    user,
                                                    algo: {'appId': 'f0f3f'}
                                                })
                                                if (this.haskey(aw2, 'data') || this.haskey(aw2, 'success')) {
                                                    p.log(`[${i.taskShowTitle || i.taskTitle}] 受理制领奖成功`)
                                                    if (!p.info.balck) {
                                                        await this.baseInfo(p)
                                                        await this.two(p)
                                                    }
                                                }
                                                else {
                                                    p.log(`[${i.taskShowTitle || i.taskTitle}] 领奖失败:`, JSON.stringify(aw2).slice(0, 80))
                                                }
                                            }
                                        }
                                        else {
                                            p.log(`[${i.taskShowTitle || i.taskTitle}] 受理被拒:`, JSON.stringify(st2).slice(0, 100))
                                        }
                                    }
                                    else {
                                        p.log("任务失败:", this.haskey(doTask, 'errMsg') || JSON.stringify(doTask).slice(0, 60))
                                    }
                                    ok = 1
                                }
                            }
                            else {
                                p.log(`跳过(需真机打开页面): ${i.taskShowTitle || i.taskTitle}`)
                                p.context.realBrowseSkip = (p.context.realBrowseSkip || 0) + 1
                                ok = 1
                            }
                            break
                        case 'BROWSE_PRODUCT':
                        case 'BROWSE_RTB':
                            if (i.taskSourceUrl) {
                                var doTask = await this.jpCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                        'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)},"taskInsert":false,"itemId":"${encodeURIComponent(i.taskSourceUrl)}"}&t=1738480908001&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                        algo: {'appId': '54ed7'},
                                        user
                                    }
                                )
                                if (this.haskey(doTask, 'success')) {
                                    p.log("任务完成")
                                }
                                else {
                                    p.log("任务失败:", this.haskey(doTask, 'errMsg') || doTask)
                                }
                                let award = await this.jpCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                        'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                        user,
                                        algo: {
                                            appId: 'f0f3f'
                                        }
                                    }
                                )
                                if (this.haskey(award, 'data')) {
                                    if (!p.info.balck) {
                                        await this.baseInfo(p)
                                        await this.two(p)
                                    }
                                }
                            }
                            else {
                                let apTaskDetail = await this.jpCurl({
                                        'url': `https://api.m.jd.com/api?functionId=apTaskDetail`,
                                        'form': `functionId=apTaskDetail&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1738480907628&appid=activities_platform&client=ios&clientVersion=15.0.11&`,
                                        user
                                    }
                                )
                                let taskItemList = this.haskey(apTaskDetail, 'data.taskItemList')
                                if (taskItemList) {
                                    let abc = 0
                                    for (let j in Array.from(Array(i.taskLimitTimes - i.taskDoTimes), (_val, index) => index)) {
                                        if (abc) {
                                            break
                                        }
                                        if (taskItemList[j] && taskItemList[j].itemId) {
                                            if (i.timeLimitPeriod) {
                                                let start = await this.jpCurl({
                                                        'url': `https://api.m.jd.com/api?functionId=apStartTaskTime`,
                                                        'form': `functionId=apStartTaskTime&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps({
                                                            ...i.pipeExt, ...taskItemList[j].pipeExt
                                                        })},"taskInsert":false,"itemId":"${encodeURIComponent(taskItemList[j].itemId)}"}&t=1738483884373&appid=activity_platform_se&client=ios&clientVersion=15.0.11&platform=3&loginType=2&loginWQBiz=wegame`,
                                                        user,
                                                        algo: {
                                                            appId: 'acb1e'
                                                        }
                                                    }
                                                )
                                                if (!start || (typeof start === 'string' && start.length === 0)) {
                                                    // apStartTaskTime 已失效(恒返回空): 需真机打开页面
                                                    p.log(`跳过(需真机打开页面): ${i.taskShowTitle || i.taskTitle}`)
                                                    abc++
                                                    ok = 1
                                                    break
                                                }
                                                if (this.haskey(start, 'code', 1)) {
                                                    p.log("失败了")
                                                    break
                                                }
                                                p.log(`等待${i.timeLimitPeriod}秒...`)
                                                await this.wait(i.timeLimitPeriod * 1000)
                                                var doTask = await this.jpCurl({
                                                    'url': `https://api.m.jd.com/api?functionId=apDoLimitTimeTask`,
                                                    'form': `functionId=apDoLimitTimeTask&body={"linkId":"${context.linkId}"}&t=1738483906048&appid=activities_platform&client=ios&clientVersion=15.0.11&platform=3&loginType=2&loginWQBiz=wegame`,
                                                    user,
                                                    algo: {
                                                        appId: 'ebecc'
                                                    }
                                                })
                                            }
                                            else {
                                                var doTask = await this.jpCurl({
                                                        'url': `https://api.m.jd.com/api?functionId=apsDoTask`,
                                                        'form': `functionId=apsDoTask&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps({
                                                            ...i.pipeExt, ...taskItemList[j].pipeExt
                                                        })},"taskInsert":false,"itemId":"${encodeURIComponent(taskItemList[j].itemId)}"}&t=1738480908001&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                        algo: {'appId': '54ed7'},
                                                        user
                                                    }
                                                )
                                            }
                                            if (this.haskey(doTask, 'success')) {
                                                p.log("任务完成", `[${parseInt(j) + 1}/${i.taskLimitTimes - i.taskDoTimes}]`)
                                            }
                                            else {
                                                let emC = String(this.haskey(doTask, 'errMsg') || '')
                                                p.log("任务失败:", emC || doTask)
                                                // 计时被服务端吞掉 = 浏览没生效, 剩余次数与领奖全部放弃
                                                if (emC.includes('没有需要查询的计时任务')) {
                                                    p.log("服务端未记录计时, 放弃该任务剩余浏览")
                                                    abc++
                                                    break
                                                }
                                                if (this.haskey(doTask, 'code', 2005)) {
                                                    let award = await this.jpCurl({
                                                            'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                            'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                            user,
                                                            algo: {
                                                                appId: 'f0f3f'
                                                            }
                                                        }
                                                    )
                                                    abc++
                                                    break
                                                }
                                            }
                                            let award = await this.jpCurl({
                                                    'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                                    'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}"}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                                    user,
                                                    algo: {
                                                        appId: 'f0f3f'
                                                    }
                                                }
                                            )
                                            if (this.haskey(award, 'data')) {
                                                if (!p.info.balck) {
                                                    await this.baseInfo(p)
                                                    await this.two(p)
                                                }
                                            }
                                            await this.wait(3000)
                                        }
                                    }
                                }
                            }
                            break
                    }
                }
            }
            else {
                // console.log(i)
                if (i.taskLimitTimes>1) {
                    let di = 0
                    for (let j = 0; j<i.taskLimitTimes; j++) {
                        let award = await this.jpCurl({
                                'url': `https://api.m.jd.com/api?functionId=apTaskDrawAward`,
                                'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"channel":4,"checkVersion":true,"linkId":"${context.linkId}","pipeExt":${this.dumps(i.pipeExt)}}&t=1739360342034&appid=activities_platform&client=ios&clientVersion=15.0.11`,
                                user,
                                algo: {
                                    appId: 'f0f3f'
                                }
                            }
                        )
                        // console.log(award)
                        if (this.haskey(award, 'data')) {
                            di++
                        }
                        else {
                            break
                        }
                        await this.wait(1000)
                    }
                    if (!p.info.balck && di) {
                        await this.baseInfo(p)
                        await this.two(p)
                    }
                }
                p.log(`任务完成`, i.taskShowTitle || i.taskTitle)
            }
        }
        if (p.context.realBrowseSkip) {
            p.log(`汇总: ${p.context.realBrowseSkip} 个限时浏览任务需真机打开页面完成(游戏/活动页类), 脚本仅能做即时类浏览任务`)
        }
        await this.two(p)
        list = await this.jpCurl({
            'url': `https://api.m.jd.com/`,
            'form': `functionId=apTaskList&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
            user
        })
        for (let i of this.haskey(list, 'data')) {
            if (i.canDrawAwardNum) {
                for (let n of Array(i.canDrawAwardNum)) {
                    let d = await this.jpCurl({
                        'url': `https://api.m.jd.com/`,
                        'form': `functionId=apTaskDrawAward&body={"taskType":"${i.taskType}","taskId":${i.id},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                        user,
                        algo: {
                            appId: "55276"
                        }
                    })
                    if (this.haskey(d, 'success')) {
                        p.log(`获取${i.taskTitle}金币...`, d.success)
                        await this.baseInfo(p)
                        await this.two(p)
                    }
                }
            }
        }
        let joys = []
        for (let i in this.dict[user].joy) {
            for (let j of this.dict[user].joy[i]) {
                joys.push(j)
            }
        }
        if (this.dict[user].unlock && joys.length>0) {
            joys = joys.reverse()
            let min = Math.min(joys.length, this.dict[user].unlock)
            for (let i = 0; i<min; i++) {
                let move = await this.jpCurl({
                    'url': `https://api.m.jd.com/`,
                    'form': `functionId=joyMove&body={"joyId":${joys[i]},"location":${i + 1},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                    user,
                    algo: {
                        appId: "50788"
                    }
                })
                p.log('移动狗子去工作...', this.haskey(move, 'success'))
            }
        }
        p.info.work = true
    }

    async one(p) {
        let user = p.data.user
        let context = p.context
        let joy = this.dict[user].joy || {}
        let isChange = 0
        for (let i in this.dict[user].joy) {
            if (this.dict[user].joy[i].length>1) {
                let list = this.dict[user].joy[i]
                let spl = this.slice(list, 2)
                for (let k = 0; k<spl.length; k++) {
                    let kk = spl[k].sort()
                    let merge = await this.jpCurl({
                        'url': `https://api.m.jd.com/?functionId=joyMergeGet&body={"joyOneId":${kk[0]},"joyTwoId":${kk[1]},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                        user,
                        algo: {
                            'appId': 'c3beb'
                        }
                    })
                    if (this.haskey(merge, 'data.joyPrizeVO.prizeName')) {
                        let prizeType = merge.data.joyPrizeVO.prizeType
                        if (prizeType == 2) {
                            p.msg(`红包: ${merge.data.joyPrizeVO.prizeName}`)
                        }
                        else if (prizeType == 3) {
                            p.msg(`京豆: ${merge.data.joyPrizeVO.prizeName}`)
                        }
                        else if (prizeType == 4) {
                            p.msg(`现金: ${merge.data.joyPrizeVO.prizeName}`)
                        }
                        else {
                            p.log(`升级奖励: ${merge.data.joyPrizeVO.prizeName}`)
                        }
                    }
                    if (this.haskey(merge, 'data.joyVO.id')) {
                        isChange++
                        let joyss = this.dict[user].joy
                        joyss[merge.data.joyVO.level] = joyss[merge.data.joyVO.level] || []
                        joyss[merge.data.joyVO.level].push(merge.data.joyVO.id)
                        joyss[i] = spl[k + 1] || []
                        p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, JSON.stringify(joyss))
                    }
                    // p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, this.dict[user].joy[parseInt(i) + 1])
                }
            }
        }
        if (isChange>0) {
            await this.baseInfo(p)
            await this.joyList(p)
        }
        for (let i of this.range(this.dict[user].min, this.dict[user].buyLevel)) {
            if (joy[i] && joy[i].length != 2) {
                let buy = await this.jpCurl({
                    'url': `https://api.m.jd.com/`,
                    'form': `functionId=joyBuy&body={"level":${i},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                    user,
                    algo: {
                        'appId': 'ffb36'
                    }
                })
                if (this.haskey(buy, 'data')) {
                    await this.shopList(p)
                    // p.log(`购买等级${i}的狗子成功...`, this.dict[user].joy[i])
                    p.log(`购买等级${i}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                    // 此处为了防止有低等级狗子合并购买逻辑混乱
                    let list = this.dict[user].joy[i]
                    if (list && list.length>1) {
                        let spl = this.slice(list, 2)
                        for (let k of spl) {
                            let kk = k.sort()
                            let merge = await this.jpCurl({
                                'url': `https://api.m.jd.com/?functionId=joyMergeGet&body={"joyOneId":${kk[0]},"joyTwoId":${kk[1]},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                                user,
                                algo: {
                                    'appId': 'c3beb'
                                }
                            })
                            if (this.haskey(merge, 'data.joyPrizeVO.prizeName')) {
                                let prizeType = merge.data.joyPrizeVO.prizeType
                                if (prizeType == 2) {
                                    p.msg(`红包: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                                else if (prizeType == 3) {
                                    p.msg(`京豆: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                                else if (prizeType == 4) {
                                    p.msg(`现金: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                                else {
                                    p.log(`升级奖励: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                            }
                            p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                        }
                    }
                    await this.baseInfo(p)
                    await this.joyList(p)
                }
                else {
                    p.log(`购买等级${i}的狗子失败...`)
                    break
                }
            }
        }
        if (joy["25"] && joy["26"] && joy["27"] && joy["28"] && joy["29"] && joy["25"].length>0 && joy["26"].length>0 && joy["27"].length>0 && joy["28"].length>0 && joy["29"].length>0) {
            for (let i = 21; i<25; i++) {
                if ((joy["25"].length + joy["26"].length + joy["27"].length + joy["28"].length + joy["29"].length)>5) {
                    break
                }
                if (!this.haskey(joy, `${i}.0`)) {
                    // if (this.dict[user].joy && (this.dict[user].joy[i] && this.dict[user].joy[i].length == 0) || !this.dict[user].joy[i]) {
                    let joyInfo = this.haskey(this.dict[user], `shop.${i}`)
                    if (joyInfo && this.dict[user].coin>0 && joyInfo.consume>0 && joyInfo.consume<this.dict[user].coin) {
                        if (this.dict[user].number>9) {
                            p.log("不能再养狗子了...")
                            break
                        }
                        let buy = await this.jpCurl({
                            'url': `https://api.m.jd.com/`,
                            'form': `functionId=joyBuy&body={"level":${i},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                            user,
                            algo: {
                                'appId': 'ffb36'
                            }
                        })
                        await this.baseInfo(p)
                        await this.joyList(p)
                        await this.shopList(p)
                        if (this.haskey(buy, 'data')) {
                            // p.log(`购买等级${i}的狗子成功...`, this.dict[user].joy[i])
                            p.log(`购买等级${i}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                        }
                        else {
                            p.log(`购买等级${i}的狗子失败...`)
                            break
                        }
                    }
                    else {
                        p.log(`没有足够的金币可以购买等级${i}的狗子...`)
                        break
                    }
                }
            }
            if (joy["21"] && joy["22"] && joy["23"] && joy["24"] && joy["21"].length>0 && joy["22"].length>0 && joy["23"].length>0 && joy["24"].length>0) {
                for (let i = 21; i<22; i++) {
                    let joyInfo = this.haskey(this.dict[user], `shop.${i}`)
                    if (joyInfo && this.dict[user].coin>0 && joyInfo.consume>0 && joyInfo.consume<this.dict[user].coin) {
                        if (this.dict[user].number>9) {
                            p.log("不能再养狗子了...")
                            break
                        }
                        let buy = await this.jpCurl({
                            'url': `https://api.m.jd.com/`,
                            'form': `functionId=joyBuy&body={"level":${i},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                            user,
                            algo: {
                                'appId': 'ffb36'
                            }
                        })
                        await this.baseInfo(p)
                        await this.joyList(p)
                        await this.shopList(p)
                        if (this.haskey(buy, 'data')) {
                            // p.log(`购买等级${i}的狗子成功...`, this.dict[user].joy[i])
                            p.log(`购买等级${i}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                        }
                        else {
                            p.log(`购买等级${i}的狗子失败...`)
                            break
                        }
                    }
                    else {
                        p.log(`没有足够的金币可以购买等级${i}的狗子...`)
                        break
                    }
                }
                for (let i in this.dict[user].joy) {
                    if (this.dict[user].joy[i] && this.dict[user].joy[i].length>1 && this.dict[user].joy[i].length % 2 == 0) {
                        let list = this.dict[user].joy[i]
                        let spl = this.slice(list, 2)
                        for (let k of spl) {
                            let kk = k.sort()
                            let merge = await this.jpCurl({
                                'url': `https://api.m.jd.com/?functionId=joyMergeGet&body={"joyOneId":${kk[0]},"joyTwoId":${kk[1]},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                                user,
                                algo: {
                                    'appId': 'c3beb'
                                }
                            })
                            if (this.haskey(merge, 'data.joyPrizeVO.prizeName')) {
                                let prizeType = merge.data.joyPrizeVO.prizeType
                                if (prizeType == 2) {
                                    p.msg(`红包: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                                else if (prizeType == 3) {
                                    p.msg(`京豆: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                                else if (prizeType == 4) {
                                    p.msg(`现金: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                                else {
                                    p.log(`升级奖励: ${merge.data.joyPrizeVO.prizeName}`)
                                }
                            }
                            await this.baseInfo(p)
                            await this.joyList(p)
                            p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                        }
                    }
                }
            }
        }
        else {
            for (let i in this.dict[user].joy) {
                if (this.dict[user].joy[i] && this.dict[user].joy[i].length>1 && this.dict[user].joy[i].length % 2 == 0) {
                    let list = this.dict[user].joy[i]
                    let spl = this.slice(list, 2)
                    for (let k of spl) {
                        let kk = k.sort()
                        let merge = await this.jpCurl({
                            'url': `https://api.m.jd.com/?functionId=joyMergeGet&body={"joyOneId":${kk[0]},"joyTwoId":${kk[1]},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                            user,
                            algo: {
                                'appId': 'c3beb'
                            }
                        })
                        if (this.haskey(merge, 'data.joyPrizeVO.prizeName')) {
                            let prizeType = merge.data.joyPrizeVO.prizeType
                            if (prizeType == 2) {
                                p.msg(`红包: ${merge.data.joyPrizeVO.prizeName}`)
                            }
                            else if (prizeType == 3) {
                                p.msg(`京豆: ${merge.data.joyPrizeVO.prizeName}`)
                            }
                            else if (prizeType == 4) {
                                p.msg(`现金: ${merge.data.joyPrizeVO.prizeName}`)
                            }
                            else {
                                p.log(`升级奖励: ${merge.data.joyPrizeVO.prizeName}`)
                            }
                        }
                        await this.baseInfo(p)
                        await this.joyList(p)
                        // p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, this.dict[user].joy[parseInt(i) + 1])
                        p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                    }
                }
            }
            for (let i in this.dict[user].joy) {
                if (this.dict[user].joy[i] && this.dict[user].joy[i].length % 2 == 1 && i<this.dict[user].buyLevel) {
                    if (!this.dict[user].shop) {
                        await this.shopList(p)
                    }
                    let joyInfo = this.dict[user].shop[i]
                    if (joyInfo && this.dict[user].coin>0 && joyInfo.consume>0 && joyInfo.consume<this.dict[user].coin) {
                        if (this.dict[user].number>9) {
                            p.log("不能再养狗子了...")
                            break
                        }
                        let buy = await this.jpCurl({
                            'url': `https://api.m.jd.com/`,
                            'form': `functionId=joyBuy&body={"level":${i},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                            user,
                            algo: {
                                'appId': 'ffb36'
                            }
                        })
                        if (this.haskey(buy, 'data')) {
                            await this.shopList(p)
                            // p.log(`购买等级${i}的狗子成功...`, this.dict[user].joy[i])
                            p.log(`购买等级${i}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                            // 此处为了防止有低等级狗子合并购买逻辑混乱
                            let list = this.dict[user].joy[i]
                            if (list && list.length>1) {
                                let spl = this.slice(list, 2)
                                for (let k of spl) {
                                    let kk = k.sort()
                                    let merge = await this.jpCurl({
                                        'url': `https://api.m.jd.com/?functionId=joyMergeGet&body={"joyOneId":${kk[0]},"joyTwoId":${kk[1]},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                                        user,
                                        algo: {
                                            'appId': 'c3beb'
                                        }
                                    })
                                    if (this.haskey(merge, 'data.joyPrizeVO.prizeName')) {
                                        let prizeType = merge.data.joyPrizeVO.prizeType
                                        if (prizeType == 2) {
                                            p.msg(`红包: ${merge.data.joyPrizeVO.prizeName}`)
                                        }
                                        else if (prizeType == 3) {
                                            p.msg(`京豆: ${merge.data.joyPrizeVO.prizeName}`)
                                        }
                                        else if (prizeType == 4) {
                                            p.msg(`现金: ${merge.data.joyPrizeVO.prizeName}`)
                                        }
                                        else {
                                            p.log(`升级奖励: ${merge.data.joyPrizeVO.prizeName}`)
                                        }
                                    }
                                    p.log(`合成等级${parseInt(i) + 1}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                                }
                            }
                            await this.baseInfo(p)
                            await this.joyList(p)
                        }
                        else {
                            p.log(`购买等级${i}的狗子失败...`)
                        }
                    }
                    else {
                        p.log(`没有足够的金币可以购买等级${i}的狗子...`)
                    }
                }
            }
        }
    }

    async two(p) {
        let user = p.data.user
        let context = p.context
        // if (this.profile.merge) {
        if (1) {
            await this.one(p)
            let joy = this.dict[user].joy || {}
            for (let i = 0; i<30; i++) {
                if (this.dict[user].coin>this.dict[user].buyCoin) {
                    if (this.dict[user].number>9) {
                        p.log("不能再养狗子了...")
                        break
                    }
                    let i = this.dict[user].buyLevel
                    let buy = await this.jpCurl({
                        'url': `https://api.m.jd.com/`,
                        'form': `functionId=joyBuy&body={"level":${i},"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                        user,
                        algo: {
                            'appId': 'ffb36'
                        }
                    })
                    await this.baseInfo(p)
                    await this.joyList(p)
                    await this.shopList(p)
                    if (this.haskey(buy, 'data')) {
                        // p.log(`购买等级${i}的狗子成功...`, this.dict[user].joy[i])
                        p.log(`购买等级${i}的狗子成功...`, JSON.stringify(this.dict[user].joy))
                    }
                    else {
                        p.log(`购买等级${i}的狗子失败...`)
                        break
                    }
                }
                else {
                    p.log(this.dict[user].buyLevel ? `购买等级${this.dict[user].buyLevel}的狗子金币不足...` : '金币不足...')
                    await this.one(p)
                    break
                }
                await this.one(p)
            }
        }
    }

    async shopList(p) {
        let user = p.data.user
        let context = p.context
        let s = await this.jpCurl({
                'url': `https://api.m.jd.com/api?functionId=gameShopList`,
                'form': `functionId=gameShopList&body={"linkId":"${context.linkId}"}&t=1741137369938&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user,
                algo: {
                    expire: {
                        code: 1000
                    }
                }
            }
        )
        let data = this.haskey(s, 'data')
        if (data) {
            let obj = {
                shop: this.column(data, '', 'userLevel')
            }
            this.dict[user] = {
                ...this.dict[user],
                ...obj
            }
            return obj
        }
        else {
            return {}
        }
    }

    async joyList(p) {
        let user = p.data.user
        let context = p.context
        var joyList = await this.jpCurl({
            'url': `https://api.m.jd.com/api?functionId=joyList`,
            'form': `functionId=joyList&body={"linkId":"${context.linkId}"}&t=1741137369938&appid=activities_platform&client=ios&clientVersion=15.0.25`,
            user,
            algo: {
                'appId': 'e18ed'
            }
        })
        if (this.haskey(joyList, 'data')) {
            let number = joyList.data.joyNumber
            var joy = {}
            for (let i of joyList.data.activityJoyList) {
                joy[i.level] = joy[i.level] || []
                joy[i.level].push(i.id)
            }
            if (this.haskey(joyList, 'data.workJoyInfoList')) {
                for (let i of joyList.data.workJoyInfoList) {
                    if (this.haskey(i, 'joyDTO.id')) {
                        let move = await this.jpCurl({
                            'url': 'https://api.m.jd.com/',
                            'form': `functionId=joyMove&body={"joyId":${i.joyDTO.id},"location":0,"linkId":"${context.linkId}"}&t=1741137369938&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                            user,
                            algo: {
                                'appId': '50788'
                            }
                        })
                        if (this.haskey(move, 'success')) {
                            joy[i.joyDTO.level] = joy[i.joyDTO.level] || []
                            joy[i.joyDTO.level].push(i.joyDTO.id)
                        }
                    }
                }
            }
            let list = Object.keys(joy).map(d => parseInt(d))
            let min = Math.min(...list)
            let max = Math.max(...list)
            for (let i = min; i<max; i++) {
                joy[i] = joy[i] || []
            }
            let unlock = joyList.data.workJoyInfoList.filter(d => d.unlock).length
            let obj = {
                joy,
                number,
                min,
                max,
                unlock
            }
            this.dict[user] = {
                ...this.dict[user],
                ...obj
            }
            return obj
        }
        else {
            let obj = {
                joy: {}
            }
            this.dict[user] = {
                ...this.dict[user],
                ...obj
            }
            return obj
        }
    }

    async baseInfo(p) {
        let user = p.data.user
        let context = p.context
        this.dict[user] = {}
        await this.jpCurl({
                'form': `functionId=gameHeartbeat&body={"businessCode":1,"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user,
                delay: 10,
            }
        )
        let baseInfo = await this.jpCurl({
                'url': `https://api.m.jd.com/api?functionId=joyBaseInfo`,
                'form': `functionId=joyBaseInfo&body={"taskId":"","inviteType":"","inviterPin":"","linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user, algo: {
                    appId: "4abce",
                    expire: {
                        code: 1000
                    }
                }
            }
        )
        if (this.haskey(baseInfo, 'errMsg', 'blackfail')) {
            p.log("狗子在小黑屋里面...")
            p.info.jump = true
            p.info.black = true
            return {
                error: 1
            }
        }
        var data = this.haskey(baseInfo, 'data')
        if (this.haskey(baseInfo, 'data.level') == 1 && !this.haskey(baseInfo, 'data.joyCoin')) {
            await this.jpCurl({
                'url': `https://api.m.jd.com/`,
                'form': `functionId=newStartReward&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user
            })
        }
        if (this.haskey(baseInfo, 'data.level') == 30) {
            let joyRestart = await this.jpCurl({
                'url': `https://api.m.jd.com/`,
                'form': `functionId=joyRestart&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user,
                algo: {
                    'appId': '4abce'
                }
            })
            p.log(`已经满级了,正在切换场景`)
            await this.jpCurl({
                'url': `https://api.m.jd.com/`,
                'form': `functionId=newStartReward&body={"linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                user
            })
            for (let i of Array(2)) {
                baseInfo = await this.jpCurl({
                    'url': `https://api.m.jd.com/`,
                    'form': `functionId=joyBaseInfo&body={"taskId":"","inviteType":"","inviterPin":"","linkId":"${context.linkId}"}&t=1741137369937&appid=activities_platform&client=ios&clientVersion=15.0.25`,
                    user,
                    algo: {
                        appId: "4abce"
                    }
                })
                data = this.haskey(baseInfo, 'data')
                if (data) {
                    break
                }
                else {
                    await this.wait(2000)
                }
            }
        }
        if (this.haskey(data, 'invitePin')) {
            var compact = {
                coin: data.joyCoin,
                buyCoin: data.fastBuyCoin,
                level: data.level,
                buyLevel: data.fastBuyLevel,
                invitePin: data.invitePin,
            }
            // if (inviterPin) {
            //     compact.helpPin = inviterPin
            //     compact.helpUser = helpUser
            // }
            this.dict[user] = {
                ...this.dict[user],
                ...compact
            }
        }
        else {
            this.dict[user] = {
                joy: {},
                shop: {}
            }
            var compact = {
                joy: {},
                shop: {}
            }
        }
        return compact
    }

    slice(data, num) {
        let result = [];
        if (num == 0) {
            result = [data]
        }
        else {
            for (let i = 0, len = data.length; i<len; i += num) {
                result.push(data.slice(i, i + num));
            }
        }
        return result
    }
}

