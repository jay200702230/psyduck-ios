import fs from 'fs'
import net from 'net'
import path from 'path'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const LK = 'inunNxmIFaBl4Ex4Z3e90w'  // 真机抓包 2026-10-26: weGameLottery 成功 (markStr 可空)
const PAGE = 'https://pro.m.jd.com/mall/active/41D8A8L5aMNPg9TstWamSHnKzj1i/index.html?babelChannel=ttt2&collectionId=345'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA_BASE = 'jdapp;android;15.10.50;;;M/5.0;appBuild/102649;ef/1;ep/'
const EP = JSON.stringify({hdid: 'JM9F1ywUPwflvMIpYPok0tt5k9kW4ArJEU3lfLhxBqw=', ts: 0, ridx: -1, cipher: {sv: 'CJC=', ad: 'CzLuCWSnYJCyCJdrCzu5ZK==', od: 'CJHPCNunEUZMHOGyDOC0HOPOGtrODuDNHJK1HNu1DOHuDJLwCzqzDQYmCWC0DtunZwY2DzrvDzHsYzZvDJK0Zq==', ov: 'CzC=', ud: 'CzLuCWSnYJCyCJdrCzu5ZK=='}, ciphertype: 5, version: '1.2.1', appname: 'com.jingdong.app.mall'})
globalThis.__uaTs = globalThis.__uaTs || Date.now()
const UA = UA_BASE + encodeURIComponent(EP).replace('%22ts%22%3A0', '%22ts%22%3A' + globalThis.__uaTs) + ';Mozilla/5.0 (Linux; Android 13; IN2010) AppleWebKit/537.36 Chrome/120.0.6099.188 Mobile Safari/537.36'

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '小游戏签到', pageUrl: PAGE, headers: {referer: PAGE}, turn: 1, crontab: 3}
        this._fails = 0
    }

    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=')) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpc = await this._rpcCk()
        if (rpc && rpc.includes('pt_key=')) {
            const pinOf = ck => { try { const m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            const want = pinOf(base), got = pinOf(rpc)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpc
        }
        return base
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    async call(p, user, fn, bodyObj) {
        for (let k = 1; k <= 2; k++) {
            try {
                if (!this._signer) {
                    try { this._signer = await import('./jd_signer_node.mjs') } catch (e) {}
                }
                if (!this._signer) { p.log('no signer'); return null }
                const ck = await this._ckFull(user)
                if (!ck) { p.log('no ck'); return null }
                const signed = this._signer.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'wegame-hub', client: 'android', clientVersion: '15.10.50'}, appId: '730a6', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('platform', '3')
                f.append('loginType', '2')
                f.append('loginWQBiz', 'wegame')
                const post = f.toString()
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    const s = this._h2()
                    if (!s) return fin(null)
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE, 'x-referer-page': PAGE, 'x-rp-client': 'h5_2.4.0', 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
                p.log(fn + ' 空响应, 第' + k + '次...')
            } catch (e) {
                p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100))
            }
            await this.wait(5000 * k)
        }
        return null
    }

    async main(p) {
        const user = p.data.user
        const r = await this.call(p, user, 'weGameHome', {envType: 1, linkId: LK, babelChannel: 'ttt2'})
        const sm = ((r || {}).data || {}).signMainVo || {}
        const sl = ((r || {}).data || {}).signListVo || []
        const cs = Number(sm.currentStatus || 0)
        const markStr = sm.markStr || ''
        const today = sl.find(d => Number(d.todayFlag) === 1)
        p.log('小游戏签到: 连签', sm.signDays, '天 | 今日', today ? '第' + today.currentDay + '天(' + today.rewardName + ')' : '?', '| 状态', cs, sm.buttonText || '')
        if (cs === 1) {
            const lr = await this.call(p, user, 'weGameLottery', {envType: 1, linkId: LK, status: 1, markStr})
            const code = String((lr || {}).code)
            p.log('签到上报:', code, String((lr || {}).errMsg || '').slice(0, 40))
            if (code === '0') {
                await this.wait(3000)
                const r2 = await this.call(p, user, 'weGameHome', {envType: 1, linkId: LK, babelChannel: 'ttt2'})
                const sm2 = ((r2 || {}).data || {}).signMainVo || {}
                p.log('复检: 连签', sm2.signDays, '天 |', sm2.buttonText || '')
            } else this._fails++
        } else if (cs === 3) {
            p.log('今日已签')
        } else {
            p.log('状态', cs, '跳过')
        }
        p.info.work = this._fails === 0
    }
}
