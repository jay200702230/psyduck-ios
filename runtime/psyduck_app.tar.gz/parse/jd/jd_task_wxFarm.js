import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'

const WF_INI = (() => {
    for (const pt of ['/ql/data/psyduck/cookie/jd.ini', '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini']) {
        try { if (fs.existsSync(pt)) return pt } catch (e) {}
    }
    return '/data/user/0/com.psyduck.jdtask/files/rt/psyduck/cookie/jd.ini'
})()
const WF_PAGE = 'https://h5.m.jd.com/pb/015686010/Bc9WX7MpCW7nW9QjZ5N3fFeJXMH/index.html'
const WF_EU = '3303461326131633', WF_FV = '2313731633939346'
// 微信农场任务面板活动池(抓包: pro.m.jd.com/mini/active/9RQKznJKT9x6SSfKcAqGhU31U1H)
const WF_LINKS = ['b_ob6ZUuE77kgDezYBbQKw']
const WF_APPIDS = {
    apTaskList: ['54ed7', 'activities_platform'],
    apsDoTask: ['54ed7', 'activities_platform'],
    apStartTaskTime: ['acb1e', 'activity_platform_se'],
    apTaskDrawAward: ['f0f3f', 'activities_platform'],
    farm_water: ['28981', 'signed_farm_mp'],
    farm_home: ['c57f6', 'signed_farm_mp']
}

export class Main extends Template {
    constructor() {
        super()
        this.profile = {
            title: '京东微信农场',
            crontab: 3,
            headers: {
                'user-agent': 'wechat',
                'referer': 'https://h5.m.jd.com/wq/dev/RFz7fuh1jc5mfj4speLLRjb1pEQ/index.html'
            },
            delay: 500
        }
    }

    // ============ 自签名直连层(框架curl被服务端风控全拒, 与 jd_task_farmNew 同链路) ============
    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(WF_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this.wfCookie()
    }
    wfCookie() {
        if (this._wfCk && Date.now() - this._wfCkAt < 600000) return this._wfCk
        try {
            const txt = fs.readFileSync(WF_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._wfCk = guid ? guid + ';' + ck : ck; this._wfCkAt = Date.now() }
        } catch (e) {}
        return this._wfCk || ''
    }

    async wfSigner() {
        if (!this._wfSignerObj) {
            try { this._wfSignerObj = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        return this._wfSignerObj
    }

    wfEid() {
        if (this._wfEid !== undefined) return this._wfEid
        const m = this.wfCookie().match(/3AB9D23F7A4B3CSS=([^;\s]+)/)
        this._wfEid = m ? m[1] : ''
        return this._wfEid
    }

    async wfCurl(opts) {
        const signer = await this.wfSigner()
        if (!signer) return null
        const form = String(opts.form || '')
        const getv = k => { const m = form.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return null
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const t = String(Date.now())
        const base = {
            appid: getv('appid') || 'signed_farm_mp',
            client: getv('client') || 'apple', clientVersion: getv('clientVersion') || '15.1.35',
            t, body, functionId: fn, networkType: 'wifi'
        }
        const signed = signer.sign({functionId: fn, appId: (opts.algo && opts.algo.appId) || 'c57f6', ck, body, base})
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    origin: WF_PAGE, referer: WF_PAGE,
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    // 活动平台任务请求(farmNew apReq 同款, jdapp形态自签名)
    async wfApReq(p, fn, bodyObj) {
        const signer = await this.wfSigner()
        if (!signer) { p.err('签名器缺失(需 parse/jd 下 jd_signer_node.mjs/farm_sign_sdk.js/farm_wq_seed.json)'); return null }
        const cfg = WF_APPIDS[fn] || ['54ed7', 'activities_platform']
        const ck = this._ckForUser(p.data.user)
        const body = JSON.stringify(bodyObj)
        const t = String(Date.now())
        const ext = JSON.stringify({appType: 'jdapp', systemType: 'android', bigScreen: false, 'x-api-eid-token': this.wfEid(), 'wg-sdk-token': '', pageUrl: encodeURIComponent(WF_PAGE)})
        const signed = signer.sign({
            functionId: fn, appId: cfg[0], ck, body,
            base: {
                appid: cfg[1],
                client: 'android', clientVersion: '15.10.50', t, body, functionId: fn,
                platform: '3', loginType: '2', loginWQBiz: 'wegame',
                uuid: WF_EU + '-' + WF_FV, build: '102649', screen: '360*800', networkType: 'wifi',
                d_brand: 'OnePlus', d_model: 'IN2010', lang: 'zh_CN', osVersion: '13', partner: 'oppo',
                'wg-sdk-token': '', ext, eufv: '1', eu: WF_EU, fv: WF_FV, cthr: '1'
            }
        })
        delete signed.wqDefault
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const form = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: '/api?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(form), cookie: ck,
                    origin: WF_PAGE, referer: WF_PAGE,
                    'user-agent': 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
                }
            }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(JSON.parse(d)) } catch (e) { resolve(null) } }) })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(form); rq.end()
        })
    }

    wfBrief(t) {
        return {
            asg: (t.pipeExt && t.pipeExt.assignmentId) || t.assignmentId || '',
            type: String(t.taskType || ''),
            src: t.taskSourceUrl || (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].itemId) || '',
            pipeItem: (t.taskItemList && t.taskItemList[0] && t.taskItemList[0].pipeExt && t.taskItemList[0].pipeExt.itemId) || (t.pipeExt && t.pipeExt.itemId) || '',
            times: (t.taskDoTimes || 0), limit: (t.taskLimitTimes || 0),
            fin: t.taskFinished === true,
            title: String(t.taskShowTitle || t.taskTitle || '').slice(0, 14),
            tl: (t.timeLimitPeriod || 0),
            raw: t
        }
    }

    // 浇水任务: apsDoTask 直接上报即计数, 吃干了才 farm_water 补浇再报
    async wfWater(p) {
        let total = 0
        for (const LINK_ID of WF_LINKS) {
            const lr = await this.wfApReq(p, 'apTaskList', {linkId: LINK_ID})
            const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
            const wt = tasks.find(t => t.taskType === 'CUMULATIVE_TIMES' && String(t.taskShowTitle || '').includes('浇水') && (t.taskDoTimes || 0) < (t.taskLimitTimes || 0))
            if (!wt) continue
            const left = (wt.taskLimitTimes || 0) - (wt.taskDoTimes || 0)
            p.log(`[${LINK_ID.slice(0, 6)}] 浇水任务还需 ${left} 次(直接上报, 无需受理)`)
            let doneN = 0, failN = 0, rate = 0
            while (doneN < left && failN < 2 && rate < 3) {
                const dr = await this.wfApReq(p, 'apsDoTask', {taskType: 'CUMULATIVE_TIMES', taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: wt.pipeExt || {}, taskInsert: false})
                if (dr && (dr.success === true || dr.code === 0)) {
                    failN = 0
                    doneN++; total++
                    const uf = (dr.data && dr.data.userFinishedTimes) || '?', fn = (dr.data && dr.data.finishNeed) || '?'
                    p.log(`[${LINK_ID.slice(0, 6)}] 上报[${doneN}/${left}] 进度:${uf}/${fn}${dr.data && dr.data.finished ? ' [任务完成!]' : ''}`)
                    if (dr.data && dr.data.finished) break
                    await this.wait(2000)
                    continue
                }
                failN++
                const wr = await this.wfApReq(p, 'farm_water', {version: 21, channelParam: '1', waterType: 2, onlineGiftPackageFlg: true, babelChannel: 'ttt6', lbsSwitch: true})
                const bw = wr && wr.data && wr.data.result && wr.data.result.bottleWater
                if (!bw) {
                    const code = String((wr && wr.code) || (wr && wr.data && wr.data.bizCode) || '')
                    const msg = String((wr && wr.msg) || (wr && wr.data && wr.data.bizMsg) || '')
                    if (/405|火爆|稍后|频繁|繁忙/.test(code + msg)) {
                        rate++
                        p.log(`浇水限流(${msg || code}) 重试${rate}/3`)
                        await this.wait(20000)
                        continue
                    }
                    p.log(`水不足/浇水异常(${code} ${msg}), 本轮已上报${doneN}次, 攒够水滴下轮继续`)
                    break
                }
                p.log(`[${LINK_ID.slice(0, 6)}] 浇水1次(剩余:${bw}), 继续上报`)
                await this.wait(2500)
            }
            const aw = await this.wfApReq(p, 'apTaskDrawAward', {taskType: 'CUMULATIVE_TIMES', taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: wt.pipeExt || {}})
            const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
            if (awd) p.log(`[${LINK_ID.slice(0, 6)}] 浇水奖励 ${awd}`)
        }
        if (total) p.log(`本轮浇水任务共上报 ${total} 次`)
        return total
    }

    // 浏览/关注任务: 活动池遍历, apStartTaskTime 受理 → 停留 → apsDoTask 上报 → apTaskDrawAward 领奖
    async doActivityTasks(p) {
        let lastRej = 0
        try { lastRej = +(await this.getTemp('farmWvReject')) || 0 } catch (e) {}
        if (lastRej && Date.now() - lastRej < 180000) {
            p.log('农场活动任务: ' + Math.ceil((180000 - (Date.now() - lastRej)) / 60000) + '分钟前被软拒过, 本轮跳过')
            return
        }
        // GAME/PLAY_/MINI_GAME 不再跳过: AI掼蛋/斗地主类「访问即完成」可协议做, do 拒自动落补领/跳过
        const skipType = /^(CUMULATIVE_TIMES|JOIN_OTHER_ACT|ADD_WIDGET|WECHAT_SHARE|ORDER_MARK|SUBSCRIBE|WECHAT|ACCUMULATE|SHOPPING|SIGN|WATER)/
        let done = 0, fails = 0
        linkLoop: for (const LINK_ID of WF_LINKS) {
            const skipAsg = new Set()
            let guard = 0
            while (guard++ < 40) {
                const lr = await this.wfApReq(p, 'apTaskList', {linkId: LINK_ID})
                const tasks = (lr && lr.data && (Array.isArray(lr.data) ? lr.data : lr.data.taskList)) || []
                if (!tasks.length) { p.err('apTaskList 无数据: ' + JSON.stringify(lr).slice(0, 100)); continue linkLoop }
                if (guard === 1) p.log(`[${LINK_ID.slice(0, 6)}] 活动任务池 ${tasks.length} 个`)
                const cur = tasks.map(t => this.wfBrief(t)).find(b => !b.fin && !skipAsg.has(b.asg) && !skipType.test(b.type) && /^(BROWSE|FOLLOW|EXTERNAL_BROWSE|GAME|PLAY_|MINI_GAME)/.test(b.type))
                if (!cur) break
                let src = cur.src
                if (!/^FOLLOW/.test(cur.type) && /^\d+$/.test(src)) src = 'http://item.jd.com/' + src + '.html'
                const itemId = src ? encodeURIComponent(src) : encodeURIComponent(WF_PAGE)
                // pipeExt 用服务端下发的原始对象(自拼会被严格任务校验拒「没有达到做任务条件」)
                const pipeExt = (cur.raw.pipeExt && Object.keys(cur.raw.pipeExt).length) ? {...cur.raw.pipeExt} : {taskType: cur.type, assignmentId: cur.asg}
                if (cur.pipeItem && !pipeExt.itemId) pipeExt.itemId = cur.pipeItem
                const st = await this.wfApReq(p, 'apStartTaskTime', {linkId: LINK_ID, taskId: -9999, itemId, channel: 4, pipeExt})
                if (!(st && (st.success === true || st.code === 0))) {
                    // wxapp授权专属任务(领券/看视频/直播/小游戏)在jdapp形态下统一受理拒, 静默跳过
                    skipAsg.add(cur.asg); fails++
                    await this.wait(/太多|火爆|稍后|频繁/.test((st && (st.errMsg || st.msg)) || '') ? 8000 : 2000)
                    continue
                }
                await this.wait((cur.tl > 0 ? cur.tl : 10) * 1000 + 1500)
                const dr = await this.wfApReq(p, 'apsDoTask', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt, itemId})
                if (!(dr && (dr.success === true || dr.code === 0))) {
                    const dm = (dr && (dr.errMsg || dr.msg)) || JSON.stringify(dr).slice(0, 60)
                    p.log(`[${cur.title}] do拒: ` + dm)
                    // 「任务已完成」「没有达到做任务条件」不跳过: 微信/App内真实完成的任务 do 上报会被拒, 落 drawAward 直接补领
                    if (!/已完成|没有达到做任务条件/.test(dm)) {
                        skipAsg.add(cur.asg); fails++
                        await this.wait(3000)
                        continue
                    }
                    await this.wait(1500)
                } else {
                    await this.wait(2000 + Math.floor(Math.random() * 2000))
                }
                const aw = await this.wfApReq(p, 'apTaskDrawAward', {taskType: cur.type, taskId: -9999, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt})
                const awd = aw && Array.isArray(aw.data) ? aw.data.map(k => '+' + k.awardGivenNumber + (k.awardTitle || k.awardName || '')).join(',') : ''
                if (awd) { done++; p.log(`[${cur.title}] ${awd}`) }
                else {
                    p.log(`[${cur.title}] 领奖: ` + ((aw && (aw.errMsg || aw.msg)) || JSON.stringify(aw).slice(0, 60)))
                    if (aw && aw.success === true) done++
                    else skipAsg.add(cur.asg)
                }
                await this.wait(3000 + Math.floor(Math.random() * 3000))
            }
        }
        await this.wfWater(p)
        // 收尾扫荡: 全池补领悬赏(前轮做完没领/领奖失败的 canDrawAwardNum>0)
        try {
            for (const LINK_ID of WF_LINKS) {
                const lr2 = await this.wfApReq(p, 'apTaskList', {linkId: LINK_ID})
                const ts2 = (lr2 && lr2.data && (Array.isArray(lr2.data) ? lr2.data : lr2.data.taskList)) || []
                for (const t2 of ts2) {
                    if (!t2.canDrawAwardNum) continue
                    const pe2 = t2.pipeExt || {}
                    for (let k = 0; k < t2.canDrawAwardNum; k++) {
                        const aw2 = await this.wfApReq(p, 'apTaskDrawAward', {taskType: t2.taskType, taskId: t2.id === undefined ? -9999 : t2.id, channel: 4, checkVersion: true, linkId: LINK_ID, pipeExt: pe2})
                        const awd2 = aw2 && Array.isArray(aw2.data) ? aw2.data.map(x => '+' + x.awardGivenNumber + (x.awardTitle || x.awardName || '')).join(',') : ''
                        if (awd2) { done++; p.log(`[补领][${String(t2.taskShowTitle || t2.taskTitle || '').slice(0, 14)}] ${awd2}`) }
                        await this.wait(1500)
                    }
                }
            }
        } catch (e) { p.log('补领异常 ' + e) }
        const hm = await this.wfApReq(p, 'farm_home', {version: 21, channelParam: '1'})
        const bw = hm && hm.data && hm.data.result && hm.data.result.bottleWater
        p.log(`活动任务: 浏览完成${done} 微信端专属跳过${fails} 水滴余额: ${bw === undefined ? '?' : bw}`)
        if (fails) p.log(`(其余 ${fails} 个为领券/看视频/直播/小游戏类, 须微信小程序内真实交互, 脚本无法代做)`)
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let st = 1
        // miniTask_queryFarmSignList/doFarmSign (hot_channel) 已废弃, 服务端返回 no access; 换 dongDongFarmSignIn (活动平台签到, 与主农场同款)
        let sign = await this.wfCurl({
                'url': `https://api.m.jd.com/api?functionId=dongDongFarmSignIn`,
                'form': `functionId=dongDongFarmSignIn&body={"linkId":"LCH-fV7hSnChB-6i5f4ayw"}&t=1740546479554&appid=activities_platform&client=ios&clientVersion=15.0.20&build=169736&screen=390*844&networkType=wifi&d_brand=iPhone&d_model=iPhone13,3&lang=zh_CN&osVersion=15.1.1&partner=-1&cthr=1`,
                user,
                algo: {
                    appId: '65f9d'
                }
            }
        )
        if (this.haskey(sign, 'success')) {
            p.log(`签到成功: ${JSON.stringify(sign.data || {}).slice(0, 100)}`)
        }
        else if (String(sign && sign.errMsg || '').includes('已签到') || String(sign && sign.code) === '16510') {
            p.log("今日已签到..")
        }
        else {
            p.log("签到返回:", sign ? JSON.stringify(sign).slice(0, 150) : '空响应')
            st = 0
        }
        let taskList = await this.wfCurl({
                'url': `https://api.m.jd.com/client.action`,
                'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739972758582&body={"version":9,"channelParam":"2","channel":0,"pushSwitch":false,"showSubscribe":false,"babelChannel":"ttt1"}&functionId=farm_task_list`,
                user,
                algo: {
                    appId: 'c57f6'
                }
            }
        )
        let list = this.haskey(taskList, 'data.result.taskList')
        if (!list) {
            p.err("没有获取到任务列表...", taskList ? JSON.stringify(taskList).slice(0, 150) : '')
        }
        else {
            let status = 1
            // 按 taskType 跳过: 标题含"下单"的可能是 BROWSE_CHANNEL 浏览任务(如"京东秒杀 下单返京豆"), 不能按标题跳
            const skipRe = /^(ORDER_MARK|SHOPPING|ADD_WIDGET|WECHAT|SUBSCRIBE|JOIN_OTHER_ACT|GAME|PLAY_|MINI_GAME|SIGN$|ACCUMULATE)/
            for (let i of list) {
                if (skipRe.test(i.taskType)) {
                    p.log("跳过(需真实交互):", i.mainTitle, i.taskType)
                }
                else if (i.taskDoTimes != i.taskLimitTimes) {
                    p.log("正在运行:", i.mainTitle)
                    if (i.mainTitle.includes("浇水")) {
                        if (i.taskDoTimes != i.taskLimitTimes) {
                            status = 0
                            for (let j of Array(Math.ceil((i.taskLimitTimes - i.taskDoTimes) / 4))) {
                                let water = await this.wfCurl({
                                        'url': `https://api.m.jd.com/client.action`,
                                        'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739982505593&body={"version":9,"channelParam":"2","waterType":2,"babelChannel":"ttt1"}&functionId=farm_water`,
                                        user,
                                        algo: {
                                            appId: '28981'
                                        }
                                    }
                                )
                                if (this.haskey(water, 'data.result.bottleWater')) {
                                    status = 1
                                    p.log("浇水成功....")
                                }
                                else {
                                    status = 0
                                    p.log("浇水失败...")
                                    break
                                }
                                await this.wait(1000)
                            }
                            if (status) {
                                let award = await this.wfCurl({
                                        'url': `https://api.m.jd.com/client.action`,
                                        'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739981615997&body={"version":9,"channelParam":"2","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_receive_award`,
                                        user,
                                        algo: {
                                            appId: '33e0f'
                                        }
                                    }
                                )
                                if (this.haskey(award, 'data.result.taskAward')) {
                                    p.log(award.data.result.taskAward)
                                }
                                else {
                                    p.log("领取奖励失败", award)
                                }
                            }
                        }
                    }
                    else {
                        if (i.taskSourceUrl) {
                            var doTask = await this.wfCurl({
                                    'url': `https://api.m.jd.com/client.action`,
                                    'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739973082105&body={"version":9,"channelParam":"2","taskType":"${i.taskType}","taskId":${i.taskId},"taskInsert":false,"itemId":"${new Buffer.from(i.taskSourceUrl, 'utf-8').toString('base64')}","channel":0}&functionId=farm_do_task`,
                                    user,
                                    algo: {
                                        appId: '28981'
                                    }
                                }
                            )
                        }
                        else if (i.pipeExt) {
                            let detail = await this.wfCurl({
                                    'url': `https://api.m.jd.com/client.action`,
                                    'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739978261715&body={"version":9,"channelParam":"2","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_detail`,
                                    user,
                                    algo: {
                                        appId: 'c57f6'
                                    }
                                }
                            )
                            var doTask = await this.wfCurl({
                                    'url': `https://api.m.jd.com/client.action`,
                                    'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739978263580&body={"version":9,"channelParam":"2","taskType":"${i.taskType}","taskId":${i.taskId},"taskInsert":false,"itemId":"${new Buffer.from(this.haskey(detail, 'data.result.taskDetaiList.0.itemId'), 'utf-8').toString('base64')}","channel":0}&functionId=farm_do_task`,
                                    user,
                                    algo: {
                                        appId: '28981'
                                    }
                                }
                            )
                        }
                        if (this.haskey(doTask, 'data.success')) {
                            p.log("任务完成...")
                            status = 1
                            let award = await this.wfCurl({
                                    'url': `https://api.m.jd.com/client.action`,
                                    'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739981615997&body={"version":9,"channelParam":"2","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_receive_award`,
                                    user,
                                    algo: {
                                        appId: '33e0f'
                                    }
                                }
                            )
                            if (this.haskey(award, 'data.result.taskAward')) {
                                p.log(award.data.result.taskAward)
                            }
                            else {
                                p.log("领取奖励失败", award)
                            }
                        }
                        else {
                            status = 0
                            p.log("任务失败", doTask)
                        }
                        await this.wait(1000)
                    }
                }
                else if (i.taskStatus == 2) {
                    let award = await this.wfCurl({
                            'url': `https://api.m.jd.com/client.action`,
                            'form': `appid=signed_farm_mp&client=&clientVersion=1.0.0&screen=390*812&wqDefault=false&loginType=2&t=1739981615997&body={"version":9,"channelParam":"2","taskType":"${i.taskType}","taskId":${i.taskId},"channel":0}&functionId=farm_task_receive_award`,
                            user,
                            algo: {
                                appId: '33e0f'
                            }
                        }
                    )
                    if (this.haskey(award, 'data.result.taskAward')) {
                        p.log(award.data.result.taskAward)
                        status = 1
                    }
                    else {
                        p.log("领取奖励失败", award)
                        status = 0
                    }
                }
                else {
                    p.log("任务已完成:", i.mainTitle)
                }
            }
            if (status) {
                st = 1
            }
        }
        // 微信农场任务面板活动池(b_ob6ZUuE77kgDezYBbQKw): 浏览/关注/浇水任务全链路
        await this.doActivityTasks(p)
        if (st) {
            p.info.work = true
        }
    }
}
