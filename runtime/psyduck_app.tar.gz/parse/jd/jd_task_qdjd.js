import fs from 'fs'
import path from 'path'
import net from 'net'
import http2 from 'http2'
import {fileURLToPath} from 'url'
import {Template} from '../../template.js'

const PAGE = 'https://pro.m.jd.com/'
const CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')
const UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
// 频道签到池 collectionId 列表 (home/sign 按账号全局生效, collectionId 标识楼层)
const COLLS = ['1028', '2']

export class Main extends Template {
    constructor() {
        super()
        this.profile = {title: '京东频道签到', pageUrl: PAGE, headers: {referer: PAGE}, turn: 1, crontab: 3}
        this._fails = 0
        this._h2s = null
    }

    _ckForUser(u) {
        if (this._ckOverride) return this._ckOverride
        try {
            const pin = String(u || '').trim()
            if (pin && !pin.includes('pt_key=')) {
                const ov = fs.readFileSync('/ql/data/psyduck/ck_full/' + encodeURIComponent(pin) + '.txt', 'utf8').trim()
                if (ov.includes('pt_key=')) return ov
            }
        } catch (e) {}
        let txt = ''
        try { txt = fs.readFileSync(CK_INI, 'utf8') } catch (e) {}
        if (typeof u === 'string' && u && !u.includes('pt_key=') && txt) {
            let want = u
            try { want = decodeURIComponent(u) } catch (e) {}
            for (const ln of txt.split(/\r?\n/)) {
                if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                let pin = ln.match(/pt_pin=([^;\s]+)/)[1]
                try { pin = decodeURIComponent(pin) } catch (e) {}
                if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) return ln.trim()
            }
        }
        let cur = '', mainCk = '', any = ''
        for (const ln of txt.split(/\r?\n/)) {
            const m = ln.match(/^\[(.+)\]$/)
            if (m) { cur = m[1]; continue }
            if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                if (!any) any = ln.trim()
                if (cur === 'main' && !mainCk) mainCk = ln.trim()
            }
        }
        return mainCk || any || ''
    }

    // app 内 RPC cookie 通道(全量 19 字段含设备指纹)
    _rpcCk() {
        return new Promise(resolve => {
            try {
                const s = net.connect({host: '127.0.0.1', port: 28900}, () => {
                    s.write(JSON.stringify({cmd: 'cookie'}) + '\n')
                })
                let d = ''
                s.on('data', c => {
                    d += c.toString()
                    if (d.includes('\n')) {
                        try { s.end() } catch (e) {}
                        try { resolve(JSON.parse(d).cookie || '') } catch (e) { resolve('') }
                    }
                })
                s.on('error', () => resolve(''))
                setTimeout(() => { try { s.destroy() } catch (e) {}; resolve('') }, 5000)
            } catch (e) { resolve('') }
        })
    }

    async _ckFull(user) {
        const base = this._ckForUser(user)
        const rpcCk = await this._rpcCk()
        if (rpcCk && rpcCk.includes('pt_key=')) {
            const pinOf = ck => { try { let m = ck.match(/pt_pin=([^;\s]+)/); return m ? decodeURIComponent(m[1]) : '' } catch (e) { return '' } }
            let want = pinOf(base)
            const got = pinOf(rpcCk)
            if (got && (!want || got === want || 'jd_' + got === want || 'jd_' + want === got)) return rpcCk
        }
        return base
    }

    _h2() {
        if (this._h2s && !this._h2s.destroyed) return this._h2s
        try {
            this._h2s = http2.connect('https://api.m.jd.com')
            this._h2s.on('error', () => { try { this._h2s.close() } catch (e) {}; if (this._h2s) this._h2s = null })
            return this._h2s
        } catch (e) { return null }
    }

    // bean_deliverySign 族: signed_wh5_ihub + h5st 域 987dd(award 用 0cc57), rfs=0000 + bare origin 必须带
    async callG(p, user, fn, bodyObj, h5stApp) {
        for (let k = 1; k <= 2; k++) {
            try {
                if (!this._signer) { try { this._signer = await import('./jd_signer_node.mjs') } catch (e) {} }
                if (!this._signer) { p.log('no signer'); return null }
                const ck = await this._ckFull(user)
                if (!ck) return null
                const signed = this._signer.sign({functionId: fn, body: bodyObj, ck, base: {appid: 'signed_wh5_ihub', client: 'android', clientVersion: '15.10.50'}, appId: h5stApp || '987dd', slim: true})
                const f = new URLSearchParams()
                for (const kk in signed) f.append(kk, String(signed[kk]))
                f.append('rfs', '0000')
                f.append('client', 'android')
                f.append('uuid', '')
                f.append('build', '169743')
                f.append('clientVersion', '15.0.25')
                f.append('d_model', '')
                f.append('osVersion', '15.1.53')
                const post = f.toString()
                const s = this._h2()
                if (!s) return null
                const r = await new Promise(resolve => {
                    let done = false
                    const fin = v => { if (!done) { done = true; resolve(v) } }
                    let st = null
                    try {
                        st = s.request({':method': 'POST', ':path': '/api?functionId=' + fn, 'content-type': 'application/x-www-form-urlencoded; charset=UTF-8', 'content-length': String(Buffer.byteLength(post)), cookie: ck, origin: 'https://pro.m.jd.com', referer: PAGE, 'user-agent': UA})
                    } catch (e) { try { s.close() } catch (e2) {}; this._h2s = null; return fin(null) }
                    let d = ''
                    st.on('data', c => d += c)
                    st.on('end', () => { try { fin(JSON.parse(d)) } catch (e) { fin(null) } })
                    st.on('error', e => { try { s.close() } catch (e2) {}; this._h2s = null; fin(null) })
                    st.end(post)
                    setTimeout(() => { try { st.close() } catch (e2) {}; fin(null) }, 15000)
                })
                if (r) return r
            } catch (e) { p.log(fn + ' 异常: ' + String(e && e.message || e).slice(0, 100)) }
            await this.wait(3000 * k)
        }
        return null
    }

    async main(p) {
        const user = p.data.user
        // 全局签到(空body): 按账号生效, collectionId 只是楼层标识
        let home = await this.callG(p, user, 'bean_deliverySign_home', {})
        const d = home && home.data ? home.data : {}
        const btn = ((d.result || {}).signButton || {}).status
        const bubble = (((d.result || {}).bubbleList || [])[0] || {})
        p.log('home:', 'biz=' + d.bizCode, 'btn=' + btn, 'bubble=' + (bubble.text || '?') + '(' + (bubble.status ?? '') + ')', 'risk=' + ((d.result || {}).riskLevel || '?'))
        if (String((d.result || {}).signButton ? btn : '') === '2') {
            p.log('今日已签到(-2002幂等)')
        } else {
            const sg = await this.callG(p, user, 'bean_deliverySign_sign', {})
            const sd = sg && sg.data ? sg.data : {}
            const biz = sd.bizCode
            const val = sd.result ? sd.result.value : null
            if (Number(biz) === 0) {
                p.log('签到[OK]: 豆+' + val)
                if (val && Number(val) > 0) p.info.work = true
            } else if (Number(biz) === -2002) {
                p.log('签到: 已签过(-2002)')
            } else {
                p.log('签到[--]:', 'biz=' + biz, String(sd.bizMsg || '').slice(0, 40), biz === undefined ? 'raw=' + JSON.stringify(sg).slice(0, 140) : '')
                this._fails++
            }
        }
        // 连签奖(0cc57 域, 有过期机制要早跑); -4001=无可领奖励(过期/不存在), 无害不算败
        const ca = await this.callG(p, user, 'bean_deliverySign_continue_award', {}, '0cc57')
        const cd = ca && ca.data ? ca.data : {}
        const cbiz = Number(cd.bizCode)
        if (cbiz === 0 && cd.result && cd.result.value) {
            p.log('连签奖[OK]: 豆+' + cd.result.value)
            p.info.work = true
        } else if (cbiz === -4001) {
            p.log('连签奖: 无可领(-4001)')
        } else {
            p.log('连签奖:', 'biz=' + cd.bizCode, String(cd.bizMsg || '').slice(0, 40))
        }
        // 复查最终态
        const fin = await this.callG(p, user, 'bean_deliverySign_home', {})
        const fd = fin && fin.data ? fin.data : {}
        const fbtn = ((fd.result || {}).signButton || {}).status
        p.log('终态: btn=' + fbtn, Number(fbtn) === 2 ? '(已签)' : '(未签?)')
        if (Number(fbtn) !== 2) this._fails++
        if (this._fails > 0) {
            p.log('存在 ' + this._fails + ' 个失败项, 本轮不写缓存')
            p.info.work = false
        } else {
            p.info.work = true
        }
    }
}
