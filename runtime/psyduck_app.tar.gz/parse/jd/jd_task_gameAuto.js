import {Template} from '../../template.js'
import crypto from 'crypto'
import https from 'https'
import fs from 'fs'
import net from 'net'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

// 农场外链小游戏通用上报 (v4): 厂商库 + 未知 appId 自动三厂探测 + 全量领奖
// 已知链路: 螺丝=devourad gameUpV2 / 功夫=aslk2018 assignment/finish(score=20) / 箭了又箭=sm0 notify
// 每日游戏池轮换时, 新 appId 走探测: sm0 cfg / devourad gameLogin / aslk game/login, 结果写日志
export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() { super(); this.profile = {title: '农场游戏通用上报', prompt: {}, keyExpire: 7200, crontab: '30 3 * * *'} }
    async prepare() {}

    md5(v) { return crypto.createHash('md5').update(v).digest('hex') }

    // v5: JDNet 签名走 LSPosed 模块 RPC (127.0.0.1:28900), 模块调京东 App JNI getSignFromJni 真签名
    // key 轮换免疫; 模块不在线返回 null
    jdSign(fid, body) {
        return new Promise(resolve => {
            const s = net.createConnection({host: '127.0.0.1', port: 28900})
            let buf = ''
            let done = false
            const fin = v => { if (!done) { done = true; try { s.destroy() } catch (e) {} resolve(v) } }
            s.on('connect', () => s.write(JSON.stringify({fid, body}) + '\n'))
            s.on('data', d => {
                buf += d
                if (buf.includes('\n')) {
                    try { const j = JSON.parse(buf); fin(j.ok ? String(j.sign) : null) } catch (e) { fin(null) }
                }
            })
            s.on('error', () => fin(null))
            setTimeout(() => fin(null), 5000)
        })
    }

    // 运行时读最新 cookie (App 手动跑前会 refreshCookie 写回 jd.ini, 这里跟随刷新)
    freshCookie() {
        if (this._ck && Date.now() - this._ckAt < 600000) return this._ck
        try {
            const txt = fs.readFileSync(new URL('../../cookie/jd.ini', import.meta.url), 'utf8')
            let cur = '', main = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !main) main = ln.trim()
                }
            }
            const ck = main || any
            if (ck) { this._ck = ck; this._ckAt = Date.now() }
        } catch (e) {}
        return this._ck || ''
    }

    async apReq(user, fnId, bodyObj) {
        return await this.autoCurl({
            url: `https://api.m.jd.com/api?functionId=${fnId}`,
            form: `functionId=${fnId}&appid=activities_platform&client=ios&clientVersion=15.9.30&body=${this.dumps(bodyObj)}`,
            user
        })
    }

    async gencode(user, appId, hostId) {
        // iOS 指纹一次机会 (jda 风控时 no access, 快速失败进 android 兜底)
        const gc = await this.autoCurl({
            url: `https://api.m.jd.com/api?functionId=jdaGenerateLoginCode`,
            form: `functionId=jdaGenerateLoginCode&appid=activities_platform&client=ios&clientVersion=15.9.30&body=${this.dumps({app_id: appId})}`,
            user
        })
        const code = this.haskey(gc, 'data.login_code')
        if (code) return code
        return await this.gencodeAndroid(appId, hostId)
    }

    // android JDNet 签名: 优先模块 RPC 真签名, 失败回退本地 key 算法
    // 2026-10-14 JFE 新规: POST 缺 Origin/Referer 直接 302 err=40, 必须带
    // 2026-10-14 App 同款 body 必须带 host_id(游戏容器实例ID, 三游戏同值), 否则 code 被厂商判无效
    async gencodeAndroid(appId, hostId) {
        const JD_COOKIE = this.freshCookie()
        const body = JSON.stringify(hostId ? {app_id: appId, host_id: hostId} : {app_id: appId})
        // 1) 模块 RPC 真签名 (uuid 由模块注入 App 当前值, form 需带上)
        const sig = await this.jdSign('jdaGenerateLoginCode', body)
        if (sig) {
            const form = `functionId=jdaGenerateLoginCode&body=${encodeURIComponent(body)}&uuid=30d1b1a3217a399d&client=android&clientVersion=15.10.50&${sig}`
            const code = await new Promise(resolve => {
                const rq = https.request({
                    hostname: 'api.m.jd.com', path: '/client.action?functionId=jdaGenerateLoginCode', method: 'POST',
                    headers: {
                        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                        'content-length': Buffer.byteLength(form),
                        cookie: JD_COOKIE,
                        origin: 'https://pro.m.jd.com',
                        referer: 'https://pro.m.jd.com/',
                        'user-agent': 'okhttp/3.12.6;jdmall;android;version/15.10.50;build/102649;'
                    }
                }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(this.haskey(JSON.parse(d), 'data.login_code')) } catch { resolve(null) } }) })
                rq.on('error', () => resolve(null))
                rq.setTimeout(12000, () => { rq.destroy(); resolve(null) })
                rq.write(form); rq.end()
            })
            if (code) return code
        }
        // 2) 回退: 本地 key 算法 (key 轮换后通常失效, 保底)
        const UUID = '3303461326131633-2313731633939346'
        const KEYS = ['44e715a6e322ccb7d028f7a42fa55040', '7d0069660c9b5d32074facf37c3738a1', '80306f4370b39fd5630ad0529f77adb6']
        const CTAB = Buffer.from([0x37, 0x92, 0x44, 0x68, 0xa5, 0x3d, 0xcc, 0x7f, 0xbb, 0x0f, 0xd9, 0x88, 0xee, 0x9a, 0xe9, 0x5a])
        const ORDER = [0, 2, 1]
        for (let i = 0; i < 6; i++) {
            try {
                const ki = ORDER[i % 3]
                const body = JSON.stringify({app_id: appId})
                const st = String(Date.now())
                const plain = `functionId=jdaGenerateLoginCode&body=${body}&uuid=${UUID}&client=android&clientVersion=15.10.50&st=${st}&sv=120`
                const K = Buffer.from(KEYS[ki].slice(0, 8), 'ascii')
                const raw = Buffer.from(plain, 'utf8')
                const out = Buffer.alloc(raw.length)
                for (let j = 0; j < raw.length; j++) {
                    const C = CTAB[j & 0xf]
                    out[j] = ((((C ^ raw[j] ^ K[j & 7]) + C) & 0xff) ^ C) ^ K[j & 7]
                }
                const b64 = out.toString('base64')
                const md5hex = this.md5(b64)
                const form = `functionId=jdaGenerateLoginCode&body=${encodeURIComponent(body)}&uuid=${encodeURIComponent(UUID)}&client=android&clientVersion=15.10.50&st=${st}&sign=${md5hex}${'0'.repeat(32)}&sv=120`
                const code = await new Promise(resolve => {
                    const rq = https.request({
                        hostname: 'api.m.jd.com', path: '/client.action?functionId=jdaGenerateLoginCode', method: 'POST',
                        headers: {
                            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                            'content-length': Buffer.byteLength(form),
                            cookie: JD_COOKIE,
                            origin: 'https://pro.m.jd.com',
                            referer: 'https://pro.m.jd.com/',
                            'user-agent': 'okhttp/3.12.6;jdmall;android;version/15.10.50;build/102649;'
                        }
                    }, rs => { let d = ''; rs.on('data', c => d += c); rs.on('end', () => { try { resolve(this.haskey(JSON.parse(d), 'data.login_code')) } catch { resolve(null) } }) })
                    rq.on('error', () => resolve(null))
                    rq.setTimeout(12000, () => { rq.destroy(); resolve(null) })
                    rq.write(form); rq.end()
                })
                if (code) return code
            } catch (e) {}
            await this.wait(1500)
        }
        return null
    }

    jsonPost(user, url, obj, headers = {}) {
        return this.autoCurl(Object.assign({url, form: this.dumps(obj), 'content-type': 'application/json', user}, headers))
    }

    // ===== 厂商链路 =====
    // devour appkey 每游戏独立 (2026-10-26 从容器缓存包 JS 挖出: sign=md5(appid+appKey))
    async devour(user, g) {
        const KEYS = {
            'DB1F2AD16FBA4761977E8F9C39F2A612': 'bc4c0885b6f7bc94987296fb6500a8ac',
            'F507900C3BB6508C73FA3EB9FA620AF3': 'c107f18820ff60334a000a79c608e535',
        }
        const DEVOUR_APPKEY = KEYS[g.appId] || 'bc4c0885b6f7bc94987296fb6500a8ac'
        const gameLogin = code => this.jsonPost(user, 'https://api.devourad.com/Jd/gameLogin', {code, appid: g.appId, sign: this.md5(g.appId + DEVOUR_APPKEY)})
        let code = await this.gencode(user, g.appId, g.hostId)
        if (!code) return 'devour gencode失败'
        let login = await gameLogin(code)
        const xid = this.haskey(login, 'data.xId')
        if (!xid) return 'devour gameLogin失败 ' + JSON.stringify(login).slice(0, 150)
        // 2026-10-26: gameUpV2 连击打穿累计门槛(智商乐 200 怪=30 连 fin false→true); devour 不校验 actionType, 门槛=累计次数
        let upLast = ''
        for (let i = 0; i < 12; i++) {
            const assignmentParams = encodeURIComponent(JSON.stringify({assignmentToken: g.token, encryptAssignmentId: g.encId, assignmentActionType: 100011}))
            const up = await this.jsonPost(user, 'https://api.devourad.com/Jd/gameUpV2', {appid: g.appId, sign: this.md5(g.appId + DEVOUR_APPKEY), assignmentParams, xid})
            upLast = JSON.stringify(up).slice(0, 120)
            if (!upLast.includes('成功')) break
            await this.wait(2000)
        }
        return `devour up连击 ${upLast}`
    }

    async kungfu(user, g) {
        const code = await this.gencode(user, g.appId, g.hostId)
        if (!code) return 'kungfu gencode失败'
        const reqId = () => Date.now() + '_' + Math.ceil(Math.random() * 1000)
        const login = await this.jsonPost(user, 'https://gamesapi2.aslk2018.com/v2/game/login', {
            v: '1.0.1', version: '1.0.1', reqId: reqId(), gid: g.gid || 'jd_zjsgf', errMsg: 'login:ok', code, pf: 'jd', scene: g.scene || '4-00-fexhx4',
            ad_param: {advertiser_id: '', channel: '', ad_id: '', creative_id: '', group_id: '', request_id: '', appId: g.appId}
        }, {'user-agent': 'JD4iPhone/170394 (iPhone; iOS 16.3; Scale/3.00)'})
        const uid = this.haskey(login, 'data.user_id')
        const tk = this.haskey(login, 'data.token')
        if (!uid || !tk) return 'kungfu login失败 ' + JSON.stringify(login).slice(0, 120)
        const fin = await this.jsonPost(user, 'https://gamesapi2.aslk2018.com/v2/jingdong/assignment/finish', {
            v: '1.0.1', version: '1.0.1', reqId: reqId(), gid: g.gid || 'jd_zjsgf', uid, assignmentToken: g.token, actionType: '100011', score: String(g.score || 20), encryptAssignmentId: g.encId
        }, {headers: {authorization: tk}, 'user-agent': 'JD4iPhone/170394 (iPhone; iOS 16.3; Scale/3.00)'})
        return `kungfu finish ${JSON.stringify(fin).slice(0, 120)}`
    }

    // sm0 体系(箭了又箭): gencode → code2openid 换 xid → notify 上报
    // 2026-10-26: notify 连击 5 次可打穿「累计门槛」(1709→103), 单次上报不够
    async sm0(user, g) {
        const code = await this.gencode(user, g.appId, g.hostId)
        if (!code) return 'sm0 gencode失败'
        const c2o = await this.jsonPost(user, 'https://api.sm0.fun/v2/code2openid', {code, appid: g.appId})
        const xid = this.haskey(c2o, 'data.data.xid') || this.haskey(c2o, 'data.data.data')
        if (!xid) return 'sm0 code2openid失败 ' + JSON.stringify(c2o).slice(0, 120)
        let last = ''
        for (let i = 0; i < 5; i++) {
            const nf = await this.jsonPost(user, 'https://api.sm0.fun/v2/jd/notify', {assignmentToken: g.token, xid_buyer: xid, actiontype: '100011', activityId: g.appId})
            last = (JSON.stringify(nf) || String(nf)).slice(0, 140)
            if (last.includes('"103"') || last.includes('任务已完成')) return `sm0 notify 第${i + 1}次达标 ${last}`
            await this.wait(3000)
        }
        return `sm0 notify ${last}`
    }

    // 毛线拆个爽: aslk 系 (gid=jd_mxcgs), 每日通关1关 → score=1
    async yarn(user, g) {
        const code = await this.gencode(user, g.appId, g.hostId)
        if (!code) return 'yarn gencode失败'
        const reqId = () => Date.now() + '_' + Math.ceil(Math.random() * 1000)
        const login = await this.jsonPost(user, 'https://gamesapi2.aslk2018.com/v2/game/login', {
            v: '1.0.1', version: '1.0.1', reqId: reqId(), gid: 'jd_mxcgs', errMsg: 'login:ok', code, pf: 'jd', scene: '4-00-fexhx4',
            ad_param: {advertiser_id: '', channel: '', ad_id: '', creative_id: '', group_id: '', request_id: '', appId: g.appId}
        }, {'user-agent': 'JD4iPhone/170394 (iPhone; iOS 16.3; Scale/3.00)'})
        const uid = this.haskey(login, 'data.user_id')
        const tk = this.haskey(login, 'data.token')
        if (!uid || !tk) return 'yarn login失败 ' + JSON.stringify(login).slice(0, 120)
        const fin = await this.jsonPost(user, 'https://gamesapi2.aslk2018.com/v2/jingdong/assignment/finish', {
            v: '1.0.1', version: '1.0.1', reqId: reqId(), gid: 'jd_mxcgs', uid, assignmentToken: g.token, actionType: '100011', score: String(g.score || 1), encryptAssignmentId: g.encId
        }, {headers: {authorization: tk}, 'user-agent': 'JD4iPhone/170394 (iPhone; iOS 16.3; Scale/3.00)'})
        return `yarn finish ${JSON.stringify(fin).slice(0, 120)}`
    }

    // JDGames 统一体系(游娱司 apix.yyggames4jd.com): gencode → auth/login → assignment/finish
    // 2026-10-26 从枪手请就位容器包逆向, 实割 3 游戏(枪手/水果/解压毛线); appKey=容器appId 本身
    async jdgames(user, g) {
        const code = await this.gencode(user, g.appId, g.hostId)
        if (!code) return 'jdgames gencode失败'
        const login = await this.jsonPost(user, 'https://apix.yyggames4jd.com/auth/login', {code, appKey: g.appId, api_access_token: false, api_wx_user_info: false})
        const token = login && (login.accessToken || (login.data && login.data.accessToken))
        if (!token) return 'jdgames login失败 ' + JSON.stringify(login).slice(0, 120)
        const fin = await this.jsonPost(user, 'https://apix.yyggames4jd.com/assignment/finish', {score: 20, assignmentToken: g.token, encryptAssignmentId: g.encId, actionType: 100011}, {headers: {authorization: 'Bearer ' + token}})
        return `jdgames finish ${JSON.stringify(fin).slice(0, 120)}`
    }

    // ===== 未知 appId 三厂探测 =====
    async probe(user, g) {
        const out = []
        // 1) sm0 体系: 公开配置接口
        const cfg = await this.autoCurl({url: `https://api.sm0.fun/v2/cfg/${g.appId}/1/`, user})
        const cfgStr = JSON.stringify(cfg)
        if (cfgStr && !/404|不存在|not found/i.test(cfgStr.slice(0, 200))) out.push('sm0cfg命中 ' + cfgStr.slice(0, 150))
        else out.push('sm0cfg无 ' + cfgStr.slice(0, 80))
        // 2) devourad 体系: 假 code 探 gameLogin 报错特征
        const dv = await this.jsonPost(user, 'https://api.devourad.com/Jd/gameLogin', {code: 'probe_probe', appid: g.appId, sign: this.md5(g.appId + 'bc4c0885b6f7bc94987296fb6500a8ac')})
        const dvStr = JSON.stringify(dv).slice(0, 150)
        out.push(/不存在|app.*not|invalid appid/i.test(dvStr) ? 'devour非此体系' : 'devour疑似命中 ' + dvStr)
        // 3) aslk 体系: 假 code 探 game/login
        const aslk = await this.jsonPost(user, 'https://gamesapi2.aslk2018.com/v2/game/login', {
            v: '1.0.1', version: '1.0.1', reqId: Date.now() + '_1', gid: 'jd_probe', errMsg: 'login:ok', code: 'probe_probe', pf: 'jd', scene: '4-00-fexhx4',
            ad_param: {advertiser_id: '', channel: '', ad_id: '', creative_id: '', group_id: '', request_id: '', appId: g.appId}
        }, {'user-agent': 'JD4iPhone/170394 (iPhone; iOS 16.3; Scale/3.00)'})
        const aslkStr = JSON.stringify(aslk).slice(0, 150)
        out.push(/gid|游戏不存在|invalid/i.test(aslkStr) && !/code/.test(aslkStr) ? 'aslk非此体系' : 'aslk疑似命中 ' + aslkStr)
        return 'PROBE ' + out.join(' || ')
    }

    // 容器受理上报 (v6): App 点开游戏时 native 发 jdaInfos(type=201) 携 assignmentParams 绑定任务
    // 厂商 finish 核销时京东查此受理状态, 缺失报「浏览任务未领取」; apStartTaskTime 已废弃(App 不调用)
    async jdaAccept(user, g) {
        const ap = encodeURIComponent(JSON.stringify({assignmentToken: g.token, encryptAssignmentId: g.encId, assignmentActionType: 100011}))
        const body = JSON.stringify({app_id: g.appId, host_id: g.hostId, lazy: '1', param: JSON.stringify({assignmentParams: ap}), scene: '4-00-fexhx4', supportSub: 2, type: '201'})
        const sig = await this.jdSign('jdaInfos', body)
        if (!sig) return 'jdaAccept 签名失败'
        const form = `functionId=jdaInfos&body=${encodeURIComponent(body)}&uuid=30d1b1a3217a399d&client=android&clientVersion=15.10.50&scval=${g.appId}&${sig}`
        const r = await this.autoCurl({
            url: 'https://api.m.jd.com/client.action?functionId=jdaInfos',
            form,
            headers: {origin: 'https://pro.m.jd.com', referer: 'https://pro.m.jd.com/'},
            user
        })
        return `jdaAccept ${JSON.stringify(r).slice(0, 150)}`
    }

    async main(p) {
        let user = p.data.user
        let LINK = 'fWWo3YmB983abNOJPR7veg'
        // appId → handler 映射 (新游戏逆向后在此登记; hostId=游戏容器实例ID, 当前三游戏同值)
        const HOST_ID = 'jd00e7c795ae0f4648'
        const KNOWN = {
            'DB1F2AD16FBA4761977E8F9C39F2A612': {name: '打个螺丝', handler: 'devour'},
            'D2F7F3520186AED3075F26CA0BFF93CE': {name: '这就是功夫', handler: 'kungfu'},
            '06D914897564A06549837966840E609F': {name: '箭了又箭', handler: 'sm0'},
            '4DC1FAEC25ECEA83757C2A973501DF75': {name: '毛线拆个爽', handler: 'yarn'},
            // 2026-10-26 xI6b0R 21游戏池新增 (gid 由 scan6 字典暴力命中 / devour key+JDGames 由缓存包逆向)
            '45EAB4611D0AF4544B1E5F95E88C31F7': {name: '玩个儿毛线', handler: 'kungfu', gid: 'jd_wgemx'},
            '81273150F445784B76102E92166F64A4': {name: '拼个图吧', handler: 'kungfu', gid: 'jd_pgtb'},
            '3849289FC106725063046F2A1562E85D': {name: '捞个菜', handler: 'kungfu', gid: 'jd_lgc'},
            '3C6CCFEB46776AB6D2069A19123FD33C': {name: '枪手请就位', handler: 'jdgames'},
            'F109F104F874A3D2DA85146E4683BF60': {name: '每日水果消一消', handler: 'jdgames'},
            '93EFDE378C9B9B58FED8D48CB9941C64': {name: '解压打毛线', handler: 'jdgames'},
            'F507900C3BB6508C73FA3EB9FA620AF3': {name: '智商乐消消', handler: 'devour'},
        }

        // 双池: 农场游戏大厅 + 首页-京东小游戏(21游戏), 同为 toOuterGame 任务
        const LINK2 = 'xI6b0R-KkhEsuN2Z8_R1Rw'
        const list = async linkId => this.haskey(await this.apReq(user, 'apTaskList', {linkId, queryType: 0, channel: 4, area: '16_1342_1357_45750'}), 'data') || []
        let tasks = (await list(LINK)).map(t => (t._lk = LINK, t))
        const tasks2 = (await list(LINK2)).map(t => (t._lk = LINK2, t))
        const seen = new Set(tasks.map(t => t.id))
        for (const t of tasks2) if (!seen.has(t.id)) tasks.push(t)
        let games = tasks.filter(i => (i.appJumpType || '') === 'toOuterGame' && i.taskLimitTimes != i.taskDoTimes)
        p.log(`未完成游戏: ${games.length}`)
        for (const g of games) {
            const title = g.taskShowTitle || g.taskTitle || ''
            let fwd = ''
            try { fwd = decodeURIComponent(g.forwardUrl || '') } catch {}
            const m = fwd.match(/"appId":"([A-F0-9]{32})"/i)
            const appId = m ? m[1].toUpperCase() : ''
            const rec = KNOWN[appId]
            const ctx = {appId, hostId: HOST_ID, token: g.assignmentToken, encId: g.pipeExt && g.pipeExt.assignmentId, gid: rec && rec.gid, taskId: g.id, lk: g._lk, encProj: g.pipeExt && g.pipeExt.encryptProjectId, taskType: g.taskType}
            p.log(`[${title}] appId=${appId.slice(0, 8)} → ${rec ? rec.handler : '未知厂探测'} tok=${(g.assignmentToken || '').slice(0, 12)}...`)
            // sendMarkInfo 进出游标记 (2026-10-26 破 107 关键前置: mark1→15s→mark2 模拟容器进出, 厂商 finish 回调才被京东认可)
            if (ctx.taskId && ctx.encId && rec) {
                const mkBody = bid => ({businessId: bid, taskId: ctx.taskId, linkId: ctx.lk, pipeExt: {taskType: ctx.taskType, encryptProjectId: ctx.encProj, assignmentId: ctx.encId}})
                const m1 = await this.apReq(user, 'sendMarkInfo', mkBody(1))
                p.log(`  mark1: ${JSON.stringify(m1).slice(0, 80)}`)
                await this.wait(15000)
                const m2 = await this.apReq(user, 'sendMarkInfo', mkBody(2))
                p.log(`  mark2: ${JSON.stringify(m2).slice(0, 80)}`)
                await this.wait(2000)
            }
            // 京东侧受理: 容器上报 jdaInfos(type=201), 缺此步厂商 finish 报「浏览任务未领取」
            const acc = await this.jdaAccept(user, ctx)
            p.log(`  受理: ${acc}`)
            await this.wait(2000)
            let out = '跳过'
            try {
                if (rec && rec.handler === 'devour') out = await this.devour(user, ctx)
                else if (rec && rec.handler === 'kungfu') out = await this.kungfu(user, ctx)
                else if (rec && rec.handler === 'sm0') out = await this.sm0(user, ctx)
                else if (rec && rec.handler === 'yarn') out = await this.yarn(user, ctx)
                else if (rec && rec.handler === 'jdgames') out = await this.jdgames(user, ctx)
                else if (appId) out = await this.probe(user, ctx)
            } catch (e) { out = '异常 ' + e.message }
            p.log(`  → ${out}`)
            await this.wait(3000)
        }

        // 全量领奖 (跑两轮: 上报核销后任务可能延迟数秒才回池, 首轮扫不到, 2026-10-14 箭了又箭实测)
        for (let round = 0; round < 2; round++) {
            if (round) await this.wait(8000)
            const all = (await list(LINK)).concat(await list(LINK2))
            let drew = 0
            for (const t of all) {
                if (!t.canDrawAwardNum) continue
                const a = await this.apReq(user, 'apTaskDrawAward', {taskType: t.taskType, taskId: t.id === undefined ? -9999 : t.id, channel: 4, checkVersion: true, linkId: t._lk || LINK, pipeExt: t.pipeExt || {}})
                p.log(`领奖[${(t.taskShowTitle || t.taskTitle || '').slice(0, 14)}] code=${a && a.code} ${JSON.stringify(a && a.data || '').slice(0, 80)}`)
                if (a && String(a.code) === '0') drew++
                await this.wait(2000)
            }
            if (!drew) break
        }
        p.info.work = true
    }
}
