import {Template} from '../../template.js'
import https from 'https'
import fs from 'fs'
import path from 'path'
import {fileURLToPath} from 'url'

const AC_PAGE = 'https://pro.m.jd.com/'
const AC_UA = 'Mozilla/5.0 (Linux; Android 13; IN2010 Build/RKQ1.211119.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36'
const AC_CK_INI = path.join(path.dirname(fileURLToPath(import.meta.url)), '../../cookie/jd.ini')

export class Main extends Template {

    // 框架实例无 fwCookie(那是 farmNew 的实例方法), 自读 cookie/jd.ini (main优先 + guid, 10分钟缓存)
    _acCk() {
        if (this._ckCache && Date.now() - this._ckAt < 600000) return this._ckCache
        try {
            const txt = fs.readFileSync(AC_CK_INI, 'utf8')
            let cur = '', mainCk = '', any = ''
            for (const ln of txt.split(/\r?\n/)) {
                const m = ln.match(/^\[(.+)\]$/)
                if (m) { cur = m[1]; continue }
                if (ln.includes('pt_key=') && ln.includes('pt_pin=')) {
                    if (!any) any = ln.trim()
                    if (cur === 'main' && !mainCk) mainCk = ln.trim()
                }
            }
            const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
            const ck = mainCk || any
            if (ck) { this._ckCache = guid ? guid + ';' + ck : ck; this._ckAt = Date.now() }
        } catch (e) { }
        return this._ckCache || ''
    }

    _ckForUser(u) {
        if (typeof u === 'string' && u && u.indexOf('pt_key=') < 0) {
            let txt = ''
            try { txt = fs.readFileSync(AC_CK_INI, 'utf8') } catch (e) { }
            if (txt) {
                const guid = (txt.match(/guid=([^;\n]+)/) || ['', ''])[1]
                let want = u
                try { want = decodeURIComponent(u) } catch (e) { }
                for (const ln of txt.split(/\r?\n/)) {
                    if (!ln.includes('pt_key=') || !ln.includes('pt_pin=')) continue
                    const m = ln.match(/pt_pin=([^;]+)/)
                    if (!m) continue
                    let pin = m[1]
                    try { pin = decodeURIComponent(pin) } catch (e) { }
                    if (pin === want || pin === 'jd_' + want || 'jd_' + pin === want) {
                        return guid ? guid + ';' + ln.trim() : ln.trim()
                    }
                }
            }
        }
        return this._acCk()
    }
    // 框架curl链路对api.m.jd.com被风控, 改 h5st 自签名直连 (同 scratchBean 模式)
    // 兼容 form 型与 client.action 型(body 在 URL query), 非 api 域请求回退框架 curl
    async autoCurl(opts) {
        const form = opts && opts.form
        const u = String((opts && opts.url) || '')
        if (!(form || u.includes('api.m.jd.com'))) return await this.curl(opts)
        if (!this._acSigner) {
            try { this._acSigner = await import('./jd_signer_node.mjs') } catch (e) {}
        }
        if (!this._acSigner) return null
        let urlQs = ''
        let urlPath = '/api'
        try {
            const pu = new URL(u)
            urlPath = pu.pathname
            urlQs = pu.search.slice(1)
        } catch (e) { urlQs = u.includes('?') ? u.slice(u.indexOf('?') + 1) : '' }
        const pool = form ? (urlQs ? urlQs + '&' + form : String(form)) : urlQs
        const getv = k => { const m = pool.match(new RegExp('(?:^|&)' + k + '=([^&]*)')); return m ? m[1] : '' }
        const fn = getv('functionId')
        if (!fn) return await this.curl(opts)
        let body = getv('body')
        try { body = decodeURIComponent(body) } catch (e) {}
        if (!body) body = '{}'
        let bodyObj
        try { bodyObj = JSON.parse(body) } catch (e) { bodyObj = {} }
        const ck = this._ckForUser(opts.user)
        if (!ck) return null
        const signed = this._acSigner.sign({
            functionId: fn, body: bodyObj, ck,
            base: {appid: getv('appid') || 'signed_wh5', client: getv('client') || 'android', clientVersion: getv('clientVersion') || '15.10.50'}
        })
        const f = new URLSearchParams()
        for (const k in signed) f.append(k, String(signed[k]))
        const signedKeys = new Set(['functionId', 'appid', 'body', 'client', 'clientVersion', 't', 'h5st', 'networkType', 'wqDefault'])
        for (const seg of pool.split('&')) {
            const ek = seg.split('=')[0]
            if (ek && !signedKeys.has(ek) && seg.includes('=')) f.append(ek, seg.slice(ek.length + 1))
        }
        const post = f.toString()
        return new Promise(resolve => {
            const rq = https.request({
                hostname: 'api.m.jd.com', path: urlPath + '?functionId=' + fn, method: 'POST',
                headers: {
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'content-length': Buffer.byteLength(post), cookie: ck,
                    // origin 必须是裸域: bff 网关校验 origin 规范性
                    origin: 'https://pro.m.jd.com', referer: AC_PAGE, 'user-agent': AC_UA
                }
            }, rs => {
                let d = ''
                rs.on('data', c => d += c)
                rs.on('end', () => {
                    let out = null
                    try { out = JSON.parse(d) } catch (e) {
                        const jm = String(d).match(/\((\{[\s\S]*\})\)/)
                        if (jm) { try { out = JSON.parse(jm[1]) } catch (e2) {} }
                    }
                    resolve(out)
                })
            })
            rq.on('error', () => resolve(null))
            rq.setTimeout(15000, () => { rq.destroy(); resolve(null) })
            rq.write(post); rq.end()
        })
    }

    constructor() {
        super()
        this.profile = {
            title: '京东当天京豆汇总',
            crontab: `${this.rand(0, 40)} ${this.rand(21, 23)} * * *`
        }
    }

    async prepare() {
    }

    async main(p) {
        let user = p.data.user;
        let context = p.context;
        let echo
        let x = this.getDate(this.timestamp, 0, '-')
        let r = new RegExp(`${x}`)
        let xs = []
        let s = await this.autoCurl({
                'url': `https://api.m.jd.com/?appid=jd-cphdeveloper-m&functionId=myBean&body={"tenantCode":"jgminise","bizModelCode":6,"bizModeClientType":"WxMiniProgram","externalLoginType":1}&sceneval=2&g_login_type=1&callback=draw_activetemporary&g_tk=610895985&g_ty=ls`,
                user,
                algo: {
                    expire: {"code": "1001"}
                }
            }
        )
        if (typeof s != 'object' && s && s.includes("}{")) {
            s = this.jsonParse(s.split("}{")[0] + '}')
        }
        if (this.haskey(s, 'list')) {
            for (let k of this.haskey(s, 'list')) {
                if (k.createDate.includes(x)) {
                    xs.push(k)
                }
            }
            let z = [], f = []
            let d = {}
            for (let i of xs) {
                d[i.visibleInfo] = d[i.visibleInfo] || {
                    eventMassage: i.visibleInfo.replace(/参加|店铺活动|-奖励|\[|\]/g, ''),
                    amount: 0
                }
                d[i.visibleInfo].amount += parseInt(i.amount)
            }
            let dict = Object.values(d).sort(function(a, b) {
                return b.amount - a.amount
            })
            echo = [`🐹  今日总共收入: ${this.sum(this.column(dict, 'amount').filter(d => d>0)) || 0}  支出: ${this.sum(this.column(dict, 'amount').filter(d => d<0)) || 0}`]
            for (let i of dict) {
                if (parseInt(i.amount)<0) {
                    echo.push(`🐶  [${i.amount}] ${i.eventMassage}`)
                }
                else {
                    echo.push(`🦁  [${i.amount}] ${i.eventMassage}`)
                }
            }
            if (this.haskey(s, 'willExpireNum')) {
                echo.push(`🙊  [${s.willExpireNum}] 即将过期`)
            }
        }
        else {
            for (let i = 1; i<20; i++) {
                let s = await this.autoCurl({
                    "url": `https://api.m.jd.com/client.action?functionId=getJingBeanBalanceDetail`,
                    "form": `body=${escape(JSON.stringify({"pageSize": "20", "page": i.toString()}))}&appid=ld`,
                    'user': p.user
                })
                if (!this.match(r, JSON.stringify(s))) {
                    break
                }
                for (let k of s.detailList) {
                    if (k.date.includes(x)) {
                        xs.push(k)
                    }
                }
            }
            let z = [], f = []
            let d = {}
            for (let i of xs) {
                d[i.eventMassage] = d[i.eventMassage] || {
                    eventMassage: i.eventMassage.replace(/参加|店铺活动|-奖励|\[|\]/g, ''),
                    amount: 0
                }
                d[i.eventMassage].amount += parseInt(i.amount)
            }
            let dict = Object.values(d).sort(function(a, b) {
                return b.amount - a.amount
            })
            echo = [`🐹  今日总共收入: ${this.sum(this.column(dict, 'amount').filter(d => d>0)) || 0}  支出: ${this.sum(this.column(dict, 'amount').filter(d => d<0)) || 0}`]
            for (let i of dict) {
                if (parseInt(i.amount)<0) {
                    echo.push(`🐶  [${i.amount}] ${i.eventMassage}`)
                }
                else {
                    echo.push(`🦁  [${i.amount}] ${i.eventMassage}`)
                }
            }
            let jbd = await this.autoCurl({
                    'url': `https://api.m.jd.com/client.action`,
                    'form': `functionId=jingBeanDetail&body={"pageSize":20,"pageNo":1}&appid=ld&client=apple&clientVersion=12.3.1`,
                    user,
                    algo: {
                        sign: true
                    }
                }
            )
            if (this.haskey(jbd, 'others.jingBeanExpire.title')) {
                let expire = this.match(/有(\d+)个/, jbd.others.jingBeanExpire.title)
                if (expire) {
                    echo.push(`🙊  [${expire}] 即将过期`)
                }
            }
        }
        p.msg(echo.join("\n"))
    }

    getDate(date, day, join = '-') {
        var dd = new Date(date);
        dd.setDate(dd.getDate() + day);
        var y = dd.getFullYear();
        var m = dd.getMonth() + 1<10 ? "0" + (dd.getMonth() + 1) : dd.getMonth() + 1;
        var d = dd.getDate()<10 ? "0" + dd.getDate() : dd.getDate();
        return y + join + m + join + d;
    }

    sum(array, n = 0) {
        let sum = eval(array.join("+"))
        if (n) {
            sum = sum.toFixed(n)
        }
        return sum
    }
}

